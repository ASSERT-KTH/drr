import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.6" + "'", str3.equals("1.6"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION", (double) 8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "100", charSequence1, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("11b-08.42", (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java Virtual Machine SpecificationJava Virtual Ma1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Vi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("10410410", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                       ORACLE CORPORATION                                        ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean9 = javaVersion6.atLeast(javaVersion8);
        boolean boolean10 = javaVersion3.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean12 = javaVersion8.atLeast(javaVersion11);
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        java.lang.String str14 = javaVersion11.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0.9" + "'", str14.equals("0.9"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8", 21, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8" + "'", str3.equals("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "/", (java.lang.CharSequence) "1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/" + "'", charSequence2.equals("/"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION", "", "10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.10                                                                                                  ");
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("9740");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9740.0f + "'", float1.equals(9740.0f));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        long[] longArray6 = new long[] { 32L, 32L, (short) 0, 35, 52L, 35 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 378, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                                                                                                                                      " + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                                                                                                                                      "));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10410410041MAC os x", charArray11);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray11, '4');
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "h", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "oracle corporation-1.0a10.0a0.0a0.0ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONn-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "#4#4#4#4a44" + "'", str15.equals("#4#4#4#4a44"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#100                                                                                             ", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhC.4", "10 1 1 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhC.4" + "'", str2.equals("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhC.4"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Oracle Corporation");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("MAC OS X", strArray4, strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0aSUN.AWT.cgRAPHICSeNVIRONMENT0", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "MAC OS X" + "'", str7.equals("MAC OS X"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 17 + "'", int8 == 17);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Ur/rrUrM/Ur/rrUr/Ur/rrUrc/Ur/rrUr /Ur/rrUrO/Ur/rrUrS/Ur/rrUr /Ur/rrUrX/Ur/rrUr", 52, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Ur/rrUrM/Ur/rrUr/Ur/rrUrc/Ur/rrUr /Ur/rrUrO/Ur/rrUrS/Ur/rrUr /Ur/rrUrX/Ur/rrUr" + "'", str3.equals("/Ur/rrUrM/Ur/rrUr/Ur/rrUrc/Ur/rrUr /Ur/rrUrO/Ur/rrUrS/Ur/rrUr /Ur/rrUrX/Ur/rrUr"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ", "1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ" + "'", str2.equals("1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x4864_4644sun4.4awt4.4CG4raphics4E4nvironment", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", charSequence2.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("SUN.LWAWT.MACOSX.cpRINTE");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("410410041", "tionacle CorporaOr");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sunalwawtamacosxacprinterjob");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.0", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0                         " + "'", str2.equals("1.0                         "));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "100 10 -1 -1 100", "ORACLECORPORATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java Virtual Machine SpecificationJava Virtual Ma1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("01#001#001#001#001#001#001#001#", 14.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 14.0f + "'", float2 == 14.0f);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("86", "SUN.LWAWT.MACOSX.cpRINTERjOB       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "86" + "'", str2.equals("86"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "0 10", (java.lang.CharSequence) "            10 10 100 1            ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "0 10" + "'", charSequence2.equals("0 10"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0a100.0" + "'", str1.equals("1.0a100.0"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C", "", "rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59");
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("7", "rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 378, 14);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "7rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str4.equals("7rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.7.0_80100", 6, 378);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "80100" + "'", str3.equals("80100"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "-1.0a10.0a0.0a0.0a10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str2.equals("rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 35, 22);
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte18 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a10a100a1" + "'", str8.equals("10a10a100a1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10410410041" + "'", str10.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10410410041" + "'", str12.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 100 + "'", byte17 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) 1 + "'", byte18 == (byte) 1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0a100.", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10 10 100 1", "1.4");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10 10 100 1" + "'", str3.equals("10 10 100 1"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("   1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        int[] intArray3 = new int[] { 18, (byte) -1, (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "18#-1#0" + "'", str5.equals("18#-1#0"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1" + "'", str3.equals("-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("ORACLE 1.", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE 1.                                                                                           " + "'", str2.equals("ORACLE 1.                                                                                           "));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        double[] doubleArray5 = new double[] { 32L, 22.0f, 10, 10410410041L, 1.0f };
        double[] doubleArray11 = new double[] { 32L, 22.0f, 10, 10410410041L, 1.0f };
        double[] doubleArray17 = new double[] { 32L, 22.0f, 10, 10410410041L, 1.0f };
        double[] doubleArray23 = new double[] { 32L, 22.0f, 10, 10410410041L, 1.0f };
        double[] doubleArray29 = new double[] { 32L, 22.0f, 10, 10410410041L, 1.0f };
        double[] doubleArray35 = new double[] { 32L, 22.0f, 10, 10410410041L, 1.0f };
        double[][] doubleArray36 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29, doubleArray35 };
        java.lang.String str37 = org.apache.commons.lang3.StringUtils.join(doubleArray36);
        java.lang.String str38 = org.apache.commons.lang3.StringUtils.join(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C", (int) '4', 495);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("NOITAROPROC ELCARO##############/Users/sop10410410041Java Platform API Specification#####NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO", 499);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOITAROPROC ELCARO##############/Users/sop10410410041Java Platform API Specification#####NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO" + "'", str2.equals("NOITAROPROC ELCARO##############/Users/sop10410410041Java Platform API Specification#####NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie#####", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie#####" + "'", str2.equals("/Users/sophie#####"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "0410");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 499);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 499 + "'", int2 == 499);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Mixed mode", (java.lang.CharSequence) "hhhhhhhhhhhhhhhhhhhhhhhhhC.4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5", "-1 100 -1");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5" + "'", str5.equals("CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5CLELCORCOC5"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("\n");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   /.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   /5");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "     0.9", (java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        int[] intArray3 = new int[] { 18, (byte) -1, (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ', 1, (int) (short) 0);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "18#-1#0" + "'", str5.equals("18#-1#0"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 18 + "'", int11 == 18);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1" + "'", str1.equals("-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        short[] shortArray5 = new short[] { (byte) 100, (short) 10, (short) -1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', (int) (short) 100, 0);
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 10 -1 -1 100" + "'", str7.equals("100 10 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1004104-14-14100" + "'", str9.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) -1 + "'", short15 == (short) -1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("###10.14.3", "HI");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("      Hi!       a      Hi!       ", "rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59", "4.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.0", 499);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "      Hi!       a      Hi!       " + "'", str4.equals("      Hi!       a      Hi!       "));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("   1.7", "hi!h", 22, (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "   1.7hi!h" + "'", str4.equals("   1.7hi!h"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("52.", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0a100.0" + "'", str1.equals("1.0a100.0"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        char[] charArray10 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http://java.oracle.com/", charArray10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ');
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.5-1#100#-1", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "# # # # a 4" + "'", str15.equals("# # # # a 4"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "# # # # a 4" + "'", str17.equals("# # # # a 4"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Oracle Corporati", (java.lang.CharSequence) "4.0 -1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("cosx.cpr############################################         ############################################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cosx.cpr############################################         ############################################" + "'", str2.equals("cosx.cpr############################################         ############################################"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("SUN.AWT.cgRAPHICSeNVIRONMENT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0410410041mac OS XOracle Corporatio");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "52.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("EN##################################################", "1m", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 4, 0, 9740);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9740 + "'", int3 == 9740);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        int[] intArray2 = new int[] { 'a', 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        java.lang.Class<?> wildcardClass10 = intArray2.getClass();
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9740" + "'", str7.equals("9740"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97a0" + "'", str9.equals("97a0"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sunalwawtamacosxacprinterjob", (java.lang.CharSequence) ".LCARO...LCARO...LCARO444444444/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("###10.14.3###10.14.3###10.14.3###10.14.3", "", "cosx4.0-1.010.t.ma sun.lw");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###10.14.3###10.14.3###10.14.3###10.14.3" + "'", str3.equals("###10.14.3###10.14.3###10.14.3###10.14.3"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0 l M  Virtu v tionJ chine Specific l M  Virtu v J" + "'", str3.equals("1.0 l M  Virtu v tionJ chine Specific l M  Virtu v J"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) -1, 0L, 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mac OS X", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/soprary/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/USERS/SOPRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', (int) (short) 4, (int) (short) 4);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 1 + "'", byte9 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 1 + "'", byte14 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1.041.0", (java.lang.CharSequence) "10                                                                                                  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "rs/_v/6v59", (java.lang.CharSequence) "0", 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/444444444ORACL...ORACL...ORACL.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/444444444ORACL...ORACL...ORACL.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1.0", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("0a10", "mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a10" + "'", str2.equals("0a10"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("             10410410              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "             10410410             " + "'", str1.equals("             10410410             "));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1.0 10.0 0.0 0.0 10.0", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "4.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "############################################         ############################################", (java.lang.CharSequence) "52.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("       ", 14, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("SUN.LWAWT.MACOSX.cpRINTE", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTE" + "'", str2.equals("SUN.LWAWT.MACOSX.cpRINTE"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        int[] intArray2 = new int[] { 'a', 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', (int) (short) 10, 0);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', (-1), 142);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.7.0_801001.7.0_801001.7.0_801h", "                                       ORACLE CORPORATION                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_801001.7.0_801001.7.0_801h" + "'", str2.equals("1.7.0_801001.7.0_801001.7.0_801h"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##################", "");
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("10enfalse", strArray3, strArray4);
        java.lang.Class<?> wildcardClass6 = strArray3.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray7 = new java.lang.reflect.GenericDeclaration[] { wildcardClass6 };
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##################", "");
        java.lang.String[] strArray12 = null;
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("10enfalse", strArray11, strArray12);
        java.lang.Class<?> wildcardClass14 = strArray11.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray15 = new java.lang.reflect.GenericDeclaration[] { wildcardClass14 };
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##################", "");
        java.lang.String[] strArray20 = null;
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("10enfalse", strArray19, strArray20);
        java.lang.Class<?> wildcardClass22 = strArray19.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray23 = new java.lang.reflect.GenericDeclaration[] { wildcardClass22 };
        java.lang.reflect.GenericDeclaration[][] genericDeclarationArray24 = new java.lang.reflect.GenericDeclaration[][] { genericDeclarationArray7, genericDeclarationArray15, genericDeclarationArray23 };
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray24);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10enfalse" + "'", str5.equals("10enfalse"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(genericDeclarationArray7);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10enfalse" + "'", str13.equals("10enfalse"));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(genericDeclarationArray15);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10enfalse" + "'", str21.equals("10enfalse"));
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(genericDeclarationArray23);
        org.junit.Assert.assertNotNull(genericDeclarationArray24);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/users/sophie", (java.lang.CharSequence) "RACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 4, (long) 21, (long) 620);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4L + "'", long3 == 4L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        long[] longArray1 = new long[] { 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, '#', 9, (int) (byte) 0);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                       ORACLE CORPORATION                                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                                        ORACLE CORPORATION                                         is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C", 97, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("0410410041mac OS X0410410041mac OS X0410410041mac OS X0410410041mac OS Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0410410041macOSX0410410041macOSX0410410041macOSX0410410041macOSVirtualMachineSpecification" + "'", str1.equals("0410410041macOSX0410410041macOSX0410410041macOSX0410410041macOSVirtualMachineSpecification"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.1", "             10410410              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".1" + "'", str2.equals(".1"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "  x86_64  ", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.8", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "#m#m#m#mam", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "01#001#001#001#001#001#001#001#", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray9 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray9);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', 100, 142);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (-1), 2.0f, (float) 500L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "X86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("#100#100#100#100#100#100#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#100#100#100#100#100#100#100" + "'", str1.equals("#100#100#100#100#100#100#100"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("O1.7.0_80-b15racle1.7.0_80-b151.7.0_80-b15C1.7.0_80-b15orporation", "-1 100 -1", "46_68x#10046_68x#10046_68x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "O6.7.8_884b65racle6.7.8_884b656.7.8_884b65C6.7.8_884b65orporation" + "'", str3.equals("O6.7.8_884b65racle6.7.8_884b656.7.8_884b65C6.7.8_884b65orporation"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0" + "'", str1.equals("18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("46_68x#10046_68x#10046_68x", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "46_68x#10046_68x#10046_68x" + "'", str2.equals("46_68x#10046_68x#10046_68x"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Aaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Aaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("    -1.041.0", (long) 500);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 500L + "'", long2 == 500L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        char[] charArray13 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10410410041MAC os x", charArray13);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray13, '4');
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "h", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "44:n...", charArray13);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray13);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "cosx.cpr############################################         ############################################", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "#4#4#4#4a44" + "'", str17.equals("#4#4#4#4a44"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 31 + "'", int21 == 31);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("SUN.LWAWT.MACOSX.cpRINTERj", 19, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERj" + "'", str3.equals("SUN.LWAWT.MACOSX.cpRINTERj"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "x so CAM14001401401", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 97, (float) 100, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.0 l M  Virtu v tionJ chine Specific l M  Virtu v J", (byte) 7);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 7 + "'", byte2 == (byte) 7);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "0410410041macOSX0410410041macOSX0410410041macOSX0410410041macOSVirtualMachineSpecification", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        short[] shortArray5 = new short[] { (byte) 100, (short) 10, (short) -1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', (int) '4', (int) (short) -1);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 10 -1 -1 100" + "'", str7.equals("100 10 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004104-14-14100" + "'", str10.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1004104-14-14100" + "'", str14.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("184-140", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 0, (long) 10, (long) (short) 4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "4410...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1004444444444444444444444444444444444444444444444444", (java.lang.CharSequence) " Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("01#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "01#0" + "'", str1.equals("01#0"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "oracle corporationrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C", 9740);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C" + "'", str2.equals("x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("O1.7.0_80-b15racle1.7.0_80-b151.7.0_80-b15C1.7.0_80-b15orporation", "10.14.3");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "X86_64SUN.AWT.CGRAPHICSENVIRONMENT", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "O1.7.0_80-b15racle1.7.0_80-b151.7.0_80-b15C1.7.0_80-b15orporation" + "'", str5.equals("O1.7.0_80-b15racle1.7.0_80-b151.7.0_80-b15C1.7.0_80-b15orporation"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.7.0_80", "s86_6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s86_6" + "'", str2.equals("s86_6"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("-1.0#22.0", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0#22.0" + "'", str2.equals("-1.0#22.0"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("RO", "sun.awt.CGraphicsEnvironment", 8);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "O1.7.0_80-b15racle1.7.0_80-b151.7.0_80-b15C1.7.0_80-b15orporation", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("0", "10ENFALSE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10ENFALSE" + "'", str2.equals("10ENFALSE"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("cosx.cpr ", (int) '4', 33);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray11, '4', 1, (int) (short) -1);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.14.3", charArray11);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "      Hi!       a      Hi!       ", charArray11);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".1", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 16 + "'", int19 == 16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0410410041mac OS X", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0410410041mc OS X" + "'", str2.equals("0410410041mc OS X"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Mixed mode", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1004444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        float[] floatArray1 = new float[] { 1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0" + "'", str3.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0" + "'", str5.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0" + "'", str7.equals("1.0"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   /", "0#10", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0410410041mac OS X0410410041mac OS X0410410041mac OS X0410410041mac OS Virtual Machine Specification", (java.lang.CharSequence) "01#0mixedmodemix");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93 + "'", int2 == 93);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("MIXED MODE", "oracle corporationrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) -1, (byte) 7);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        float[] floatArray1 = new float[] { 1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0" + "'", str3.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0" + "'", str5.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0" + "'", str7.equals("1.0"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("      Hi!       ", "X86_6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      Hi!       " + "'", str2.equals("      Hi!       "));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10a10a100a1", (int) (short) 4, "cosx4.0-1.010.t.ma sun.lw");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a10a100a1" + "'", str3.equals("10a10a100a1"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("oracle corporationrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation", (int) (byte) 1, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "racle corporationrs/_v/6v59rs/_v" + "'", str3.equals("racle corporationrs/_v/6v59rs/_v"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("EN##################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EN##################################################" + "'", str1.equals("EN##################################################"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger(".1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("              ORACLEaCORPORATION", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "              ORACLEaCORPORATION" + "'", str3.equals("              ORACLEaCORPORATION"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str1.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("            10 10 100 1            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 10 100 1" + "'", str1.equals("10 10 100 1"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "::::::::", (java.lang.CharSequence) "1.0#100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8", "/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Librar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8" + "'", str2.equals("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "oracle corporationrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation", (java.lang.CharSequence) "::::::::");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("C4", (float) 620L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 620.0f + "'", float2 == 620.0f);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        short[] shortArray5 = new short[] { (byte) 100, (short) 10, (short) -1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 8, (int) (byte) 1);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 10 -1 -1 100" + "'", str7.equals("100 10 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004104-14-14100" + "'", str10.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1004104-14-14100" + "'", str14.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1004104-14-14100" + "'", str16.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        char[] charArray12 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http://java.oracle.com/", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "::::::::", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "7.1", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray12);
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray12, '#', 16, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 16");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        short[] shortArray5 = new short[] { (byte) 100, (short) 10, (short) -1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short17 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short18 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 10 -1 -1 100" + "'", str7.equals("100 10 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004104-14-14100" + "'", str10.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1004104-14-14100" + "'", str14.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1004104-14-14100" + "'", str16.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + short17 + "' != '" + (short) 100 + "'", short17 == (short) 100);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) -1 + "'", short18 == (short) -1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION" + "'", str1.equals("ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION##################ORACLECORPORATION"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10410410", (java.lang.CharSequence) "             10410410              ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("       ", "1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       " + "'", str2.equals("       "));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                   " + "'", str1.equals("                                   "));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 10, 0.0f, (short) 0, 10.0f };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0a10.0a0.0a0.0a10.0" + "'", str8.equals("-1.0a10.0a0.0a0.0a10.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0a10.0a0.0a0.0a10.0" + "'", str11.equals("-1.0a10.0a0.0a0.0a10.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/444444444", (java.lang.CharSequence) "4.0 1.0 10.0", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10101001", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10101001" + "'", str2.equals("10101001"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (java.lang.CharSequence) "10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                            SUN.LWAWT.MACOSX.cpRINTE", "sun.lwawt.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                            SUN.LWAWT.MACOSX.cpRINTE" + "'", str2.equals("                            SUN.LWAWT.MACOSX.cpRINTE"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        long[] longArray2 = new long[] { '4', 1L };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a', 498, 620);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 498");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/USERS/SOPRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 4, (short) 4);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 4 + "'", short3 == (short) 4);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/444444444ORACL...ORACL...ORACL.", 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "Aaaaaaaat.jarAaaaaaaaa", 16, 9);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("macns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jacns:/Libram" + "'", str2.equals(":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jacns:/Libram"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "cosx4.0-1.010.t.ma sun.lw");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/J/a/v/a/ /P/l/a/t/f/o/r/m/ /A/P/I/ /S/p/e/c/i/f/i/c/a/t/i/o/n/", 7, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(".1", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".1" + "'", str3.equals(".1"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4.0 -1.0 10.0", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0a10");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("            10 10 100 1            ", strArray5, strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(".LCARO...LCARO...LCARO444444444/", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "            10 10 100 1            " + "'", str8.equals("            10 10 100 1            "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + ".LCARO...LCARO...LCARO444444444/" + "'", str9.equals(".LCARO...LCARO...LCARO444444444/"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("10a10a100a1", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("sun.lwawt.macosx.LWCToolkit", "rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        short[] shortArray5 = new short[] { (byte) 100, (short) 10, (short) -1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#', 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 10 -1 -1 100" + "'", str7.equals("100 10 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004104-14-14100" + "'", str10.equals("1004104-14-14100"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.0                         ", "              ORACLEaCORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0" + "'", str2.equals("1.0"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("#100", 468);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10#1#1#1", (java.lang.CharSequence) "Hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                             444444444/                                             ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("HI", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("0000aaaaaaaaaa", "oracle corporationrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation", 468);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mac OS X", "100#10#-1#-1#100");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "100a10a-1a-1a100", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("O1.7.0_80-b15racle1.7.0_80-b15 1.7.0_80-b15C1.7.0_80-b15orporation", '#');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("########a#4", "");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10.0410.0452.0410.040.0410.0", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0410.0452.0410.040.0410.0" + "'", str7.equals("10.0410.0452.0410.040.0410.0"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(19, (int) (byte) 100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "10101001", "   US   ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, ' ', (int) (byte) 4, 12);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Librar", "1.11.11.11.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) (short) 10, (-1));
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', 2, 2);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte19 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#', 10, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10#10#100#1" + "'", str18.equals("10#10#100#1"));
        org.junit.Assert.assertTrue("'" + byte19 + "' != '" + (byte) 100 + "'", byte19 == (byte) 100);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", 'a');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "ORACLECORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("   1.7hi!h", ".1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "hie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/librar", (java.lang.CharSequence) "0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSX");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "10");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("en", "/", (int) (short) 10);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("24.80-b11", strArray5, strArray10);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Oracle Corporation");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1004104-14-14100", strArray5, strArray14);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "en" + "'", str11.equals("en"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "24.80-b11" + "'", str12.equals("24.80-b11"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1004104-14-14100" + "'", str15.equals("1004104-14-14100"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 10, 0.0f, (short) 0, 10.0f };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', (int) (short) 100, 2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0410.040.040.0410.0" + "'", str8.equals("-1.0410.040.040.0410.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0410.040.040.0410.0" + "'", str14.equals("-1.0410.040.040.0410.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1.0a10.0a0.0a0.0a10.0" + "'", str16.equals("-1.0a10.0a0.0a0.0a10.0"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.7.0_80-b15", "macosx.cpr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("    ");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a10a100a1" + "'", str8.equals("10a10a100a1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10410410041" + "'", str10.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 1 + "'", byte11 == (byte) 1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "O1.7.0_80-b15racle1.7.0_80-b15 1.7.0_80-b15C1.7.0_80-b15orporation                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre", 21, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                            SUN.LWAWT.MACOSX.cpRINTE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str2.equals("rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C", 107, "x86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C" + "'", str3.equals("x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10410410041mac OS X", "\n");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0 10", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "cosx.cpr ", (java.lang.CharSequence) "ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION" + "'", str2.equals("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSX");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10410041m\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM) SE Runtime Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 12, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "racle corporationrs/_v/6v59rs/_v", (java.lang.CharSequence) "-1.0410.040.040.0410.0-1.0410.040.040.0410.0-1.0410.", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("-1.0a10.0a0.0a0.0a10.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Ur/rrUrM/Ur/rrUr/Ur/rrUrc/Ur/rrUr /Ur/rrUrO/Ur/rrUrS/Ur/rrUr /Ur/rrUrX/Ur/rrUr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Ur/rrUrM/Ur/rrUr/Ur/rrUrc/Ur/rrUr /Ur/rrUrO/Ur/rrUrS/Ur/rrUr /Ur/rrUrX/Ur/rrUr\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ", (java.lang.CharSequence) "x86_64", 620);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle Corporation", "co!", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mixed mode", "10414141", (int) (byte) 1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.io.Serializable[]) strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mixed mode" + "'", str4.equals("Mixed mode"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.044.040.04100.0435.0", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4.040.04100.0435.0" + "'", str2.equals("4.040.04100.0435.0"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "10101001                                                                                         ", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", ' ');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("0.9", "", 30);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10410410041", "4.040.04100.0435.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.044.040.04100.0435.0", "x4864_4644sun4.4awt4.4CG4raphics4E4nvironment", "###10.14.3");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("104104100", (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 104104100L + "'", long2 == 104104100L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_50469_1560277335" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_50469_1560277335"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("a#a#a#aaaa", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a#a#a#aaaa" + "'", str2.equals("a#a#a#aaaa"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("macosx.cpr", "aaaaaaaaaaa104104100aaaaaaaaaaa", "80100", 21);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "macosx.cpr" + "'", str4.equals("macosx.cpr"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Oracle Corporatio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle Corporatio\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("01#0mixedmodemix");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " HotSpot(TM) 64-Bit Server VMavaJ", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIO", 0, 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORAC..." + "'", str3.equals("ORAC..."));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mixed mode", '#');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaat.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 500 + "'", int2 == 500);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        short[] shortArray3 = new short[] { (byte) -1, (short) 100, (byte) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 32, 2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1a100a-1" + "'", str11.equals("-1a100a-1"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("oRACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun.lwawt.macosx.cprinterjob", "/Users/sophie#####");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str2.equals("sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/", 368);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/444444444ORACL...ORACL...ORACL.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "mac os x", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Hi!", "SUN.LWAWT.MACOSX.cpRINT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!" + "'", str2.equals("Hi!"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION", "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION" + "'", str2.equals("oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        int[] intArray2 = new int[] { 'a', 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97a0" + "'", str9.equals("97a0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9740" + "'", str11.equals("9740"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sunalwawtamacosxacprinterjob", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        int[] intArray3 = new int[] { 18, (byte) -1, (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray3, '4', 2, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "18#-1#0" + "'", str5.equals("18#-1#0"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 18 + "'", int8 == 18);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        long[] longArray1 = new long[] { (byte) 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ');
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray1, '#', 30, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10" + "'", str13.equals("10"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "4444", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("01#0", ' ');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.5-1#100#-1", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Users/sop10410410041Java Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sop10410410041Java Platform API Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59", "macosx");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) ".0_801.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("4.0 1.0 10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4.0 1.0 10.0" + "'", str1.equals("4.0 1.0 10.0"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "cosx.cpr ", "86");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("hhhhhhhhhhhhhhhhhhhhhhhhhhhhh1.4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hhhhhhhhhhhhhhhhhhhhhhhhhhhhh1.4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("01#0mixedmodemix", "hi/444444444", "   SU   ", 378);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "01#0mixedmodemix" + "'", str4.equals("01#0mixedmodemix"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        char[] charArray9 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10410410041MAC os x", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie#####", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C", 31, "52.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C" + "'", str3.equals("x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("10.00101001.052.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray12 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence4, charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "  x86_64  ", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10101001", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "      Hi!       a      Hi!       ", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 2, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa" + "'", str3.equals("aa"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhC.4", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("51.0", "0410410041mac OS XOracle Corporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 10, 0.0f, (short) 0, 10.0f };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', (int) 'a', 3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0a10.0a0.0a0.0a10.0" + "'", str12.equals("-1.0a10.0a0.0a0.0a10.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 10.0 0.0 0.0 10.0" + "'", str14.equals("-1.0 10.0 0.0 0.0 10.0"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("0000aaaaaaaaaa", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "10410410041m", (java.lang.CharSequence) "      Hi!       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        double[] doubleArray1 = new double[] { 52.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 620, 35);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "52.0" + "'", str5.equals("52.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52.0" + "'", str7.equals("52.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 52.0d + "'", double8 == 52.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "-1.041.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("HIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRAR", 620);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRAR" + "'", str2.equals("HIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRAR"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd(" sun.lwawt.macosx.cprinterjob", "52.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " sun.lwawt.macosx.cprinterjob" + "'", str2.equals(" sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("10 1 1 1", 620);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 1 1 1" + "'", str2.equals("10 1 1 1"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "mixed mode", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "10enfals", 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1, (double) 104104100L, (double) 378);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.041041E8d + "'", double3 == 1.041041E8d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "x so CAM14001401401");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("104104100", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "104104100" + "'", str2.equals("104104100"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 18, ".0_801.7.0_8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100 10 -1 -1 100", "hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Lib");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "#M#M#M#MaM");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIO");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100 10 -1 -1 100" + "'", str5.equals("100 10 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 10 -1 -1 100" + "'", str7.equals("100 10 -1 -1 100"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 33L, (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 33L + "'", long3 == 33L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10enfals", (java.lang.CharSequence) "  x86_64  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("0410410041mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0410410041MAC os x" + "'", str1.equals("0410410041MAC os x"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1.7.0_801001.7.0_801001.7.0_801h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_801001.7.0_801001.7.0_801h" + "'", str1.equals("1.7.0_801001.7.0_801001.7.0_801h"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.6", (java.lang.CharSequence) "macosx");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "46_68x", (java.lang.CharSequence) "###10.14.3###10.14.3###10.14.3###10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0A10.0A0.0A0.0A10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0A10.0A0.0A0.0A10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8" + "'", str1.equals("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0A10.0A0.0A0.0A10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.14.310.14.310.14.3", (java.lang.CharSequence) "      Hi!       a      Hi!       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("########a#M", "Oracle Corporation", "4.0-1.010.");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "Java HotSpot(TM) 64-Bit Server VM", "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "cosx.cpr ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("a", ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "46_68x");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "a" + "'", str4.equals("a"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 10, (short) 4);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaat.jar", 0, "hhhhhhhhhhhhhhhhhhhhhhhhhhhhh1.4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaat.jar" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaat.jar"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "ORACLECORPORATION1ORACLECORPORATION1ORACLECORPORATIONbORACLECORPORATION-ORACLECORPORATION0ORACLECORPORATION8ORACLECORPORATION.ORACLECORPORATION4ORACLECORPORATION2ORACLECORPORATION", (java.lang.CharSequence) "UTF-8", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) (short) 10, (-1));
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', 2, 2);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte19 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte20 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10#10#100#1" + "'", str18.equals("10#10#100#1"));
        org.junit.Assert.assertTrue("'" + byte19 + "' != '" + (byte) 100 + "'", byte19 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte20 + "' != '" + (byte) 1 + "'", byte20 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10410410041" + "'", str22.equals("10410410041"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray2 = new java.math.BigDecimal[] { bigDecimal1 };
        java.math.BigDecimal bigDecimal4 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray5 = new java.math.BigDecimal[] { bigDecimal4 };
        java.math.BigDecimal bigDecimal7 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray8 = new java.math.BigDecimal[] { bigDecimal7 };
        java.math.BigDecimal bigDecimal10 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray11 = new java.math.BigDecimal[] { bigDecimal10 };
        java.math.BigDecimal bigDecimal13 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray14 = new java.math.BigDecimal[] { bigDecimal13 };
        java.math.BigDecimal[][] bigDecimalArray15 = new java.math.BigDecimal[][] { bigDecimalArray2, bigDecimalArray5, bigDecimalArray8, bigDecimalArray11, bigDecimalArray14 };
        java.math.BigDecimal bigDecimal17 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray18 = new java.math.BigDecimal[] { bigDecimal17 };
        java.math.BigDecimal bigDecimal20 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray21 = new java.math.BigDecimal[] { bigDecimal20 };
        java.math.BigDecimal bigDecimal23 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray24 = new java.math.BigDecimal[] { bigDecimal23 };
        java.math.BigDecimal bigDecimal26 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray27 = new java.math.BigDecimal[] { bigDecimal26 };
        java.math.BigDecimal bigDecimal29 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray30 = new java.math.BigDecimal[] { bigDecimal29 };
        java.math.BigDecimal[][] bigDecimalArray31 = new java.math.BigDecimal[][] { bigDecimalArray18, bigDecimalArray21, bigDecimalArray24, bigDecimalArray27, bigDecimalArray30 };
        java.math.BigDecimal bigDecimal33 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray34 = new java.math.BigDecimal[] { bigDecimal33 };
        java.math.BigDecimal bigDecimal36 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray37 = new java.math.BigDecimal[] { bigDecimal36 };
        java.math.BigDecimal bigDecimal39 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray40 = new java.math.BigDecimal[] { bigDecimal39 };
        java.math.BigDecimal bigDecimal42 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray43 = new java.math.BigDecimal[] { bigDecimal42 };
        java.math.BigDecimal bigDecimal45 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray46 = new java.math.BigDecimal[] { bigDecimal45 };
        java.math.BigDecimal[][] bigDecimalArray47 = new java.math.BigDecimal[][] { bigDecimalArray34, bigDecimalArray37, bigDecimalArray40, bigDecimalArray43, bigDecimalArray46 };
        java.math.BigDecimal bigDecimal49 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray50 = new java.math.BigDecimal[] { bigDecimal49 };
        java.math.BigDecimal bigDecimal52 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray53 = new java.math.BigDecimal[] { bigDecimal52 };
        java.math.BigDecimal bigDecimal55 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray56 = new java.math.BigDecimal[] { bigDecimal55 };
        java.math.BigDecimal bigDecimal58 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray59 = new java.math.BigDecimal[] { bigDecimal58 };
        java.math.BigDecimal bigDecimal61 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray62 = new java.math.BigDecimal[] { bigDecimal61 };
        java.math.BigDecimal[][] bigDecimalArray63 = new java.math.BigDecimal[][] { bigDecimalArray50, bigDecimalArray53, bigDecimalArray56, bigDecimalArray59, bigDecimalArray62 };
        java.math.BigDecimal bigDecimal65 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray66 = new java.math.BigDecimal[] { bigDecimal65 };
        java.math.BigDecimal bigDecimal68 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray69 = new java.math.BigDecimal[] { bigDecimal68 };
        java.math.BigDecimal bigDecimal71 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray72 = new java.math.BigDecimal[] { bigDecimal71 };
        java.math.BigDecimal bigDecimal74 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray75 = new java.math.BigDecimal[] { bigDecimal74 };
        java.math.BigDecimal bigDecimal77 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray78 = new java.math.BigDecimal[] { bigDecimal77 };
        java.math.BigDecimal[][] bigDecimalArray79 = new java.math.BigDecimal[][] { bigDecimalArray66, bigDecimalArray69, bigDecimalArray72, bigDecimalArray75, bigDecimalArray78 };
        java.math.BigDecimal bigDecimal81 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray82 = new java.math.BigDecimal[] { bigDecimal81 };
        java.math.BigDecimal bigDecimal84 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray85 = new java.math.BigDecimal[] { bigDecimal84 };
        java.math.BigDecimal bigDecimal87 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray88 = new java.math.BigDecimal[] { bigDecimal87 };
        java.math.BigDecimal bigDecimal90 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray91 = new java.math.BigDecimal[] { bigDecimal90 };
        java.math.BigDecimal bigDecimal93 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal[] bigDecimalArray94 = new java.math.BigDecimal[] { bigDecimal93 };
        java.math.BigDecimal[][] bigDecimalArray95 = new java.math.BigDecimal[][] { bigDecimalArray82, bigDecimalArray85, bigDecimalArray88, bigDecimalArray91, bigDecimalArray94 };
        java.math.BigDecimal[][][] bigDecimalArray96 = new java.math.BigDecimal[][][] { bigDecimalArray15, bigDecimalArray31, bigDecimalArray47, bigDecimalArray63, bigDecimalArray79, bigDecimalArray95 };
        java.lang.String str97 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray96);
        org.junit.Assert.assertNotNull(bigDecimal1);
        org.junit.Assert.assertNotNull(bigDecimalArray2);
        org.junit.Assert.assertNotNull(bigDecimal4);
        org.junit.Assert.assertNotNull(bigDecimalArray5);
        org.junit.Assert.assertNotNull(bigDecimal7);
        org.junit.Assert.assertNotNull(bigDecimalArray8);
        org.junit.Assert.assertNotNull(bigDecimal10);
        org.junit.Assert.assertNotNull(bigDecimalArray11);
        org.junit.Assert.assertNotNull(bigDecimal13);
        org.junit.Assert.assertNotNull(bigDecimalArray14);
        org.junit.Assert.assertNotNull(bigDecimalArray15);
        org.junit.Assert.assertNotNull(bigDecimal17);
        org.junit.Assert.assertNotNull(bigDecimalArray18);
        org.junit.Assert.assertNotNull(bigDecimal20);
        org.junit.Assert.assertNotNull(bigDecimalArray21);
        org.junit.Assert.assertNotNull(bigDecimal23);
        org.junit.Assert.assertNotNull(bigDecimalArray24);
        org.junit.Assert.assertNotNull(bigDecimal26);
        org.junit.Assert.assertNotNull(bigDecimalArray27);
        org.junit.Assert.assertNotNull(bigDecimal29);
        org.junit.Assert.assertNotNull(bigDecimalArray30);
        org.junit.Assert.assertNotNull(bigDecimalArray31);
        org.junit.Assert.assertNotNull(bigDecimal33);
        org.junit.Assert.assertNotNull(bigDecimalArray34);
        org.junit.Assert.assertNotNull(bigDecimal36);
        org.junit.Assert.assertNotNull(bigDecimalArray37);
        org.junit.Assert.assertNotNull(bigDecimal39);
        org.junit.Assert.assertNotNull(bigDecimalArray40);
        org.junit.Assert.assertNotNull(bigDecimal42);
        org.junit.Assert.assertNotNull(bigDecimalArray43);
        org.junit.Assert.assertNotNull(bigDecimal45);
        org.junit.Assert.assertNotNull(bigDecimalArray46);
        org.junit.Assert.assertNotNull(bigDecimalArray47);
        org.junit.Assert.assertNotNull(bigDecimal49);
        org.junit.Assert.assertNotNull(bigDecimalArray50);
        org.junit.Assert.assertNotNull(bigDecimal52);
        org.junit.Assert.assertNotNull(bigDecimalArray53);
        org.junit.Assert.assertNotNull(bigDecimal55);
        org.junit.Assert.assertNotNull(bigDecimalArray56);
        org.junit.Assert.assertNotNull(bigDecimal58);
        org.junit.Assert.assertNotNull(bigDecimalArray59);
        org.junit.Assert.assertNotNull(bigDecimal61);
        org.junit.Assert.assertNotNull(bigDecimalArray62);
        org.junit.Assert.assertNotNull(bigDecimalArray63);
        org.junit.Assert.assertNotNull(bigDecimal65);
        org.junit.Assert.assertNotNull(bigDecimalArray66);
        org.junit.Assert.assertNotNull(bigDecimal68);
        org.junit.Assert.assertNotNull(bigDecimalArray69);
        org.junit.Assert.assertNotNull(bigDecimal71);
        org.junit.Assert.assertNotNull(bigDecimalArray72);
        org.junit.Assert.assertNotNull(bigDecimal74);
        org.junit.Assert.assertNotNull(bigDecimalArray75);
        org.junit.Assert.assertNotNull(bigDecimal77);
        org.junit.Assert.assertNotNull(bigDecimalArray78);
        org.junit.Assert.assertNotNull(bigDecimalArray79);
        org.junit.Assert.assertNotNull(bigDecimal81);
        org.junit.Assert.assertNotNull(bigDecimalArray82);
        org.junit.Assert.assertNotNull(bigDecimal84);
        org.junit.Assert.assertNotNull(bigDecimalArray85);
        org.junit.Assert.assertNotNull(bigDecimal87);
        org.junit.Assert.assertNotNull(bigDecimalArray88);
        org.junit.Assert.assertNotNull(bigDecimal90);
        org.junit.Assert.assertNotNull(bigDecimalArray91);
        org.junit.Assert.assertNotNull(bigDecimal93);
        org.junit.Assert.assertNotNull(bigDecimalArray94);
        org.junit.Assert.assertNotNull(bigDecimalArray95);
        org.junit.Assert.assertNotNull(bigDecimalArray96);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", "     0.9");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) (byte) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", " 1.0a100.0", 10);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/" + "'", str5.equals("/"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("0 10", "4444444444444444444444444444", "46_68x#10046_68x#10046_68x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 10" + "'", str3.equals("0 10"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0000aaaaaaaaaa", "4.0 -1.0 10.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10enfalse", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 6, (float) 0, (float) 8);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Java Virtual Machine SpecificationJava Virtual Ma1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("10.0 10.0 52.0 10.0 0.0 10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0 10.0 52.0 10.0 0.0 10.0" + "'", str1.equals("10.0 10.0 52.0 10.0 0.0 10.0"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 0, 6, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.0", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 10.0f, 1.041041E7f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.041041E7f + "'", float3 == 1.041041E7f);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("      Hi!       a      Hi!       ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10 10 100 ", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Users/sophie/Library/Java/E18#-1#0/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/E18#-1#0/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!", 35, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-B15", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTE", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) ".jar", (java.lang.CharSequence) "SX.cpRINTE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        short[] shortArray1 = new short[] { (short) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 14, (int) (short) 4);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 'a', 0.0d, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(".1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".1" + "'", str1.equals(".1"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "a", "X86_64SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "-1.0410.040.040.0410.0-1.0410.040.040.0410.0-1.0410.", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("tionacle CorporaOr", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   tionacle CorporaOr" + "'", str2.equals("   tionacle CorporaOr"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSX", "                                             /444444444                                             ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Aaaaaaaaaa", (java.lang.CharSequence) "rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray13 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone(charSequence5, charArray13);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "  x86_64  ", charArray13);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.8", charArray13);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjO", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "t.jar", charArray13);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        char[] charArray9 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#a#a#a#aaa4" + "'", str14.equals("#a#a#a#aaa4"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("macosx", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIO", "4444444444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "co!", (java.lang.CharSequence) "1.0a100.", 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10410410041MAC os x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10410410041MAC os x" + "'", str1.equals("10410410041MAC os x"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("52.04444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaa" + "'", str2.equals("aaaaaaaaa"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("::::::::", 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "cosx.cprinterjobawt.ma sun.l", (java.lang.CharSequence) "18#-1#018#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "46_68x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("EN##################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"EN##################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                                                 1.7", 19);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                1.7" + "'", str2.equals("                1.7"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("10410410041mac OS X");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        long[] longArray1 = new long[] { (byte) 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) ' ', (int) (byte) 4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10" + "'", str9.equals("10"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1004104-14-14100", 2, "h");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1004104-14-14100" + "'", str3.equals("1004104-14-14100"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ORACLECORPORATION1ORACLECORPORATION1ORACLECORPORATIONbORACLECORPORATION-ORACLECORPORATION0ORACLECORPORATION8ORACLECORPORATION.ORACLECORPORATION4ORACLECORPORATION2ORACLECORPORATION", 256, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaORACLECORPORATION1ORACLECORPORATION1ORACLECORPORATIONbORACLECORPORATION-ORACLECORPORATION0ORACLECORPORATION8ORACLECORPORATION.ORACLECORPORATION4ORACLECORPORATION2ORACLECORPORATIONaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaORACLECORPORATION1ORACLECORPORATION1ORACLECORPORATIONbORACLECORPORATION-ORACLECORPORATION0ORACLECORPORATION8ORACLECORPORATION.ORACLECORPORATION4ORACLECORPORATION2ORACLECORPORATIONaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("########en", (short) (byte) 4);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 4 + "'", short2 == (short) 4);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("44:n...", "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "/Users/sophie#####");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        short[] shortArray5 = new short[] { (byte) 100, (short) 10, (short) -1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 10 -1 -1 100" + "'", str7.equals("100 10 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004104-14-14100" + "'", str10.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100 10 -1 -1 100" + "'", str14.equals("100 10 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) -1 + "'", short15 == (short) -1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-141004-1");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-141004-1" + "'", str2.equals("-141004-1"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-141004-1" + "'", str3.equals("-141004-1"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean9 = javaVersion6.atLeast(javaVersion8);
        boolean boolean10 = javaVersion0.atLeast(javaVersion6);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("-1.0 10.0 0.0 0.0 10.0", "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8", 19);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-1 100 -1", (java.lang.CharSequence) "18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) 10, (short) (byte) 7);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("MIXED MODE");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        short[] shortArray5 = new short[] { (byte) 100, (short) 10, (short) -1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 10 -1 -1 100" + "'", str7.equals("100 10 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1004104-14-14100" + "'", str9.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100#10#-1#-1#100" + "'", str11.equals("100#10#-1#-1#100"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", charArray11);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray11, 'a', (int) (byte) 10, (int) (byte) 4);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray11);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0" + "'", str1.equals("1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("0410410041mac OS X", 256);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0410410041mac OS X" + "'", str2.equals("0410410041mac OS X"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("-1.041.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.041.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "0#1-#810#1-#810#1-#810aaaaaaaaaa");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10a10a100a1                                                                                         ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("46_68x#10046_68x#10046_68x");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("SUN.LWAWT.MACOSX.cpRINTERjOB       ", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("JavaUPlatfermU/PIUSpecificatien");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x" + "'", str1.equals("x"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("44:n...", "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44:" + "'", str2.equals("44:"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C", "10 10 100", 500);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 4, (long) 32, (long) 142);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4L + "'", long3 == 4L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "ORACL...", (java.lang.CharSequence) "#######################################################################################Aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(" HotSpot(TM) 64-Bit Server VMavaJ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " HotSpot(TM) 64-Bit Server VMavaJ" + "'", str2.equals(" HotSpot(TM) 64-Bit Server VMavaJ"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("-1a100a-1", "/Users/soprary/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a100a-1" + "'", str2.equals("-1a100a-1"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os..." + "'", str2.equals("-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os..."));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaORACLECORPORATION1ORACLECORPORATION1ORACLECORPORATIONbORACLECORPORATION-ORACLECORPORATION0ORACLECORPORATION8ORACLECORPORATION.ORACLECORPORATION4ORACLECORPORATION2ORACLECORPORATIONaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("10410410041m");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10410410041m" + "'", str1.equals("10410410041m"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                1.7", "O6.7.8_884b65racle6.7.8_884b656.7.8_884b65C6.7.8_884b65orporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4', 10, (int) (byte) 10);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 1 + "'", byte8 == (byte) 1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION", 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION" + "'", str3.equals("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("cosx.cpr############################################         ############################################", "hhhhhhhhhhhhhhhhhhhhhhhhhC.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hhhhhhhhhhhhhhhhhhhhhhhhhC.4" + "'", str2.equals("hhhhhhhhhhhhhhhhhhhhhhhhhC.4"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", 499);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ORACLE 1.                                                                                           ", 7, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLE 1.                                                                                           " + "'", str3.equals("ORACLE 1.                                                                                           "));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("18a-1a0", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                          18a-1a0" + "'", str2.equals("                                                                                          18a-1a0"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("########en");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        long[] longArray1 = new long[] { 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        java.lang.Class<?> wildcardClass4 = longArray1.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, '#', (int) '#', 22);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) (short) 1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        short[] shortArray1 = new short[] { (short) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', 378, 0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10.0#10.0#52.0#10.0#0.0#10.0", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                                                                                                                                      ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("ORACLE 1.                                                                                           ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE 1.                                                                                           " + "'", str2.equals("ORACLE 1.                                                                                           "));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "10a10a100a1                                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5" + "'", str1.equals("CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("   SU   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"   SU   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) " 1.0a100.0", (java.lang.CharSequence) "1m");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        float[] floatArray6 = new float[] { 10L, 10, '4', 10L, (short) 0, 10L };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 52.0f + "'", float8 == 52.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0 10.0 52.0 10.0 0.0 10.0" + "'", str10.equals("10.0 10.0 52.0 10.0 0.0 10.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10.0 10.0 52.0 10.0 0.0 10.0" + "'", str13.equals("10.0 10.0 52.0 10.0 0.0 10.0"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ORACLECORPORATION1ORACLECORPORATION1ORACLECORPORATIONbORACLECORPORATION-ORACLECORPORATION0ORACLECORPORATION8ORACLECORPORATION.ORACLECORPORATION4ORACLECORPORATION2ORACLECORPORATION", "10.00101001.052.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("184-140", "1004104-14-14100", "10a10a100a1SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.044.040.04100.0435.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 4, (byte) 0, (byte) 7);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "4.0a-1.0a10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) (byte) 4, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "mIXED MODE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        short[] shortArray3 = new short[] { (byte) -1, (short) 100, (byte) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-141004-1" + "'", str6.equals("-141004-1"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(96, 0, 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C", "10.0a10.0a52.0a10.0a0.0a10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C" + "'", str2.equals("x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.8", 97, 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray12 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.0a100.0", charArray12);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray12, 'a', (int) (byte) 4, 1);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "mac os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaat.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 17, (long) 9, (long) 468);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 468L + "'", long3 == 468L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Library/Java/E18#-1#0/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (java.lang.CharSequence) "44:n...", (int) (short) 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", "hie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/librar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/E18#-1#0", (java.lang.CharSequence) "sun.lwawt.", 9740);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("52.", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "rpc.xsocaM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "0", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("7.1", "x86_64");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("#a#a#a#aaaa", 24L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24L + "'", long2 == 24L);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION", (int) (byte) 1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "-1a100a-1");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1.84444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.7.0_80" + "'", str9.equals("1.7.0_80"));
    }
}

