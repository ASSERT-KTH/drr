import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("10", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        char[] charArray9 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10410410041MAC os x", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "x86_64", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5" + "'", str1.equals("CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "OracleCorporatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "      0A10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("         ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("X.cpRINTE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: X.cpRINTE is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/users/sophie", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "hhhhhhhhhhhhhhhhhhhhhhhhhhhhh1.4");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0 10.0 52.0 10.0 0.0 10.0", "410410041", (int) (byte) 100);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 0, (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporatio", "x so CAM14001401401");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 368 + "'", int4 == 368);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("macns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("-1.041.0", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    -1.041.0" + "'", str2.equals("    -1.041.0"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "X86_64SUN.AWT.CGRAPHICSENVIRONMENT", (java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "0", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        double[] doubleArray1 = new double[] { 52.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', (int) 'a', 8);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52.0" + "'", str8.equals("52.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 52.0d + "'", double9 == 52.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("cosx.cpr ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8" + "'", str2.equals("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        double[] doubleArray2 = new double[] { 97.0f, 9 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "97.0a9.0" + "'", str4.equals("97.0a9.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 9.0d + "'", double5 == 9.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO" + "'", str1.equals("NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10410410041", "-1 100 -1", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/444444444ORACL...ORACL...ORACL.", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "racle Corporati", 21);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10410410041", "-1 100 -1", 0);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("-");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "10a10a100a1                                                                                         ");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-" + "'", str3.equals("-"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("9740");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "9740" + "'", str1.equals("9740"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 2, (long) 100, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "4410444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "52.0", 0, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "52.04444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str4.equals("52.04444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("4.0-1.010.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4.0-1.010.0" + "'", str1.equals("4.0-1.010.0"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("444444444444444444", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hhhhhhhhhhhhhhhhhhhhhhhhhhhhh1.4", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.7.0_80100", "a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80100" + "'", str2.equals("1.7.0_80100"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.7.0_801001.7.0_801001.7.0_801h");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("macosx.cpr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"macosx.cpr\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.31010.0 10.0 52.0 10.0 0.0 10.0", (int) 'a', "         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.31010.0 10.0 52.0 10.0 0.0 10.0" + "'", str3.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.31010.0 10.0 52.0 10.0 0.0 10.0"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "1.84444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "EN##################################################", charArray11);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray11, 'a');
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "#a#a#a#aaa4" + "'", str18.equals("#a#a#a#aaa4"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                hi!h");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/444444444ORACL...ORACL...ORACL.", (java.lang.CharSequence) "18#-1#0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##################", "");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "-1.0a10.0a0.0a0.0a10.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hhhhhhhhhhhhhhhhhhhhhhhhhhhhh1.4", (java.lang.CharSequence) "racle Corporati", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIO", "###10.14.3###10.14.3###10.14.3###10.14.3", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/444444444ORACL...ORACL...ORACL.", 16, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.84444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.31010.0 10.0 52.0 10.0 0.0 10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (int) (byte) 4);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a10a100a1" + "'", str8.equals("10a10a100a1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10410410041" + "'", str10.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10 10 100 1" + "'", str14.equals("10 10 100 1"));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 1 + "'", byte15 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10#10#100#1" + "'", str17.equals("10#10#100#1"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("ETNIRpc.XSOCAM.TWAWL.NUS", "10410410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ETNIRpc.XSOCAM.TWAWL.NUS" + "'", str2.equals("ETNIRpc.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("4.0 -1.0 10.0", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.0" + "'", str2.equals("4.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.04.0 -1.0 10.0"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixedmode", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   " + "'", str1.equals("   "));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "CAM14001401401", (java.lang.CharSequence) "oRACLECORPORATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("  x86_64  ", "Mixed mode", (int) (short) 0);
        java.lang.String[] strArray7 = new java.lang.String[] {};
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "10");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray9, strArray13);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "Java HotSpot(TM) 64-Bit Server VM", (int) (byte) -1, (int) (short) -1);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray5, strArray9);
        int int20 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 468 + "'", int20 == 468);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("01#001#001#001#001#001#001#001#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "01#001#001#001#001#001#001#001#" + "'", str1.equals("01#001#001#001#001#001#001#001#"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "rs/_v/6v59");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize(".0_801.7.0_8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".0_801.7.0_8" + "'", str1.equals(".0_801.7.0_8"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str4 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.1" + "'", str4.equals("1.1"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "      HI!       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 9740L, (float) 378, (float) 368);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 9740.0f + "'", float3 == 9740.0f);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("X86_6", "mac OS X", "10enfals");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "s86_6" + "'", str3.equals("s86_6"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("JavaUPlatfermU/PIUSpecificatien", 500, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 256, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 256 + "'", int3 == 256);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie#####", (java.lang.CharSequence) "                                                                                                 1.7", 256);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("             10410410              ", (int) (byte) 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       " + "'", str2.equals("       "));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0", "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Ur/rrUrM/Ur/rrUr/Ur/rrUrc/Ur/rrUr /Ur/rrUrO/Ur/rrUrS/Ur/rrUr /Ur/rrUrX/Ur/rrUr" + "'", str3.equals("/Ur/rrUrM/Ur/rrUr/Ur/rrUrc/Ur/rrUr /Ur/rrUrO/Ur/rrUrS/Ur/rrUr /Ur/rrUrX/Ur/rrUr"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("hi/444444444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "    " + "'", str1.equals("    "));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam", "", "   1.7");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8", (java.lang.CharSequence) "                                                                                                 1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        float[] floatArray6 = new float[] { 10L, 10, '4', 10L, (short) 0, 10L };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', (int) (short) 100, (int) (short) 1);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 52.0f + "'", float12 == 52.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10.0a10.0a52.0a10.0a0.0a10.0" + "'", str14.equals("10.0a10.0a52.0a10.0a0.0a10.0"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, charSequence1);
        org.junit.Assert.assertNull(charSequence2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 378);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: #m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a10a100a1" + "'", str8.equals("10a10a100a1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10410410041" + "'", str10.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10410410041" + "'", str12.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10a10a100a1" + "'", str14.equals("10a10a100a1"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        long[] longArray4 = new long[] { 10L, (byte) 1, 1, 1L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', (int) '#', 7);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10414141" + "'", str7.equals("10414141"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10 1 1 1" + "'", str10.equals("10 1 1 1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("-", "10410410041");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "mac os x");
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.5", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("hi", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi" + "'", str2.equals("hi"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("oRACLECORPORATION", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "-1.0410.040.040.0410.0");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("en", "1.5", (int) (short) 4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("10.0 10.0 52.0 10.0 0.0 10.0", strArray4, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Ur/rrUrM/Ur/rrUr/Ur/rrUrc/Ur/rrUr /Ur/rrUrO/Ur/rrUrS/Ur/rrUr /Ur/rrUrX/Ur/rrUr", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0 10.0 52.0 10.0 0.0 10.0" + "'", str9.equals("10.0 10.0 52.0 10.0 0.0 10.0"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                           10 10 100");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80-b15", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        int[] intArray3 = new int[] { 18, (byte) -1, (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "18#-1#0" + "'", str5.equals("18#-1#0"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 18 + "'", int8 == 18);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "18a-1a0" + "'", str10.equals("18a-1a0"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 368, 500);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("24.80-b11", "X86_6", "-1.041.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!" + "'", str1.equals("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10a10a100a1                                                                                         ", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a10a100a1                                                                                         " + "'", str3.equals("10a10a100a1                                                                                         "));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "NOITAROPROCaELCARO", (java.lang.CharSequence) "oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation", 107);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1004104-14-14100", (java.lang.CharSequence) "     0.9", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", (java.lang.CharSequence) "4410...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "\n", (java.lang.CharSequence) "MCAM4A3MCAM4A3MCAM4A3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335", "52.0");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7" + "'", str1.equals("7"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 3, (long) 378, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 28);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        float[] floatArray6 = new float[] { 10L, 10, '4', 10L, (short) 0, 10L };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ', 14, 10);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ', 24, 2);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 52.0f + "'", float8 == 52.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0 10.0 52.0 10.0 0.0 10.0" + "'", str10.equals("10.0 10.0 52.0 10.0 0.0 10.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10.0410.0452.0410.040.0410.0" + "'", str20.equals("10.0410.0452.0410.040.0410.0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10.0#10.0#52.0#10.0#0.0#10.0" + "'", str22.equals("10.0#10.0#52.0#10.0#0.0#10.0"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("100#10#-1#-1#100");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("######################", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   /");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "######################" + "'", str2.equals("######################"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        int[] intArray2 = new int[] { 'a', 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', (int) ' ', (int) ' ');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "########en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("SUN.LWAWT.MACOSX.cpRINTERjOB", "4.0 -1.0 10.0", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str3.equals("SUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "x86_64", "x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS X", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray13 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone(charSequence5, charArray13);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray13);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporati", charArray13);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "X86_6", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lwawt.");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "ETNIRpc.XSOCAM.TWAWL.NU", (java.lang.CharSequence) "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0A10.0A0.0A0.0A10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 495 + "'", int2 == 495);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "O1.7.0_80-b15racle1.7.0_80-b15 1.7.0_80-b15C1.7.0_80-b15orporation                                  ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("4.0-1.010.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4.0-1.010." + "'", str1.equals("4.0-1.010."));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10.0 10.0 52.0 10.0 0.0 10.0", (java.lang.CharSequence) "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("###10.14.3###10.14.3###10.14.3###10.14.3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.1", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100", "US");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "44444444444444451.04444444444444444", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("ORACLEaCORPORATION", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TION" + "'", str2.equals("TION"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        char[] charArray10 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http://java.oracle.com/", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "#a#a#a#aaa4" + "'", str16.equals("#a#a#a#aaa4"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("0410", (double) 1.5f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 410.0d + "'", double2 == 410.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("0a10", "10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("184-140", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "184-140" + "'", str2.equals("184-140"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.5");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   /");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   /.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   /5" + "'", str3.equals("1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   /.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   /5"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean9 = javaVersion6.atLeast(javaVersion8);
        boolean boolean10 = javaVersion3.atLeast(javaVersion8);
        java.lang.String str11 = javaVersion8.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.1" + "'", str11.equals("1.1"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "############################################         ############################################", (java.lang.CharSequence) " sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) (byte) 4);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 4 + "'", short3 == (short) 4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", "1.11.11.11.1", "US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8" + "'", str3.equals("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTEN", (java.lang.CharSequence) "oracle corporation-1.0a10.0a0.0a0.0ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONn-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "1.3", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("   US   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   SU   " + "'", str1.equals("   SU   "));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1UN.LWAWT.MACO1X.cpRINTERjOB       ", "97 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1UN.LWAWT.MACO1X.cpRINTERjOB       " + "'", str2.equals("1UN.LWAWT.MACO1X.cpRINTERjOB       "));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("UTF-8", "1.5-1#100#-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("410410041", "01#0mixedmodemix", "###10.14.3");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("MIXED MODE", "-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1", 31);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4.0 1.0 10.0", (int) '#', "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "           4.0 1.0 10.0            " + "'", str3.equals("           4.0 1.0 10.0            "));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "#a#a#a#aaa4", (java.lang.CharSequence) "aa01#0aa", 107);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100", "US");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "RO", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("     0.9", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str3 = javaVersion2.toString();
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean6 = javaVersion0.atLeast(javaVersion2);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "JAVA(TM) SE RUNTIME ENVIRONMENT", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "cosx.cpr", 500, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL" + "'", str1.equals("10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "# # # # a 4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "          ", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0A10.0A0.0A0.0A10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0A10.0A0.0A0.0A10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8" + "'", str2.equals("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0A10.0A0.0A0.0A10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("RO", "1.7.0_80-b15");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("10101001");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach(".0_801.7.0_8", strArray3, strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + ".0_801.7.0_8" + "'", str6.equals(".0_801.7.0_8"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("0.9 -1.0 1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9 -1.0 1.0" + "'", str1.equals("0.9 -1.0 1.0"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("CLELCORC-OC5", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.lang.String[] strArray4 = new java.lang.String[] {};
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "10");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray6, strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " ", (java.lang.CharSequence[]) strArray6);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray14 = null;
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("0#10", strArray6, strArray14);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0#10" + "'", str15.equals("0#10"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                           10 10 100", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("SUN.LWAWT.MACOSX.cpRINTERjOB       ", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB       " + "'", str3.equals("SUN.LWAWT.MACOSX.cpRINTERjOB       "));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("X.cpRINTE");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 256, 32.0d, (double) 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("x86_64");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x86_64\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Oracle Corporatio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Oracle Corporatio is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("h", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("CAM14001401401");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CAM14001401401" + "'", str1.equals("CAM14001401401"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE/LIBRARY/JAVA/EXTEN", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0A10.0A0.0A0.0A10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 499 + "'", int2 == 499);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest7.test180");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("          ", "10                                                                                                  ", "-1.0a10.0a0.0a0.0a10.0", 18);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "          " + "'", str4.equals("          "));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO", "/Users/sop10410410041Java Platform API Specification", 32, 499);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "NOITAROPROC ELCARO##############/Users/sop10410410041Java Platform API Specification#####NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO" + "'", str4.equals("NOITAROPROC ELCARO##############/Users/sop10410410041Java Platform API Specification#####NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO##################NOITAROPROC ELCARO"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/J/a/v/a/ /P/l/a/t/f/o/r/m/ /A/P/I/ /S/p/e/c/i/f/i/c/a/t/i/o/n/", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Users/sop10410410041mac OS XORACL...ORACL...ORAC...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sop10410410041mac OS XORACL...ORACL...ORAC..." + "'", str1.equals("/Users/sop10410410041mac OS XORACL...ORACL...ORAC..."));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("aa01#0aa", 9740, 21);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1", (java.lang.CharSequence) "racle Corporati", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("ETNIRpc.XSOCAM.TWAWL.NUS");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ETNIRpc.XSOCAM.TWAWL.NUS\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("oRACLECORPORATION", (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("10.0a10.0a52.0a10.0a0.0a10.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', (int) ' ', 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        int[] intArray2 = new int[] { 'a', 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', (int) (byte) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9740" + "'", str7.equals("9740"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("10410410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10410410" + "'", str1.equals("10410410"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 10, 0.0f, (short) 0, 10.0f };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0410.040.040.0410.0" + "'", str8.equals("-1.0410.040.040.0410.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0410.040.040.0410.0" + "'", str10.equals("-1.0410.040.040.0410.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "9740", (int) '#', 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 10, 0.0f, (short) 0, 10.0f };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', (int) 'a', 3);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0#1-#81", "  x86_64  ", 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "-1.0#22.0");
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.11.11.11.1", (java.lang.CharSequence[]) strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Ur/rrUrM/Ur/rrUr/Ur/rrUrc/Ur/rrUr /Ur/rrUrO/Ur/rrUrS/Ur/rrUr /Ur/rrUrX/Ur/rrUr");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("JavaUPlatfermU/PIUSpecificatien");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaUPlatfermU/PIUSpecificatien" + "'", str1.equals("JavaUPlatfermU/PIUSpecificatien"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10410410041MAC os x", "1.7.0_80");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray11 = new java.lang.String[] {};
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray11, "10");
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray16);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray13, strArray17);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " ", (java.lang.CharSequence[]) strArray13);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-141004-1");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Hi!", strArray13, strArray21);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray21, "1.7.0_80-b15");
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaaaaa", strArray5, strArray21);
        java.lang.CharSequence charSequence26 = null;
        java.lang.String[] strArray30 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("en", "rs/_v/6v59", (int) (short) 10);
        int int31 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence26, (java.lang.CharSequence[]) strArray30);
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray21, strArray30);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Hi!" + "'", str22.equals("Hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "-141004-1" + "'", str24.equals("-141004-1"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "aaaaaaaaaa" + "'", str25.equals("aaaaaaaaaa"));
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str1.equals("SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/Users/sophie#####", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/Users/sophie#####" + "'", charSequence2.equals("/Users/sophie#####"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "52.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) (short) 10, (-1));
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4', (int) (byte) 10, 378);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 1 + "'", byte13 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10#10#100#1" + "'", str15.equals("10#10#100#1"));
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 100 + "'", byte16 == (byte) 100);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("NOITAROPROC ELCARO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOITAROPROC ELCARO" + "'", str1.equals("NOITAROPROC ELCARO"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray12 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence4, charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                                                 ", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "\n", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        long[] longArray1 = new long[] { (byte) 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10" + "'", str8.equals("10"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!", "86", (int) (byte) 4);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!" + "'", str4.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        double[] doubleArray1 = new double[] { 52.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', (int) 'a', 8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 1, (int) (short) 0);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double15 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 52.0d + "'", double11 == 52.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "52.0" + "'", str13.equals("52.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 52.0d + "'", double14 == 52.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 52.0d + "'", double15 == 52.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSX", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("SUN.AWT.CGRAPHICSENVIRONMENT", (int) (byte) 4, 142);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AWT.CGRAPHICSENVIRONMENT" + "'", str3.equals("AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "     0.9");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("  x86_64  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                           10 10 100", "4.0 -1.0 10.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 620);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            "));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" HotSpot(TM) 64-Bit Server VMavaJ", (short) (byte) 4);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 4 + "'", short2 == (short) 4);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "            10 10 100 1            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray12 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10410410041MAC os x", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "h", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " 1.0a100.0", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444444444444444444", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("rs/_v/6v59", "                                           10 10 100", (int) (byte) 0, 9740);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                           10 10 100" + "'", str4.equals("                                           10 10 100"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION", (java.lang.CharSequence) "10a10a100a1", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C" + "'", str1.equals("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaa", (int) ' ', "0#1-#81");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0#1-#810#1-#810#1-#810aaaaaaaaaa" + "'", str3.equals("0#1-#810#1-#810#1-#810aaaaaaaaaa"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("  x86_64  ", "ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION", 35);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "4");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "  x86_64  " + "'", str5.equals("  x86_64  "));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "######################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 22 + "'", int1 == 22);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ", " Virtual Machine Specification", "hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Lib", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ" + "'", str4.equals("1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("U", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "U" + "'", str2.equals("U"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10410410041m", "/USERS/SOPHIE/LIBRARY/JAVA/EXTEN");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(33, (int) (byte) 7, 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 33 + "'", int3 == 33);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                   ", (java.lang.CharSequence) "10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        short[] shortArray3 = new short[] { (byte) -1, (short) 100, (byte) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-141004-1" + "'", str6.equals("-141004-1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1#100#-1" + "'", str8.equals("-1#100#-1"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Oracle Corporation");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("10enfalse");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10ENFALSE" + "'", str1.equals("10ENFALSE"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 10, 0.0f, (short) 0, 10.0f };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', (int) (short) 100, 2);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 0, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0410.040.040.0410.0" + "'", str8.equals("-1.0410.040.040.0410.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 4, 0L, (long) 24);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4', (int) (byte) 100, (int) (byte) 1);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "#m#m#m#mam", (int) '#');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION", "MAC OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION" + "'", str2.equals("RACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C" + "'", str3.equals("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        float[] floatArray1 = new float[] { 1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a', 24, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0" + "'", str3.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0" + "'", str5.equals("1.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.0" + "'", str13.equals("1.0"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 10, 0.0f, (short) 0, 10.0f };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', (int) (byte) 4, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0a10.0a0.0a0.0a10.0" + "'", str8.equals("-1.0a10.0a0.0a0.0a10.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("-1a100a-1", "racle Corporati");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/J/a/v/a/ /P/l/a/t/f/o/r/m/ /A/P/I/ /S/p/e/c/i/f/i/c/a/t/i/o/n/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "97 0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("-1a100a-1", "444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a100a-1" + "'", str2.equals("-1a100a-1"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("UTF-8");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "oRACLE CORPORATION", 7, 495);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("HI", (byte) 4);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 4 + "'", byte2 == (byte) 4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("SUN.LWAWT.MACOSX.cpRINTERjO", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjO" + "'", str3.equals("SUN.LWAWT.MACOSX.cpRINTERjO"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10a10a100a1", 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                hi!h", (int) (short) 0, 620);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.1", "1.7.0_80-b15");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "aaaaaaaaaaa104104100aaaaaaaaaaa");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "             10410410              ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aa01#0aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("cosx.cpr ", 1.041041E10f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.041041E10f + "'", float2 == 1.041041E10f);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("4.0 -1.0 10.0", (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.044.040.04100.0435.0", (java.lang.CharSequence) "100 10 -1 -1 100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("######################", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        long[] longArray4 = new long[] { 10L, (byte) 1, 1, 1L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10414141" + "'", str7.equals("10414141"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("CAM14001401401", "10ENFALSE", 468);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("   US   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        java.lang.String str5 = javaVersion2.toString();
        boolean boolean6 = javaVersion0.atLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.3" + "'", str5.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) " ", (java.lang.CharSequence) "              ORACLEaCORPORATION", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("C4", 107);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "C4                                                                                                         " + "'", str2.equals("C4                                                                                                         "));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "ETNIRpc.XSOCAM.TWAWL.NU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", (java.lang.CharSequence) "###10.14.3###10.14.3###10.14.3###10.14.3", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Mac OS X");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "Mac OS X");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray11 = new java.lang.String[] { "", "hi!" };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray8, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("24.80-b11", strArray3, strArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 52, (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "24.80-b11" + "'", str13.equals("24.80-b11"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "#100                                                                                             ", (java.lang.CharSequence) "X.cpRINTE", 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("a#a#a#aaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaat.jar", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 142);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                              " + "'", str2.equals("                                                                                                                                              "));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0", 16, "SUN.LWAWT.MACOSX.cpRINTE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0" + "'", str3.equals("18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "ORACLE 1.", (java.lang.CharSequence) "      0A10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaat.jar", "X86_64SUN.AWT.CGRAPHICSENVIRONMENT", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaat.jar" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaat.jar"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "########a#M", 0, 142);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10410410041mac OS X", "\n");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "0410410041mac OS X0410410041mac OS X0410410041mac OS X0410410041mac OS Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10410410041mac OS X" + "'", str4.equals("10410410041mac OS X"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "########a#M", (java.lang.CharSequence) "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        long[] longArray1 = new long[] { 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        java.lang.Class<?> wildcardClass4 = longArray1.getClass();
        java.lang.Class<?> wildcardClass5 = longArray1.getClass();
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("X86_6", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_6" + "'", str3.equals("X86_6"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        long[] longArray1 = new long[] { (byte) 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray1, '#', 9, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "      Hi!       ", (java.lang.CharSequence) "#4#4#4#4a44");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("cosx.cpr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cosx.cpr" + "'", str1.equals("cosx.cpr"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) (byte) 100, (float) 468);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 468.0f + "'", float3 == 468.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", "Java Platform API Specification", 10);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", "mac OS X", 18);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Aaaaaaaaaa", (java.lang.CharSequence[]) strArray9);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("UTF-8", strArray4, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 7 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) " HotSpot(TM) 64-Bit Server VMavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie#####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8.1" + "'", str1.equals("8.1"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("      Hi!       ", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("10410410", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10410410" + "'", str2.equals("10410410"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4410...", (java.lang.CharSequence) "10ENFALSE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 9740L, 0.0f, (float) 9740L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(14.0d, 14.0d, (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.0d + "'", double3 == 14.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "7.1", 9, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.00101001.052.0", "-1#100#-1", 500);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 7);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 7 + "'", byte3 == (byte) 7);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 14L, (float) 28, (float) 31);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 14.0f + "'", float3 == 14.0f);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("  x86_64  ", "0000aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  x86_64  " + "'", str2.equals("  x86_64  "));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        long[] longArray0 = new long[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '4', (int) (byte) 100, 4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        try {
            long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", "hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Librar");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(8.0d, (double) 1.041041E7f, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray12 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence4, charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "  x86_64  ", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.8", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjO", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "EN", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("oRACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE CORPORATION" + "'", str1.equals("oRACLE CORPORATION"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("RACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION", "UTF-8");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("mIXED MODE");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0000aaaaaaaaaa", 0, "mixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0000aaaaaaaaaa" + "'", str3.equals("0000aaaaaaaaaa"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray13 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone(charSequence5, charArray13);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "  x86_64  ", charArray13);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.8", charArray13);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjO", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray13);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sop10410410041Java Platform API Specification", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0A10.0A0.0A0.0A10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8", "/Users/sophie/Library/Java/E18#-1#0/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "-1a100a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "RACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        double[] doubleArray1 = new double[] { 52.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', (int) 'a', 8);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52.0" + "'", str8.equals("52.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 52.0d + "'", double9 == 52.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 52.0d + "'", double10 == 52.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52.0" + "'", str12.equals("52.0"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("10410410041", "4.0-1.010.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4.0-1.010.0" + "'", str2.equals("4.0-1.010.0"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("cosx.cpr", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("-", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0", "EN##################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0" + "'", str2.equals("1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, '#', (-1), 9740);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("10410410041mac OS X", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("::::::::", "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!", "UTF-897a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "::::::::" + "'", str3.equals("::::::::"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("t.jar", 22, "Aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Aaaaaaaat.jarAaaaaaaaa" + "'", str3.equals("Aaaaaaaat.jarAaaaaaaaa"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("18#-1#0", (int) '4', "x4864_4644sun4.4awt4.4CG4raphics4E4nvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C" + "'", str3.equals("x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                             /444444444                                             ", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                             /444444444                                             " + "'", str3.equals("                                             /444444444                                             "));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        char[] charArray9 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10410410041MAC os x", charArray9);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mIXED MODE", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "#4#4#4#4a44" + "'", str13.equals("#4#4#4#4a44"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 256, 4L, (long) 14);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 256L + "'", long3 == 256L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        float[] floatArray2 = new float[] { (byte) -1, 22 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', (int) (byte) -1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0#22.0" + "'", str5.equals("-1.0#22.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("hi", "MIXED MODE", (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi" + "'", str3.equals("hi"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", " 1.0a100.0", 10);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "Oracle Corporatio");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/" + "'", str7.equals("/"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        long[] longArray1 = new long[] { 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) ' ', (int) (byte) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', (int) (byte) 100, 3);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                       ORACLE CORPORATION                                        ", 22, "1.6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                       ORACLE CORPORATION                                        " + "'", str3.equals("                                       ORACLE CORPORATION                                        "));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0A10.0A0.0A0.0A10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8", (java.lang.CharSequence) "     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "OracleCorporatio", 368);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10", (java.lang.CharSequence) "0A10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(".0_801.7.0_8", (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 7, (short) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a10a100a1" + "'", str8.equals("10a10a100a1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10 10 100 1" + "'", str10.equals("10 10 100 1"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 1 + "'", byte11 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 1 + "'", byte12 == (byte) 1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "CLELCORC-OC5", 107);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("01#0mixedmodemix", 10410410041L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10410410041L + "'", long2 == 10410410041L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/444444444ORACL...ORACL...ORACL.", (java.lang.CharSequence) "macosx.cpr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaa104104100aaaaaaaaaaa", (long) 256);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 256L + "'", long2 == 256L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59", "1.0", "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8", 30);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59" + "'", str4.equals("rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad(" HotSpot(TM) 64-Bit Server VMavaJ", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " HotSpot(TM) 64-Bit Server VMavaJ" + "'", str2.equals(" HotSpot(TM) 64-Bit Server VMavaJ"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("cosx.cpr");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', 495, 33);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "EN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "0000aaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ORACLE 1.", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        short[] shortArray4 = new short[] { (byte) -1, (short) -1, (short) -1, (short) 4 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', 4, 142);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 4 + "'", short5 == (short) 4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.0#100.0", "Macosx.cpr", 96);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("18a-1a0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "18a-1a0" + "'", str1.equals("18a-1a0"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        double[] doubleArray2 = new double[] { 1, 100L };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a100.0" + "'", str4.equals("1.0a100.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        char[] charArray12 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray12);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray12, '4', 1, (int) (short) -1);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray12);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.14.3", charArray12);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!", charArray12);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.1", charArray12);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1m");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "   US   ", (java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        short[] shortArray3 = new short[] { (byte) -1, (short) 100, (byte) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 32, 2);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4', (int) (short) 0, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   /", (java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTE", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("   1.7");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("410410041", "0a10");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(1.8d, (double) 620, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre", "#m#m#m#mam", 468);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a', 28, (int) '4');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 32, (long) 28, 52L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        int[] intArray3 = new int[] { 18, (byte) -1, (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 16, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "18#-1#0" + "'", str5.equals("18#-1#0"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "18a-1a0" + "'", str13.equals("18a-1a0"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) ".0_801.7.0_8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "0.9 -1.0 1.0", (java.lang.CharSequence) "10#1#1#1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "0a10", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("SUN.LWAWT.MACOSX.cpRINTE", "a", 256);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1..", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "Mac OS X");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray12 = new java.lang.String[] { "", "hi!" };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray9, strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("24.80-b11", strArray4, strArray9);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.split("UTF-8");
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray16);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.stripAll(strArray17, "     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9");
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/soprary/Java/Extensions:/usr/lib/java:.", strArray4, strArray19);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "24.80-b11" + "'", str14.equals("24.80-b11"));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "/Users/soprary/Java/Extensions:/usr/lib/java:." + "'", str20.equals("/Users/soprary/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("tionacle CorporaOr", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tionacle CorporaOr" + "'", str2.equals("tionacle CorporaOr"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        long[] longArray1 = new long[] { 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        java.lang.Class<?> wildcardClass4 = longArray1.getClass();
        java.lang.Class<?> wildcardClass5 = longArray1.getClass();
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) '4', 4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100" + "'", str14.equals("100"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("10410410041m", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10410410041m" + "'", str2.equals("10410410041m"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 10, 0.0f, (short) 0, 10.0f };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', (int) 'a', 3);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', 368, 7);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" sun.lwawt.macosx.cprinterjob", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "U", (java.lang.CharSequence) "10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "X86_64SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) (short) 10, (-1));
        java.lang.Class<?> wildcardClass13 = byteArray4.getClass();
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("NOITAROPROCaELCARO", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOITAROPROCaELCARO" + "'", str2.equals("NOITAROPROCaELCARO"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("52.04444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 142, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444452.04444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444452.04444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("4.0 1.0 10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4.0 1.0 10.0" + "'", str1.equals("4.0 1.0 10.0"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("           4.0 1.0 10.0            ", "10a10a100a1                                                                                         ", (int) (byte) 0);
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "mixedmode", 52, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("-1#100#-1", "10.00101001.052.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1#100#-1" + "'", str2.equals("-1#100#-1"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 52, (float) (short) 4, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "t.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaat.jar", (int) (byte) -1, 500);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaat.jar" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaat.jar"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "-1.0 10.0 0.0 0.0 10.0", (java.lang.CharSequence) "97 0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        int[] intArray2 = new int[] { 'a', 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', 3, (int) (short) 1);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "10.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0410410041mac OS X0410410041mac OS X0410410041mac OS X0410410041mac OS Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str6 = javaVersion0.toString();
        java.lang.String str7 = javaVersion0.toString();
        java.lang.String str8 = javaVersion0.toString();
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str10 = javaVersion0.toString();
        java.lang.String str11 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.4" + "'", str8.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.4" + "'", str10.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.4" + "'", str11.equals("1.4"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        double[] doubleArray1 = new double[] { 52.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 0, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "52.0" + "'", str5.equals("52.0"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/J...", (java.lang.CharSequence) "0410410041mac OS X0410410041mac OS X0410410041mac OS X0410410041mac OS Virtual Machine Specification", 368);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "O1.7.0_80-b15racle1.7.0_80-b15 1.7.0_80-b15C1.7.0_80-b15orporation                                  ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporationrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation" + "'", str1.equals("oracle corporationrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("18#-1#018#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "18#-1#018#" + "'", str1.equals("18#-1#018#"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0", 24, "SUN.LWAWT.MACOSX.cpRINTERjOB       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0" + "'", str3.equals("18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        double[] doubleArray1 = new double[] { 52.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', (int) 'a', 8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 1, (int) (short) 0);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', (int) (short) 1, 256);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 52.0d + "'", double11 == 52.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "52.0" + "'", str13.equals("52.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 52.0d + "'", double14 == 52.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59" + "'", str2.equals("rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporati", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "O1.7.0_80-b15racle1.7.0_80-b151.7.0_80-b15C1.7.0_80-b15orporation", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("   SU   ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation", (java.lang.CharSequence) "4.0 1.0 10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10 10 100 1", (int) (short) 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10 10 100 1" + "'", str3.equals("10 10 100 1"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(6, 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("44444444444444451.04444444444444444", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (byte) 4);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 4 + "'", byte2 == (byte) 4);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "10.0410.0452.0410.040.0410.0", (java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "SUN.LWAWT.MACOSX.cpRINTERjO");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("97a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("ORACLEaCORPORATION", "1", "   1.7", 24);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ORACLEaCORPORATION" + "'", str4.equals("ORACLEaCORPORATION"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("410410041", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("mIXED MODE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mIXED MODE" + "'", str1.equals("mIXED MODE"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1", "Oracle Corporati");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporati" + "'", str2.equals("Oracle Corporati"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        double[] doubleArray3 = new double[] { 0.9d, (-1), 1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.9 -1.0 1.0" + "'", str5.equals("0.9 -1.0 1.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.94-1.041.0" + "'", str7.equals("0.94-1.041.0"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/E18#-1#0", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                hi!h", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Aaaaaaaaaa", (int) 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#######################################################################################Aaaaaaaaaa" + "'", str3.equals("#######################################################################################Aaaaaaaaaa"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mac OS X", (java.lang.CharSequence) "1.1", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "aa01#0aa", "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "18#-1#018#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 410.0d, (double) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("            10 10 100 1            ", "8.1", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "           4.0 1.0 10.0            ", (java.lang.CharSequence) "10.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("http://java.oracle.com/", "#100", "", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "http://java.oracle.com/" + "'", str4.equals("http://java.oracle.com/"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        float[] floatArray6 = new float[] { 10L, 10, '4', 10L, (short) 0, 10L };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ', 14, 10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 52.0f + "'", float8 == 52.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0 10.0 52.0 10.0 0.0 10.0" + "'", str10.equals("10.0 10.0 52.0 10.0 0.0 10.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10.0 10.0 52.0 10.0 0.0 10.0" + "'", str16.equals("10.0 10.0 52.0 10.0 0.0 10.0"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        long[] longArray4 = new long[] { 10L, (byte) 1, 1, 1L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10414141" + "'", str7.equals("10414141"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10 1 1 1" + "'", str10.equals("10 1 1 1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4', 10, (int) (byte) 10);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "X.cpRINTE");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: X.cpRINTE");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 1 + "'", byte13 == (byte) 1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/", "Mac OS X");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        java.lang.Class<?> wildcardClass7 = strArray4.getClass();
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Oracle Corporatio", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##################", "");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, '4', (int) ' ', 18);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("aaaaaaaaaa", strArray4, strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/" + "'", str6.equals("/"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "aaaaaaaaaa" + "'", str16.equals("aaaaaaaaaa"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Librar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRAR" + "'", str1.equals("HIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRAR"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        char[] charArray12 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "en", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sunalwawtamacosxacprinterjob", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', 0, 2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("ORACLECORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLECORPORATION" + "'", str1.equals("ORACLECORPORATION"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        float[] floatArray6 = new float[] { 10L, 10, '4', 10L, (short) 0, 10L };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ', 14, 10);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ', 24, 2);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        float float21 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 52.0f + "'", float8 == 52.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0 10.0 52.0 10.0 0.0 10.0" + "'", str10.equals("10.0 10.0 52.0 10.0 0.0 10.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10.0410.0452.0410.040.0410.0" + "'", str20.equals("10.0410.0452.0410.040.0410.0"));
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 52.0f + "'", float21 == 52.0f);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                       ORACLE CORPORATION                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE CORPORATION" + "'", str1.equals("ORACLE CORPORATION"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                hi!h", (java.lang.CharSequence) "Sun.lwawt.", 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.7.0_80100", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80100" + "'", str2.equals("1.7.0_80100"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("###10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "#######################################################################################Aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hi!", "x86_64sun.awt.CGraphicsEnvironment", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "co!" + "'", str3.equals("co!"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("###10.14.3", "SUN.LWAWT.MACOSX.cpRINTERj");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "###10.14.3" + "'", str4.equals("###10.14.3"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 100, (float) 97L, (float) 8);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4");
        java.math.BigInteger bigInteger3 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        java.math.BigInteger bigInteger5 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        java.math.BigInteger bigInteger7 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4");
        java.math.BigInteger[] bigIntegerArray8 = new java.math.BigInteger[] { bigInteger1, bigInteger3, bigInteger5, bigInteger7 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(bigIntegerArray8);
        org.junit.Assert.assertNotNull(bigInteger1);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigIntegerArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str9.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "X86_64SUN.AWT.CGRAPHICSENVIRONMENT", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("h", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.11.11.11.1", (int) (short) 10, "X.cpRINTE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.11.11.11.1" + "'", str3.equals("1.11.11.11.1"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("51.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("10enfals", "01#0", (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10enfals" + "'", str3.equals("10enfals"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10a10a100a1                                                                                         ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10101001                                                                                         " + "'", str2.equals("10101001                                                                                         "));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "-1.0#22.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        float[] floatArray3 = new float[] { 4, (-1), 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "4.0 -1.0 10.0" + "'", str5.equals("4.0 -1.0 10.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4.0a-1.0a10.0" + "'", str9.equals("4.0a-1.0a10.0"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("sun.lwawt.", "# # # # a 4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt." + "'", str2.equals("sun.lwawt."));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "C4                                                                                                         ", (java.lang.CharSequence) "1004104-14-14100", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Aaaaaaaat.jarAaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 3, 1.100000023841858d, (double) 96);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 96.0d + "'", double3 == 96.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "1m", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "Mac OS X");
        java.lang.CharSequence charSequence4 = null;
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence4, (java.lang.CharSequence[]) strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("Hi!", strArray3, strArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "hi/444444444");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Hi!" + "'", str10.equals("Hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("10 1 1 1", "44444444444444451.04444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 1 1 1" + "'", str2.equals("10 1 1 1"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 19, 500L, (long) 8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 500L + "'", long3 == 500L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("      Hi!       ", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      Hi!       " + "'", str2.equals("      Hi!       "));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("  x86_64", 468);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  x86_64" + "'", str2.equals("  x86_64"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSX", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "                                                                                                                                              ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.", "10                                                                                                  ", 97, 368);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.10                                                                                                  " + "'", str4.equals("10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.10                                                                                                  "));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                hi!h", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   /");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                hi!h" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                hi!h"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaa" + "'", str2.equals("aaaaaaaa"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean9 = javaVersion6.atLeast(javaVersion8);
        boolean boolean10 = javaVersion3.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean12 = javaVersion8.atLeast(javaVersion11);
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("RO", "          X.cpRINTE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          X.cpRINTE" + "'", str2.equals("          X.cpRINTE"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION" + "'", str1.equals("oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 10 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "10410410");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 10410410");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a10" + "'", str5.equals("0a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h" + "'", str2.equals("h"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("18#-1#018#", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "UTF-897a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", 500, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", "10410410041MAC os x", (int) '4');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C", 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C" + "'", str3.equals("x4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4Cx4864_4644sun4.4awt4.418#-1#0x4864_4644sun4.4awt4.4C"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("###10.14.3");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("-1a100a", "co!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a100a" + "'", str2.equals("-1a100a"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.3", (int) (byte) 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("4", (double) (short) 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.6", "###10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }
}

