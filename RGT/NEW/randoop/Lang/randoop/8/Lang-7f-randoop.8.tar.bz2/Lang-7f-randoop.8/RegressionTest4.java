import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        long[] longArray1 = new long[] { 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ', 12, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10a10a100a1                                                                                         ", "/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Librar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/librar" + "'", str1.equals("hie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/librar"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("     0.9", "    ", "/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                   ", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        int[] intArray2 = new int[] { 'a', 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        int[] intArray2 = new int[] { 'a', 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "97a0" + "'", str7.equals("97a0"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("    ", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aa01#0aa", "Java(TM) SE Runtime Environment", 7);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Oracle Corporation", (int) (short) 10, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1 100 -1", (java.lang.CharSequence) "RO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("CAM14001401401", (float) 14L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 14.0f + "'", float2 == 14.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("#m#m#m#mam");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10a10a100a1", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 378 + "'", int1 == 378);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.0a100.", "1.0a100.0", "t.jar");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "10ENFALSE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "#a#a#a#aaa4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                                                                 1.7", "1..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.." + "'", str2.equals("1.."));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("#M#M#M#MaM");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("18#-1#0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("UTF-8", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("10enfalse");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10enfals" + "'", str1.equals("10enfals"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("EN##################################################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "EN##################################################" + "'", str2.equals("EN##################################################"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.044.040.04100.0435.0", 0, "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.044.040.04100.0435.0" + "'", str3.equals("1.044.040.04100.0435.0"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Lib", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("10enfals", "ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10enfals" + "'", str2.equals("10enfals"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION" + "'", str1.equals("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("#4#4#4#4a44", "", (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#4#4#4#4a44" + "'", str3.equals("#4#4#4#4a44"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("#100", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#100#100#100#100#100#100#100" + "'", str2.equals("#100#100#100#100#100#100#100"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0aSUN.AWT.cgRAPHICSeNVIRONMENT0", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0aSUN.AWT.cgRAPHICSeNVIRONMENT0" + "'", str2.equals("0aSUN.AWT.cgRAPHICSeNVIRONMENT0"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTEN", "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "aaaaaaaaaa", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(2, (int) (byte) 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERj", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", (java.lang.CharSequence) "1UN.LWAWT.MACO1X.cpRINTERjOB       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80100", (java.lang.CharSequence) "                                             /444444444                                             ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "::::::::", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1.044.040.04100.0435.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.044.040.04100.0435.0" + "'", str1.equals("1.044.040.04100.0435.0"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("7", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7" + "'", str2.equals("7"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "ORACLECORPORATION", (java.lang.CharSequence) "10#10#100#1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        int[] intArray2 = new int[] { 'a', 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9740" + "'", str7.equals("9740"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Oracle Corporatio", (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("MAC OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS X" + "'", str1.equals("MAC OS X"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.0a100.0", (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        char[] charArray8 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', 1, (int) (short) -1);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray8);
        java.lang.Class<?> wildcardClass15 = charArray8.getClass();
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("10 10 100", "oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Macosx.cpr", "1.1", "97 0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Macosx.cpr" + "'", str3.equals("Macosx.cpr"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ORACLECORPORATION", (java.lang.CharSequence) "11b-08.42", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart(" ", "#a#a#a#aaa4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("JAVA(TM) SE RUNTIME ENVIRONMENT", "10#10#100#1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA(TM) SE RUNTIME ENVIRONMENT" + "'", str2.equals("JAVA(TM) SE RUNTIME ENVIRONMENT"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.7.0_80100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80100" + "'", str1.equals("1.7.0_80100"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("0aSUN.AWT.cgRAPHICSeNVIRONMENT0", "1.7", "hi");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("SUN.LWAWT.MACOSX.cpRINTERjO");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 12, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 35.0f, (double) (short) 4, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("-1.0a10.0a0.0a0.0a10.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("-1#100#-1");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        float[] floatArray5 = new float[] { 1L, (short) 4, (byte) 0, 100, 35L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.044.040.04100.0435.0" + "'", str7.equals("1.044.040.04100.0435.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1UN.LWAWT.MACO1X.cpRINTERjOB       ", (java.lang.CharSequence) "#4#4#4#4a44");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80100", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "RO", (java.lang.CharSequence) "Oracle Corporation", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.0a100.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0a100." + "'", str1.equals("1.0a100."));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-141004-1");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.Class<?> wildcardClass3 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-141004-1" + "'", str2.equals("-141004-1"));
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        char[] charArray8 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', 1, (int) (short) -1);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "#m#m#m#mam", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) 'a', 16, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Java(TM) SE Runtime Environment", "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        short[] shortArray5 = new short[] { (byte) 100, (short) 10, (short) -1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 10 -1 -1 100" + "'", str7.equals("100 10 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004104-14-14100" + "'", str10.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1004104-14-14100" + "'", str14.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "100a10a-1a-1a100" + "'", str16.equals("100a10a-1a-1a100"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("X86_64SUN.AWT.CGRAPHICSENVIRONMENT", 378, "100 10 -1 -1 100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_64SUN.AWT.CGRAPHICSENVIRONMENT100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -" + "'", str3.equals("X86_64SUN.AWT.CGRAPHICSENVIRONMENT100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/444444444ORACL...ORACL...ORACL.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 4, (float) 4, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1#100#-1", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1#100#-1", "x so CAM14001401401", (int) (byte) 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "######################", (int) (short) 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java Platform API Specification", "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10 10 100 1", 14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/", "Mac OS X");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 18, (int) (short) 1);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.4", (java.lang.CharSequence[]) strArray3);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str6 = javaVersion0.toString();
        java.lang.String str7 = javaVersion0.toString();
        java.lang.String str8 = javaVersion0.toString();
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.Class<?> wildcardClass10 = javaVersion0.getClass();
        java.lang.String str11 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.4" + "'", str8.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.4" + "'", str11.equals("1.4"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie", "4.0 1.0 10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION", "sun.awt.CGraphicsEnvironment", (int) '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "SUN.LWAWT.MACOSX.cpRINTERjOB", (int) (byte) 1, 0);
        java.lang.String[] strArray11 = new java.lang.String[] {};
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("10414141", strArray4, strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION" + "'", str6.equals("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10414141" + "'", str13.equals("10414141"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("MAC OS X", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "10101001", (java.lang.CharSequence) "-1.0a10.0a0.0a0.0a10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "/", 9740);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Lib");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hie/Lib\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(32L, (long) 0, (long) 12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("cosx.cpr", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "10 10 100 ", (java.lang.CharSequence) "97 0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "   US   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        float[] floatArray0 = new float[] {};
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("ORACLE 1.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', (int) (byte) -1, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast(" HotSpot(TM) 64-Bit Server VMavaJ", "-1 100 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 14L, 0.0d, (double) 9.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("S", " HotSpot(TM) 64-Bit Server VMavaJ", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) 10, (short) (byte) 4);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 4 + "'", short3 == (short) 4);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("46_68x", "X86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x" + "'", str2.equals("x"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray11, '4', 1, (int) (short) -1);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray11);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!", charArray11);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aa01#0aa", "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("x so CAM14001401401", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x so CAM14001401401" + "'", str2.equals("x so CAM14001401401"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("S");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"S\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10a10a100a1                                                                                         ", "X86_64SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Macosx.cpr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Macosx.cpr" + "'", str1.equals("Macosx.cpr"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("hhhhhhhhhhhhhhhhhhhhhhhhhhhhh1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hhhhhhhhhhhhhhhhhhhhhhhhhhhhh1.4" + "'", str1.equals("hhhhhhhhhhhhhhhhhhhhhhhhhhhhh1.4"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("410410041", "9740");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "410410041" + "'", str2.equals("410410041"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 97, (long) 0, (long) (short) 4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          " + "'", str1.equals("          "));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335", "O1.7.0_80-b15racle1.7.0_80-b15 1.7.0_80-b15C1.7.0_80-b15orporation                                  ", "-1.0410.040.040.0410.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.8", "97a0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "104104100", (java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("0A10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0A10" + "'", str1.equals("0A10"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("444444444444444444", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444" + "'", str2.equals("444444444444444444"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/uSERS/SOPHIE/lIBRARY/jAVA/eXTEN");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull(" 1.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0a100.0" + "'", str1.equals("1.0a100.0"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "10414141", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("hhhhhhhhhhhhhhhhhhhhhhhhhhhhh1.4");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((-1), (-1), 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("sophie", "# # # # a 4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("         ", (int) 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############################################         ############################################" + "'", str3.equals("############################################         ############################################"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("X86_64SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_64SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str1.equals("X86_64SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("S", "10410410041MAC os x", "MCAM4A3MCAM4A3MCAM4A3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "S" + "'", str3.equals("S"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Mac OS X", (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("-1.041.0", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.041.0" + "'", str2.equals("-1.041.0"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hhhhhhhhhhhhhhhhhhhhhhhhhhhhh1.4", "01#0", "MCAM4A3MCAM4A3MCAM4A3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhC.4" + "'", str3.equals("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhC.4"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("############################################         ############################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: ############################################         ############################################ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("10101001", "1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10101001" + "'", str2.equals("10101001"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/uSERS/SOPHIE/lIBRARY/jAVA/eXTEN");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTEN" + "'", str1.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTEN"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Library/Java/J...", "10                                                                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/J..." + "'", str2.equals("/Library/Java/J..."));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        float[] floatArray1 = new float[] { 1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0" + "'", str3.equals("1.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.lwawt.macosx.CPrinterJob", "cosx.cpr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Oracle Corporatio", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporatio" + "'", str2.equals("Oracle Corporatio"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Hi!", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      Hi!       " + "'", str2.equals("      Hi!       "));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "US");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 7, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "10 10 100 1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10enfals", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "52.0", "/444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("10410410041MAC os x", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10410410041MAC os x" + "'", str2.equals("10410410041MAC os x"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        long[] longArray4 = new long[] { 10L, (byte) 1, 1, 1L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10414141" + "'", str7.equals("10414141"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10414141" + "'", str9.equals("10414141"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "410410041");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 410410041");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a10a100a1" + "'", str8.equals("10a10a100a1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10410410041" + "'", str10.equals("10410410041"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("mac os x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "macosx" + "'", str1.equals("macosx"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("ORACLE CORPORATION", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                       ORACLE CORPORATION                                        " + "'", str2.equals("                                       ORACLE CORPORATION                                        "));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "ORACLEaCORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1.0410.040.040.0410.0", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "x86_64sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "Macosx.cpr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0.9", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        org.apache.commons.lang3.StringUtils stringUtils0 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils1 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils2 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils3 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils4 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils[] stringUtilsArray5 = new org.apache.commons.lang3.StringUtils[] { stringUtils0, stringUtils1, stringUtils2, stringUtils3, stringUtils4 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(stringUtilsArray5);
        org.junit.Assert.assertNotNull(stringUtilsArray5);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10410410041MAC os x", 4, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10410410041MAC os x" + "'", str3.equals("10410410041MAC os x"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1" + "'", str2.equals("-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("-1.0410.040.040.0410.0-1.0410.040.040.0410.0-1.0410.", "", "tionacle CorporaOr");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0410.040.040.0410.0-1.0410.040.040.0410.0-1.0410." + "'", str3.equals("-1.0410.040.040.0410.0-1.0410.040.040.0410.0-1.0410."));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "mac OS X", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("ORACLE 1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE 1." + "'", str1.equals("ORACLE 1."));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10", (double) 10410410041L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 30, 0.0f, (float) '4');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1L, (double) 28, (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.0d + "'", double3 == 28.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335", (java.lang.CharSequence) "ORACLE 1.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString(" HotSpot(TM) 64-Bit Server VMavaJ", "macosx");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " HotSpot(TM) 64-Bit Server VMavaJ" + "'", str2.equals(" HotSpot(TM) 64-Bit Server VMavaJ"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) 'a', "4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("104104100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10410410" + "'", str1.equals("10410410"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        long[] longArray1 = new long[] { (byte) 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) ' ', (int) (byte) 4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("            10 10 100 1            ", "1.044.040.04100.0435.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            10 10 100 1            " + "'", str2.equals("            10 10 100 1            "));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.5", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("MAC OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac os x" + "'", str1.equals("mac os x"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "ORACL...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "9740", (java.lang.CharSequence) "97 0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "######################", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.11.11.11.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "", 12, 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 9, (float) 2, (float) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "-1.041.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        org.apache.commons.lang3.StringUtils stringUtils0 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils1 = new org.apache.commons.lang3.StringUtils();
        java.lang.Class<?> wildcardClass2 = stringUtils1.getClass();
        org.apache.commons.lang3.StringUtils stringUtils3 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils4 = new org.apache.commons.lang3.StringUtils();
        java.lang.Class<?> wildcardClass5 = stringUtils4.getClass();
        org.apache.commons.lang3.StringUtils[] stringUtilsArray6 = new org.apache.commons.lang3.StringUtils[] { stringUtils0, stringUtils1, stringUtils3, stringUtils4 };
        org.apache.commons.lang3.StringUtils[][] stringUtilsArray7 = new org.apache.commons.lang3.StringUtils[][] { stringUtilsArray6 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(stringUtilsArray7);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(stringUtilsArray6);
        org.junit.Assert.assertNotNull(stringUtilsArray7);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("100 10 -1 -1 100", "aa01#0aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 10 -1 -1 100" + "'", str2.equals("100 10 -1 -1 100"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("97 0", (float) 32L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "#100", (java.lang.CharSequence) "rs/_v/6v59");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                 ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Java Virtual Machine SpecificationJava Virtual Ma1.0", (java.lang.CharSequence) "X86_64SUN.AWT.CGRAPHICSENVIRONMENT100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "  x86_64  ", "0A10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode" + "'", str1.equals("mixed mode"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "11b-08.42", (java.lang.CharSequence) "ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10a10a100a1", 28, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("44444444444444451.04444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444451.04444444444444444" + "'", str1.equals("44444444444444451.04444444444444444"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Lib", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("10.14.3", (float) 52L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("http://java.oracle.com/", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("SUN.AWT.cgRAPHICSeNVIRONMENT", "SUN.LWAWT.MACOSX.cpRINTERj", "Oracle Corporati");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str3.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("4410444444444", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4410..." + "'", str2.equals("4410..."));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac OS X" + "'", str1.equals("mac OS X"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("10410410041mac OS X");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Oracle Corporation");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a10a100a1" + "'", str8.equals("10a10a100a1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10 10 100 1" + "'", str10.equals("10 10 100 1"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                   ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 2.0f, 9740.0d, (double) 97L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9740.0d + "'", double3 == 9740.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " HotSpot(TM) 64-Bit Server VMavaJ", 0, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(" 1.0a100.0", 22.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 22.0f + "'", float2 == 22.0f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        double[] doubleArray2 = new double[] { 1, 100L };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ', 14, 4);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a100.0" + "'", str4.equals("1.0a100.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.0#100.0" + "'", str12.equals("1.0#100.0"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "10");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray5, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " ", (java.lang.CharSequence[]) strArray5);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "a");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Library/Java/J...", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION", (float) 500L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 500.0f + "'", float2 == 500.0f);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("SUN.LWAWT.MACOSX.cpRINTE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ETNIRpc.XSOCAM.TWAWL.NUS" + "'", str1.equals("ETNIRpc.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-1.0a10.0a0.0a0.0a10.0", 500, "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8" + "'", str3.equals("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Macosx.cpr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "rpc.xsocaM" + "'", str1.equals("rpc.xsocaM"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "-1a100a-1", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "10.0 10.0 52.0 10.0 0.0 10.0", (java.lang.CharSequence) "CLELCORC-OC5");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("RO", (int) (byte) -1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10", (java.lang.CharSequence) "hi!h");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java Virtual Machine SpecificationJava Virtual Ma1.0", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ" + "'", str2.equals("1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("oRACLECORPORATION", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLECORPORATION" + "'", str2.equals("oRACLECORPORATION"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils1 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils2 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils3 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray4 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils0, numberUtils1, numberUtils2, numberUtils3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray4);
        org.junit.Assert.assertNotNull(numberUtilsArray4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "10101001", 500, 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        char[] charArray9 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10410410041MAC os x", charArray9);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "h", charArray9);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', (int) ' ', 0);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "#4#4#4#4a44" + "'", str13.equals("#4#4#4#4a44"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        short[] shortArray3 = new short[] { (byte) -1, (short) 100, (byte) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "hie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/librar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.0a100.0", (java.lang.CharSequence) "104104100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "  x86_64  ", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.8", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "X86_64SUN.AWT.CGRAPHICSENVIRONMENT", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("ORACLEaCORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLEaCORPORATION" + "'", str1.equals("ORACLEaCORPORATION"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sun.awt.CGraphicsEnvironment", 28, 22);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...GraphicsEnvironment" + "'", str3.equals("...GraphicsEnvironment"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "X86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "11b-08.42");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mac OS X", (java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("0aSUN.AWT.cgRAPHICSeNVIRONMENT0", 500);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0aSUN.AWT.cgRAPHICSeNVIRONMENT0" + "'", str2.equals("0aSUN.AWT.cgRAPHICSeNVIRONMENT0"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        short[] shortArray3 = new short[] { (byte) -1, (short) 100, (byte) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1#100#-1" + "'", str6.equals("-1#100#-1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a100a-1" + "'", str8.equals("-1a100a-1"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Library/Java/E18#-1#0/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "10414141");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "#a#a#a#aaa4", (java.lang.CharSequence) "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("ORACLEaCORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOITAROPROCaELCARO" + "'", str1.equals("NOITAROPROCaELCARO"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("macosx.cpr", (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("ETNIRpc.XSOCAM.TWAWL.NUS", "Java Virtual Machine SpecificationJava Virtual Ma1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ETNIRpc.XSOCAM.TWAWL.NU" + "'", str2.equals("ETNIRpc.XSOCAM.TWAWL.NU"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("44444444444444451.04444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("X86_64SUN.AWT.CGRAPHICSENVIRONMENT100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_64SUN.AWT.CGRAPHICSENVIRONMENT100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -" + "'", str1.equals("X86_64SUN.AWT.CGRAPHICSENVIRONMENT100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "CAM14001401401");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("-1.0410.040.040.0410.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "NOITAROPROCaELCARO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "###10.14.3", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 52, 378);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("   US   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"   US   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("10 10 100 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 10 100" + "'", str1.equals("10 10 100"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.5", "h", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("4.0 1.0 10.0", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4.0 1.0 10.0" + "'", str2.equals("4.0 1.0 10.0"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10a10a100a1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        short[] shortArray5 = new short[] { (byte) 100, (short) 10, (short) -1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 10 -1 -1 100" + "'", str7.equals("100 10 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004104-14-14100" + "'", str10.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.7", 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("10101001");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10101001" + "'", str1.equals("10101001"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java Platform API Specification", "", (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4410...", "0a10", "ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44:n..." + "'", str3.equals("44:n..."));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("mIXED MODE", 0, "1..");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mIXED MODE" + "'", str3.equals("mIXED MODE"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                       ORACLE CORPORATION                                        ", (java.lang.CharSequence) "100a10a-1a-1a100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mac OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Java Platform API Specification", "", "/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/J/a/v/a/ /P/l/a/t/f/o/r/m/ /A/P/I/ /S/p/e/c/i/f/i/c/a/t/i/o/n/" + "'", str3.equals("/J/a/v/a/ /P/l/a/t/f/o/r/m/ /A/P/I/ /S/p/e/c/i/f/i/c/a/t/i/o/n/"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "CLELCORC-OC5", (java.lang.CharSequence) "hie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/librar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x", (java.lang.CharSequence) "100#10#-1#-1#100", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                   ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", "1.7.0_80100", 97);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "10                                                                                                  ", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "######################", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 4, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 4 + "'", short3 == (short) 4);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "ETNIRpc.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("#4#4#4#4a44", "Oracle Corporatio");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("############################################         ############################################", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         " + "'", str2.equals("         "));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "    ", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "t.jar", (java.lang.CharSequence) "4444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Oracle Corporati", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "racle Corporati" + "'", str2.equals("racle Corporati"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/444444444ORACL...ORACL...ORACL.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".LCARO...LCARO...LCARO444444444/" + "'", str1.equals(".LCARO...LCARO...LCARO444444444/"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("52.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "0#1-#81", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "#a#a#a#aaa4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1..", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.." + "'", str2.equals("1.."));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10101001", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTEN", (java.lang.CharSequence) "h", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Platform API Specification", (int) '4', "/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sop10410410041Java Platform API Specification" + "'", str3.equals("/Users/sop10410410041Java Platform API Specification"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-B15" + "'", str1.equals("1.7.0_80-B15"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray12 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence4, charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "  x86_64  ", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.8", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjO", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray12);
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray12, '#', (int) (short) 4, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 4, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 4 + "'", byte3 == (byte) 4);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.9", "         ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1004104-14-14100", (java.lang.CharSequence) "10a10a100a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.044.040.04100.0435.0", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.044.040.04100.0435.0" + "'", str2.equals("1.044.040.04100.0435.0"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 10, (float) (byte) 0, (float) 22);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "10enfals", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("CLELCORC-OC5", "SUN.LWAWT.MACOSX.cpRINTERjO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CLELCORC-OC5" + "'", str2.equals("CLELCORC-OC5"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444444444", (java.lang.CharSequence) "ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION", 97, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhC.4", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhC.4" + "'", charSequence2.equals("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhC.4"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str6 = javaVersion0.toString();
        java.lang.String str7 = javaVersion0.toString();
        java.lang.String str8 = javaVersion0.toString();
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean13 = javaVersion10.atLeast(javaVersion12);
        boolean boolean14 = javaVersion0.atLeast(javaVersion10);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.4" + "'", str8.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "x so CAM14001401401");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "10.0410.0452.0410.040.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("44:n...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44:n...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "44444444444444451.04444444444444444", (java.lang.CharSequence) "JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "10414141");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "ORACLE CORPORATION", (java.lang.CharSequence) "100 10 -1 -1 100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("4410...", (byte) 4);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 4 + "'", byte2 == (byte) 4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.1", "444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "444444444444444444", (java.lang.CharSequence) "44444444444444444444444444444444444", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("-1a100a-1", "mac os x", 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1" + "'", str3.equals("-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("100 10 -1 -1 100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100 10 -1 -1 100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("ORACLECORPORATION", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        double[] doubleArray1 = new double[] { 52.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', (int) 'a', 8);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 35, 24);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 21, (int) (byte) -1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52.0" + "'", str8.equals("52.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(" sun.lwawt.macosx.cprinterjob", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " sun.lwawt.macosx.cprinterjob" + "'", str2.equals(" sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        int[] intArray2 = new int[] { 'a', 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', 7, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97a0" + "'", str9.equals("97a0"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!", (java.lang.CharSequence) "  x86_64  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Mixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "rs/_v/6v59", (java.lang.CharSequence) "mIXED MODE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("...GraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaa" + "'", str1.equals("Aaaaaaaaaa"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("EN##################################################", "UTF-8", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10410410041", "-1 100 -1", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10410410041" + "'", str5.equals("10410410041"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "rs/_v/6v59", (java.lang.CharSequence) "JavaUPlatfermU/PIUSpecificatien");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("         ", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("11b-08.42", "1.7.0_80-b15");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION" + "'", str1.equals("oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("#4#4#4#4a44");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10410410041", (java.lang.CharSequence) "aa01#0aa", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("mixedmode", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedmode" + "'", str2.equals("mixedmode"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        long[] longArray4 = new long[] { 10L, (byte) 1, 1, 1L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10414141" + "'", str7.equals("10414141"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10414141" + "'", str9.equals("10414141"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!", "#4#4#4#4a44");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!" + "'", str2.equals("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10a10a100a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 500, (float) (short) 1, (float) 6);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 500.0f + "'", float3 == 500.0f);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10410410041L, (double) (-1), (double) 52L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("##################", "########a#4");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("10101001");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10101001" + "'", str1.equals("10101001"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("01#0", "SUN.LWAWT.MACOSX.cpRINTE", "4.0 -1.0 10.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10.0a10.0a52.0a10.0a0.0a10.0", (int) (byte) 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("0A10", "-1.0a10.0a0.0a0.0a10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0A10" + "'", str2.equals("0A10"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4410444444444", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "EN", (java.lang.CharSequence) "-1#100#-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335", "52.0");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Aaaaaaaaaa", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/J...", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("10410410", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             10410410              " + "'", str2.equals("             10410410              "));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("\n", "h", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("rs/_v/6v59", 33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59" + "'", str2.equals("rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.7", "4.0 1.0 10.0", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4.0-1.010.", (java.lang.CharSequence) "10410410041");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("10.0410.0452.0410.040.0410.0", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0410.0452.0410.040.0410.0" + "'", str2.equals("10.0410.0452.0410.040.0410.0"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("#100", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#100                                                                                             " + "'", str2.equals("#100                                                                                             "));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("en", 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "########en" + "'", str3.equals("########en"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "-", (java.lang.CharSequence) "-1.041.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhC.4", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhC.4" + "'", str2.equals("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhC.4"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "97.0a9.0", (java.lang.CharSequence) "44444444444444451.04444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(10.0f, 4.0f, 1.041041E10f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("44444444444444444444444444444444444", "#M#M#M#MaM", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "\n", (java.lang.CharSequence) "10enfalse");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "10enfals");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("41.0a100.0", "1.0#100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "41.0a100.0" + "'", str2.equals("41.0a100.0"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("46_68x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "46_68x" + "'", str1.equals("46_68x"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" sun.lwawt.macosx.cprinterjob", "/Users/sophie/Library/Java/E18#-1#0/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "#M#M#M#MaM", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.0a10.0a52.0a10.0a0.0a10.0", "racle Corporati");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("18#-1#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "18#-1#0" + "'", str1.equals("18#-1#0"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "         ", (java.lang.CharSequence) "104104100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("97a0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97a0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("SX.cpRINTE", "oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/J/a/v/a/ /P/l/a/t/f/o/r/m/ /A/P/I/ /S/p/e/c/i/f/i/c/a/t/i/o/n/", (java.lang.CharSequence) "10ENFALSE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        float[] floatArray5 = new float[] { 1L, (short) 4, (byte) 0, 100, 35L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.044.040.04100.0435.0" + "'", str7.equals("1.044.040.04100.0435.0"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) (short) 10, (-1));
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', 2, 2);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "-");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: -");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (byte) 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.0 10.0 52.0 10.0 0.0 10.0", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str6 = javaVersion0.toString();
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("EN", "    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "EN" + "'", str2.equals("EN"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("             10410410              ", "10101001");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             10410410              " + "'", str2.equals("             10410410              "));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "     0.9", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9" + "'", str3.equals("     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4', 24, (int) '4');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("US", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 21, (long) '#');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "Mac OS X");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "   US   ", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("100", (int) '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1004444444444444444444444444444444444444444444444444" + "'", str3.equals("1004444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10", 9740);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        short[] shortArray3 = new short[] { (byte) -1, (short) 100, (byte) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 100, 0);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1#100#-1" + "'", str6.equals("-1#100#-1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a100a-1" + "'", str8.equals("-1a100a-1"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10a10a100a1", "ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "-1.0a10.0a0.0a0.0a10.0");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Aaaaaaaaaa", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("10", "104104100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        float[] floatArray6 = new float[] { 10L, 10, '4', 10L, (short) 0, 10L };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', (int) 'a', (int) (byte) 0);
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float14 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 52.0f + "'", float8 == 52.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 52.0f + "'", float13 == 52.0f);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.8", (int) (byte) 100, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.84444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("1.84444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" ", " ");
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "##################", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                             /444444444                                             ", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "aaaaaaaaaa");
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Oracle Corporation");
        boolean boolean14 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Mixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode", (java.lang.CharSequence[]) strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray5, strArray13);
        java.lang.Class<?> wildcardClass16 = strArray13.getClass();
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 18 + "'", int6 == 18);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Librar", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Librar" + "'", str2.equals("/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Librar"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 9740, 100L, (long) 3);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9740L + "'", long3 == 9740L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "oRACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("410410041", "10 10 100 ", "01#0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "410410041" + "'", str3.equals("410410041"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aa01#0aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa01#0aa" + "'", str1.equals("aa01#0aa"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "O1.7.0_80-b15racle1.7.0_80-b15 1.7.0_80-b15C1.7.0_80-b15orporation", "                                             /444444444                                             ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("4.0 1.0 10.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##################", "");
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "ORACLE CORPORATION", (java.lang.CharSequence[]) strArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "NOITAROPROC ELCARO", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION" + "'", str2.equals("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sunalwawtamacosxacprinterjob", (java.lang.CharSequence) "#100#100#100#100#100#100#100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80-b15", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("cosx.cpr", "SX.cpRINTE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cosx.cpr" + "'", str2.equals("cosx.cpr"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Oracle Corporati", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        short[] shortArray3 = new short[] { (byte) -1, (short) 100, (byte) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', (int) (short) 1, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "h", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "...GraphicsEnvironment", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10a10a100a1", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10a10a100a1" + "'", charSequence2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10a10a100a1"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "######################", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhC.4", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "9740");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "C4" + "'", str3.equals("C4"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("97 0", 31, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        float[] floatArray1 = new float[] { 1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0" + "'", str3.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0" + "'", str5.equals("1.0"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("###10.14.3", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION", (java.lang.CharSequence) "     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10#1#1#1", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "444444444444444444", (java.lang.CharSequence) "hi!h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "41.0a100.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sunalwawtamacosxacprinterjob");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("h", "CLELCORC-OC5", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("52.0", "CAM14001401401");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52.0" + "'", str2.equals("52.0"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray12 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence4, charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ETNIRpc.XSOCAM.TWAWL.NU", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        int[] intArray3 = new int[] { 18, (byte) -1, (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "18#-1#0" + "'", str5.equals("18#-1#0"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 18 + "'", int7 == 18);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("x86_64sun.awt.CGraphicsEnvironment", (int) (short) 4, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64sun.awt.CGraphicsEnvironment" + "'", str3.equals("x86_64sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("rs/_v/6v59");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "rs/_v/6v59" + "'", str1.equals("rs/_v/6v59"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("########en", "44:n...", "0#1-#81");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '#', (int) (byte) 100, (int) (short) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "97 0", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.0410.0452.0410.040.0410.0", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("18#-1#0");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "x86_64sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0" + "'", str4.equals("18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Lib", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a10a100a1" + "'", str8.equals("10a10a100a1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10410410041" + "'", str10.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10410410041" + "'", str12.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10#10#100#1" + "'", str14.equals("10#10#100#1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10a10a100a1" + "'", str16.equals("10a10a100a1"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        short[] shortArray5 = new short[] { (byte) 100, (short) 10, (short) -1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 10 -1 -1 100" + "'", str7.equals("100 10 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004104-14-14100" + "'", str10.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1004104-14-14100" + "'", str14.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1004104-14-14100" + "'", str16.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100a10a-1a-1a100" + "'", str18.equals("100a10a-1a-1a100"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.0#100.0", "44444444444444451.04444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB       ", "hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#4#4#4#4a44", (java.lang.CharSequence) "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "#M#M#M#MaM", (java.lang.CharSequence) "-1#100#-1", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', 0, 18);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("sunalwawtamacosxacprinterjob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"s\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("racle Corporati", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Mac OS X", "hi!");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "MAC OS X", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "10410410", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "0#1-#81");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("7.1", "-141004-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7.1" + "'", str2.equals("7.1"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0#10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.", 0, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10410410041m" + "'", str3.equals("10410410041m"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("#m#m#m#mam", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam" + "'", str2.equals("#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "...GraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 22 + "'", int1 == 22);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "9740", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("    ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "macosx.cpr", (java.lang.CharSequence) "-1.0#22.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "SUN.LWAWT.MACOSX.cpRINTERj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("en", "0A10");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("-1a100a-1", 14L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14L + "'", long2 == 14L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 10, 0.0f, (short) 0, 10.0f };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 14, 2);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0a10.0a0.0a0.0a10.0" + "'", str8.equals("-1.0a10.0a0.0a0.0a10.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-1.0 10.0 0.0 0.0 10.0" + "'", str17.equals("-1.0 10.0 0.0 0.0 10.0"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str6 = javaVersion0.toString();
        java.lang.String str7 = javaVersion0.toString();
        java.lang.String str8 = javaVersion0.toString();
        java.lang.String str9 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.4" + "'", str8.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.4" + "'", str9.equals("1.4"));
    }
}

