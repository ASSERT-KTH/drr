import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test001");
        float[] floatArray6 = new float[] { 10L, 10, '4', 10L, (short) 0, 10L };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', (int) 'a', (int) (byte) 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 52.0f + "'", float8 == 52.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10.0410.0452.0410.040.0410.0" + "'", str14.equals("10.0410.0452.0410.040.0410.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10.0a10.0a52.0a10.0a0.0a10.0" + "'", str16.equals("10.0a10.0a52.0a10.0a0.0a10.0"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test002");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test003");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "         ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test004");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "EN");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test005");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "0a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test007");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 4, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test008");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("C4", 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test009");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 10, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("ORACLEaCORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLEaCORPORATION" + "'", str1.equals("ORACLEaCORPORATION"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test011");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "C4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test012");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 10 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#10" + "'", str6.equals("0#10"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test013");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "-1a100a-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test014");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("ORACLECORPORATION");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test015");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "...GraphicsEnvironment", (java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test016");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION", "1.11.11.11.1", 97);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test017");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test018");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "hi!h", 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/444444444ORACL...ORACL...ORACL.", "/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/444444444ORACL...ORACL...ORACL." + "'", str2.equals("/444444444ORACL...ORACL...ORACL."));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test020");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("########en", "10 10 100 1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("NOITAROPROC ELCARO", "x so CAM14001401401");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x so CAM14001401401" + "'", str2.equals("x so CAM14001401401"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "########a#M", (java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test023");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "Mixed mode", (int) (byte) -1);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##################", "");
        java.lang.String[] strArray9 = null;
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("10enfalse", strArray8, strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1.0410.040.040.0410.0", strArray4, strArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, '#');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10enfalse" + "'", str10.equals("10enfalse"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0410.040.040.0410.0" + "'", str11.equals("-1.0410.040.040.0410.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "##################" + "'", str13.equals("##################"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("NOITAROPROCaELCARO", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOITAROPROCaELCARO" + "'", str2.equals("NOITAROPROCaELCARO"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test025");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("cosx.cprinterjobawt.ma sun.lw");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cosx.cprinterjobawt.ma sun.l" + "'", str1.equals("cosx.cprinterjobawt.ma sun.l"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("sophie", "10410410041");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   /", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test028");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "mac os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test029");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.84444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "#m#m#m#mam", "macosx.cpr", (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.84444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str4.equals("1.84444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test030");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(17.0f, (float) 8, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test031");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 100, (short) 4);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test032");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize(" HotSpot(TM) 64-Bit Server VMavaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " HotSpot(TM) 64-Bit Server VMavaJ" + "'", str1.equals(" HotSpot(TM) 64-Bit Server VMavaJ"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test033");
        float[] floatArray6 = new float[] { 10L, 10, '4', 10L, (short) 0, 10L };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', (int) (short) 100, (int) (short) 1);
        float float12 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test034");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1UN.LWAWT.MACO1X.cpRINTERjOB       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test036");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 4, (byte) 0, (byte) 4);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("SUN.LWAWT.MACOSX.cpRINTE", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                            SUN.LWAWT.MACOSX.cpRINTE" + "'", str2.equals("                            SUN.LWAWT.MACOSX.cpRINTE"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test038");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "   ", (java.lang.CharSequence) "4.0-1.010.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test039");
        long[] longArray1 = new long[] { (byte) 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', 1, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test040");
        int[] intArray3 = new int[] { 18, (byte) -1, (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "18#-1#0" + "'", str5.equals("18#-1#0"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "18#-1#0" + "'", str9.equals("18#-1#0"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test041");
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 10, 0.0f, (short) 0, 10.0f };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', (int) (short) 100, 2);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', 9740, 30);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0410.040.040.0410.0" + "'", str8.equals("-1.0410.040.040.0410.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSX", "1.0a100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSX" + "'", str2.equals("0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSX"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test043");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) ' ', 9740);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9740 + "'", int3 == 9740);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test044");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test045");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(21, 10, (int) (short) 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 21 + "'", int3 == 21);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test046");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1.0a10.0a0.0a0.0a10.0", (java.lang.CharSequence) "ETNIRpc.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22 + "'", int2 == 22);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "18#-1#018#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test048");
        int[] intArray3 = new int[] { 18, (byte) -1, (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', 0, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "18#-1#0" + "'", str5.equals("18#-1#0"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test049");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#100#100#100#100#100#100#100", "/Users/sophie/Library/Java/E18#-1#0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test050");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.7.0_80100", (java.lang.CharSequence) "7.1", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("-1.0#22.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0#22.0" + "'", str1.equals("-1.0#22.0"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "Oracle Corporati");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "U");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test055");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("mixed mode", 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test056");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4.0-1.010.0", (java.lang.CharSequence) "10enfals");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test057");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("t.jar", (int) (byte) 1, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".jar" + "'", str3.equals(".jar"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test058");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10 10 100", "            10 10 100 1            ");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test059");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "Java Virtual Machine SpecificationJava Virtual Ma1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test060");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray9 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test061");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) " ", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test062");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x" + "'", str1.equals("x"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("sUN.LWAWT.MACOSX.cpRINTERj", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sUN.LWAWT.MACOSX.cpRINTERj" + "'", str2.equals("sUN.LWAWT.MACOSX.cpRINTERj"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test064");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Java Virtual Machine SpecificationJava Virtual Ma1.0", (java.lang.CharSequence) "1004104-14-14100", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test065");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Java HotSpot(TM) 64-Bit Server VM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test066");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("en", "1.5", (int) (short) 4);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 17, 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "en" + "'", str5.equals("en"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test067");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("X86_6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_6" + "'", str1.equals("X86_6"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test068");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test069");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "macosx");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test070");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sop10410410041Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test071");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 142, (float) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 142.0f + "'", float3 == 142.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test072");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("US", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test074");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', 378, 30);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test075");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1..", (java.lang.CharSequence) "mac OS X", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test076");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test077");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "...GraphicsEnvironment", (java.lang.CharSequence) "CLELCORC-OC5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test078");
        long[] longArray1 = new long[] { (byte) 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ');
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10" + "'", str9.equals("10"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION", "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION" + "'", str2.equals("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("###10.14.3", "", (int) (byte) 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###10.14.3###10.14.3###10.14.3###10.14.3" + "'", str3.equals("###10.14.3###10.14.3###10.14.3###10.14.3"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test081");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 4, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test082");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                 ", "-141004-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test083");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "racle Corporati");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test084");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "mIXED MODE", 19);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test085");
        double[] doubleArray1 = new double[] { 52.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', (int) 'a', 8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 1, (int) (short) 0);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double15 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double16 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 52.0d + "'", double11 == 52.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "52.0" + "'", str13.equals("52.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 52.0d + "'", double14 == 52.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 52.0d + "'", double15 == 52.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test086");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", "mac OS X", 18);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test087");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "", (java.lang.CharSequence) "ORACLE CORPORATION", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-B15" + "'", str1.equals("1.7.0_80-B15"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test089");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10ENFALSE", (java.lang.CharSequence) "  x86_64", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test090");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10a10a100a1", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-1a100a-1", 3, "sun.lwawt.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1a100a-1" + "'", str3.equals("-1a100a-1"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test092");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "ORACLE CORPORATION", (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test093");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("x so CAM14001401401", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test094");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", ' ');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("UTF-8", '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "1.1");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTF-8" + "'", str10.equals("UTF-8"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1" + "'", str11.equals("-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test095");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) '4', (float) (-1L), (float) 33);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test096");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 30, (long) 31, (long) 14);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 14L + "'", long3 == 14L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test097");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10enfalse", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test098");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 4, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test099");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                            SUN.LWAWT.MACOSX.cpRINTE", "mIXED MODE", "1.6");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test100");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("SUN.LWAWT.MACOSX.cpRINTERjOB       ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test101");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0a10");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a10" + "'", str3.equals("0a10"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test102");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("100#10#-1#-1#100", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#10#-1#-1#100" + "'", str3.equals("100#10#-1#-1#100"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test103");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "O1.7.0_80-b15racle1.7.0_80-b151.7.0_80-b15C1.7.0_80-b15orporation", 500);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("######################", "X86_64SUN.AWT.CGRAPHICSENVIRONMENT100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test105");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10a10a100a1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test106");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "C4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test107");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre", (java.lang.CharSequence) "4410...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS X", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0410410041mac OS XOracle Corporatio" + "'", str2.equals("0410410041mac OS XOracle Corporatio"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test109");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINT", (java.lang.CharSequence) "###10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test110");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test111");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("JAVA(TM) SE RUNTIME ENVIRONMENT", "4444", "1UN.LWAWT.MACO1X.cpRINTERjOB       ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JAVA(TM) SE RUNTIME ENVIRONMENT" + "'", str4.equals("JAVA(TM) SE RUNTIME ENVIRONMENT"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test112");
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 10, 0.0f, (short) 0, 10.0f };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', (int) (short) 100, 2);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double15 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0410.040.040.0410.0" + "'", str8.equals("-1.0410.040.040.0410.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "0.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test114");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("7.1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test115");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4.0-1.010.0", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test116");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "/Library/Java/J...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test117");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("CAM14001401401", 500, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test118");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.7.0_80100");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Mac OS X");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray13 = new java.lang.String[] { "", "hi!" };
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray10, strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", strArray6, strArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.lwawt.macosx.cprinterjob", strArray3, strArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) " 1.0a100.0", (java.lang.CharSequence[]) strArray10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA" + "'", str15.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str16.equals("sun.lwawt.macosx.cprinterjob"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("-1a100a-1", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a100a" + "'", str2.equals("-1a100a"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test120");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "x4864_4644sun4.4awt4.4CG4raphics4E4nvironment", "########a#M");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test121");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "EN", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test122");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS X");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("sun.lwawt.macosx.LWCToolkit", "hi", "10a10a100a1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test124");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.5");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", " 1.0a100.0", 10);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("US", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test125");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aa01#0aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa01#0aa" + "'", str1.equals("aa01#0aa"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test127");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "10410410041mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test128");
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10410410041MAC os x", charArray11);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray11, '4');
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "h", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10410410041mac OS X", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "#4#4#4#4a44" + "'", str15.equals("#4#4#4#4a44"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test129");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("ORACLE CORPORATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ORACLE CORPORATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test130");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9", "100 10 -1 -1 100", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test131");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test132");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test133");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1UN.LWAWT.MACO1X.cpRINTERjOB       ", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1UN.LWAWT.MACO1X.cpRINTERjOB       " + "'", str2.equals("1UN.LWAWT.MACO1X.cpRINTERjOB       "));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Librar", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test136");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   /");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 498 + "'", int2 == 498);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test137");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTEN", (java.lang.CharSequence) "1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test138");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "86");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test139");
        short[] shortArray5 = new short[] { (byte) 100, (short) 10, (short) -1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', 30, 142);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 30");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 10 -1 -1 100" + "'", str7.equals("100 10 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1004104-14-14100" + "'", str9.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100#10#-1#-1#100" + "'", str11.equals("100#10#-1#-1#100"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test140");
        double[] doubleArray2 = new double[] { 1, 100L };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a100.0" + "'", str4.equals("1.0a100.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("ORACLE 1.", "97.0a9.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE 1." + "'", str2.equals("ORACLE 1."));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test142");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "", 10, 107);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/soprary/Java/Extensions:/usr/lib/java:." + "'", str4.equals("/Users/soprary/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Library/Java/E18#-1#0/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/E18#-1#0/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str1.equals("/Users/sophie/Library/Java/E18#-1#0/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test144");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "######################", 22, 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test145");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10", (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test146");
        double[][][] doubleArray0 = new double[][][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test147");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ORA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test148");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "rpc.xsocaM", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test149");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1004104-14-14100", (-1), 30);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("######################", "            10 10 100 1            ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test152");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "EN", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test153");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(" HotSpot(TM) 64-Bit Server VMavaJ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test154");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 10 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "hi!h");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: hi!h");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a10" + "'", str5.equals("0a10"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test155");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-" + "'", str1.equals("-"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test156");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("10 10 100", (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test157");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "########en", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test158");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 10 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a10" + "'", str5.equals("0a10"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test159");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "184-140", 31, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test160");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10410410041", "-1 100 -1", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test161");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("hi/444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi/444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("tionacle CorporaOr", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tionacle CorporaOr" + "'", str2.equals("tionacle CorporaOr"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test163");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray10 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone(charSequence2, charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporati", charArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "#a#a#a#aaa4" + "'", str16.equals("#a#a#a#aaa4"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION", 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION" + "'", str3.equals("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444" + "'", str1.equals("444444444444444444"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "t.jar", (java.lang.CharSequence) "h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test167");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIO");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test168");
        short[] shortArray5 = new short[] { (byte) 100, (short) 10, (short) -1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', 31, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 10 -1 -1 100" + "'", str7.equals("100 10 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004104-14-14100" + "'", str10.equals("1004104-14-14100"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test169");
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 10, 0.0f, (short) 0, 10.0f };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0410.040.040.0410.0" + "'", str8.equals("-1.0410.040.040.0410.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(" Virtual Machine Specification", (int) (short) 100, "0410410041mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0410410041mac OS X0410410041mac OS X0410410041mac OS X0410410041mac OS Virtual Machine Specification" + "'", str3.equals("0410410041mac OS X0410410041mac OS X0410410041mac OS X0410410041mac OS Virtual Machine Specification"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test171");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXED MODE" + "'", str1.equals("MIXED MODE"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "MCAM4A3MCAM4A3MCAM4A3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test173");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("mac os x", "ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 107, 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "macns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str4.equals("macns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("SUN.LWAWT.MACOSX.cpRINTE", "0.9 -1.0 1.0", 498);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTE" + "'", str3.equals("SUN.LWAWT.MACOSX.cpRINTE"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test175");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("mac os x", '#');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSX", "oRACLE CORPORATION", 10);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray3, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test176");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0A10.0A0.0A0.0A10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8", (java.lang.CharSequence) ".jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test177");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test178");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test179");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("mixed mode", (-1), "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test181");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10101001", 14, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/J/a/v/a/ /P/l/a/t/f/o/r/m/ /A/P/I/ /S/p/e/c/i/f/i/c/a/t/i/o/n/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test184");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring(":", 500, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10a10a100a1", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10a10a100a1" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10a10a100a1"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test186");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ORACLE 1.", "ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test187");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ORACLE 1.", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test188");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (byte) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("NOITAROPROCaELCARO", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOITAROPROCaELCARO" + "'", str2.equals("NOITAROPROCaELCARO"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test190");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10 10 100 1", (java.lang.CharSequence) "Mac OS X", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test191");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("18#-1#018#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) (byte) 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    " + "'", str2.equals("    "));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.", "-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL." + "'", str2.equals("10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL."));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test194");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "          ", (java.lang.CharSequence) "EN");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test195");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 8, (long) 0, (long) 22);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test196");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.11.11.11.1", (java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob", 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0A10.0A0.0A0.0A10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0A10.0A0.0A0.0A10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8" + "'", str2.equals("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0A10.0A0.0A0.0A10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test198");
        float[] floatArray6 = new float[] { 10L, 10, '4', 10L, (short) 0, 10L };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 52.0f + "'", float10 == 52.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test199");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test200");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test201");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hhhhhhhhhhhhhhhhhhhhhhhhhhhhh1.4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test202");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test203");
        short[] shortArray3 = new short[] { (byte) -1, (short) 100, (byte) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test204");
        long[] longArray1 = new long[] { (byte) 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test205");
        short[] shortArray3 = new short[] { (byte) -1, (short) 100, (byte) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 32, 2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1#100#-1" + "'", str11.equals("-1#100#-1"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test206");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1004104-14-14100", 8, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1004104-14-14100" + "'", str3.equals("1004104-14-14100"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test207");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCorporatio" + "'", str1.equals("OracleCorporatio"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test208");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 498, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 498 + "'", int3 == 498);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test209");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ORACL...", 8, "US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACL..." + "'", str3.equals("ORACL..."));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test210");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test211");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   /", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!" + "'", str1.equals("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test214");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("18#-1#0");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "97a0", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("O1.7.0_80-b15racle1.7.0_80-b15 1.7.0_80-b15C1.7.0_80-b15orporation                                  ", "10a10a100a1                                                                                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "O1.7.0_80-b15racle1.7.0_80-b15 1.7.0_80-b15C1.7.0_80-b15orporation                                  " + "'", str2.equals("O1.7.0_80-b15racle1.7.0_80-b15 1.7.0_80-b15C1.7.0_80-b15orporation                                  "));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("UTF-8", (int) 'a', "97a0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-897a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a0" + "'", str3.equals("UTF-897a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a0"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test217");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION", "##################", "#100                                                                                             ");
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("  x86_64  ", "rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  x86_64  " + "'", str2.equals("  x86_64  "));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1m");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("mac OS X", "44:n...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mac OS X" + "'", str2.equals("mac OS X"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test221");
        int[] intArray2 = new int[] { 'a', 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, '#', 32, 0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "97 0" + "'", str6.equals("97 0"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("100", "ORACL...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100" + "'", str2.equals("100"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test223");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test224");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test225");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "###10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test226");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "   1.7", (java.lang.CharSequence) "##################", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/444444444" + "'", str1.equals("/444444444"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("10", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("-1.041.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.041.0" + "'", str1.equals("-1.041.0"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("h", (int) ' ', "1.7.0_80100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_801001.7.0_801001.7.0_801h" + "'", str3.equals("1.7.0_801001.7.0_801001.7.0_801h"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test231");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test232");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray12 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence4, charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                                                 ", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie", charArray12);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray12, 'a', 9740, 52);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test233");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 500L, (double) 14.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test234");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test235");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) (byte) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test236");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "001" + "'", str1.equals("001"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test237");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("SX.cpRINTE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SX.cpRINTE" + "'", str1.equals("SX.cpRINTE"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test238");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("          ", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "0aSUN.AWT.cgRAPHICSeNVIRONMENT0");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "          " + "'", str4.equals("          "));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test239");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '4', 30, 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test240");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("mixedmode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixedmode" + "'", str1.equals("mixedmode"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test241");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION-1.0A10.0A0.0A0.0A10.0ORACLE CORPORATION");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test242");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10 1 1 1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 1 1 1" + "'", str1.equals("10 1 1 1"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test243");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", 378);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test244");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.6", (double) 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6d + "'", double2 == 1.6d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test246");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "  x86_64  ", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10101001", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "      Hi!       a      Hi!       ", charArray11);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray11, 'a', 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test247");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC" + "'", str1.equals("CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test249");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1", "#a#a#a#aaa4", "NOITAROPROCaELCARO", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1" + "'", str4.equals("-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre", "100#10#-1#-1#100", "10a10a100a1SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test252");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                                                                                                 ", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                                                                 " + "'", charSequence2.equals("                                                                                                 "));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("46_68x", "JavaUPlatfermU/PIUSpecificatien", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test254");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC", "0aSUN.AWT.cgRAPHICSeNVIRONMENT0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC" + "'", str2.equals("CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test256");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("x", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test257");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("X.cpRINTE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad(" HotSpot(TM) 64-Bit Server VMavaJ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " HotSpot(TM) 64-Bit Server VMavaJ" + "'", str2.equals(" HotSpot(TM) 64-Bit Server VMavaJ"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test259");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                             /444444444                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                             444444444/                                             " + "'", str1.equals("                                             444444444/                                             "));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test260");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test261");
        long[] longArray2 = new long[] { '4', 1L };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test262");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "100a10a-1a-1a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test263");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10enfalse", "-141004-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test264");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                             444444444/                                             ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test265");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 21, 19);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str4.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test266");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test267");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("###10.14.3###10.14.3###10.14.3###10.14.3");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test268");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "9740", (java.lang.CharSequence) "ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0" + "'", str2.equals("18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Mixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test271");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("      Hi!       a      Hi!       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!aHi!" + "'", str1.equals("Hi!aHi!"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test272");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "macosx.cpr", (java.lang.CharSequence) "ETNIRpc.XSOCAM.TWAWL.NU", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " " + "'", str1.equals(" "));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test274");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("S");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: S is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test275");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) (short) 10, (-1));
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 12, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 1 + "'", byte13 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10#10#100#1" + "'", str15.equals("10#10#100#1"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test276");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("ORACL...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test277");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) '#', (int) '#');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', 6, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 1 + "'", byte9 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaa", "7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "10 10 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test280");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam#m#m#m#mam", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test281");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "/", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test282");
        int[] intArray2 = new int[] { 'a', 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "97a0" + "'", str5.equals("97a0"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test284");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "0#10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("0#10", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTEN");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("4.0-1.010.0", "4.0 1.0 10.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test287");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "            10 10 100 1            ", (java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test288");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "RO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test289");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "###10.14.3###10.14.3###10.14.3###10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test290");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("NOITAROPROC ELCARO", "sunalwawtamacosxacprinterjob");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "ORACLE 1.", (int) (short) 1, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test291");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test292");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("U", "                                                                                                 ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sop10410410041mac OS XORACL...ORACL...ORAC..." + "'", str2.equals("/Users/sop10410410041mac OS XORACL...ORACL...ORAC..."));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test294");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test295");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "10#1#1#1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test296");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "U");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("-141004-1", "         ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test298");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test299");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   /");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test300");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '#', 0, 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test301");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10.0a10.0a52.0a10.0a0.0a10.0", (java.lang.CharSequence) "O1.7.0_80-b15racle1.7.0_80-b151.7.0_80-b15C1.7.0_80-b15orporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test302");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "   US   ", (java.lang.CharSequence) "1004104-14-14100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test303");
        long[] longArray1 = new long[] { (byte) 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) ' ', (int) (byte) 4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) (short) 100, 0);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test304");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "OracleCorporatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("11b-08.42", "", "ORACLECORPORATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLECORPORATION1ORACLECORPORATION1ORACLECORPORATIONbORACLECORPORATION-ORACLECORPORATION0ORACLECORPORATION8ORACLECORPORATION.ORACLECORPORATION4ORACLECORPORATION2ORACLECORPORATION" + "'", str3.equals("ORACLECORPORATION1ORACLECORPORATION1ORACLECORPORATIONbORACLECORPORATION-ORACLECORPORATION0ORACLECORPORATION8ORACLECORPORATION.ORACLECORPORATION4ORACLECORPORATION2ORACLECORPORATION"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test306");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Aaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test307");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.11.11.11.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.11.11.11.1" + "'", str1.equals("1.11.11.11.1"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test308");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0 10.0 52.0 10.0 0.0 10.0", "100 10 -1 -1 100", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test309");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "10.00101001.052.0", 10, (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.00101001.052.0" + "'", str4.equals("10.00101001.052.0"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test310");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test311");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) " 1.0a100.0", (java.lang.CharSequence) "10                                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test312");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("ORACLE 1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE 1." + "'", str1.equals("ORACLE 1."));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test313");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1.5");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 1.5f + "'", number1.equals(1.5f));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test314");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str1.equals("SUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test315");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 1, (long) 52, (long) 28);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test316");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) " Virtual Machine Specification", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test317");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION", "10 10 100 1", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test318");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444444444444444");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 32, (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test319");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.3", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test320");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("rpc.xsocaM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "rpc.xsocaM" + "'", str1.equals("rpc.xsocaM"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "1.7.0_801001.7.0_801001.7.0_801h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_801001.7.0_801001.7.0_801h" + "'", str2.equals("1.7.0_801001.7.0_801001.7.0_801h"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test322");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("cosx.cprinterjobawt.ma sun.lw", "4.0-1.010.", 4, 18);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "cosx4.0-1.010.t.ma sun.lw" + "'", str4.equals("cosx4.0-1.010.t.ma sun.lw"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test323");
        long[] longArray1 = new long[] { 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        java.lang.Class<?> wildcardClass4 = longArray1.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, '#', 21, 0);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test324");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(8.0d, (double) 28, (double) 10414141L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0414141E7d + "'", double3 == 1.0414141E7d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test325");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test326");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10                                                                                                  ", (java.lang.CharSequence) "-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test327");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION", 22, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION" + "'", str3.equals("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test328");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) (short) 10, (-1));
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 1 + "'", byte13 == (byte) 1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test329");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "U");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "hi!", ".jar");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test331");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(24.0d, (double) (byte) -1, 256.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test332");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray13 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10410410041MAC os x", charArray13);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray13, '4');
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "h", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "#a#a#a#aaaa", charArray13);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", charArray13);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "#4#4#4#4a44" + "'", str17.equals("#4#4#4#4a44"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION-1.0a10.0a0.0a0.0a10.0oRACLE CORPORATION", "Oracle Corporation");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test334");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("     0.9", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     0.9" + "'", str2.equals("     0.9"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test336");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "S", 12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C", "Macosx.cpr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C" + "'", str2.equals("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test338");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Mixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test339");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("S", "", "1.0#100.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test340");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("#4#4#4#4a44", (long) 24);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24L + "'", long2 == 24L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test341");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str1.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test342");
        double[] doubleArray1 = new double[] { 52.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 16, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 16");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test343");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test344");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Oracle Corporati", (int) (short) 100, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test345");
        char[] charArray13 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray13);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http://java.oracle.com/", charArray13);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "::::::::", charArray13);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "7.1", charArray13);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10410410041", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test346");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "EN##################################################", charArray11);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray11, '#', 8, 0);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test347");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "4444", (java.lang.CharSequence) "97.0a9.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test348");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray10 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone(charSequence2, charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "9740", charArray10);
        java.lang.Class<?> wildcardClass14 = charArray10.getClass();
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.5-1#100#-1", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("X.cpRINTE", 19);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          X.cpRINTE" + "'", str2.equals("          X.cpRINTE"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "#a#a#a#aaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test351");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1m");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1m" + "'", str1.equals("1m"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("0A10", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      0A10" + "'", str2.equals("      0A10"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test353");
        char[] charArray4 = new char[] { ' ', ' ', '#' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4.0 -1.0 10.0", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test354");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10 10 100 ", (java.lang.CharSequence) "ORACLE 1.0", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test355");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", (java.lang.CharSequence) "CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test356");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.awt.CGraphicsEnvironment", "t.jar", 35);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100 10 -1 -1 100", "hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Lib");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("0410", strArray4, strArray7);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a', 1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0410" + "'", str8.equals("0410"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("4.0 -1.0 10.0", "      Hi!       a      Hi!       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test358");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", "mac OS X", 18);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Aaaaaaaaaa", (java.lang.CharSequence[]) strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "0410410041mac OS X0410410041mac OS X0410410041mac OS X0410410041mac OS Virtual Machine Specification", 6, 3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "ETNIRpc.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test360");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob", "sophie");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sunalwawtamacosxacprinterjob", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "   1.7", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test361");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.0");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test362");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("7");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 7 + "'", byte1 == (byte) 7);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test363");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "184-140", 7, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test364");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10#1#1#1", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test365");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test366");
        double[] doubleArray2 = new double[] { 1, 100L };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a100.0" + "'", str4.equals("1.0a100.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", 33, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test368");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/444444444ORACL...ORACL...ORACL.", (java.lang.CharSequence) "-1.0#22.0", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test369");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "###10.14.3", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test370");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split(".LCARO...LCARO...LCARO444444444/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize(".jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".jar" + "'", str1.equals(".jar"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test372");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str4 = javaVersion0.toString();
        java.lang.String str5 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.4" + "'", str5.equals("1.4"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test373");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 10 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', 0, 2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a10" + "'", str5.equals("0a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0410" + "'", str11.equals("0410"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0 10" + "'", str13.equals("0 10"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8" + "'", str2.equals("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test375");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation", "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION", (int) '#', (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "oracle corporation-1.0a10.0a0.0a0.0ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONn-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation" + "'", str4.equals("oracle corporation-1.0a10.0a0.0a0.0ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONn-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test376");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", "S");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test377");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("hhhhhhhhhhhhhhhhhhhhhhhhhC.4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("########a#4", "1004104-14-14100", "########en");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test379");
        float[] floatArray2 = new float[] { (-1L), 1.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4');
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.041.0" + "'", str5.equals("-1.041.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("RO", "-1.0410.040.040.0410.0-1.0410.040.040.0410.0-1.0410.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RO" + "'", str2.equals("RO"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test382");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "10");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray3, strArray7);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Oracle Corporation");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "", 28, 9);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str1.equals("sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test384");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "10ENFALSE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test385");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("UTF-8", '4');
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "10 10 100 1", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10", (java.lang.CharSequence[]) strArray5);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "001", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test386");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "01#001#001#001#001#001#001#001#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test387");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/uSERS/SOPHIE/lIBRARY/jAVA/eXTEN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("10101001", "/Users/sop10410410041mac OS XORACL...ORACL...ORAC...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test389");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" ", " ");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "##################", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "10 1 1 1", (int) (short) -1, 107);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 18 + "'", int4 == 18);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test390");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 620 + "'", int1 == 620);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test391");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "10                                                                                                  ", (java.lang.CharSequence) "10410410");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test392");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10410410041mac OS X", "\n");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 100, (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "");
        boolean boolean13 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10410410041mac OS X" + "'", str9.equals("10410410041mac OS X"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10410410041mac OS X" + "'", str12.equals("10410410041mac OS X"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/soprary/Java/Extensions:/usr/lib/java:.", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/soprary/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/soprary/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test394");
        short[] shortArray3 = new short[] { (byte) -1, (short) 100, (byte) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-141004-1" + "'", str6.equals("-141004-1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1#100#-1" + "'", str8.equals("-1#100#-1"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("-1.0a10.0a0.0a0.0a10.0", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0a10.0a0.0a0.0a10.0" + "'", str2.equals("-1.0a10.0a0.0a0.0a10.0"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test396");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5", "h");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5" + "'", str4.equals("CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5CLELCORC-OC5"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test397");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("444444444444444444");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("hi!h", 500);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                hi!h" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                hi!h"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test399");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 620, (long) 18, 14L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 620L + "'", long3 == 620L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0" + "'", str1.equals("1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test401");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "10#10#100#1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test402");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.7.0_80-B15", charSequence1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test403");
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http://java.oracle.com/", charArray11);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray11, ' ');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4410444444444", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "# # # # a 4" + "'", str16.equals("# # # # a 4"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test404");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 0, 378);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("0410410041mac OS XOracle Corporatio", "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0410410041mac OS XOracle Corporatio" + "'", str2.equals("0410410041mac OS XOracle Corporatio"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("#100#100#100#100#100#100#100", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#100#100#100#100#100#100#100" + "'", str2.equals("#100#100#100#100#100#100#100"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test407");
        short[] shortArray3 = new short[] { (byte) -1, (short) 100, (byte) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 32, 2);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test408");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "mac OS X", 30);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test409");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.31010.0 10.0 52.0 10.0 0.0 10.0", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test410");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "MAC OS X", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test411");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10a10a100a1SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS", "1UN.LWAWT.MACO1X.cpRINTERjOB       ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("4444", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444" + "'", str2.equals("4444"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test414");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "             10410410              ", "hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test415");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("ORACLE 1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE 1." + "'", str1.equals("ORACLE 1."));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("-", "########en", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-" + "'", str3.equals("-"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test418");
        int[] intArray2 = new int[] { 'a', 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', 14, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 14");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "97 0" + "'", str6.equals("97 0"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test419");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Hi!aHi!", (java.lang.CharSequence) "7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test420");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTEN", (java.lang.CharSequence) "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test421");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 10, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("UTF-897a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a0", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-897a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a0" + "'", str2.equals("UTF-897a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a097a0"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test423");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Hi!", (java.lang.CharSequence) "10a10a100a1                                                                                         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("CLELCORC-OC5", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CLELCORC-OC5" + "'", str2.equals("CLELCORC-OC5"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test425");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("macosx", "###10.14.3", 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "US", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test426");
        short[] shortArray5 = new short[] { (byte) 100, (short) 10, (short) -1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', 378, 378);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 10 -1 -1 100" + "'", str7.equals("100 10 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1004104-14-14100" + "'", str9.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100#10#-1#-1#100" + "'", str11.equals("100#10#-1#-1#100"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test427");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("001");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("oRACLE CORPORATION", "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("O1.7.0_80-b15racle1.7.0_80-b151.7.0_80-b15C1.7.0_80-b15orporation", (int) (short) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "O1.7.0_80-b15racle1.7.0_80-b151.7.0_80-b15C1.7.0_80-b15orporation" + "'", str3.equals("O1.7.0_80-b15racle1.7.0_80-b151.7.0_80-b15C1.7.0_80-b15orporation"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test430");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.14.310.14.310.14.3", (java.lang.CharSequence) "1.84444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 9740);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 96 + "'", int3 == 96);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.7.0_80-b15", "52.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test432");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", 32, 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test433");
        long[] longArray1 = new long[] { (byte) 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) ' ', (int) (byte) 4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', (int) 'a', (int) ' ');
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10" + "'", str13.equals("10"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test434");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sop10410410041mac OS XORACL...ORACL...ORAC...", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test435");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("rpc.xsocaM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"rpc.xsocaM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophie/Library/Java/E18#-1#0", "1..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.." + "'", str2.equals("1.."));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java HotSpot(TM) 64-Bit Server VM", "###10.14.3###10.14.3###10.14.3###10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test438");
        byte[][] byteArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(byteArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("97 0", "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97 0" + "'", str2.equals("97 0"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test440");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("0A10", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test441");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-141004-1");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-141004-1" + "'", str2.equals("-141004-1"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-141004-1" + "'", str3.equals("-141004-1"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("sun.awt.CGraphicsEnvironment", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaa", 14, "0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0000aaaaaaaaaa" + "'", str3.equals("0000aaaaaaaaaa"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test444");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 4, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test445");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("4.0 1.0 10.0", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test446");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1..");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test447");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "184-140");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test448");
        double[] doubleArray1 = new double[] { 52.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', (int) 'a', 8);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', (int) (byte) 0, 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52.0" + "'", str8.equals("52.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 52.0d + "'", double9 == 52.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "52.0" + "'", str15.equals("52.0"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test449");
        int[] intArray3 = new int[] { 18, (byte) -1, (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', 9, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "18#-1#0" + "'", str5.equals("18#-1#0"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test450");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", "Oracle Corporatio");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test452");
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 10, 0.0f, (short) 0, 10.0f };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', (int) 'a', 3);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0410.040.040.0410.0" + "'", str14.equals("-1.0410.040.040.0410.0"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test453");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "tionacle CorporaOr", (java.lang.CharSequence) "hhhhhhhhhhhhhhhhhhhhhhhhhC.4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test454");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 100, (long) '#', 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test455");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "01#0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "01#0" + "'", charSequence2.equals("01#0"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test456");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("46_68x#10046_68x#10046_68x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "46_68x#10046_68x#10046_68x" + "'", str1.equals("46_68x#10046_68x#10046_68x"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test457");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "01#0mixedmodemix", (java.lang.CharSequence) "#M#M#M#MaM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test458");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(".0_801.7.0_8", 1.5f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.5f + "'", float2 == 1.5f);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test459");
        float[] floatArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test460");
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 10, 0.0f, (short) 0, 10.0f };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 33, 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0a10.0a0.0a0.0a10.0" + "'", str8.equals("-1.0a10.0a0.0a0.0a10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.5-1#100#-1", "97 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5-1#100#-1" + "'", str2.equals("1.5-1#100#-1"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test463");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "O1.7.0_80-b15racle1.7.0_80-b151.7.0_80-b15C1.7.0_80-b15orporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test464");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(1.0410409984E10d, (double) (byte) 10, 1.100000023841858d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0410409984E10d + "'", double3 == 1.0410409984E10d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/uSERS/SOPHIE/lIBRARY/jAVA/eXTEN", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTEN" + "'", str2.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTEN"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test466");
        short[] shortArray3 = new short[] { (byte) -1, (short) 100, (byte) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-141004-1" + "'", str6.equals("-141004-1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1#100#-1" + "'", str8.equals("-1#100#-1"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-141004-1" + "'", str12.equals("-141004-1"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test467");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("a#a#a#aaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test468");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "ORACL...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test469");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test470");
        char[] charArray9 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', 1, (int) (short) -1);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray9);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.14.3", charArray9);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "########a#4" + "'", str18.equals("########a#4"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test471");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "100", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test472");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test473");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "#100#100#100#100#100#100#100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test474");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/444444444ORACL...ORACL...ORACL.", "/USERS/SOPHIE/LIBRARY/JAVA/EXTEN");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test475");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '#', (int) (byte) 4, (int) (short) 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test476");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("sun.lwawt.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt." + "'", str1.equals("Sun.lwawt."));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test477");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "/444444444");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-B15", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("hi/444444444", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test478");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("########a#4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "########a#4" + "'", str1.equals("########a#4"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test479");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "97a0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test481");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "-1.041.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test482");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "0aSUN.AWT.cgRAPHICSeNVIRONMENT0", (java.lang.CharSequence) "                                           10 10 100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test483");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", (float) 52L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("ETNIRpc.XSOCAM.TWAWL.NU", "#4#4#4#4a44");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#4#4#4#4a44" + "'", str2.equals("#4#4#4#4a44"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test485");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10410410041mac OS X", 0, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test486");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10a10a100a1", 9740, ' ');
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("     0.9", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     0.9" + "'", str2.equals("     0.9"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test488");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("-1.0410.040.040.0410.0", 24L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24L + "'", long2 == 24L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test489");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" ", " ");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "##################", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                             /444444444                                             ", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "aaaaaaaaaa");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 18 + "'", int5 == 18);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test490");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(2.0f, (float) 10, (float) 620L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 620.0f + "'", float3 == 620.0f);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test491");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 500.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 500.0f + "'", float2 == 500.0f);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test492");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("x so CAM14001401401", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test493");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("97 0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test494");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "JavaUPlatfermU/PIUSpecificatien");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test495");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "cosx4.0-1.010.t.ma sun.lw");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test496");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("#100                                                                                             ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test497");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("##################", "0410410041mac OS X0410410041mac OS X0410410041mac OS X0410410041mac OS Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test498");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/soprary/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test499");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("O1.7.0_80-b15racle1.7.0_80-b15 1.7.0_80-b15C1.7.0_80-b15orporation", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "O1.7.0_80-b15racle1.7.0_80-b15 1.7.0_80-b15C1.7.0_80-b15orporation" + "'", str3.equals("O1.7.0_80-b15racle1.7.0_80-b15 1.7.0_80-b15C1.7.0_80-b15orporation"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("10                                                                                                  ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }
}

