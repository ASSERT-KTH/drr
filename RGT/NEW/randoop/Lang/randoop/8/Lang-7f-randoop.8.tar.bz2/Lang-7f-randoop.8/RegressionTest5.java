import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "410410041", "#100");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ', 100, (int) (byte) 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 17, (double) 30, (double) 52);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java(TM) SE Runtime Environment", "", "10410410041m");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#', (int) (short) 1, 17);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/J/a/v/a/ /P/l/a/t/f/o/r/m/ /A/P/I/ /S/p/e/c/i/f/i/c/a/t/i/o/n/", (java.lang.CharSequence) "#100                                                                                             ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "      Hi!       ", (java.lang.CharSequence) "###10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("#4#4#4#4a44");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#4#4#4#4a44" + "'", str1.equals("#4#4#4#4a44"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test011");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "4.0-1.010.0", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10a10a100a1", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("X86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_6" + "'", str1.equals("X86_6"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("S", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S" + "'", str2.equals("S"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("SUN.LWAWT.MACOSX.cpRINTERjOB       ", 0, "10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB       " + "'", str3.equals("SUN.LWAWT.MACOSX.cpRINTERjOB       "));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("MAC OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "CLELCORC-OC5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("SUN.LWAWT.MACOSX.cpRINTE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.cpRINT" + "'", str1.equals("SUN.LWAWT.MACOSX.cpRINT"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-1.0#22.0", (java.lang.CharSequence) " sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.0a100.", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("X86_6");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test021");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("10410410");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.041041E7f + "'", float1 == 1.041041E7f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a', 31, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("     0.9");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9d + "'", double1 == 0.9d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sunalwawtamacosxacprinterjob", (int) (short) 4, "11b-08.42");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sunalwawtamacosxacprinterjob" + "'", str3.equals("sunalwawtamacosxacprinterjob"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "#m#m#m#mam");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 10 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "9740");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 9740");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#10" + "'", str6.equals("0#10"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                       ORACLE CORPORATION                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE CORPORATION" + "'", str1.equals("ORACLE CORPORATION"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERj");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("10ENFALSE", "Java Virtual Machine SpecificationJava Virtual Ma1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10ENFALSE" + "'", str2.equals("10ENFALSE"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                             /444444444                                             ", (int) (short) -1, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        java.math.BigDecimal[] bigDecimalArray0 = new java.math.BigDecimal[] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray0);
        org.junit.Assert.assertNotNull(bigDecimalArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Java Virtual Machine SpecificationJava Virtual Ma1.0", 9740);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("SUN.AWT.cgRAPHICSeNVIRONMENT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SUN.AWT.cgRAPHICSeNVIRONMENT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("52.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52.0" + "'", str1.equals("52.0"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("hi!h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!h" + "'", str1.equals("hi!h"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("rs/_v/6v59");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"rs/_v/6v59\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("SUN.LWAWT.MACOSX.cpRINTERjO", "mac os x");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjO" + "'", str2.equals("SUN.LWAWT.MACOSX.cpRINTERjO"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sun.awt.CGraphicsEnvironment", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Aaaaaaaaaa", "0#10", 7);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Mac OS X", "hi!");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "MAC OS X", (java.lang.CharSequence[]) strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "10", (int) (short) 10, 6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("44444444444444444444444444444444444", "1..", "4.0-1.010.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Oracle Corporation");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("MAC OS X", strArray5, strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/444444444ORACL...ORACL...ORACL.", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("", '#');
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.split("", '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray13, strArray16);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray16);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C", strArray5, strArray18);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "MAC OS X" + "'", str8.equals("MAC OS X"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C" + "'", str19.equals("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.8", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "x86_64sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB       ", 378);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaat.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("########a#4", "44444444444444451.04444444444444444", "Mixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "########a#M" + "'", str3.equals("########a#M"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a" + "'", str1.equals("a"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "          ", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 10, 0.0f, (short) 0, 10.0f };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', 9, 9);
        double double15 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0a10.0a0.0a0.0a10.0" + "'", str8.equals("-1.0a10.0a0.0a0.0a10.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "oRACLE CORPORATION", (java.lang.CharSequence) "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("mixedmode", 6, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixedmode" + "'", str3.equals("mixedmode"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("10.0410.0452.0410.040.0410.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "a", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("-1a100a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a100a-1" + "'", str1.equals("-1a100a-1"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("100a10a-1a-1a100", (int) (byte) 10, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a10a-1a-1a100" + "'", str3.equals("100a10a-1a-1a100"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart(":", "###10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhC.4", "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("             10410410              ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("x86_64sun.awt.CGraphicsEnvironment", (int) (short) 1, 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "86" + "'", str3.equals("86"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("24.80-b11", (int) (byte) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 100, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("86", "10101001");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1#100#-1", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("CAM14001401401", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CAM14001401401" + "'", str2.equals("CAM14001401401"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(2, 2, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "100 10 -1 -1 100", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("44:n...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44:n..." + "'", str1.equals("44:n..."));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1#100#-1", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10", (java.lang.CharSequence) "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0", "#100", "1.84444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0" + "'", str3.equals("1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI" + "'", str1.equals("HI"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhC.4", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hhhhhhhhhhhhhhhhhhhhhhhhhC.4" + "'", str2.equals("hhhhhhhhhhhhhhhhhhhhhhhhhC.4"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 9740, (float) (short) 0, (float) 16);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "1.11.11.11.1", (int) (short) 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10410410041MAC os x", "1.7.0_80");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "         ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0A10.0A0.0A0.0A10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8" + "'", str1.equals("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0A10.0A0.0A0.0A10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", (int) (short) 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ORACLEaCORPORATION", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "SX.cpRINTE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "9740", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", '#');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("10 10 100 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0 10 100 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("C4", "1.7.0_80100");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(4, 35, 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("#a#a#a#aaa4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#a#a#a#aaa4" + "'", str1.equals("#a#a#a#aaa4"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                                                                                 1.7", "         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 1.7" + "'", str2.equals("                                                                                                 1.7"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("#4#4#4#4a44", "X86_64", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#4#4#4#4a44" + "'", str3.equals("#4#4#4#4a44"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporatio" + "'", str1.equals("Oracle Corporatio"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 4, (-1.0f), 35.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Oracle Corporati", "-1.0410.040.040.0410.0-1.0410.040.040.0410.0-1.0410.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporati" + "'", str2.equals("Oracle Corporati"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "                                                                                                 1.7", (int) (byte) 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                                                                                 ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Librar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "O1.7.0_80-b15racle1.7.0_80-b15 1.7.0_80-b15C1.7.0_80-b15orporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "10410410041");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION", "10410410041");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION" + "'", str2.equals("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 3, (long) 32, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("#a#a#a#aaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#a#a#a#aaaa" + "'", str1.equals("#a#a#a#aaaa"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Lib", "SUN.LWAWT.MACOSX.cpRINTERjOB       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Lib" + "'", str2.equals("hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Lib"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaaaaaa", "10 10 100", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaa" + "'", str3.equals("aaaaaaaaaa"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/", 28, "7.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7.17.17.17.17.17.17.17.17.1/" + "'", str3.equals("7.17.17.17.17.17.17.17.17.1/"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("########a#4", "10.0410.0452.0410.040.0410.0", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("S");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "S" + "'", str1.equals("S"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "hi!h");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        float[] floatArray2 = new float[] { (-1L), 1.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', 2, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.041.0" + "'", str5.equals("-1.041.0"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("10 1 1 1", "", "x86_64sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test122");
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray11);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray11, '4');
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "EN##################################################", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "#4#4#4#4a44" + "'", str17.equals("#4#4#4#4a44"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test123");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "a", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 142 + "'", int2 == 142);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test124");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("86", (int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test125");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java Virtual Machine Specification", "-", "sunalwawtamacosxacprinterjob");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test126");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", '#');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray7);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100#10#-1#-1#100", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0A10", "1.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0A10" + "'", str2.equals("0A10"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test128");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9     0.9");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 107 + "'", int2 == 107);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/uSERS/SOPHIE/lIBRARY/jAVA/eXTEN");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTEN" + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTEN"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test130");
        double[] doubleArray3 = new double[] { 52L, 0.0f, 52.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test131");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '#', (int) (short) 0, 32);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C", "mIXED MODE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C" + "'", str2.equals("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Jclass [Ljava.lang.String;class [C"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                             /444444444                                             ", "4.0-1.010.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                             /444444444                                             " + "'", str2.equals("                                             /444444444                                             "));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test134");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("SUN.LWAWT.MACOSX.cpRINTERj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sUN.LWAWT.MACOSX.cpRINTERj" + "'", str1.equals("sUN.LWAWT.MACOSX.cpRINTERj"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test135");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test136");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("rs/_v/6v59");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 107);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test138");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIO" + "'", str1.equals("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIO"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test139");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("10410410041m", (int) (short) 10, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1m" + "'", str3.equals("1m"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test140");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Librar", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test141");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) 10, "18#-1#0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "18#-1#018#" + "'", str3.equals("18#-1#018#"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test142");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80-b11", "", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test143");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test144");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test145");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1004104-14-14100", (java.lang.CharSequence) "ORACLE 1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test146");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporatio", "");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 21, 12);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("cosx.cpr", "Java Virtual Machine SpecificationJava Virtual Ma1.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test149");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "EN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test150");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test151");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("h");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"h\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test152");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", " 1.0a100.0", 10);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "Oracle Corporatio");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test153");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 4, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test154");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIO", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test155");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("-1.0a10.0a0.0a0.0a10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Hi!", "Mac OS X", "ORACLEaCORPORATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hi!" + "'", str3.equals("Hi!"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test157");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0#1-#81", "  x86_64  ", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "-1.0#22.0");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "ORACLE CORPORATION");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ORACLE CORPORATION" + "'", str7.equals("ORACLE CORPORATION"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test158");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("104104100", 31, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaa104104100aaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaa104104100aaaaaaaaaaa"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test159");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Mixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode", "7", "MAC OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode" + "'", str3.equals("Mixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test161");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "4.0 1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test162");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("\n", (long) 33);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 33L + "'", long2 == 33L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test163");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("cosx.cpr", 9, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test164");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie" + "'", str1.equals("/users/sophie"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0" + "'", str2.equals("1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test166");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("cosx.cpr", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test167");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 0, 9740);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test168");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("x86_64sun.awt.CGraphicsEnvironment", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test169");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.0a100.0M1.0a100.0a1.0a100.0c1.0a100.0 1.0a100.0O1.0a100.0S1.0a100.0 1.0a100.0X1.0a100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1004444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1004444444444444444444444444444444444444444444444444" + "'", str1.equals("1004444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test171");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/", (java.lang.CharSequence) "7.17.17.17.17.17.17.17.17.1/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test172");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Hi!", "10ENFALSE");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test173");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test174");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "########en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test175");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/J/a/v/a/ /P/l/a/t/f/o/r/m/ /A/P/I/ /S/p/e/c/i/f/i/c/a/t/i/o/n/", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("51.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("mixedmode", "JavaUPlatfermU/PIUSpecificatien");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedmode" + "'", str2.equals("mixedmode"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("SUN.LWAWT.MACOSX.cpRINT", "18x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment-x86_64sun.awt.CGraphicsEnvironment1x86_64sun.awt.CGraphicsEnvironment#x86_64sun.awt.CGraphicsEnvironment0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test179");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(33, (int) ' ', 9740);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9740 + "'", int3 == 9740);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test181");
        float[] floatArray6 = new float[] { 10L, 10, '4', 10L, (short) 0, 10L };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ', 14, 10);
        float float15 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 52.0f + "'", float8 == 52.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0 10.0 52.0 10.0 0.0 10.0" + "'", str10.equals("10.0 10.0 52.0 10.0 0.0 10.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test182");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 4, (long) 24, 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4L + "'", long3 == 4L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test183");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("52.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52." + "'", str1.equals("52."));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test185");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ORACLEaCORPORATION", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test186");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 10 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 0, (int) (short) -1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test187");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "hi!h", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("MCAM4A3MCAM4A3MCAM4A3", "macosx");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MCAM4A3MCAM4A3MCAM4A3" + "'", str2.equals("MCAM4A3MCAM4A3MCAM4A3"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test189");
        short[] shortArray5 = new short[] { (byte) 100, (short) 10, (short) -1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 10 -1 -1 100" + "'", str7.equals("100 10 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004104-14-14100" + "'", str10.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100 10 -1 -1 100" + "'", str12.equals("100 10 -1 -1 100"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test190");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("10#1#1#1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test191");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.1", (java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test192");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 4, 0L, (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test193");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("###10.14.3", "SUN.LWAWT.MACOSX.cpRINTERj");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test194");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "ORACL...", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test195");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", "mac OS X", 18);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Aaaaaaaaaa", (java.lang.CharSequence[]) strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "1.1", 97, (int) (byte) 4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n" + "'", str1.equals("\n"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test197");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "         ", 14, (int) (short) -1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test198");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100", "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "10.0410.0452.0410.040.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#100" + "'", str1.equals("#100"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test201");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test202");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "0#10", (java.lang.CharSequence) "/Users/sophie/Library/Java/E18#-1#0/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test203");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("SX.cpRINTE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SX.cpRINTE" + "'", str1.equals("SX.cpRINTE"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("10 10 100", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                           10 10 100" + "'", str2.equals("                                           10 10 100"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test205");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100 10 -1 -1 100", (-1), 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test207");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/J/a/v/a/ /P/l/a/t/f/o/r/m/ /A/P/I/ /S/p/e/c/i/f/i/c/a/t/i/o/n/", (java.lang.CharSequence) "Macosx.cpr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test208");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1004444444444444444444444444444444444444444444444444", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test209");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test210");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/444444444ORACL...ORACL...ORACL.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test211");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) " HotSpot(TM) 64-Bit Server VMavaJ", (java.lang.CharSequence) "ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test212");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("######################", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "######################" + "'", str2.equals("######################"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test214");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/users/sophie", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("macosx", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "macosx" + "'", str2.equals("macosx"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test216");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test217");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hhhhhhhhhhhhhhhhhhhhhhhhhC.4", (java.lang.CharSequence) "C4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("en", "MCAM4A3MCAM4A3MCAM4A3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test219");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1.0410.040.040.0410.0", (java.lang.CharSequence) "mixedmode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22 + "'", int2 == 22);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test220");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "macosx", 24, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/", 500);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   /" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   /"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test222");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "4.0-1.010.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test223");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10414141");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION", "mIXED MODE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test225");
        char[] charArray12 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.6", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1m", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ORACLEaCORPORATION", (int) ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "              ORACLEaCORPORATION" + "'", str3.equals("              ORACLEaCORPORATION"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("4410444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4410444444444" + "'", str1.equals("4410444444444"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.6", (int) (byte) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.6" + "'", str3.equals("1.6"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test229");
        int[] intArray3 = new int[] { 18, (byte) -1, (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 16, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "18#-1#0" + "'", str5.equals("18#-1#0"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "18#-1#0" + "'", str13.equals("18#-1#0"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test230");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10101001", (java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("0#1-#81");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#1-#81" + "'", str1.equals("0#1-#81"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test232");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("http://java.oracle.com/", "1.8", 18);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test233");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIO", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test234");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("-", 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test235");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Library/Java/E18#-1#0/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie", 18, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie#####" + "'", str3.equals("/Users/sophie#####"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test238");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" ", " ");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "##################", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                             /444444444                                             ", (java.lang.CharSequence[]) strArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 18 + "'", int5 == 18);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test239");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("10a10a100a1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sop10410410041Java Platform API Specification", "X86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sop10410410041Java Platform API Specification" + "'", str2.equals("/Users/sop10410410041Java Platform API Specification"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test241");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "#a#a#a#aaaa", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test242");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "10enfals");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test243");
        char[] charArray12 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mac OS X", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Macosx.cpr", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test244");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 1.1f, (double) 7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test245");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("      Hi!       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "      HI!       " + "'", str1.equals("      HI!       "));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test247");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "18#-1#018#", 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test248");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", (int) (byte) 100, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "U" + "'", str3.equals("U"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test249");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10414141", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test250");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.6", (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("mixed mode", "oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test252");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERj", (java.lang.CharSequence) "############################################         ############################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("##################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test254");
        short[] shortArray5 = new short[] { (byte) 100, (short) 10, (short) -1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 10 -1 -1 100" + "'", str7.equals("100 10 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004104-14-14100" + "'", str10.equals("1004104-14-14100"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1004104-14-14100" + "'", str13.equals("1004104-14-14100"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test255");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test256");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "-1.0410.040.040.0410.0");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("en", "1.5", (int) (short) 4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("10.0 10.0 52.0 10.0 0.0 10.0", strArray4, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "10.0 10.0 52.0 10.0 0.0 10.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0 10.0 52.0 10.0 0.0 10.0" + "'", str9.equals("10.0 10.0 52.0 10.0 0.0 10.0"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("cosx.cpr", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cosx.cpr " + "'", str2.equals("cosx.cpr "));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test258");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test259");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0#1-#81", 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test260");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "JavaUPlatfermU/PIUSpecificatien", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test261");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test262");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Mixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode", "0.9", "1004444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test263");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "# # # # a 4", (java.lang.CharSequence) "7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test265");
        double[] doubleArray1 = new double[] { 52.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', (int) 'a', 8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 1, (int) (short) 0);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 52.0d + "'", double11 == 52.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "52.0" + "'", str13.equals("52.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 52.0d + "'", double14 == 52.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test266");
        short[] shortArray3 = new short[] { (byte) -1, (short) 100, (byte) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1#100#-1" + "'", str6.equals("-1#100#-1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a100a-1" + "'", str8.equals("-1a100a-1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1#100#-1" + "'", str10.equals("-1#100#-1"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.0 10.0 52.0 10.0 0.0 10.0", 142, "10.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.31010.0 10.0 52.0 10.0 0.0 10.0" + "'", str3.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.31010.0 10.0 52.0 10.0 0.0 10.0"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test268");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10 10 100", 10410410041L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10410410041L + "'", long2 == 10410410041L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test269");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"          \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test270");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("rs/_v/6v59", "10#1#1#1", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test271");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray12 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10410410041MAC os x", charArray12);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray12, '4');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_80-b15", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-", charArray12);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray12, 'a', 97, 24);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.0 10.0 52.0 10.0 0.0 10.0", charArray12);
        int int24 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "#4#4#4#4a44" + "'", str16.equals("#4#4#4#4a44"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test272");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str6 = javaVersion0.toString();
        java.lang.String str7 = javaVersion0.toString();
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str9 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion10 = null;
        try {
            boolean boolean11 = javaVersion0.atLeast(javaVersion10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.4" + "'", str9.equals("1.4"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test273");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", "mac OS X", 18);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "en" + "'", str4.equals("en"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Java Virtual Machine Specification", (int) (short) 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Virtual Machine Specification" + "'", str2.equals(" Virtual Machine Specification"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test275");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("97 0", 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test276");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 100.0f, 0.0d, (double) 12);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test277");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.4");
        java.math.BigDecimal bigDecimal3 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal bigDecimal5 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10");
        java.math.BigDecimal[] bigDecimalArray6 = new java.math.BigDecimal[] { bigDecimal1, bigDecimal3, bigDecimal5 };
        java.math.BigDecimal bigDecimal8 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.4");
        java.math.BigDecimal bigDecimal10 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal bigDecimal12 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10");
        java.math.BigDecimal[] bigDecimalArray13 = new java.math.BigDecimal[] { bigDecimal8, bigDecimal10, bigDecimal12 };
        java.math.BigDecimal bigDecimal15 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.4");
        java.math.BigDecimal bigDecimal17 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal bigDecimal19 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10");
        java.math.BigDecimal[] bigDecimalArray20 = new java.math.BigDecimal[] { bigDecimal15, bigDecimal17, bigDecimal19 };
        java.math.BigDecimal bigDecimal22 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.4");
        java.math.BigDecimal bigDecimal24 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4");
        java.math.BigDecimal bigDecimal26 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10");
        java.math.BigDecimal[] bigDecimalArray27 = new java.math.BigDecimal[] { bigDecimal22, bigDecimal24, bigDecimal26 };
        java.math.BigDecimal[][] bigDecimalArray28 = new java.math.BigDecimal[][] { bigDecimalArray6, bigDecimalArray13, bigDecimalArray20, bigDecimalArray27 };
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray28);
        org.junit.Assert.assertNotNull(bigDecimal1);
        org.junit.Assert.assertNotNull(bigDecimal3);
        org.junit.Assert.assertNotNull(bigDecimal5);
        org.junit.Assert.assertNotNull(bigDecimalArray6);
        org.junit.Assert.assertNotNull(bigDecimal8);
        org.junit.Assert.assertNotNull(bigDecimal10);
        org.junit.Assert.assertNotNull(bigDecimal12);
        org.junit.Assert.assertNotNull(bigDecimalArray13);
        org.junit.Assert.assertNotNull(bigDecimal15);
        org.junit.Assert.assertNotNull(bigDecimal17);
        org.junit.Assert.assertNotNull(bigDecimal19);
        org.junit.Assert.assertNotNull(bigDecimalArray20);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertNotNull(bigDecimal24);
        org.junit.Assert.assertNotNull(bigDecimal26);
        org.junit.Assert.assertNotNull(bigDecimalArray27);
        org.junit.Assert.assertNotNull(bigDecimalArray28);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test278");
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "en", charArray11);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray11, ' ', 4, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test279");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-1a100a-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test280");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "cosx.cpr", "10.00101001.052.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test281");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie#####", "cosx.cpr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test282");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("0A10", "SUN.LWAWT.MACOSX.cpRINTERjO", "ORACLE CORPORATION");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test283");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Oracle Corporatio", 33, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test284");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "########a#4", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test285");
        double[] doubleArray1 = new double[] { 52.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', (int) 'a', 8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 1, (int) (short) 0);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double15 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 30, 3);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 52.0d + "'", double11 == 52.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "52.0" + "'", str13.equals("52.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 52.0d + "'", double14 == 52.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 52.0d + "'", double15 == 52.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test286");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("44444444444444451.04444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test287");
        java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("#100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 256 + "'", int1.equals(256));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                                 ", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                 " + "'", str3.equals("                                                                                                 "));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test289");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation", (java.lang.CharSequence) "x");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test290");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "            10 10 100 1            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test291");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!", (java.lang.CharSequence) "Aaaaaaaaaa", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test292");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10");
        java.lang.String[] strArray8 = new java.lang.String[] { "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.31010.0 10.0 52.0 10.0 0.0 10.0", "-1#100#-1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "9740", "aaaaaaaaaa" };
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("0aSUN.AWT.cgRAPHICSeNVIRONMENT0", strArray2, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("########en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "########en" + "'", str1.equals("########en"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Aaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("#4#4#4#4a44", "-1.041.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#4#4#4#4a44" + "'", str2.equals("#4#4#4#4a44"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test296");
        char[] charArray11 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray11);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray11, '4', 1, (int) (short) -1);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray11);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10410410041", charArray11);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ETNIRpc.XSOCAM.TWAWL.NU", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("10 10 100", "1m");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 10 100" + "'", str2.equals("10 10 100"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test298");
        char[] charArray10 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", charArray10);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ', (int) '#', 0);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test299");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "01#0", (java.lang.CharSequence) "0A10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test301");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test302");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "#100                                                                                             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                   ", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   " + "'", str2.equals("   "));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("x so CAM14001401401", 9740, "1.8");
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("EN");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EN" + "'", str1.equals("EN"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test306");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test307");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("01#0", "/Users/sophie", "S", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "01#0" + "'", str4.equals("01#0"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test308");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS XOracle Corporatio0410410041mac OS X", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSX" + "'", str2.equals("0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSXOracleCorporatio0410410041macOSX"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test310");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        java.lang.String str6 = javaVersion4.toString();
        boolean boolean7 = javaVersion2.atLeast(javaVersion4);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.6" + "'", str6.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0a10.0a0.0a0.0a10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("rs/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test312");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str4 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean7 = javaVersion0.atLeast(javaVersion5);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.3" + "'", str4.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test313");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "mac os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test314");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10a10a100a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10a10a100a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "###10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test316");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("            10 10 100 1            ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test317");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8-1.0A10.0A0.0A0.0A10.01.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0_801.7.0_8" + "'", str2.equals(".0_801.7.0_8"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("X86_64SUN.AWT.CGRAPHICSENVIRONMENT100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64SUN.AWT.CGRAPHICSENVIRONMENT100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -" + "'", str2.equals("X86_64SUN.AWT.CGRAPHICSENVIRONMENT100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test320");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', 2, 3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("         ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test322");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "0410410041mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test323");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(" Virtual Machine Specification", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " Virtual Machine Specification" + "'", str3.equals(" Virtual Machine Specification"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test324");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0#1-#81", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("10410410041MAC os x", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test326");
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 10, 0.0f, (short) 0, 10.0f };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', (int) (short) 100, 2);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double15 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0410.040.040.0410.0" + "'", str8.equals("-1.0410.040.040.0410.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test327");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIO", (short) (byte) 4);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 4 + "'", short2 == (short) 4);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Users/sophie#####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test329");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 10 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 35, 378);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test330");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "ns:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test332");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str6 = javaVersion0.toString();
        java.lang.String str7 = javaVersion0.toString();
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        boolean boolean11 = javaVersion0.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str13 = javaVersion12.toString();
        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        boolean boolean16 = javaVersion9.atLeast(javaVersion12);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.4" + "'", str13.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test333");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10410410041", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test334");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "rs/_v/6v59");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test335");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "52.", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test336");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("10414141");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10414141L + "'", long1 == 10414141L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test337");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1.0a10.0a0.0a0.0a10.0", (float) 9);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test338");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 4, 9, 107);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 107 + "'", int3 == 107);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("410410041", "1..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "410410041" + "'", str2.equals("410410041"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test340");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "10                                                                                                  ", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test341");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 1L, (float) 28, (float) '#');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test342");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("hi", "/444444444", 30, (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi/444444444" + "'", str4.equals("hi/444444444"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test343");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/E18#-1#0", charSequence1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("NOITAROPROCaELCARO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOITAROPROCaELCARO" + "'", str1.equals("NOITAROPROCaELCARO"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test345");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("10101001");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test346");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 6, 378);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a10a100a1" + "'", str8.equals("10a10a100a1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10 10 100 1" + "'", str10.equals("10 10 100 1"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test347");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1" + "'", charSequence2.equals("-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1-1a100a-1"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test348");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10410410041MAC os x", "1.7.0_80");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80100", (java.lang.CharSequence[]) strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "              ORACLEaCORPORATION");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10410410041MAC os x" + "'", str7.equals("10410410041MAC os x"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("7.1", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7.1" + "'", str2.equals("7.1"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "1.0a100.", "-1 100 -1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test351");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test352");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("http://java.oracle.com/", "100#10#-1#-1#100", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test353");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 24L, (double) 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 24.0d + "'", double3 == 24.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie" + "'", str1.equals("/users/sophie"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test355");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\n", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test356");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "ETNIRpc.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test357");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("24.80-b11", 10414141L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10414141L + "'", long2 == 10414141L);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test358");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("cosx.cpr", "############################################         ############################################", 12, 28);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "cosx.cpr############################################         ############################################" + "'", str4.equals("cosx.cpr############################################         ############################################"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test359");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("a", "", "      Hi!       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "      Hi!       a      Hi!       " + "'", str3.equals("      Hi!       a      Hi!       "));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test361");
        char[] charArray10 = new char[] { '#', '#', '#', '#', 'a', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http://java.oracle.com/", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "::::::::", charArray10);
        java.lang.Class<?> wildcardClass15 = charArray10.getClass();
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test362");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test363");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ", "/Users/sop10410410041Java Platform API Specification", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ" + "'", str3.equals("1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test364");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "x86_64sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("18#-1#018#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "18#-1#018#" + "'", str1.equals("18#-1#018#"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation", "NOITAROPROCaELCARO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation" + "'", str2.equals("oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation-1.0a10.0a0.0a0.0a10.0oracle corporation"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test367");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie#####", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("MCAM4A3MCAM4A3MCAM4A3", "tionacle CorporaOr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MCAM4A3MCAM4A3MCAM4A3" + "'", str2.equals("MCAM4A3MCAM4A3MCAM4A3"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test369");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "18#-1#0", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test370");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("SUN.LWAWT.MACOSX.cpRINTERjOB       ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test371");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.4");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION", "############################################         ############################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION" + "'", str2.equals("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase(".0_801.7.0_8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".0_801.7.0_8" + "'", str1.equals(".0_801.7.0_8"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test374");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 1, 0L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test375");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test376");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "9740", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test377");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10414141L, (double) 1.041041E7f, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test378");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIONhi!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test379");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/Java/E18#-1#0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test380");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.0", "1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ", "X86_64", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0" + "'", str4.equals("1.0"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("4444", "Macosx.cpr", "US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444" + "'", str3.equals("4444"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test382");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ", "10#10#100#1", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test383");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("01#0", 16, "mixedmode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "01#0mixedmodemix" + "'", str3.equals("01#0mixedmodemix"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test384");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100", "x so CAM14001401401", 3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test385");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "            10 10 100 1            ", 14, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test386");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("-1.0410.040.040.0410.0");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test387");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("EN##################################################", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test388");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("x86_64sun.awt.CGraphicsEnvironment");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "X86_64", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "x4864_4644sun4.4awt4.4CG4raphics4E4nvironment" + "'", str4.equals("x4864_4644sun4.4awt4.4CG4raphics4E4nvironment"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test389");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 256, (double) 52.0f, (double) 142);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 256.0d + "'", double3 == 256.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test390");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("46_68x", (float) 17);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 17.0f + "'", float2 == 17.0f);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test391");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATIO", (java.lang.CharSequence) "0A10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test392");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("#100                                                                                             ");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ', 14, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 14");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test393");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test394");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.0a100.0", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0a100.0" + "'", str3.equals("1.0a100.0"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test395");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Macosx.cpr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test396");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", "                                                                                                 ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test397");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10.14.3", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test399");
        int[] intArray3 = new int[] { 18, (byte) -1, (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "18#-1#0" + "'", str5.equals("18#-1#0"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "184-140" + "'", str9.equals("184-140"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test400");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1mac os x-1a100a-1", (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Mixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode", 33, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode" + "'", str3.equals("Mixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode10enfalseMixed mode"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("#a#a#a#aaa4", "-1.041.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#a#a#a#aaa4" + "'", str2.equals("#a#a#a#aaa4"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("########a#M", "#a#a#a#aaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a#a#a#aaaa" + "'", str2.equals("a#a#a#aaaa"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 31, "01#0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "01#001#001#001#001#001#001#001#" + "'", str3.equals("01#001#001#001#001#001#001#001#"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test405");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "410410041", (java.lang.CharSequence) "O1.7.0_80-b15racle1.7.0_80-b151.7.0_80-b15C1.7.0_80-b15orporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test406");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("4444", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test407");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 8, 0L, (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test408");
        float[] floatArray6 = new float[] { 10L, 10, '4', 10L, (short) 0, 10L };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', (int) (short) 100, (int) (short) 1);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 52.0f + "'", float12 == 52.0f);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 52.0f + "'", float13 == 52.0f);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test409");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 35, (long) 500, 97L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 500L + "'", long3 == 500L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test410");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 17, 0L, (long) 97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test411");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.4", (java.lang.CharSequence) "97 0", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("0410410041mac OS X", "0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test413");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 18, (long) 9, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 18L + "'", long3 == 18L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("7.17.17.17.17.17.17.17.17.1/", (int) (short) 4, "100 10 -1 -1 100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7.17.17.17.17.17.17.17.17.1/" + "'", str3.equals("7.17.17.17.17.17.17.17.17.1/"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("SUN.LWAWT.MACOSX.cpRINTERjOB", "########en");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("0410410041mac OS X", 14, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("oRACLECORPORATION", "1.0a100.0", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION" + "'", str3.equals("oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test418");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("46_68x", "#100", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "46_68x#10046_68x#10046_68x" + "'", str3.equals("46_68x#10046_68x#10046_68x"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test420");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 16, (long) 32, (long) (short) 4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test421");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("x86_64sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test422");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test423");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) (short) 10, (-1));
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', 2, 2);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte19 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10410410041" + "'", str6.equals("10410410041"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10#10#100#1" + "'", str18.equals("10#10#100#1"));
        org.junit.Assert.assertTrue("'" + byte19 + "' != '" + (byte) 1 + "'", byte19 == (byte) 1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(" sun.lwawt.macosx.cprinterjob", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cosx.cprinterjobawt.ma sun.lw" + "'", str2.equals("cosx.cprinterjobawt.ma sun.lw"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test425");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "4.0 1.0 10.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test426");
        short[] shortArray5 = new short[] { (byte) 100, (short) 10, (short) -1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', (int) (short) 4, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 10 -1 -1 100" + "'", str7.equals("100 10 -1 -1 100"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test427");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                                 1.7", "##################", 18);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test428");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10a10a100a1", (java.lang.CharSequence) "X86_64SUN.AWT.CGRAPHICSENVIRONMENT100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -1 -1 100100 10 -");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10a10a100a1", 142, "S");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a10a100a1SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS" + "'", str3.equals("10a10a100a1SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.4", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test431");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test432");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("x86_64sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x86_64sun.awt.CGraphicsEnvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test433");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "-1#100#-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test434");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test435");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aa01#0aa", (java.lang.CharSequence) "######################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test436");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 256, (long) 100, (long) 8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 256L + "'", long3 == 256L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test437");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sop10410410041mac OS XORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL...ORACL.ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test438");
        double[] doubleArray1 = new double[] { 52.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "52.0" + "'", str5.equals("52.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52.0" + "'", str7.equals("52.0"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test439");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4.0-1.010.", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4.0-1.010." + "'", str3.equals("4.0-1.010."));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.7", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   1.7" + "'", str2.equals("   1.7"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("U", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "U" + "'", str2.equals("U"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test442");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION", (int) (byte) 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-1a100a-1", 0, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50469_1560277335");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1a100a-1" + "'", str3.equals("-1a100a-1"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test444");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 4, (short) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 4 + "'", short3 == (short) 4);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "-141004-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-141004-1" + "'", str2.equals("-141004-1"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", " sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " sun.lwawt.macosx.cprinterjob" + "'", str2.equals(" sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test447");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.0al Ma VirtuavationJachine Specifical Ma VirtuavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test448");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sUN.LWAWT.MACOSX.cpRINTERj");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test449");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("10.14.3", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test452");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0#10", "10410410041m");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test453");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("SX.cpRINTE", (int) (byte) 1, 16);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X.cpRINTE" + "'", str3.equals("X.cpRINTE"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test454");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhC.4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test455");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ORACL...", (java.lang.CharSequence) "01#0mixedmodemix", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test456");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION" + "'", str1.equals("oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION1.0a100.0oRACLECORPORATION"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test457");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "4.0-1.010.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test458");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/librar", (java.lang.CharSequence) "10.0 10.0 52.0 10.0 0.0 10.0", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test459");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "4410444444444", (java.lang.CharSequence) "racle Corporati");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test460");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1..");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.." + "'", str1.equals("1.."));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test461");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("#M#M#M#MaM", (int) (byte) 0, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#M#M#M#MaM" + "'", str3.equals("#M#M#M#MaM"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test462");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaat.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaat.jar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test463");
        short[] shortArray1 = new short[] { (short) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', 0, 0);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', (int) (short) -1, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test464");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 28, 0.0d, (double) 9.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.0d + "'", double3 == 28.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test465");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(8, 14, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("mac OS X", "ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION111111111111111111ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mac OS X" + "'", str2.equals("mac OS X"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test467");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "10                                                                                                  ", (java.lang.CharSequence) "O1.7.0_80-b15racle1.7.0_80-b15 1.7.0_80-b15C1.7.0_80-b15orporation                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test468");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                                 1.7", (java.lang.CharSequence) "10101001");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test469");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "0A10", (java.lang.CharSequence) "          ", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test470");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1004104-14-14100", (java.lang.CharSequence) "mixedmode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test471");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Librar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test472");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (java.lang.CharSequence) "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test473");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 10L, (float) 10, (float) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test474");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("0.9");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test475");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-1.0410.040.040.0410.0-1.0410.040.040.0410.0-1.0410.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test476");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4410...", (java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTEN", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test477");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "          ", 10, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test478");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '#', 31, 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test479");
        long[] longArray1 = new long[] { 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        java.lang.Class<?> wildcardClass4 = longArray1.getClass();
        java.lang.Class<?> wildcardClass5 = longArray1.getClass();
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ', 0, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test480");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 10 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0410" + "'", str5.equals("0410"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test481");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("97a0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test482");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "   ", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", 142);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test483");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "-141004-1", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test484");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION", "-1#100#-1", 10);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "rs/_v/6v59");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.Class<?> wildcardClass9 = strArray4.getClass();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION" + "'", str6.equals("ORACLE CORPORATIONrs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59rs/_v/6v59#########ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION##################ORACLE CORPORATION"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test485");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("en", "/", (int) (short) 10);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", (java.lang.CharSequence[]) strArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.044.040.04100.0435.0", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "0a10");
        int int13 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray12);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "en" + "'", str6.equals("en"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "en" + "'", str9.equals("en"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test486");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                           10 10 100", (java.lang.CharSequence) "1.7.0_80100", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test487");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", (java.lang.CharSequence) "S");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "-1.0#22.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test489");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "11b-08.42");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test490");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.lwawt.macosx.CPrinterJob", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("HI", 256);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test492");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "-1.0410.040.040.0410.0");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Macosx.cpr", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test493");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1004104-14-14100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1.044.040.04100.0435.0", "1.6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre16616-1-1166/Library/Java/JavaVirtualMachines/jdk1.7.6_86.jdk/Contents/Home/jre"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test494");
        double[] doubleArray1 = new double[] { 52.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', (int) 'a', 8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 1, (int) (short) 0);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double15 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double16 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 52.0d + "'", double11 == 52.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "52.0" + "'", str13.equals("52.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 52.0d + "'", double14 == 52.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 52.0d + "'", double15 == 52.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test495");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "10410410041mac OS X");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 19 + "'", int1 == 19);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test496");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0410", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test497");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 4, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("macosx.cpr", 19, (int) (short) 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test499");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "1.11.11.11.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test500");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) ".0_801.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}

