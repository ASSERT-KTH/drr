import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        java.lang.String str2 = strBuilder1.getNewLineText();
        java.lang.Class<?> wildcardClass3 = strBuilder1.getClass();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.setNewLineText("1-1.0");
        boolean boolean7 = strBuilder5.endsWith("");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        char[] charArray11 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder1.append(charArray11);
        char[] charArray13 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray13, strMatcher14);
        java.lang.String[] strArray16 = strTokenizer15.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher17 = strTokenizer15.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder12.deleteFirst(strMatcher17);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder12.setLength((int) (byte) 0);
        int int23 = strBuilder12.lastIndexOf('4', (int) (short) 1);
        boolean boolean25 = strBuilder12.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        java.lang.String str28 = strBuilder27.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder27.delete((int) (short) 0, (int) (byte) 100);
        boolean boolean33 = strBuilder31.endsWith("1");
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer();
        java.lang.String str36 = strTokenizer35.previousToken();
        org.apache.commons.lang.text.StrMatcher strMatcher37 = strTokenizer35.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse", strMatcher37);
        int int40 = strBuilder31.indexOf(strMatcher37, (-1));
        java.lang.StringBuffer stringBuffer41 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder31.append(stringBuffer41, (int) (byte) 10, 52);
        char[] charArray45 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer(charArray45, strMatcher46);
        java.lang.String[] strArray48 = strTokenizer47.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder44.appendWithSeparators((java.lang.Object[]) strArray48, "1004444444true4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444f");
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder44.appendPadding(97, '#');
        char[] charArray54 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher55 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer(charArray54, strMatcher55);
        java.lang.String[] strArray57 = strTokenizer56.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer56.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer56.setIgnoredChar('a');
        java.lang.String[] strArray61 = strTokenizer60.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder44.appendWithSeparators((java.lang.Object[]) strArray61, "4444444444444444444444444444444444444444444444444444444f4lse");
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder12.appendWithSeparators((java.lang.Object[]) strArray61, "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444flse");
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strMatcher17);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(strMatcher37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(strArray61);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertNotNull(strBuilder65);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("hi!", '0');
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        char[] charArray11 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder1.append(charArray11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = new org.apache.commons.lang.text.StrTokenizer(charArray11, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer14.reset("");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder18.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder26.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int32 = strBuilder26.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder26.replaceFirst('a', '4');
        char[] charArray36 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder26.append(charArray36);
        char[] charArray38 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher39 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer(charArray38, strMatcher39);
        java.lang.String[] strArray41 = strTokenizer40.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher42 = strTokenizer40.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder37.deleteFirst(strMatcher42);
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder22.replaceFirst(strMatcher42, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer14.setTrimmerMatcher(strMatcher42);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer14.setDelimiterString("114.0");
        java.lang.Object obj49 = strTokenizer14.clone();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 96 + "'", int32 == 96);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(strMatcher42);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(obj49);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        java.lang.Object obj14 = null;
        boolean boolean15 = strBuilder13.equals(obj14);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder17.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int23 = strBuilder17.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder17.replaceFirst('a', '4');
        char[] charArray27 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder17.append(charArray27);
        char[] charArray29 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray29, strMatcher30);
        java.lang.String[] strArray32 = strTokenizer31.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher33 = strTokenizer31.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder28.appendWithSeparators((java.util.Iterator) strTokenizer31, "lse");
        char[] charArray38 = new char[] { ' ', '4' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer31.reset(charArray38);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder13.append(charArray38);
        java.lang.String str43 = strBuilder40.midString((int) (short) 1, 35);
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder40.insert((int) '4', (int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder48.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int54 = strBuilder48.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder48.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder57.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder57.replaceFirst('#', '4');
        int int64 = strBuilder57.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder57.deleteAll("lse");
        org.apache.commons.lang.text.StrBuilder strBuilder68 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder68.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int74 = strBuilder68.indexOf('a');
        boolean boolean76 = strBuilder68.endsWith("");
        int int77 = strBuilder68.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder78 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder68.append(strBuilder78, (int) '4', (int) (byte) 10);
        char[] charArray85 = new char[] { 'a', ' ', ' ' };
        char[] charArray86 = strBuilder68.getChars(charArray85);
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = new org.apache.commons.lang.text.StrTokenizer(charArray86);
        char[] charArray88 = strBuilder66.getChars(charArray86);
        org.apache.commons.lang.text.StrTokenizer strTokenizer89 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray88);
        char[] charArray90 = strBuilder46.getChars(charArray88);
        org.apache.commons.lang.text.StrTokenizer strTokenizer92 = new org.apache.commons.lang.text.StrTokenizer(charArray90, '4');
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 96 + "'", int23 == 96);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(charArray38);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "44444444444444444444444444444444444" + "'", str43.equals("44444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 96 + "'", int54 == 96);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 100 + "'", int64 == 100);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strBuilder72);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 96 + "'", int74 == 96);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 100 + "'", int77 == 100);
        org.junit.Assert.assertNotNull(strBuilder81);
        org.junit.Assert.assertNotNull(charArray85);
        org.junit.Assert.assertNotNull(charArray86);
        org.junit.Assert.assertNotNull(charArray88);
        org.junit.Assert.assertNotNull(strTokenizer89);
        org.junit.Assert.assertNotNull(charArray90);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int21 = strBuilder15.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder15.replaceFirst('a', '4');
        java.lang.Object[] objArray29 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder13.appendWithSeparators(objArray29, "");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder13.deleteAll('#');
        int int36 = strBuilder13.indexOf("lse", 10);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder13.insert(3, (float) 35);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 96 + "'", int21 == 96);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 97 + "'", int36 == 97);
        org.junit.Assert.assertNotNull(strBuilder39);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.deleteFirst('a');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder11.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder15.clear();
        char[] charArray17 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher18 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer(charArray17, strMatcher18);
        java.lang.String[] strArray20 = strTokenizer19.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer19.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder16.replaceFirst(strMatcher21, "hi!");
        char[] charArray24 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher25 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer(charArray24, strMatcher25);
        org.apache.commons.lang.text.StrMatcher strMatcher27 = strTokenizer26.getIgnoredMatcher();
        int int29 = strBuilder16.indexOf(strMatcher27, (int) '4');
        boolean boolean30 = strBuilder1.contains(strMatcher27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strBuilder1.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder32 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder1.append(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strMatcher27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strBuilder33);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int21 = strBuilder15.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder15.replaceFirst('a', '4');
        java.lang.Object[] objArray29 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder13.appendWithSeparators(objArray29, "");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder31.append('4');
        java.lang.StringBuffer stringBuffer34 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.append(stringBuffer34);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder38.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder42.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder42.append((double) 100L);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder48.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        java.lang.String str54 = strBuilder48.substring((int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder48.append((int) (short) 100);
        java.util.Collection collection57 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder48.appendWithSeparators(collection57, "");
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder46.append(strBuilder59);
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder60.append("4lse441000-1.0 0.0");
        org.apache.commons.lang.text.StrBuilder strBuilder64 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder64.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int70 = strBuilder64.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder64.replaceFirst('a', '4');
        char[] charArray74 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder64.append(charArray74);
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = new org.apache.commons.lang.text.StrTokenizer(charArray74, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder78 = strBuilder62.append(charArray74);
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder35.insert(4, charArray74);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 96 + "'", int21 == 96);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "lse" + "'", str54.equals("lse"));
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 96 + "'", int70 == 96);
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertNotNull(charArray74);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertNotNull(strBuilder78);
        org.junit.Assert.assertNotNull(strBuilder79);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        char[] charArray0 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer(charArray0, strMatcher1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = strTokenizer2.reset("lse");
        int int5 = strTokenizer2.previousIndex();
        org.apache.commons.lang.text.StrBuilder strBuilder7 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder7.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int13 = strBuilder7.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder7.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder16.delete((int) (short) 100, (int) (short) 100);
        java.lang.Object obj20 = null;
        boolean boolean21 = strBuilder19.equals(obj20);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder23.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int29 = strBuilder23.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder23.replaceFirst('a', '4');
        char[] charArray33 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder23.append(charArray33);
        char[] charArray35 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher36 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray35, strMatcher36);
        java.lang.String[] strArray38 = strTokenizer37.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer37.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder34.deleteFirst(strMatcher39);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder19.deleteAll(strMatcher39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer2.setTrimmerMatcher(strMatcher39);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder44.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder48.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder48.deleteAll('a');
        java.lang.String str52 = strBuilder48.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder48.append((int) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder56.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder60.clear();
        char[] charArray62 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher63 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = new org.apache.commons.lang.text.StrTokenizer(charArray62, strMatcher63);
        java.lang.String[] strArray65 = strTokenizer64.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher66 = strTokenizer64.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder61.replaceFirst(strMatcher66, "hi!");
        char[] charArray69 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher70 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer(charArray69, strMatcher70);
        org.apache.commons.lang.text.StrMatcher strMatcher72 = strTokenizer71.getIgnoredMatcher();
        int int74 = strBuilder61.indexOf(strMatcher72, (int) '4');
        int int75 = strBuilder54.lastIndexOf(strMatcher72);
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = strTokenizer2.setIgnoredMatcher(strMatcher72);
        org.junit.Assert.assertNotNull(strTokenizer4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 96 + "'", int13 == 96);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 96 + "'", int29 == 96);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(strMatcher39);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(strArray65);
        org.junit.Assert.assertNotNull(strMatcher66);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strMatcher72);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer76);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.deleteAll('a');
        char[] charArray9 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder8.append(charArray9, (int) (short) 100, 1);
        int int15 = strBuilder8.indexOf("lse", (int) (short) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder8.deleteFirst("41");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.appendPadding(8, 'a');
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder20);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder9.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int15 = strBuilder9.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder9.replaceFirst('a', '4');
        char[] charArray19 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder9.append(charArray19);
        char[] charArray21 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer(charArray21, strMatcher22);
        java.lang.String[] strArray24 = strTokenizer23.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer23.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder20.deleteFirst(strMatcher25);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder5.replaceFirst(strMatcher25, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder28.setNewLineText("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.setEmptyTokenAsNull(true);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder30.append((java.lang.Object) true);
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder34.append("");
        int int39 = strBuilder36.indexOf("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444f", (int) '0');
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 96 + "'", int15 == 96);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance("44444444444444444444444444444444444");
        boolean boolean2 = strTokenizer1.hasNext();
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        char[] charArray11 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder1.append(charArray11);
        char[] charArray13 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray13, strMatcher14);
        java.lang.String[] strArray16 = strTokenizer15.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher17 = strTokenizer15.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder12.deleteFirst(strMatcher17);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder12.append((int) (short) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder22.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder26.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder26.append((double) 100L);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder26.reverse();
        boolean boolean33 = strBuilder31.endsWith("1");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder31.deleteAll(".0");
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder20.appendFixedWidthPadRight((java.lang.Object) ".0", (int) (byte) 0, '0');
        org.apache.commons.lang.text.StrBuilder strBuilder40 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder40.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int46 = strBuilder40.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder40.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder40.insert((int) '#', 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder52.deleteCharAt((int) (byte) 100);
        java.lang.StringBuffer stringBuffer55 = strBuilder52.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder38.append(stringBuffer55);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder38.insert(10, (float) (short) -1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strMatcher17);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 96 + "'", int46 == 96);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(stringBuffer55);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder59);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.append('4');
        int int10 = strBuilder1.indexOf("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse41000-1.0 ", 63);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.minimizeCapacity();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.deleteAll('a');
        java.lang.String str10 = strBuilder5.rightString(0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder5.appendWithSeparators((java.util.Iterator) strTokenizer11, "StrTokenizer[not tokenized yet]");
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.deleteCharAt((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strBuilder13);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        char[] charArray11 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder1.append(charArray11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = new org.apache.commons.lang.text.StrTokenizer(charArray11, "1");
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder18.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.append('a');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder26.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int32 = strBuilder26.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder26.replaceFirst('a', '4');
        char[] charArray36 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder26.append(charArray36);
        char[] charArray38 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher39 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer(charArray38, strMatcher39);
        java.lang.String[] strArray41 = strTokenizer40.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher42 = strTokenizer40.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder37.deleteFirst(strMatcher42);
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder37.setLength((int) (byte) 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = new org.apache.commons.lang.text.StrTokenizer();
        java.lang.String str47 = strTokenizer46.previousToken();
        org.apache.commons.lang.text.StrMatcher strMatcher48 = strTokenizer46.getTrimmerMatcher();
        int int49 = strBuilder45.indexOf(strMatcher48);
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder24.deleteAll(strMatcher48);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = new org.apache.commons.lang.text.StrTokenizer("lse", strMatcher48);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher48);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 96 + "'", int32 == 96);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(strMatcher42);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(strMatcher48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(strBuilder50);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        java.lang.Object obj14 = null;
        boolean boolean15 = strBuilder13.equals(obj14);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder17.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int23 = strBuilder17.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder17.replaceFirst('a', '4');
        char[] charArray27 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder17.append(charArray27);
        char[] charArray29 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray29, strMatcher30);
        java.lang.String[] strArray32 = strTokenizer31.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher33 = strTokenizer31.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder28.deleteFirst(strMatcher33);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder13.deleteAll(strMatcher33);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder13.replaceFirst("", "");
        boolean boolean40 = strBuilder13.contains('a');
        int int43 = strBuilder13.indexOf("flse", 0);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 96 + "'", int23 == 96);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int21 = strBuilder15.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder15.replaceFirst('a', '4');
        java.lang.Object[] objArray29 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder13.appendWithSeparators(objArray29, "");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.insert((int) (short) 100, '4');
        char[] charArray37 = strBuilder34.toCharArray(0, 10);
        int int38 = strBuilder34.size();
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder34.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder42 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder42.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int48 = strBuilder42.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder42.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder51.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder56.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int62 = strBuilder56.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder56.replaceFirst('a', '4');
        java.lang.Object[] objArray70 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder54.appendWithSeparators(objArray70, "");
        java.lang.StringBuffer stringBuffer73 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder54.append(stringBuffer73, (-1), (int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder78 = strBuilder76.setNewLineText("hi!");
        int int80 = strBuilder76.lastIndexOf('#');
        boolean boolean81 = strBuilder34.equalsIgnoreCase(strBuilder76);
        char[] charArray82 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher83 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = new org.apache.commons.lang.text.StrTokenizer(charArray82, strMatcher83);
        java.lang.String[] strArray85 = strTokenizer84.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher86 = strTokenizer84.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer88 = strTokenizer84.setIgnoredChar('a');
        java.lang.String[] strArray89 = strTokenizer88.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder91 = strBuilder76.appendWithSeparators((java.lang.Object[]) strArray89, "1-1.0100.0");
        java.lang.StringBuffer stringBuffer92 = strBuilder91.toStringBuffer();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 96 + "'", int21 == 96);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 111 + "'", int38 == 111);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 96 + "'", int48 == 96);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 96 + "'", int62 == 96);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(strBuilder72);
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(strBuilder78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(strArray85);
        org.junit.Assert.assertNotNull(strMatcher86);
        org.junit.Assert.assertNotNull(strTokenizer88);
        org.junit.Assert.assertNotNull(strArray89);
        org.junit.Assert.assertNotNull(strBuilder91);
        org.junit.Assert.assertNotNull(stringBuffer92);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder9.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder13.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder13.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder18.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder22.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder23.setNewLineText("lse");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder13.appendFixedWidthPadLeft((java.lang.Object) strBuilder25, (int) '4', '#');
        boolean boolean29 = strBuilder5.equalsIgnoreCase(strBuilder25);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder31.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder35.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder36.setNewLineText("lse");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder40.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int46 = strBuilder40.indexOf('a');
        boolean boolean48 = strBuilder40.endsWith("");
        int int49 = strBuilder40.capacity();
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strBuilder40.asTokenizer();
        java.util.List list51 = strTokenizer50.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder38.appendWithSeparators((java.util.Collection) list51, "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse");
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder5.appendWithSeparators((java.util.Collection) list51, "lse");
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder55.clear();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 96 + "'", int46 == 96);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 100 + "'", int49 == 100);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(list51);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strBuilder56);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder10.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder14.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.setNewLineText("lse");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder5.appendFixedWidthPadLeft((java.lang.Object) strBuilder17, (int) '4', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder22.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder26.append('a');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder20.appendFixedWidthPadRight((java.lang.Object) 'a', (int) (short) 100, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer();
        java.lang.String str35 = strTokenizer34.previousToken();
        org.apache.commons.lang.text.StrMatcher strMatcher36 = strTokenizer34.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse", strMatcher36);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer("1", strMatcher36, strMatcher38);
        boolean boolean40 = strBuilder20.contains(strMatcher36);
        org.apache.commons.lang.text.StrBuilder strBuilder42 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        java.lang.String str43 = strBuilder42.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder42.append(false);
        int int48 = strBuilder45.lastIndexOf("StrTokenizer[not tokenized yet]", 97);
        boolean boolean49 = strBuilder20.equalsIgnoreCase(strBuilder45);
        java.lang.Class<?> wildcardClass50 = strBuilder20.getClass();
        org.apache.commons.lang.text.StrBuilder strBuilder52 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder52.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder56.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder56.delete((int) (short) 0, (int) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder62 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder62.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int68 = strBuilder62.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder62.deleteFirst('a');
        char[] charArray71 = null;
        char[] charArray72 = strBuilder62.getChars(charArray71);
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder60.append(charArray72);
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = new org.apache.commons.lang.text.StrTokenizer(charArray72);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder20.append(charArray72);
        org.apache.commons.lang.text.StrBuilder strBuilder77 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder77.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int83 = strBuilder77.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder86 = strBuilder77.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder77.insert((int) '#', 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder91 = strBuilder89.deleteCharAt((int) (byte) 100);
        java.lang.StringBuffer stringBuffer92 = strBuilder89.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder93 = strBuilder20.append(stringBuffer92);
        java.lang.StringBuffer stringBuffer94 = strBuilder93.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder95 = strBuilder93.appendNewLine();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(strMatcher36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 96 + "'", int68 == 96);
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNotNull(charArray72);
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertNotNull(strBuilder81);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 96 + "'", int83 == 96);
        org.junit.Assert.assertNotNull(strBuilder86);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder91);
        org.junit.Assert.assertNotNull(stringBuffer92);
        org.junit.Assert.assertNotNull(strBuilder93);
        org.junit.Assert.assertNotNull(stringBuffer94);
        org.junit.Assert.assertNotNull(strBuilder95);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        int int11 = strBuilder1.size();
        int int12 = strBuilder1.length();
        char[] charArray13 = null;
        char[] charArray14 = strBuilder1.getChars(charArray13);
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer(charArray14, 'a');
        boolean boolean17 = strTokenizer16.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer16.setEmptyTokenAsNull(true);
        int int20 = strTokenizer19.previousIndex();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        java.lang.String str7 = strBuilder5.leftString((int) (short) 1);
        java.lang.String str9 = strBuilder5.rightString((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder11.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int17 = strBuilder11.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder11.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder20.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder25.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int31 = strBuilder25.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder25.replaceFirst('a', '4');
        java.lang.Object[] objArray39 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder23.appendWithSeparators(objArray39, "");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder41.insert((int) (short) 100, '4');
        char[] charArray47 = strBuilder44.toCharArray(0, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder5.append(charArray47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer(charArray47, 'a', 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer(charArray47, "4444444444");
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray47);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 96 + "'", int17 == 96);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 96 + "'", int31 == 96);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(charArray47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertNotNull(strTokenizer55);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        char[] charArray11 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder1.append(charArray11);
        char[] charArray13 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray13, strMatcher14);
        java.lang.String[] strArray16 = strTokenizer15.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher17 = strTokenizer15.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder12.deleteFirst(strMatcher17);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder20.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int26 = strBuilder20.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder20.replaceFirst('a', '4');
        char[] charArray30 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder20.append(charArray30);
        char[] charArray32 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher33 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer(charArray32, strMatcher33);
        java.lang.String[] strArray35 = strTokenizer34.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher36 = strTokenizer34.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder31.deleteFirst(strMatcher36);
        boolean boolean38 = strBuilder12.equals((java.lang.Object) strBuilder31);
        java.lang.String str40 = strBuilder31.leftString(0);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder31.trim();
        java.lang.String str43 = strBuilder41.rightString((int) '4');
        int int45 = strBuilder41.lastIndexOf("2");
        java.lang.StringBuffer stringBuffer46 = strBuilder41.toStringBuffer();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strMatcher17);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 96 + "'", int26 == 96);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(strMatcher36);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "44444444444444444444444444444444444444444444444f4lse" + "'", str43.equals("44444444444444444444444444444444444444444444444f4lse"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer46);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder9.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder13.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder13.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder18.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder22.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder23.setNewLineText("lse");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder13.appendFixedWidthPadLeft((java.lang.Object) strBuilder25, (int) '4', '#');
        boolean boolean29 = strBuilder5.equalsIgnoreCase(strBuilder25);
        int int31 = strBuilder5.lastIndexOf('a');
        java.io.Reader reader32 = strBuilder5.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder5.append((double) 114);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(reader32);
        org.junit.Assert.assertNotNull(strBuilder34);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder5.append((double) (short) -1);
        int int13 = strBuilder10.indexOf('#', 0);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int22 = strBuilder16.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder16.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder16.insert((int) '#', 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder30.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int36 = strBuilder30.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder30.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder39.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder44.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int50 = strBuilder44.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder44.replaceFirst('a', '4');
        java.lang.Object[] objArray58 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder42.appendWithSeparators(objArray58, "");
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder60.insert((int) (short) 100, '4');
        char[] charArray66 = strBuilder63.toCharArray(0, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder28.append(charArray66);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder10.insert((-1), charArray66, 9, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 96 + "'", int22 == 96);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 96 + "'", int36 == 96);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 96 + "'", int50 == 96);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strBuilder67);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        char[] charArray0 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer(charArray0, strMatcher1);
        int int3 = strTokenizer2.size();
        boolean boolean4 = strTokenizer2.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer6 = strTokenizer2.setDelimiterChar(' ');
        org.apache.commons.lang.text.StrMatcher strMatcher7 = strTokenizer6.getIgnoredMatcher();
        boolean boolean8 = strTokenizer6.hasNext();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strTokenizer6);
        org.junit.Assert.assertNotNull(strMatcher7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        char[] charArray0 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder2.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder10.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int16 = strBuilder10.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder10.replaceFirst('a', '4');
        char[] charArray20 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder10.append(charArray20);
        char[] charArray22 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray22, strMatcher23);
        java.lang.String[] strArray25 = strTokenizer24.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher26 = strTokenizer24.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder21.deleteFirst(strMatcher26);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder6.replaceFirst(strMatcher26, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer(charArray0, strMatcher26);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 96 + "'", int16 == 96);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(strMatcher26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder29);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.deleteFirst('a');
        char[] charArray10 = null;
        char[] charArray11 = strBuilder1.getChars(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder1.insert(0, (int) (byte) 100);
        java.lang.StringBuffer stringBuffer15 = strBuilder1.toStringBuffer();
        java.lang.String str16 = strBuilder1.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder1.appendFixedWidthPadLeft(116, (int) (short) 0, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder22.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int28 = strBuilder22.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder22.replaceFirst('a', '4');
        char[] charArray32 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder22.append(charArray32);
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray32, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer35.reset("");
        int int38 = strTokenizer37.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer37.setEmptyTokenAsNull(true);
        org.apache.commons.lang.text.StrMatcher strMatcher41 = strTokenizer37.getTrimmerMatcher();
        org.apache.commons.lang.text.StrMatcher strMatcher42 = strTokenizer37.getTrimmerMatcher();
        int int44 = strBuilder1.indexOf(strMatcher42, 103);
        int int47 = strBuilder1.indexOf('a', 60);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(stringBuffer15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 96 + "'", int28 == 96);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(charArray32);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strMatcher41);
        org.junit.Assert.assertNotNull(strMatcher42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        char[] charArray7 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher8 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray7, strMatcher8);
        java.lang.String[] strArray10 = strTokenizer9.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = strTokenizer9.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder6.replaceFirst(strMatcher11, "hi!");
        int int15 = strBuilder6.lastIndexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder6.append(0L);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder19.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int25 = strBuilder19.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder19.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder19.insert((int) '#', 1L);
        boolean boolean33 = strBuilder19.contains(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder19.deleteFirst(' ');
        java.lang.String str38 = strBuilder19.substring(0, (int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder40.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int46 = strBuilder40.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder40.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder49.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder49.replaceFirst('#', '4');
        int int56 = strBuilder49.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder58 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder58.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder62.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder62.append((double) 100L);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder49.appendFixedWidthPadRight((java.lang.Object) strBuilder62, (int) 'a', ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder71 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        java.lang.String str72 = strBuilder71.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder71.delete((int) (short) 0, (int) (byte) 100);
        boolean boolean77 = strBuilder75.endsWith("1");
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = new org.apache.commons.lang.text.StrTokenizer();
        java.lang.String str80 = strTokenizer79.previousToken();
        org.apache.commons.lang.text.StrMatcher strMatcher81 = strTokenizer79.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = new org.apache.commons.lang.text.StrTokenizer("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse", strMatcher81);
        int int84 = strBuilder75.indexOf(strMatcher81, (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder62.deleteFirst(strMatcher81);
        org.apache.commons.lang.text.StrBuilder strBuilder87 = strBuilder19.replaceAll(strMatcher81, "StrTokenizer[]");
        org.apache.commons.lang.text.StrBuilder strBuilder88 = strBuilder17.deleteAll(strMatcher81);
        org.apache.commons.lang.text.StrMatcher strMatcher89 = null;
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder94 = strBuilder88.replace(strMatcher89, "hi!", 4, (int) 'a', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strMatcher11);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 96 + "'", int25 == 96);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "4" + "'", str38.equals("4"));
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 96 + "'", int46 == 96);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 100 + "'", int56 == 100);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNull(str80);
        org.junit.Assert.assertNotNull(strMatcher81);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(strBuilder87);
        org.junit.Assert.assertNotNull(strBuilder88);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444falsea", 'a');
        try {
            java.lang.Object obj3 = strTokenizer2.previous();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) (-1L));
        char[] charArray8 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray8, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setDelimiterChar(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder14.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int20 = strBuilder14.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder14.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder23.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder28.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int34 = strBuilder28.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder28.replaceFirst('a', '4');
        java.lang.Object[] objArray42 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder26.appendWithSeparators(objArray42, "");
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder44.insert((int) (short) 100, '4');
        char[] charArray50 = strBuilder47.toCharArray(0, 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = strTokenizer10.reset(charArray50);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray50);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer("", 'a');
        int int56 = strTokenizer55.size();
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse");
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer58.setIgnoredChar(' ');
        org.apache.commons.lang.text.StrMatcher strMatcher61 = strTokenizer58.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer55.setTrimmerMatcher(strMatcher61);
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        org.apache.commons.lang.text.StrMatcher strMatcher64 = strTokenizer63.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = new org.apache.commons.lang.text.StrTokenizer(charArray50, strMatcher61, strMatcher64);
        int int66 = strBuilder7.indexOf(strMatcher64);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 96 + "'", int20 == 96);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 96 + "'", int34 == 96);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(charArray50);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(strMatcher61);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(strTokenizer63);
        org.junit.Assert.assertNotNull(strMatcher64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        char[] charArray11 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder1.append(charArray11);
        char[] charArray13 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray13, strMatcher14);
        java.lang.String[] strArray16 = strTokenizer15.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher17 = strTokenizer15.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder12.appendWithSeparators((java.util.Iterator) strTokenizer15, "lse");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.deleteFirst(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder23.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int29 = strBuilder23.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder23.deleteFirst('a');
        char[] charArray32 = null;
        char[] charArray33 = strBuilder23.getChars(charArray32);
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder23.insert(0, (int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder36.deleteAll("lse");
        java.util.Collection collection39 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder36.appendWithSeparators(collection39, "");
        boolean boolean42 = strBuilder19.equals(strBuilder36);
        boolean boolean44 = strBuilder36.contains('4');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder36.append(false);
        java.lang.String str47 = strBuilder46.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder46.trim();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strMatcher17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 96 + "'", int29 == 96);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "10044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444ffalse" + "'", str47.equals("10044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444ffalse"));
        org.junit.Assert.assertNotNull(strBuilder48);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder9.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder17.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int23 = strBuilder17.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder17.replaceFirst('a', '4');
        char[] charArray27 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder17.append(charArray27);
        char[] charArray29 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray29, strMatcher30);
        java.lang.String[] strArray32 = strTokenizer31.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher33 = strTokenizer31.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder28.deleteFirst(strMatcher33);
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder13.replaceFirst(strMatcher33, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder5.deleteFirst(strMatcher33);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder39.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder43.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder43.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder43.append((double) (short) -1);
        int int51 = strBuilder48.indexOf('#', 0);
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder48.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder55 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder55.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder59.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder60.setNewLineText("lse");
        org.apache.commons.lang.text.StrBuilder strBuilder64 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder64.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int70 = strBuilder64.indexOf('a');
        boolean boolean72 = strBuilder64.endsWith("");
        int int73 = strBuilder64.capacity();
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = strBuilder64.asTokenizer();
        java.util.List list75 = strTokenizer74.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder77 = strBuilder62.appendWithSeparators((java.util.Collection) list75, "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse");
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder53.appendWithSeparators((java.util.Collection) list75, "");
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder37.appendWithSeparators((java.util.Collection) list75, "####################################################");
        org.apache.commons.lang.text.StrBuilder strBuilder84 = strBuilder37.setCharAt(109, 'a');
        char[] charArray85 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher86 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = new org.apache.commons.lang.text.StrTokenizer(charArray85, strMatcher86);
        org.apache.commons.lang.text.StrMatcher strMatcher88 = strTokenizer87.getIgnoredMatcher();
        java.lang.Object obj89 = strTokenizer87.clone();
        org.apache.commons.lang.text.StrMatcher strMatcher90 = strTokenizer87.getTrimmerMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder91 = strBuilder84.deleteAll(strMatcher90);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 96 + "'", int23 == 96);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 96 + "'", int70 == 96);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 100 + "'", int73 == 100);
        org.junit.Assert.assertNotNull(strTokenizer74);
        org.junit.Assert.assertNotNull(list75);
        org.junit.Assert.assertNotNull(strBuilder77);
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertNotNull(strBuilder81);
        org.junit.Assert.assertNotNull(strBuilder84);
        org.junit.Assert.assertNotNull(strMatcher88);
        org.junit.Assert.assertNotNull(obj89);
        org.junit.Assert.assertNotNull(strMatcher90);
        org.junit.Assert.assertNotNull(strBuilder91);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        boolean boolean9 = strBuilder1.endsWith("");
        int int10 = strBuilder1.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder1.append(strBuilder11, (int) '4', (int) (byte) 10);
        char[] charArray16 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray16, strMatcher17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer18.reset("lse");
        int int21 = strTokenizer18.previousIndex();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder23.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int29 = strBuilder23.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder23.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder32.delete((int) (short) 100, (int) (short) 100);
        java.lang.Object obj36 = null;
        boolean boolean37 = strBuilder35.equals(obj36);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder39.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int45 = strBuilder39.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder39.replaceFirst('a', '4');
        char[] charArray49 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder39.append(charArray49);
        char[] charArray51 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher52 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer(charArray51, strMatcher52);
        java.lang.String[] strArray54 = strTokenizer53.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher55 = strTokenizer53.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder50.deleteFirst(strMatcher55);
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder35.deleteAll(strMatcher55);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer18.setTrimmerMatcher(strMatcher55);
        int int59 = strTokenizer18.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer18.setDelimiterChar(' ');
        boolean boolean62 = strTokenizer61.hasNext();
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder1.insert(114, (java.lang.Object) boolean62);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 114");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 96 + "'", int29 == 96);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 96 + "'", int45 == 96);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(charArray49);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertNotNull(strMatcher55);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder1.appendFixedWidthPadLeft(0, 0, 'a');
        char[] charArray15 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = new org.apache.commons.lang.text.StrTokenizer(charArray15, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder19.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int25 = strBuilder19.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder19.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder28.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder33.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int39 = strBuilder33.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder33.replaceFirst('a', '4');
        java.lang.Object[] objArray47 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder31.appendWithSeparators(objArray47, "");
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder49.insert((int) (short) 100, '4');
        char[] charArray55 = strBuilder52.toCharArray(0, 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer17.reset(charArray55);
        char[] charArray57 = strBuilder14.getChars(charArray55);
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = new org.apache.commons.lang.text.StrTokenizer(charArray57, "1");
        int int60 = strTokenizer59.nextIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer59.setIgnoreEmptyTokens(false);
        java.util.List list63 = strTokenizer59.getTokenList();
        org.apache.commons.lang.text.StrMatcher strMatcher64 = strTokenizer59.getIgnoredMatcher();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 96 + "'", int25 == 96);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 96 + "'", int39 == 96);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(charArray55);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(charArray57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(list63);
        org.junit.Assert.assertNotNull(strMatcher64);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.deleteAll('a');
        char[] charArray9 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder8.append(charArray9, (int) (short) 100, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder8.replace((int) (short) 0, 1, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder8.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.replaceAll("-1", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444flse");
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        boolean boolean22 = strBuilder17.contains(strMatcher21);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder17.insert(111, (double) 102);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 111");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.deleteAll('a');
        char[] charArray9 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder8.append(charArray9, (int) (short) 100, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder8.replace((int) (short) 0, 1, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder8.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.replaceAll("-1", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444flse");
        java.lang.String str21 = strBuilder17.getNullText();
        int int22 = strBuilder17.length();
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder24.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int30 = strBuilder24.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder24.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder33.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder38.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int44 = strBuilder38.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder38.replaceFirst('a', '4');
        java.lang.Object[] objArray52 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder36.appendWithSeparators(objArray52, "");
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder54.insert((int) (short) 100, '4');
        char[] charArray60 = strBuilder57.toCharArray(0, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder57.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder62.insert((int) (short) 0, 'a');
        int int66 = strBuilder65.length();
        boolean boolean68 = strBuilder65.endsWith("4lse441000-1.0 0.0");
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder65.replaceFirst('a', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder65.insert(10, false);
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder65.deleteFirst('a');
        int int77 = strBuilder76.length();
        boolean boolean78 = strBuilder17.equals(strBuilder76);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 96 + "'", int30 == 96);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 96 + "'", int44 == 96);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertNotNull(charArray60);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 116 + "'", int66 == 116);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder74);
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 120 + "'", int77 == 120);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder10.replaceFirst('#', '4');
        int int17 = strBuilder10.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder19.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder23.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder23.append((double) 100L);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder10.appendFixedWidthPadRight((java.lang.Object) strBuilder23, (int) 'a', ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        java.lang.String str33 = strBuilder32.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder32.delete((int) (short) 0, (int) (byte) 100);
        boolean boolean38 = strBuilder36.endsWith("1");
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer();
        java.lang.String str41 = strTokenizer40.previousToken();
        org.apache.commons.lang.text.StrMatcher strMatcher42 = strTokenizer40.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse", strMatcher42);
        int int45 = strBuilder36.indexOf(strMatcher42, (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder23.deleteFirst(strMatcher42);
        boolean boolean47 = strBuilder23.isEmpty();
        java.lang.String str49 = strBuilder23.substring((int) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder23.append((float) 100L);
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder51.setNullText("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse");
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(strMatcher42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1-1.0100.0" + "'", str49.equals("1-1.0100.0"));
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder53);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        char[] charArray0 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer(charArray0, strMatcher1);
        int int3 = strTokenizer2.size();
        boolean boolean4 = strTokenizer2.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer6 = strTokenizer2.setDelimiterChar(' ');
        boolean boolean7 = strTokenizer2.hasPrevious();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strTokenizer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int21 = strBuilder15.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder15.replaceFirst('a', '4');
        java.lang.Object[] objArray29 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder13.appendWithSeparators(objArray29, "");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.insert((int) (short) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder34.append(0.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder38.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder42.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder42.append((double) 100L);
        char[] charArray47 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher48 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = new org.apache.commons.lang.text.StrTokenizer(charArray47, strMatcher48);
        org.apache.commons.lang.text.StrMatcher strMatcher50 = strTokenizer49.getIgnoredMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder42.deleteFirst(strMatcher50);
        int int52 = strBuilder36.indexOf(strMatcher50);
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder36.deleteFirst('4');
        java.lang.String str55 = strBuilder36.getNullText();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 96 + "'", int21 == 96);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strMatcher50);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNull(str55);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) (-1L));
        int int10 = strBuilder7.lastIndexOf('a', (int) (short) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder7.append((float) 96);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder14.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder18.clear();
        char[] charArray20 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray20, strMatcher21);
        java.lang.String[] strArray23 = strTokenizer22.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher24 = strTokenizer22.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder19.replaceFirst(strMatcher24, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer27.setEmptyTokenAsNull(true);
        java.lang.String str30 = strTokenizer29.getContent();
        org.apache.commons.lang.text.StrBuilder strBuilder32 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder32.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int38 = strBuilder32.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder32.deleteFirst('a');
        char[] charArray41 = null;
        char[] charArray42 = strBuilder32.getChars(charArray41);
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray42, '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer29.reset(charArray42);
        org.apache.commons.lang.text.StrMatcher strMatcher46 = strTokenizer45.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder26.replaceAll(strMatcher46, "");
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder12.replaceFirst(strMatcher46, "444444444444444444444444444444444441444444444444444444444444444444444444444444444444444444444444f4lse");
        java.lang.String str53 = strBuilder50.midString(0, 63);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(strMatcher24);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 96 + "'", int38 == 96);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(charArray42);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strMatcher46);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "1-1.096.0" + "'", str53.equals("1-1.096.0"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        java.lang.String str2 = strBuilder1.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.delete((int) (short) 0, (int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.append(96);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder9.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder13.clear();
        char[] charArray15 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher16 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = new org.apache.commons.lang.text.StrTokenizer(charArray15, strMatcher16);
        java.lang.String[] strArray18 = strTokenizer17.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher19 = strTokenizer17.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder14.replaceFirst(strMatcher19, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder1.deleteFirst(strMatcher19);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder1.replaceFirst('#', '4');
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strMatcher19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int21 = strBuilder15.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder15.replaceFirst('a', '4');
        java.lang.Object[] objArray29 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder13.appendWithSeparators(objArray29, "");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.insert((int) (short) 100, '4');
        char[] charArray37 = strBuilder34.toCharArray(0, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder34.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder39.appendNull();
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder40.insert(156, (float) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 156");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 96 + "'", int21 == 96);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder40);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int21 = strBuilder15.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder15.replaceFirst('a', '4');
        java.lang.Object[] objArray29 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder13.appendWithSeparators(objArray29, "");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.insert((int) (short) 100, '4');
        char[] charArray37 = strBuilder34.toCharArray(0, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder34.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder39.insert((int) 'a', (double) 2);
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder42.insert(111, (long) (short) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder42.replaceFirst('#', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder42.deleteCharAt((int) (byte) 100);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 96 + "'", int21 == 96);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder50);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", 'a', '#');
        java.lang.String[] strArray4 = strTokenizer3.getTokenArray();
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        char[] charArray11 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder1.append(charArray11);
        char[] charArray13 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray13, strMatcher14);
        java.lang.String[] strArray16 = strTokenizer15.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher17 = strTokenizer15.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder12.appendWithSeparators((java.util.Iterator) strTokenizer15, "lse");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.deleteFirst(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder23.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int29 = strBuilder23.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder23.deleteFirst('a');
        char[] charArray32 = null;
        char[] charArray33 = strBuilder23.getChars(charArray32);
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder23.insert(0, (int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder36.deleteAll("lse");
        java.util.Collection collection39 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder36.appendWithSeparators(collection39, "");
        boolean boolean42 = strBuilder19.equals(strBuilder36);
        java.lang.Class<?> wildcardClass43 = strBuilder19.getClass();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder19.appendPadding(0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder19.clear();
        java.io.Writer writer48 = strBuilder47.asWriter();
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder47.insert(0, '#');
        char char53 = strBuilder47.charAt(0);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strMatcher17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 96 + "'", int29 == 96);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(writer48);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertTrue("'" + char53 + "' != '" + '#' + "'", char53 == '#');
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int21 = strBuilder15.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder15.replaceFirst('a', '4');
        java.lang.Object[] objArray29 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder13.appendWithSeparators(objArray29, "");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.insert((int) (short) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder34.appendPadding((int) (short) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder34.setNewLineText("rTokenizer[]100StrTokenizer[]0StrTokenizer[]-1.0StrTokenizer[] ");
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 96 + "'", int21 == 96);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder39);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder5.append((double) (short) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder10.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder13.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int19 = strBuilder13.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder13.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder22.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder27.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int33 = strBuilder27.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder27.replaceFirst('a', '4');
        java.lang.Object[] objArray41 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder25.appendWithSeparators(objArray41, "");
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder43.insert((int) (short) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder46.append(0.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder50 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder50.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder54.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder54.deleteAll('a');
        java.lang.String str58 = strBuilder54.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder54.append((int) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder48.append((java.lang.Object) strBuilder60);
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder11.append(strBuilder48, (int) (byte) 0, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder11.trim();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 96 + "'", int19 == 96);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 96 + "'", int33 == 96);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "" + "'", str58.equals(""));
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder65);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.deleteAll('a');
        java.lang.String str9 = strBuilder5.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder5.append((int) (byte) -1);
        int int13 = strBuilder11.indexOf("StrTokenizer[]");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder19.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder19.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder24.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder28.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder29.setNewLineText("lse");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder19.appendFixedWidthPadLeft((java.lang.Object) strBuilder31, (int) '4', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder31.replaceAll("1", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder31.append("e");
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder41.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder45.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder46.setNewLineText("lse");
        org.apache.commons.lang.text.StrBuilder strBuilder50 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder50.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int56 = strBuilder50.indexOf('a');
        boolean boolean58 = strBuilder50.endsWith("");
        int int59 = strBuilder50.capacity();
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strBuilder50.asTokenizer();
        java.util.List list61 = strTokenizer60.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder48.appendWithSeparators((java.util.Collection) list61, "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse");
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder39.appendWithSeparators((java.util.Collection) list61, "StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder11.append(strBuilder39);
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder66.ensureCapacity(99);
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder68.append(true);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 96 + "'", int56 == 96);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 100 + "'", int59 == 100);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder70);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        java.lang.String str7 = strBuilder5.leftString((int) (short) 1);
        java.lang.String str9 = strBuilder5.rightString((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder11.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int17 = strBuilder11.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder11.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder20.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder25.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int31 = strBuilder25.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder25.replaceFirst('a', '4');
        java.lang.Object[] objArray39 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder23.appendWithSeparators(objArray39, "");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder41.insert((int) (short) 100, '4');
        char[] charArray47 = strBuilder44.toCharArray(0, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder5.append(charArray47);
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder5.replaceFirst("lse", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444falsea");
        org.apache.commons.lang.text.StrBuilder strBuilder53 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder53.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int59 = strBuilder53.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder53.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder62.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder67 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder67.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int73 = strBuilder67.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder67.replaceFirst('a', '4');
        java.lang.Object[] objArray81 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder83 = strBuilder65.appendWithSeparators(objArray81, "");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder51.appendWithSeparators(objArray81, "StrTokenizer[]");
        int int86 = strBuilder85.length();
        int int88 = strBuilder85.indexOf('#');
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 96 + "'", int17 == 96);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 96 + "'", int31 == 96);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(charArray47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 96 + "'", int59 == 96);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 96 + "'", int73 == 96);
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(strBuilder83);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 77 + "'", int86 == 77);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        char[] charArray11 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder1.append(charArray11);
        char[] charArray13 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray13, strMatcher14);
        java.lang.String[] strArray16 = strTokenizer15.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher17 = strTokenizer15.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder12.deleteFirst(strMatcher17);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder12.setLength((int) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder20.replaceAll(' ', ' ');
        java.lang.String str25 = strBuilder20.leftString(100);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder20.append((double) '#');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder29.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int35 = strBuilder29.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder29.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder38.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder38.replaceFirst('#', '4');
        int int45 = strBuilder38.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder47 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder47.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder51.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder51.append((double) 100L);
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder38.appendFixedWidthPadRight((java.lang.Object) strBuilder51, (int) 'a', ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder27.append(strBuilder58);
        org.apache.commons.lang.text.StrBuilder strBuilder61 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder61.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder65.append('a');
        org.apache.commons.lang.text.StrBuilder strBuilder69 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder69.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder73.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder77 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder77.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int83 = strBuilder77.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder86 = strBuilder77.replaceFirst('a', '4');
        char[] charArray87 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder88 = strBuilder77.append(charArray87);
        char[] charArray89 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher90 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer91 = new org.apache.commons.lang.text.StrTokenizer(charArray89, strMatcher90);
        java.lang.String[] strArray92 = strTokenizer91.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher93 = strTokenizer91.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder94 = strBuilder88.deleteFirst(strMatcher93);
        org.apache.commons.lang.text.StrBuilder strBuilder96 = strBuilder73.replaceFirst(strMatcher93, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder97 = strBuilder65.deleteFirst(strMatcher93);
        int int98 = strBuilder27.lastIndexOf(strMatcher93);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strMatcher17);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 96 + "'", int35 == 96);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertNotNull(strBuilder81);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 96 + "'", int83 == 96);
        org.junit.Assert.assertNotNull(strBuilder86);
        org.junit.Assert.assertNotNull(charArray87);
        org.junit.Assert.assertNotNull(strBuilder88);
        org.junit.Assert.assertNotNull(strArray92);
        org.junit.Assert.assertNotNull(strMatcher93);
        org.junit.Assert.assertNotNull(strBuilder94);
        org.junit.Assert.assertNotNull(strBuilder96);
        org.junit.Assert.assertNotNull(strBuilder97);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + (-1) + "'", int98 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        char[] charArray11 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder1.append(charArray11);
        char[] charArray13 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray13, strMatcher14);
        java.lang.String[] strArray16 = strTokenizer15.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher17 = strTokenizer15.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder12.appendWithSeparators((java.util.Iterator) strTokenizer15, "lse");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.deleteFirst(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder23.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int29 = strBuilder23.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder23.deleteFirst('a');
        char[] charArray32 = null;
        char[] charArray33 = strBuilder23.getChars(charArray32);
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder23.insert(0, (int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder36.deleteAll("lse");
        java.util.Collection collection39 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder36.appendWithSeparators(collection39, "");
        boolean boolean42 = strBuilder19.equals(strBuilder36);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder44.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int50 = strBuilder44.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder44.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder53.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder58 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder58.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int64 = strBuilder58.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder58.replaceFirst('a', '4');
        java.lang.Object[] objArray72 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder56.appendWithSeparators(objArray72, "");
        org.apache.commons.lang.text.StrBuilder strBuilder77 = strBuilder74.insert((int) (short) 100, '4');
        char[] charArray78 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher79 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = new org.apache.commons.lang.text.StrTokenizer(charArray78, strMatcher79);
        java.lang.String[] strArray81 = strTokenizer80.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher82 = strTokenizer80.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = strTokenizer80.setIgnoredChar('a');
        java.lang.String[] strArray85 = strTokenizer84.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher86 = strTokenizer84.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder87 = strBuilder77.deleteAll(strMatcher86);
        int int88 = strBuilder36.lastIndexOf(strMatcher86);
        org.apache.commons.lang.text.StrBuilder strBuilder90 = strBuilder36.deleteFirst('4');
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strMatcher17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 96 + "'", int29 == 96);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 96 + "'", int50 == 96);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 96 + "'", int64 == 96);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(strBuilder74);
        org.junit.Assert.assertNotNull(strBuilder77);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertNotNull(strMatcher82);
        org.junit.Assert.assertNotNull(strTokenizer84);
        org.junit.Assert.assertNotNull(strArray85);
        org.junit.Assert.assertNotNull(strMatcher86);
        org.junit.Assert.assertNotNull(strBuilder87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
        org.junit.Assert.assertNotNull(strBuilder90);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        org.apache.commons.lang.text.StrTokenizer strTokenizer0 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder2.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int8 = strBuilder2.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder2.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder2.appendFixedWidthPadLeft(0, 0, 'a');
        char[] charArray16 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray16, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder20.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int26 = strBuilder20.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder20.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder29.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder34.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int40 = strBuilder34.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder34.replaceFirst('a', '4');
        java.lang.Object[] objArray48 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder32.appendWithSeparators(objArray48, "");
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder50.insert((int) (short) 100, '4');
        char[] charArray56 = strBuilder53.toCharArray(0, 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strTokenizer18.reset(charArray56);
        char[] charArray58 = strBuilder15.getChars(charArray56);
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = strTokenizer0.reset(charArray56);
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer(charArray56);
        org.junit.Assert.assertNotNull(strTokenizer0);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 96 + "'", int8 == 96);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 96 + "'", int26 == 96);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 96 + "'", int40 == 96);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(charArray56);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertNotNull(charArray58);
        org.junit.Assert.assertNotNull(strTokenizer59);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        char[] charArray7 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher8 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray7, strMatcher8);
        java.lang.String[] strArray10 = strTokenizer9.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = strTokenizer9.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder6.replaceFirst(strMatcher11, "hi!");
        int int15 = strBuilder6.lastIndexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder6.append(0L);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder6.appendNewLine();
        boolean boolean20 = strBuilder6.endsWith("4444444444");
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strMatcher11);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int21 = strBuilder15.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder15.replaceFirst('a', '4');
        java.lang.Object[] objArray29 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder13.appendWithSeparators(objArray29, "");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.insert((int) (short) 100, '4');
        char[] charArray37 = strBuilder34.toCharArray(0, 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray37);
        boolean boolean39 = strTokenizer38.isEmptyTokenAsNull();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 96 + "'", int21 == 96);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        char[] charArray11 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder1.append(charArray11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = new org.apache.commons.lang.text.StrTokenizer(charArray11, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int22 = strBuilder16.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder16.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder16.insert((int) '#', 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder30.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int36 = strBuilder30.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder30.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder39.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder44.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int50 = strBuilder44.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder44.replaceFirst('a', '4');
        java.lang.Object[] objArray58 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder42.appendWithSeparators(objArray58, "");
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder60.insert((int) (short) 100, '4');
        char[] charArray66 = strBuilder63.toCharArray(0, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder28.append(charArray66);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer(charArray66, "####################################################");
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray66);
        char[] charArray71 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher72 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = new org.apache.commons.lang.text.StrTokenizer(charArray71, strMatcher72);
        java.lang.String[] strArray74 = strTokenizer73.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher75 = strTokenizer73.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strTokenizer73.setIgnoredChar('a');
        java.lang.String[] strArray78 = strTokenizer77.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher79 = strTokenizer77.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = new org.apache.commons.lang.text.StrTokenizer(charArray66, strMatcher79);
        org.apache.commons.lang.text.StrTokenizer strTokenizer81 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher79);
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        java.lang.Object obj86 = strTokenizer85.clone();
        boolean boolean87 = strTokenizer85.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer89 = strTokenizer85.setIgnoredChar(' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer90 = strTokenizer89.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher91 = strTokenizer89.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer92 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher91);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 96 + "'", int22 == 96);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 96 + "'", int36 == 96);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 96 + "'", int50 == 96);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(strTokenizer70);
        org.junit.Assert.assertNotNull(strArray74);
        org.junit.Assert.assertNotNull(strMatcher75);
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertNotNull(strArray78);
        org.junit.Assert.assertNotNull(strMatcher79);
        org.junit.Assert.assertNotNull(obj86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(strTokenizer89);
        org.junit.Assert.assertNotNull(strTokenizer90);
        org.junit.Assert.assertNotNull(strMatcher91);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        java.lang.String str7 = strBuilder5.leftString((int) (short) 1);
        java.lang.String str9 = strBuilder5.rightString((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder11.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int17 = strBuilder11.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder11.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder20.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder25.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int31 = strBuilder25.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder25.replaceFirst('a', '4');
        java.lang.Object[] objArray39 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder23.appendWithSeparators(objArray39, "");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder41.insert((int) (short) 100, '4');
        char[] charArray47 = strBuilder44.toCharArray(0, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder5.append(charArray47);
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder5.replaceFirst("lse", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444falsea");
        org.apache.commons.lang.text.StrBuilder strBuilder53 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder53.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int59 = strBuilder53.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder53.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder62.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder67 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder67.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int73 = strBuilder67.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder67.replaceFirst('a', '4');
        java.lang.Object[] objArray81 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder83 = strBuilder65.appendWithSeparators(objArray81, "");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder51.appendWithSeparators(objArray81, "StrTokenizer[]");
        int int86 = strBuilder85.length();
        org.apache.commons.lang.text.StrBuilder strBuilder87 = null;
        try {
            boolean boolean88 = strBuilder85.equalsIgnoreCase(strBuilder87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 96 + "'", int17 == 96);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 96 + "'", int31 == 96);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(charArray47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 96 + "'", int59 == 96);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 96 + "'", int73 == 96);
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(strBuilder83);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 77 + "'", int86 == 77);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.deleteFirst('a');
        char[] charArray10 = null;
        char[] charArray11 = strBuilder1.getChars(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder1.insert(0, (int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.deleteAll("lse");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder14.insert((int) '4', (int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.deleteAll('#');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder23.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int29 = strBuilder23.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder23.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder32.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder37 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder37.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int43 = strBuilder37.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder37.replaceFirst('a', '4');
        java.lang.Object[] objArray51 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder35.appendWithSeparators(objArray51, "");
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder53.insert((int) (short) 100, '4');
        char[] charArray59 = strBuilder56.toCharArray(0, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder56.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder56.appendFixedWidthPadLeft(97, (int) (short) 10, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder67 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder67.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder71.clear();
        java.lang.Class<?> wildcardClass73 = strBuilder72.getClass();
        org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder56.append((java.lang.Object) wildcardClass73);
        java.lang.StringBuffer stringBuffer75 = strBuilder74.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder21.append(stringBuffer75);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 96 + "'", int29 == 96);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 96 + "'", int43 == 96);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder72);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNotNull(strBuilder74);
        org.junit.Assert.assertNotNull(stringBuffer75);
        org.junit.Assert.assertNotNull(strBuilder76);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int21 = strBuilder15.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder15.replaceFirst('a', '4');
        java.lang.Object[] objArray29 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder13.appendWithSeparators(objArray29, "");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.insert((int) (short) 100, '4');
        char[] charArray37 = strBuilder34.toCharArray(0, 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray37);
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer(charArray37, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer(charArray37, "4444444444");
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray37, "41000-1.0 0.0.0 true");
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 96 + "'", int21 == 96);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertNotNull(strTokenizer38);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        java.lang.String str12 = strBuilder10.substring(10);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder14.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder18.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder18.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder23.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder27.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder28.setNewLineText("lse");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder18.appendFixedWidthPadLeft((java.lang.Object) strBuilder30, (int) '4', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder35 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder35.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder39.append('a');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder33.appendFixedWidthPadRight((java.lang.Object) 'a', (int) (short) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder44.append((double) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder46.replaceAll('4', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strBuilder46.asTokenizer();
        char[] charArray51 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher52 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer(charArray51, strMatcher52);
        java.lang.String[] strArray54 = strTokenizer53.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher55 = strTokenizer53.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer50.setIgnoredMatcher(strMatcher55);
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder10.replaceFirst(strMatcher55, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder58.setLength(1);
        char[] charArray61 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer(charArray61, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer63.setDelimiterChar(' ');
        org.apache.commons.lang.text.StrMatcher strMatcher66 = strTokenizer65.getIgnoredMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder58.appendFixedWidthPadLeft((java.lang.Object) strMatcher66, (int) (short) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder58.setCharAt(0, '#');
        int int73 = strBuilder58.capacity();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse" + "'", str12.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse"));
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertNotNull(strMatcher55);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertNotNull(strMatcher66);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 100 + "'", int73 == 100);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.setNewLineText("lse");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder10.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int16 = strBuilder10.indexOf('a');
        boolean boolean18 = strBuilder10.endsWith("");
        int int19 = strBuilder10.capacity();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strBuilder10.asTokenizer();
        java.util.List list21 = strTokenizer20.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder8.appendWithSeparators((java.util.Collection) list21, "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder23.deleteCharAt((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder25.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder26.append('a');
        org.apache.commons.lang.text.StrBuilder strBuilder30 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        java.lang.String str31 = strBuilder30.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder30.delete((int) (short) 0, (int) (byte) 100);
        boolean boolean36 = strBuilder34.endsWith("1");
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer();
        java.lang.String str39 = strTokenizer38.previousToken();
        org.apache.commons.lang.text.StrMatcher strMatcher40 = strTokenizer38.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse", strMatcher40);
        int int43 = strBuilder34.indexOf(strMatcher40, (-1));
        java.lang.StringBuffer stringBuffer44 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder34.append(stringBuffer44, (int) (byte) 10, 52);
        char[] charArray48 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer(charArray48, strMatcher49);
        java.lang.String[] strArray51 = strTokenizer50.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder47.appendWithSeparators((java.lang.Object[]) strArray51, "1004444444true4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444f");
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder47.appendPadding(97, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder26.append(strBuilder47, 60, 35);
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder59.setCharAt(4, '4');
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 96 + "'", int16 == 96);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(strMatcher40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(strArray51);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder62);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder10.replaceFirst('#', '4');
        int int17 = strBuilder10.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder10.deleteAll("lse");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder21.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int27 = strBuilder21.indexOf('a');
        boolean boolean29 = strBuilder21.endsWith("");
        int int30 = strBuilder21.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder31 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder21.append(strBuilder31, (int) '4', (int) (byte) 10);
        char[] charArray38 = new char[] { 'a', ' ', ' ' };
        char[] charArray39 = strBuilder21.getChars(charArray38);
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer(charArray39);
        char[] charArray41 = strBuilder19.getChars(charArray39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray41);
        org.apache.commons.lang.text.StrMatcher strMatcher43 = strTokenizer42.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer42.setIgnoreEmptyTokens(false);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 96 + "'", int27 == 96);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(charArray38);
        org.junit.Assert.assertNotNull(charArray39);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strMatcher43);
        org.junit.Assert.assertNotNull(strTokenizer45);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance("-1.0100.044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444false100");
        java.lang.String str2 = strTokenizer1.nextToken();
        int int3 = strTokenizer1.previousIndex();
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0100.044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444false100" + "'", str2.equals("-1.0100.044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444false100"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder5.append((double) (short) -1);
        try {
            java.lang.String str12 = strBuilder5.substring(53);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) (-1L));
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("", 'a');
        int int11 = strTokenizer10.size();
        java.lang.String str12 = strTokenizer10.nextToken();
        char[] charArray19 = new char[] { 'a', ' ', ' ', '4', 'a', ' ' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer10.reset(charArray19);
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder22.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder26.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder26.deleteAll('a');
        java.lang.String str30 = strBuilder26.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder26.append((int) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder34.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder38.clear();
        char[] charArray40 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher41 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer(charArray40, strMatcher41);
        java.lang.String[] strArray43 = strTokenizer42.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher44 = strTokenizer42.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder39.replaceFirst(strMatcher44, "hi!");
        char[] charArray47 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher48 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = new org.apache.commons.lang.text.StrTokenizer(charArray47, strMatcher48);
        org.apache.commons.lang.text.StrMatcher strMatcher50 = strTokenizer49.getIgnoredMatcher();
        int int52 = strBuilder39.indexOf(strMatcher50, (int) '4');
        int int53 = strBuilder32.lastIndexOf(strMatcher50);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer(charArray19, strMatcher50);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder7.replace(strMatcher50, "", (int) (short) 1, 104, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder7.setLength((int) (byte) 10);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertNotNull(strMatcher44);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strMatcher50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder61);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        char[] charArray7 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher8 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray7, strMatcher8);
        java.lang.String[] strArray10 = strTokenizer9.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = strTokenizer9.getDelimiterMatcher();
        boolean boolean12 = strBuilder6.contains(strMatcher11);
        int int13 = strBuilder6.length();
        java.lang.String str14 = strBuilder6.toString();
        java.lang.Object obj15 = null;
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder6.appendFixedWidthPadLeft(obj15, (int) '0', 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strMatcher11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.setNewLineText("lse");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder10.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int16 = strBuilder10.indexOf('a');
        boolean boolean18 = strBuilder10.endsWith("");
        int int19 = strBuilder10.capacity();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strBuilder10.asTokenizer();
        java.util.List list21 = strTokenizer20.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder8.appendWithSeparators((java.util.Collection) list21, "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder23.deleteCharAt((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder27.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder31.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder36 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder36.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder40.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder41.setNewLineText("lse");
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder31.appendFixedWidthPadLeft((java.lang.Object) strBuilder43, (int) '4', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder31.deleteAll('4');
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder31.ensureCapacity((-1));
        java.lang.String str52 = strBuilder31.substring(0);
        java.lang.String str54 = strBuilder31.leftString((int) (short) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder25.append((java.lang.Object) str54);
        char[] charArray56 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher57 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer(charArray56, strMatcher57);
        org.apache.commons.lang.text.StrMatcher strMatcher59 = strTokenizer58.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer58.setDelimiterChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher62 = strTokenizer58.getIgnoredMatcher();
        boolean boolean63 = strTokenizer58.hasNext();
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder25.appendWithSeparators((java.util.Iterator) strTokenizer58, "");
        org.apache.commons.lang.text.StrBuilder strBuilder69 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder69.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder73.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder77 = strBuilder73.delete((int) (short) 0, (int) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder79 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder83 = strBuilder79.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int85 = strBuilder79.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder87 = strBuilder79.deleteFirst('a');
        char[] charArray88 = null;
        char[] charArray89 = strBuilder79.getChars(charArray88);
        org.apache.commons.lang.text.StrBuilder strBuilder90 = strBuilder77.append(charArray89);
        org.apache.commons.lang.text.StrTokenizer strTokenizer91 = new org.apache.commons.lang.text.StrTokenizer(charArray89);
        org.apache.commons.lang.text.StrTokenizer strTokenizer93 = new org.apache.commons.lang.text.StrTokenizer(charArray89, "hi!");
        try {
            strBuilder65.getChars(111, 102, charArray89, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 102");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 96 + "'", int16 == 96);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "####################################################" + "'", str52.equals("####################################################"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "#" + "'", str54.equals("#"));
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strMatcher59);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strMatcher62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertNotNull(strBuilder74);
        org.junit.Assert.assertNotNull(strBuilder77);
        org.junit.Assert.assertNotNull(strBuilder83);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 96 + "'", int85 == 96);
        org.junit.Assert.assertNotNull(strBuilder87);
        org.junit.Assert.assertNotNull(charArray89);
        org.junit.Assert.assertNotNull(strBuilder90);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.deleteFirst('a');
        char[] charArray10 = null;
        char[] charArray11 = strBuilder1.getChars(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder1.insert(0, (int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        boolean boolean22 = strBuilder20.contains(' ');
        java.lang.StringBuffer stringBuffer23 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder20.append(stringBuffer23, 1, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder26.append((double) 114);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder26.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder26.append((double) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder14.append(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder32);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder5.delete((int) (short) 0, (int) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder11.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int17 = strBuilder11.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder11.deleteFirst('a');
        char[] charArray20 = null;
        char[] charArray21 = strBuilder11.getChars(charArray20);
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder9.append(charArray21);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder22.appendNewLine();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder22.insert((int) ' ', 156);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 96 + "'", int17 == 96);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder26);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        java.lang.String str2 = strBuilder1.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.delete((int) (short) 0, (int) (byte) 100);
        boolean boolean7 = strBuilder5.endsWith("1");
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer();
        java.lang.String str10 = strTokenizer9.previousToken();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = strTokenizer9.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse", strMatcher11);
        int int14 = strBuilder5.indexOf(strMatcher11, (-1));
        java.lang.StringBuffer stringBuffer15 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder5.append(stringBuffer15, (int) (byte) 10, 52);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder5.deleteFirst(' ');
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(strMatcher11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder20);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        java.lang.String str10 = strBuilder9.getNewLineText();
        java.lang.Class<?> wildcardClass11 = strBuilder9.getClass();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder9.setNewLineText("1-1.0");
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer("", 'a');
        int int17 = strTokenizer16.size();
        java.lang.String str18 = strTokenizer16.nextToken();
        char[] charArray25 = new char[] { 'a', ' ', ' ', '4', 'a', ' ' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer16.reset(charArray25);
        org.apache.commons.lang.text.StrMatcher strMatcher27 = strTokenizer26.getTrimmerMatcher();
        java.util.List list28 = strTokenizer26.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder9.appendWithSeparators((java.util.Collection) list28, "e");
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder7.append(strBuilder9, 35, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: startIndex must be valid");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strMatcher27);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(strBuilder30);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int21 = strBuilder15.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder15.replaceFirst('a', '4');
        java.lang.Object[] objArray29 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder13.appendWithSeparators(objArray29, "");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.insert((int) (short) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder34.append(0.0d);
        java.lang.String str38 = strBuilder36.substring(96);
        int int39 = strBuilder36.size();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse");
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer41.setDelimiterChar('a');
        java.util.List list44 = strTokenizer41.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder36.appendWithSeparators((java.util.Collection) list44, "1");
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 96 + "'", int21 == 96);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "4lse441000-1.0 0.0" + "'", str38.equals("4lse441000-1.0 0.0"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 114 + "'", int39 == 114);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertNotNull(strBuilder46);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.deleteAll('a');
        java.lang.String str9 = strBuilder5.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder5.append((int) (byte) -1);
        java.lang.String str13 = strBuilder11.rightString((int) (short) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder11.appendNewLine();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertNotNull(strBuilder14);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder10.replaceFirst('#', '4');
        int int17 = strBuilder10.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder19.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder23.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder23.append((double) 100L);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder10.appendFixedWidthPadRight((java.lang.Object) strBuilder23, (int) 'a', ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        java.lang.String str33 = strBuilder32.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder32.delete((int) (short) 0, (int) (byte) 100);
        boolean boolean38 = strBuilder36.endsWith("1");
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer();
        java.lang.String str41 = strTokenizer40.previousToken();
        org.apache.commons.lang.text.StrMatcher strMatcher42 = strTokenizer40.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse", strMatcher42);
        int int45 = strBuilder36.indexOf(strMatcher42, (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder23.deleteFirst(strMatcher42);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder46.delete((int) (byte) 0, 156);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(strMatcher42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder49);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder5.append((double) 100L);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder5.reverse();
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer14.setEmptyTokenAsNull(false);
        boolean boolean17 = strBuilder5.equals((java.lang.Object) strTokenizer14);
        int int19 = strBuilder5.lastIndexOf('#');
        boolean boolean21 = strBuilder5.endsWith("false");
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder5.append((double) 100L);
        java.util.Collection collection10 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder9.appendWithSeparators(collection10, "");
        int int14 = strBuilder9.indexOf('4');
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder9.append("#", 110, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: startIndex must be valid");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) (-1L));
        int int10 = strBuilder7.lastIndexOf('a', (int) (short) 10);
        int int13 = strBuilder7.lastIndexOf('#', (int) (short) 100);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder5.append((double) 100L);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder5.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder5.appendFixedWidthPadLeft(116, 104, 'a');
        boolean boolean16 = strBuilder5.endsWith("");
        boolean boolean18 = strBuilder5.contains('0');
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.deleteAll('a');
        java.lang.String str10 = strBuilder5.rightString(0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder5.appendWithSeparators((java.util.Iterator) strTokenizer11, "StrTokenizer[not tokenized yet]");
        int int14 = strBuilder5.length();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder5.append((double) 100L);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder5.reverse();
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer14.setEmptyTokenAsNull(false);
        boolean boolean17 = strBuilder5.equals((java.lang.Object) strTokenizer14);
        org.apache.commons.lang.text.StrMatcher strMatcher18 = strTokenizer14.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder20.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int26 = strBuilder20.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder20.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder29.delete((int) (short) 100, (int) (short) 100);
        java.lang.Object obj33 = null;
        boolean boolean34 = strBuilder32.equals(obj33);
        org.apache.commons.lang.text.StrBuilder strBuilder36 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder36.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int42 = strBuilder36.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder36.replaceFirst('a', '4');
        char[] charArray46 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder36.append(charArray46);
        char[] charArray48 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer(charArray48, strMatcher49);
        java.lang.String[] strArray51 = strTokenizer50.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher52 = strTokenizer50.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder47.appendWithSeparators((java.util.Iterator) strTokenizer50, "lse");
        char[] charArray57 = new char[] { ' ', '4' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer50.reset(charArray57);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder32.append(charArray57);
        java.lang.String str62 = strBuilder59.midString((int) (short) 1, 35);
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder59.insert((int) '4', (int) (byte) 10);
        char[] charArray66 = strBuilder65.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strTokenizer14.reset(charArray66);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer(charArray66, ' ');
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(strMatcher18);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 96 + "'", int26 == 96);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 96 + "'", int42 == 96);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(charArray46);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(strArray51);
        org.junit.Assert.assertNotNull(strMatcher52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(charArray57);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "44444444444444444444444444444444444" + "'", str62.equals("44444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strTokenizer67);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int21 = strBuilder15.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder15.replaceFirst('a', '4');
        java.lang.Object[] objArray29 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder13.appendWithSeparators(objArray29, "");
        java.lang.StringBuffer stringBuffer32 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder13.append(stringBuffer32, (-1), (int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder35.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder35.appendPadding((int) (short) 10, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder42 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder42.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int48 = strBuilder42.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder42.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder42.insert((int) '#', 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder54.deleteCharAt((int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder40.appendFixedWidthPadLeft((java.lang.Object) strBuilder54, 60, '0');
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder59.replaceAll("100444444444444444444444444444444444444444444444", "96");
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 96 + "'", int21 == 96);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 96 + "'", int48 == 96);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder62);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int21 = strBuilder15.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder15.replaceFirst('a', '4');
        java.lang.Object[] objArray29 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder13.appendWithSeparators(objArray29, "");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.insert((int) (short) 100, '4');
        char[] charArray37 = strBuilder34.toCharArray(0, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder34.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder39.insert((int) (short) 0, 'a');
        int int43 = strBuilder42.length();
        boolean boolean45 = strBuilder42.endsWith("4lse441000-1.0 0.0");
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder42.replaceFirst('a', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder42.insert(10, false);
        char[] charArray54 = strBuilder42.toCharArray(110, 110);
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer(charArray54, '4', 'a');
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 96 + "'", int21 == 96);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 116 + "'", int43 == 116);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(charArray54);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("####################################################", 'a');
        try {
            strTokenizer2.remove();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: remove() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        java.lang.String str8 = strBuilder6.leftString(4);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        char[] charArray0 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer(charArray0, strMatcher1);
        java.lang.String[] strArray3 = strTokenizer2.getTokenArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer2.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder7.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int13 = strBuilder7.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder7.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder16.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder16.replaceFirst('#', '4');
        int int23 = strBuilder16.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder16.deleteAll("lse");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder27.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int33 = strBuilder27.indexOf('a');
        boolean boolean35 = strBuilder27.endsWith("");
        int int36 = strBuilder27.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder37 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder27.append(strBuilder37, (int) '4', (int) (byte) 10);
        char[] charArray44 = new char[] { 'a', ' ', ' ' };
        char[] charArray45 = strBuilder27.getChars(charArray44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = new org.apache.commons.lang.text.StrTokenizer(charArray45);
        char[] charArray47 = strBuilder25.getChars(charArray45);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer2.reset(charArray47);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 96 + "'", int13 == 96);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 96 + "'", int33 == 96);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 100 + "'", int36 == 100);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(charArray44);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(charArray47);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strTokenizer49);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder10.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder14.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.setNewLineText("lse");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder5.appendFixedWidthPadLeft((java.lang.Object) strBuilder17, (int) '4', '#');
        boolean boolean21 = strBuilder5.isEmpty();
        int int24 = strBuilder5.indexOf("114.0", 48);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.deleteFirst('a');
        char[] charArray10 = null;
        char[] charArray11 = strBuilder1.getChars(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder1.insert(0, (int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.deleteAll("lse");
        int int19 = strBuilder16.lastIndexOf("", 97);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder16.appendFixedWidthPadLeft((int) (byte) -1, (int) '4', ' ');
        int int25 = strBuilder23.lastIndexOf('a');
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 97 + "'", int19 == 97);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", '4', ' ');
        char[] charArray4 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer6 = new org.apache.commons.lang.text.StrTokenizer(charArray4, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = strTokenizer6.setDelimiterChar(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder10.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int16 = strBuilder10.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder10.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder19.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder24.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int30 = strBuilder24.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder24.replaceFirst('a', '4');
        java.lang.Object[] objArray38 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder22.appendWithSeparators(objArray38, "");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder40.insert((int) (short) 100, '4');
        char[] charArray46 = strBuilder43.toCharArray(0, 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer6.reset(charArray46);
        int int48 = strTokenizer47.nextIndex();
        org.apache.commons.lang.text.StrMatcher strMatcher49 = strTokenizer47.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer3.setDelimiterMatcher(strMatcher49);
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 96 + "'", int16 == 96);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 96 + "'", int30 == 96);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(charArray46);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(strMatcher49);
        org.junit.Assert.assertNotNull(strTokenizer50);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        java.lang.String str7 = strBuilder5.leftString((int) (short) 1);
        java.lang.String str9 = strBuilder5.rightString((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder11.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int17 = strBuilder11.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder11.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder20.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder25.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int31 = strBuilder25.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder25.replaceFirst('a', '4');
        java.lang.Object[] objArray39 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder23.appendWithSeparators(objArray39, "");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder41.insert((int) (short) 100, '4');
        char[] charArray47 = strBuilder44.toCharArray(0, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder5.append(charArray47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer(charArray47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer50.setQuoteChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher53 = strTokenizer52.getQuoteMatcher();
        org.apache.commons.lang.text.StrMatcher strMatcher54 = strTokenizer52.getIgnoredMatcher();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 96 + "'", int17 == 96);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 96 + "'", int31 == 96);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(charArray47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strMatcher53);
        org.junit.Assert.assertNotNull(strMatcher54);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.deleteFirst('a');
        char[] charArray10 = null;
        char[] charArray11 = strBuilder1.getChars(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder1.insert(0, (int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.deleteAll("lse");
        java.util.Collection collection17 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder14.appendWithSeparators(collection17, "");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.deleteAll("2");
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder19.delete(150, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        java.lang.String str12 = strBuilder10.substring(10);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder10.deleteFirst(' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = new org.apache.commons.lang.text.StrTokenizer("", 'a');
        int int18 = strTokenizer17.size();
        java.lang.String str19 = strTokenizer17.nextToken();
        char[] charArray26 = new char[] { 'a', ' ', ' ', '4', 'a', ' ' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer17.reset(charArray26);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder14.appendWithSeparators((java.util.Iterator) strTokenizer27, "hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher30 = strTokenizer27.getIgnoredMatcher();
        boolean boolean31 = strTokenizer27.isIgnoreEmptyTokens();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse" + "'", str12.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444f4lse"));
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(strMatcher30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.deleteFirst('a');
        char[] charArray10 = null;
        char[] charArray11 = strBuilder1.getChars(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder1.insert(0, (int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.deleteAll("lse");
        int int19 = strBuilder16.lastIndexOf("", 97);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder16.appendFixedWidthPadLeft((int) (byte) -1, (int) '4', ' ');
        int int25 = strBuilder23.indexOf('4');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder23.appendNull();
        char[] charArray27 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder23.append(charArray27);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 97 + "'", int19 == 97);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder28);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) (-1L));
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder5.append((double) 100L);
        char[] charArray10 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher11);
        org.apache.commons.lang.text.StrMatcher strMatcher13 = strTokenizer12.getIgnoredMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder5.deleteFirst(strMatcher13);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder5.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder17.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.append('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder21.minimizeCapacity();
        boolean boolean25 = strBuilder15.equals(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strMatcher13);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        java.lang.Object obj14 = null;
        boolean boolean15 = strBuilder13.equals(obj14);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder17.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int23 = strBuilder17.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder17.replaceFirst('a', '4');
        char[] charArray27 = new char[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder17.append(charArray27);
        char[] charArray29 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray29, strMatcher30);
        java.lang.String[] strArray32 = strTokenizer31.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher33 = strTokenizer31.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder28.appendWithSeparators((java.util.Iterator) strTokenizer31, "lse");
        char[] charArray38 = new char[] { ' ', '4' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer31.reset(charArray38);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder13.append(charArray38);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder40.appendFixedWidthPadLeft(1, 104, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder44.ensureCapacity(0);
        int int48 = strBuilder46.indexOf("alse100lse");
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 96 + "'", int23 == 96);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(charArray38);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.setNullText("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder7.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder10.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int16 = strBuilder10.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder10.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder19.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder24.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int30 = strBuilder24.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder24.replaceFirst('a', '4');
        java.lang.Object[] objArray38 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder22.appendWithSeparators(objArray38, "");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder40.insert((int) (short) 100, '4');
        char[] charArray46 = strBuilder43.toCharArray(0, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder43.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder43.insert((int) (short) 100, (int) (short) 100);
        int int53 = strBuilder43.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder43.appendFixedWidthPadRight((int) (byte) 10, 0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder8.append(strBuilder57, 5, 101);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 96 + "'", int16 == 96);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 96 + "'", int30 == 96);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(charArray46);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertNotNull(strBuilder60);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        boolean boolean7 = strBuilder5.contains(' ');
        java.lang.StringBuffer stringBuffer8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder5.append(stringBuffer8, 1, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder11.append((double) 114);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder11.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder11.append((double) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.deleteFirst("l");
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance("#");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int9 = strBuilder3.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder3.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder3.insert((int) '#', 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder18.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder22.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder22.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder27.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder31.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder32.setNewLineText("lse");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder22.appendFixedWidthPadLeft((java.lang.Object) strBuilder34, (int) '4', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder39 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder39.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder43.append('a');
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder37.appendFixedWidthPadRight((java.lang.Object) 'a', (int) (short) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder48.append((double) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder50.replaceAll('4', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strBuilder50.asTokenizer();
        char[] charArray55 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher56 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer(charArray55, strMatcher56);
        java.lang.String[] strArray58 = strTokenizer57.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher59 = strTokenizer57.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer54.setIgnoredMatcher(strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer("1004444444true4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444f", strMatcher59);
        org.apache.commons.lang.text.StrMatcher strMatcher62 = strTokenizer61.getQuoteMatcher();
        boolean boolean63 = strBuilder3.contains(strMatcher62);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer1.setQuoteMatcher(strMatcher62);
        int int65 = strTokenizer64.previousIndex();
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 96 + "'", int9 == 96);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strArray58);
        org.junit.Assert.assertNotNull(strMatcher59);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(strMatcher62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        java.lang.String str7 = strBuilder1.substring((int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.append((int) (short) 100);
        java.util.Collection collection10 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder1.appendWithSeparators(collection10, "");
        java.lang.String str15 = strBuilder1.substring(0, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder1.append("1");
        int int18 = strBuilder17.size();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "lse" + "'", str7.equals("lse"));
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 104 + "'", int18 == 104);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444flse", "44444444444444444444444444444444444");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = strTokenizer2.reset();
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoredChar('#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer3.reset("35.0");
        org.junit.Assert.assertNotNull(strTokenizer3);
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(strTokenizer7);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) 100.0d, (int) (byte) 1, '#');
        java.lang.String str7 = strBuilder5.leftString((int) (short) 1);
        java.lang.String str9 = strBuilder5.rightString((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder11.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int17 = strBuilder11.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder11.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder20.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder25.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int31 = strBuilder25.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder25.replaceFirst('a', '4');
        java.lang.Object[] objArray39 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder23.appendWithSeparators(objArray39, "");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder41.insert((int) (short) 100, '4');
        char[] charArray47 = strBuilder44.toCharArray(0, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder5.append(charArray47);
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder5.replaceFirst("lse", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444falsea");
        org.apache.commons.lang.text.StrBuilder strBuilder53 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder53.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int59 = strBuilder53.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder53.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder62.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder67 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder67.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int73 = strBuilder67.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder67.replaceFirst('a', '4');
        java.lang.Object[] objArray81 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder83 = strBuilder65.appendWithSeparators(objArray81, "");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder51.appendWithSeparators(objArray81, "StrTokenizer[]");
        org.apache.commons.lang.text.StrBuilder strBuilder88 = strBuilder85.appendPadding((int) (byte) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder88.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder92 = strBuilder89.insert(0, 0L);
        org.apache.commons.lang.text.StrBuilder strBuilder94 = strBuilder92.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder97 = strBuilder92.delete(8, 51);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 96 + "'", int17 == 96);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 96 + "'", int31 == 96);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(charArray47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 96 + "'", int59 == 96);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 96 + "'", int73 == 96);
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(strBuilder83);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(strBuilder88);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder92);
        org.junit.Assert.assertNotNull(strBuilder94);
        org.junit.Assert.assertNotNull(strBuilder97);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.deleteAll('a');
        java.lang.String str9 = strBuilder5.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder5.append((int) (byte) -1);
        int int13 = strBuilder11.indexOf("StrTokenizer[]");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int21 = strBuilder15.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder15.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder24.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder29.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int35 = strBuilder29.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder29.replaceFirst('a', '4');
        java.lang.Object[] objArray43 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder27.appendWithSeparators(objArray43, "");
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder45.insert((int) (short) 100, '4');
        char[] charArray51 = strBuilder48.toCharArray(0, 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray51);
        char[] charArray53 = strBuilder11.getChars(charArray51);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer54.reset("lse");
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 96 + "'", int21 == 96);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 96 + "'", int35 == 96);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(charArray51);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strTokenizer56);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        boolean boolean7 = strBuilder5.contains(' ');
        java.lang.StringBuffer stringBuffer8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder5.append(stringBuffer8, 1, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder11.append((double) 114);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder13.appendFixedWidthPadRight(102, 63, 'a');
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder17);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int21 = strBuilder15.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder15.replaceFirst('a', '4');
        java.lang.Object[] objArray29 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder13.appendWithSeparators(objArray29, "");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.insert((int) (short) 100, '4');
        char[] charArray37 = strBuilder34.toCharArray(0, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder34.append('a');
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 96 + "'", int21 == 96);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertNotNull(strBuilder39);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        boolean boolean9 = strBuilder1.endsWith("");
        int int10 = strBuilder1.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder1.append(strBuilder11, (int) '4', (int) (byte) 10);
        char[] charArray18 = new char[] { 'a', ' ', ' ' };
        char[] charArray19 = strBuilder1.getChars(charArray18);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray18, ' ', 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray18, "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444flse");
        try {
            java.lang.Object obj25 = strTokenizer24.previous();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray19);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder1.insert((int) '#', 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int21 = strBuilder15.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder15.replaceFirst('a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder24.delete((int) (short) 100, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = new org.apache.commons.lang.text.StrBuilder((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder29.appendFixedWidthPadLeft((java.lang.Object) false, (int) (byte) 100, '4');
        int int35 = strBuilder29.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder29.replaceFirst('a', '4');
        java.lang.Object[] objArray43 = new java.lang.Object[] { '4', 100, (byte) 0, (-1.0d), ' ' };
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder27.appendWithSeparators(objArray43, "");
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder45.insert((int) (short) 100, '4');
        char[] charArray51 = strBuilder48.toCharArray(0, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder13.append(charArray51);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer(charArray51, "####################################################");
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray51);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer(charArray51, '4', 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray51);
        org.apache.commons.lang.text.StrMatcher strMatcher60 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer(charArray51, strMatcher60);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = new org.apache.commons.lang.text.StrTokenizer(charArray51, ' ', ' ');
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 96 + "'", int21 == 96);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 96 + "'", int35 == 96);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(charArray51);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strTokenizer59);
    }
}

