import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("A.LAVASS [LJANG.STRING;CLA.LAVASS [LJANG.STRING;CLA.LAVASS [LJAC", "Tion4chine Specific4l M4 Virtu4v4J", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "ot(TM) 64-Bit Server ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "/users/sophie/documents/defects4j/tmp/run_randoop.pl_94747_1560209543", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                   va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                   ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2699 + "'", int5 == 2699);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aJaJaJaJaJaJa86_6aJaJaJaJaJaJa", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "v server 64-bit hotspot(tm) va");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1#.#7                      ", (java.lang.CharSequence) "10.14.3                            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "wawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        float[] floatArray5 = new float[] { (byte) 0, (byte) 0, 100.0f, (short) 0, (byte) 1 };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(".macosx.lwctoolki", (short) 15);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 15 + "'", short2 == (short) 15);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("######################java hotspot(tm) 64-bit server v##############################", "d                                                                   /avaJ/yrarbiL//Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents", "wawt.macosx.LWCToolkit", 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "######################java hotspot(tm) 64-bit server v##############################" + "'", str4.equals("######################java hotspot(tm) 64-bit server v##############################"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/users/sophie/documents/defects4j/tmp/run_randoop.pl_94747_156020954", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randoop.pl_94747_156020954" + "'", str2.equals("/users/sophie/documents/defects4j/tmp/run_randoop.pl_94747_156020954"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVA hOTsPOT(tm) 64-bIT sERVER AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "                                1.5                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVA hOTsPOT(tm) 64-bIT sERVER AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVA hOTsPOT(tm) 64-bIT sERVER AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("JavaHotSpot(TM)64-BitServerV");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543", (java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "s/Home/jre", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                           " + "'", str2.equals("                           "));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("cosx.LWCToawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.masun.lw", "Sun.lwawt.macosx.lwctoolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cosx.LWCToawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCT" + "'", str2.equals("cosx.LWCToawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCT"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(100.0d, 67.0d, (double) 4.4444446E16f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.4444446133059584E16d + "'", double3 == 4.4444446133059584E16d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("280-B11                                                          ", "                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                          " + "'", str2.equals("                                                                          "));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("   Corporation24.80-B11Corporation ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   Corporation24.80-B11Corporation " + "'", str2.equals("   Corporation24.80-B11Corporation "));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("racle Corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "racle Corporatio" + "'", str1.equals("racle Corporatio"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "tsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCTo");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                                                   ", (java.lang.CharSequence) "oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("51b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7./");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"51b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7./\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        double[] doubleArray5 = new double[] { (-1L), (short) -1, 1.0d, 97.0d, 1.0f };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.Class<?> wildcardClass10 = doubleArray5.getClass();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 97.0d + "'", double9 == 97.0d);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.81.11.51.11.8", "/USER");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.81.11.51.11.8" + "'", str2.equals("1.81.11.51.11.8"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        char[] charArray7 = new char[] {};
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "racle Corporation", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ng.String;a.lavass [Ljang.String;cla.lavass [Ljang.String;cla.lavass [Ljacl", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "24.80-B11", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                           ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "               ", 1245, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents(":.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR" + "'", str1.equals(":.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "#################44444444444444444##################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java(TM) SE Runtime Environment", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("SUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKI", "Corporation Oracle", 4);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(5, 93, 1245);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-" + "'", str2.equals("ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "A.LAVASS [LJANG.STRING;CLA.LAVASS [LJANG.STRING;CLA.LAVASS [LJAC");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest8.test041");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
//        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        java.lang.String str4 = javaVersion3.toString();
//        java.lang.String str5 = javaVersion3.toString();
//        java.lang.String str6 = javaVersion3.toString();
//        boolean boolean7 = javaVersion1.atLeast(javaVersion3);
//        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
//        boolean boolean12 = javaVersion9.atLeast(javaVersion10);
//        boolean boolean13 = javaVersion1.atLeast(javaVersion10);
//        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean16 = javaVersion14.atLeast(javaVersion15);
//        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion15);
//        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean20 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion19);
//        boolean boolean21 = javaVersion18.atLeast(javaVersion19);
//        org.apache.commons.lang3.JavaVersion javaVersion22 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
//        boolean boolean23 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion22);
//        java.lang.String str24 = javaVersion22.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion25 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean26 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion25);
//        org.apache.commons.lang3.JavaVersion javaVersion27 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        org.apache.commons.lang3.JavaVersion javaVersion28 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean29 = javaVersion27.atLeast(javaVersion28);
//        org.apache.commons.lang3.JavaVersion javaVersion30 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        java.lang.String str31 = javaVersion30.toString();
//        java.lang.String str32 = javaVersion30.toString();
//        java.lang.String str33 = javaVersion30.toString();
//        boolean boolean34 = javaVersion28.atLeast(javaVersion30);
//        org.apache.commons.lang3.JavaVersion[] javaVersionArray35 = new org.apache.commons.lang3.JavaVersion[] { javaVersion10, javaVersion15, javaVersion19, javaVersion22, javaVersion25, javaVersion30 };
//        java.lang.String str36 = org.apache.commons.lang3.StringUtils.join(javaVersionArray35);
//        java.lang.String str37 = org.apache.commons.lang3.StringUtils.join((java.lang.Enum<org.apache.commons.lang3.JavaVersion>[]) javaVersionArray35);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.4" + "'", str5.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion22 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion22.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1.1" + "'", str24.equals("1.1"));
//        org.junit.Assert.assertTrue("'" + javaVersion25 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion25.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion27 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion27.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + javaVersion28 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion28.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion30 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion30.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1.4" + "'", str31.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1.4" + "'", str32.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.4" + "'", str33.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(javaVersionArray35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1.81.51.81.11.81.4" + "'", str36.equals("1.81.51.81.11.81.4"));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1.81.51.81.11.81.4" + "'", str37.equals("1.81.51.81.11.81.4"));
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "51b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7./");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "klootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sophie", 30, 2699);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("51b-08_0.7.1racle Corporationracle                                                                  ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("s/sophie/documents/defects4j/tmp/run_randoop.pl_9474", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s/sophie/documents/defects4j/tmp/run_randoop.pl_9474" + "'", str2.equals("s/sophie/documents/defects4j/tmp/run_randoop.pl_9474"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("tionachine Specifical Ma VirtuavaJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"tionachine Specifical Ma VirtuavaJ\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 'a', (double) 15L, 4.4444444444444448E16d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 15.0d + "'", double3 == 15.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(1761L, (long) 32, (long) 94);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1761L + "'", long3 == 1761L);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest8.test050");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
//        java.lang.String str3 = javaVersion1.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        java.lang.String str9 = javaVersion8.toString();
//        java.lang.String str10 = javaVersion8.toString();
//        java.lang.String str11 = javaVersion8.toString();
//        boolean boolean12 = javaVersion6.atLeast(javaVersion8);
//        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean16 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion15);
//        boolean boolean17 = javaVersion14.atLeast(javaVersion15);
//        boolean boolean18 = javaVersion6.atLeast(javaVersion15);
//        boolean boolean19 = javaVersion4.atLeast(javaVersion6);
//        boolean boolean20 = javaVersion1.atLeast(javaVersion4);
//        boolean boolean21 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.4" + "'", str9.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.4" + "'", str10.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.4" + "'", str11.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("noitaroproC elcarO", "1.8", "class [Sclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitaroproC elcarO" + "'", str3.equals("noitaroproC elcarO"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        long[] longArray5 = new long[] { 10L, (short) 0, (byte) -1, (byte) 10, ' ' };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("#################################/#################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#################################/#################################" + "'", str1.equals("#################################/#################################"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) ":", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 15, (short) (byte) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(9, (int) (short) 100, 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("51bUS51b-", "sun.lwawt.mac...", "en#########################ULib-");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("_94747_1560209543/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("JavaHotSpot(TM)64-BitServerV");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVAhOTsPOT(tm)64-bITsERVERv" + "'", str1.equals("jAVAhOTsPOT(tm)64-bITsERVERv"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("http://java.oracle.com/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: http://java.oracle.com/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "##################################JavaHotSpot(TM)64-BitServerV###################################", "/Library/Java/JavaVirtualMachines/jdksun.lwawt.macosJava Platform API Specificationx.lwctoolkit.7.sun.lwawt.macosx.lwctoolkit_sun.lwawt.macosx.lwctoolkit.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "459020651_74749_L", (java.lang.CharSequence) "459020651_74749_l", 65);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                    ", (java.lang.CharSequence) "...######");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "jAVAhOTsPOT(tm)64-bITsERVERv", (java.lang.CharSequence) "                                   v revres tib-46 )mt(topstoh av                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("java hotspot(tm) 64-bit server v");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java hotspot(tm) 64-bit server v" + "'", str1.equals("java hotspot(tm) 64-bit server v"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "users/sophie/documents/defects4j...", (java.lang.CharSequence) "en#########################ULib-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '#', (long) 100, (long) 67);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "######################j#v#hotspot(tm)#64-bit#server#v#####################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("51.0", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 30, (float) 53, (float) 5);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 53.0f + "'", float3 == 53.0f);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "klootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nus", (java.lang.CharSequence) "            ng.String;a.lavraphi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("mixed mode", "sun.awt.CGraphicsEnvironment");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "10.14.3                            ", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "x4d 4d" + "'", str6.equals("x4d 4d"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.lwctoolkitsun.lwawt.macosx.lwcth...", "                                 erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "x/Library/Java/JavaVirtualMachines/jdksun.lwawt.macosx.lwctoolkit.7.sun.lwawt.macosx.lwctoolkit_sun.lwawt.macosx.lwctoolkit.jdk/Contents/Home/jrd/Library/Java/JavaVirtualMachines/jdksun.lwawt.macosx.lwctoolkit.7.sun.lwawt.macosx.lwctoolkit_sun.lwawt.macosx.lwctoolkit.jdk/Contents/Home/jrd");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aphi", "                                   va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                   ", "SUN.LWAWT.MACOSX.LWCTOOLKI");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("CLASS [LJAVA.LANG", "51B-08_0.7.1RACLSCORPORATIOURACLS", "aaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server", 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        char[][][] charArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(charArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 1245, "ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFM" + "'", str3.equals("ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-ULib-F-yUJFTFUJFTFVi-tuFM"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(".", "O", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "." + "'", str3.equals("."));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "                    /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("OTCWL.XSOCAM.TWAWL.NUSTIKLOOTCWL.XSOCAM.TWAWL.NUS!IHTCWL.XSOCAM.TWAWL.NUSTIKLOOTCWL.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "sun.lwawt.macosx.lwctoolkit", (java.lang.CharSequence) "JJJJJJ86_6JJJJJJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.                              ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543", 1245);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "raphi", (int) (short) 15, (-1));
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Sun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkit", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "   ", (java.lang.CharSequence) "#################################################################", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Corporation24.80-B11Corporation ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Corpora..." + "'", str2.equals("Corpora..."));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.0#####################ULib-", "/users/sophie/documents/defects4j/tmp/run_randoop.pl_94747_156020954");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahttp://java.oracle.com/", "J/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarb", 1761, 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaJ/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarb" + "'", str4.equals("aaJ/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarb"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "51B-08_0.7.1RACLSCORPORATIOURACLS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("N", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                   ", "j/e4H/4e4C/4dj408_047414dj/4e4h4M4r4V4v4J/4v4J/yr4rb4Le4e4e4e4e4e4e4e4e4e4e4e4e4e4e4e4e");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("x86_6", "wawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_6" + "'", str2.equals("x86_6"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.CP", (java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("sun.lwawt.mac...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.mac...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("ng.String;a.lavass [Ljang.String;cla.lavass [Ljang.String;cla.lavass [Ljac", "sun.lwawt.macosx.lwctoolkitsun.lwawt.macosx.lwcth...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ng.String;a.lavass [Ljang.String;cla.lavass [Ljang.String;cla.lavass [Ljac" + "'", str2.equals("ng.String;a.lavass [Ljang.String;cla.lavass [Ljang.String;cla.lavass [Ljac"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "51B-08_0.7.1RACLSCORPORATIOURACLS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(30, (int) (byte) 100, 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 30 + "'", int3 == 30);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("en", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("51b-08_0.7.1raclsCorporatiouracls", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s" + "'", str2.equals("s"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("#################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(2, 34, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 34 + "'", int3 == 34);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str1.equals("/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "l_94747_156020954", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("aJaJaJaJaJaJa86_6aJaJaJaJaJaJa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahttp://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aJaJaJaJaJaJa86_6aJaJaJaJaJaJa" + "'", str2.equals("aJaJaJaJaJaJa86_6aJaJaJaJaJaJa"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                   va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                                                      va hotspot(tm) 64-bit server v                                   ", (int) (byte) 1, 15);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "              " + "'", str3.equals("              "));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray12 = new char[] { '#', 'a', '4', '#', '#', ' ' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence5, charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "raphi", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3                            1.", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http1.com/", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("#################################1#################################", "APHI");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "n", (java.lang.CharSequence) "##############...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "##############...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ", "/Library/Java/JavaVirtualMachines/jdksun.lwawt.macosx.lwctoolkit.7.sun.lwawt.macosx.lwctoolkit_sun.lwawt.macosx.lwctoolkit.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ" + "'", str2.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        java.lang.CharSequence charSequence7 = null;
        char[] charArray9 = new char[] {};
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence7, charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctHI!SUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctO", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "51b-08_0.7.1racls Corporatiouracls ", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "86_64", charArray9);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBILENENENENENENENENENENENENENENENENEN", charArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                  v revres tib-46 )mt(topstoh av                                   ", charArray9);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                                 ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("java HotSpot(TM) 64-Bit Server VM", "10.14.3                            n24.80-B11Corporation", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Corporation24.80-B11Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Corporation24.80-B11Corporation" + "'", str1.equals("Corporation24.80-B11Corporation"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_94747_156020954", (java.lang.CharSequence) "i44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (short) 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("tsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCTo", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCTo" + "'", str2.equals("x.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCTo"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        double[] doubleArray2 = new double[] { (-1), '4' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 52.0d + "'", double5 == 52.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 52.0d + "'", double6 == 52.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51b-08_0.7.1racls Corporatiouracls ", "", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                hi!                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                hi!                                                " + "'", str1.equals("                                                hi!                                                "));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVA hOTsPOT(tm) 64-bIT sERVER AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("uLib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-", "NG.STRING;A.LAVASS [LJANG.STRING;CLA.LAVASS [LJANG.STRING;CLA.LAVASS [LJACL");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "uLib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-" + "'", str2.equals("uLib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/eihpos", (java.lang.CharSequence) "Cdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/orporationdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Odesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/racle");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("4");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.0f + "'", float1 == 4.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("wawt.macosx.LWCToolkit", 98);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("mixed mode", "sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("");
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("m) 64-bit server v", strArray3, strArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "m) 64-bit server v" + "'", str8.equals("m) 64-bit server v"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaad aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaad" + "'", str10.equals("xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaad aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaad"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "51B-08_0.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("noitaroproC elcarO", "1#.#7                      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproC elcarO" + "'", str2.equals("noitaroproC elcarO"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("noitaroproC elcarO", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitaroproC elcarO" + "'", str3.equals("noitaroproC elcarO"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1#.#7", (java.lang.CharSequence) "tsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCTo");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73 + "'", int2 == 73);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("459020651_74749_L");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.7.0_80", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("racle Corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "racle Corporatio" + "'", str1.equals("racle Corporatio"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.1", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 15, 3, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ng.String;a.lavass [Ljang.String;cla.lavass [Ljang.String;cla.lavass [Ljac", '4');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "M_R OS X");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Corpora...", (java.lang.CharSequence) "                            3.41.01");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 10L, (float) 1761L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1761.0f + "'", float3 == 1761.0f);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("4.80-B11                                                                 ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4.80-B11                                                                 " + "'", str2.equals("4.80-B11                                                                 "));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("####################################################################################################", "   ", (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#########################   ########################" + "'", str3.equals("#########################   ########################"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdksun.lwawt.macosJava Platform API Specificationx.lwctoolkit.7.sun.lwawt.macosx.lwctoolkit_sun.lwawt.macosx.lwctoolkit.jdk/Contents/Home/jre", (java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                    ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_94747_1560209543", (java.lang.CharSequence) ".macosx.lwctoolki", 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sophie", "n", 73);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sunlwawmacosxPr1nerJob", (java.lang.CharSequence) "J/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarb", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "####################################################################################################", (java.lang.CharSequence) "Sun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2619 + "'", int2 == 2619);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 100.0f, (float) 32);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 831L, (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 831L + "'", long3 == 831L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("su...", "24.80-B11", 74);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation", (int) (short) 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle corpo..." + "'", str2.equals("oracle corpo..."));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("#########################   ########################", 1245);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#########################   ########################" + "'", str2.equals("#########################   ########################"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("UTF-8", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "SUN", (java.lang.CharSequence) "#################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "n", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Sun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.mal_94747_15awt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.mal_94747_15awt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkit" + "'", str1.equals("Sun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.mal_94747_15awt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkit"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironment", "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", 67);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/users/sophie/documents/defectsj/tmp/run_randoop.pl_977_15602095", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("51B-08_0.7.1RACLS CORPORATIOURACLS ", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("s/Home/jre", "####################################################################################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        java.lang.String str6 = javaVersion4.toString();
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str11 = javaVersion10.toString();
        java.lang.String str12 = javaVersion10.toString();
        java.lang.String str13 = javaVersion10.toString();
        boolean boolean14 = javaVersion8.atLeast(javaVersion10);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        boolean boolean16 = javaVersion4.atLeast(javaVersion8);
        boolean boolean17 = javaVersion1.atLeast(javaVersion4);
        java.lang.String str18 = javaVersion4.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.1" + "'", str6.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.4" + "'", str11.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.4" + "'", str12.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.4" + "'", str13.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.1" + "'", str18.equals("1.1"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                    sun.lwawt.macosx.CPrinterJob      ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                    sun.lwawt.macosx.CPrinterJob      " + "'", str2.equals("                                    sun.lwawt.macosx.CPrinterJob      "));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "51b-08_0.7.1raclsCorporatiouracls", (java.lang.CharSequence) "al Mac", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Java(TM) SE Runtime En[Ljacl [Ljang.String;cla.lavass [Ljang.String;cla.lavass ng.String;a.lavass");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.7", "Java HotSpot(TM) 64-Bit Server");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 'a', 1248L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                            3.41.01", "java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "US#################################", (java.lang.CharSequence) "al Mac");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "j/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarb");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "10.14.3                            1.", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444451.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8", "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, 'a', (int) (short) 1, (int) (byte) 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Cdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/orporationdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Odesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/racle", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Cdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/orporationdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Odesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/racle" + "'", str12.equals("Cdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/orporationdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Odesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/racle"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "sun.lwawt.macosx.lwctoolkitsun.lwawt.macosx.lwcth...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "NG.STRING;A.LAVASS [LJANG.STRING;CLA.LAVASS [LJANG.STRING;CLA.LAVASS [LJACL");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 5, (float) '4', (float) 94);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("tionachine Specifical Ma VirtuavaJ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("en", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", '#');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence[]) strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKIT", (java.lang.CharSequence[]) strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT", strArray4, strArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.14.3                            n24.80-B11Corporation ", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT" + "'", str12.equals("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strArray14);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                              ", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                              " + "'", str3.equals("                                                                                              "));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("en", "sun.awt.CGraphicsEnvironment");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray10 = new java.lang.String[] { "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" };
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "51b-08_0.7.1");
        java.lang.String[] strArray16 = new java.lang.String[] {};
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!", "hi!", "hi!" };
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray16, strArray20);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEach("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiLenenenenenenenenenenenenenenenenen", strArray14, strArray16);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEach("Java HotSpot(TM) 64-Bit Server V", strArray5, strArray14);
        boolean boolean24 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "8_0.7.1racls Corporatiouracls ", (java.lang.CharSequence[]) strArray14);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiLenenenenenenenenenenenenenenenenen" + "'", str22.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiLenenenenenenenenenenenenenenenenen"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Java HotSpot(TM) 64-Bit Server V" + "'", str23.equals("Java HotSpot(TM) 64-Bit Server V"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                          ", (java.lang.CharSequence) "1#.#7", 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/users/sophie/documents/defects4j/tmp/run_randoop.pl_94747_1560209543", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "", 52, 27);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/Users/sophie");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("xsocam.twawl.nus!ihTCWL.xsocam.t");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "10.14.3                            n24.80-B11Corporation", (java.lang.CharSequence) "                                 erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL", 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("N", "sun.lwawt.macosx.lwctoolkitsun                                   va hotspot(tm) 64-bit server v                                   .lwawt.macosx.lwcthi!sun.lwawt.macosx.lwctoolkitsun.lwawt.macosx.lwcto");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie", '#');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "  ", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Sun.lwawt.macosx.lwctoolkit                         ", (java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "            ng.String;a.lavass [Ljang.String;cla.lavass [Ljang.String;cla.lavass [Ljacl             ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("NG.STRING;A.LAVASS [LJANG.STRING;CLA.LAVASS [LJANG.STRING;CLA.LAVASS [LJACL", "aaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NG.STRING;A.LAVASS [LJANG.STRING;CLA.LAVASS [LJANG.STRING;CLA.LAVASS [LJACL" + "'", str2.equals("NG.STRING;A.LAVASS [LJANG.STRING;CLA.LAVASS [LJANG.STRING;CLA.LAVASS [LJACL"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("rclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String; Corporation");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/eihpos");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "SUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKI");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("cosx.LWCToawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.ma", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("s/Home/jre", "cosx.LWCToawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.masun.lw");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s/Home/jre" + "'", str2.equals("s/Home/jre"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCTo", "4444444444", "51b-08_0.7.1racls Corporatiouracls ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCTo" + "'", str3.equals("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCTo"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sun.lwawt.mac...", 18, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("######################J#V#HOTSPOT(TM)#6-BIT#SERVER#V###############################", 100, 831);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "######################J#V#HOTSPOT(TM)#6-BIT#SERVER#V###############################" + "'", str3.equals("######################J#V#HOTSPOT(TM)#6-BIT#SERVER#V###############################"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("ng.String;a.lavass [Ljang.String;cla.lavass [Ljang.String;cla.lavass [Ljacl", "                                                                                                 ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Java(TM) SE Runtime Environmen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environmen" + "'", str1.equals("Java(TM) SE Runtime Environmen"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java(TM) SE Runtime En[Ljacl [Ljang.String;cla.lavass [Ljang.String;cla.lavass ng.String;a.lavass");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaad aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaad");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("24.80-B11                                                                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B11" + "'", str1.equals("24.80-B11"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.4", (int) '#', 70);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aJ" + "'", str1.equals("aJ"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1#.#7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#.#7" + "'", str1.equals("1#.#7"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "t.macosx.LWCThi!sun.lwawt.macosx", "sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("ndoop.pl_94747_156020954ausers/sophie/documents/defects4j/tmp/run_r", "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ndoop.pl_94747_156020954ausers/sophie/documents/defects4j/tmp/run_r" + "'", str3.equals("ndoop.pl_94747_156020954ausers/sophie/documents/defects4j/tmp/run_r"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str4 = javaVersion3.toString();
        java.lang.String str5 = javaVersion3.toString();
        java.lang.String str6 = javaVersion3.toString();
        boolean boolean7 = javaVersion1.atLeast(javaVersion3);
        java.lang.Class<?> wildcardClass8 = javaVersion1.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.4" + "'", str5.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("t.macosx.LWCThi!sun.lwawt.macosx", "aaaaaaaaaaal_94747_15aaaaaaaaaaa", "            ng.String;a.lavraphi");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("SUN.LWAWT.MACOSX.LWCTOOLKI");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: SUN.LWAWT.MACOSX.LWCTOOLKI is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Java(TM) SE Runtime Environmen", "Java(TM) SE 1.e Environmen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                 1.4                  ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4d + "'", double1.equals(1.4d));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("mixed mode", "sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.lwctoolkitsun.lwawt.macosx.lwcthi!sun.lwawt.macosx.lwctoolkitsun.lwawt.macosx.lwcto", "#################################/#################################", (int) (byte) 10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, ' ', (int) (byte) 0, 0);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10.14.3                            n24.80-B11Corporation", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("SUN.LWAWT.MACOSX.lwctOOLKIT", 93, "24.80-B11                                                          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-B11                        SUN.LWAWT.MACOSX.lwctOOLKIT24.80-B11                        " + "'", str3.equals("24.80-B11                        SUN.LWAWT.MACOSX.lwctOOLKIT24.80-B11                        "));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("racle Corporatio");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543", (int) (byte) 1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ome/jre" + "'", str2.equals("ome/jre"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                                                                        11b-08.42");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.2");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##################" + "'", str2.equals("##################"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "sun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolk");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-", "US");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '#', 73, 1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-" + "'", str3.equals("ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-" + "'", str5.equals("ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava HotSpot(TM) 64-Bit Server aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("51.0", "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                 ", 74, "/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                 " + "'", str3.equals("                                                                                                 "));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("su...");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("users/sophie/documents/defects4j...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...j4stcefed/stnemucod/eihpos/sresu" + "'", str1.equals("...j4stcefed/stnemucod/eihpos/sresu"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolk", (java.lang.CharSequence) "JJJJJJ86_6JJJJJJ                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                1.5                                ", (int) ' ', (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5                             " + "'", str3.equals("1.5                             "));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.                              ", (int) (short) 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.          ..." + "'", str2.equals("1.          ..."));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "####################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                                hi!                                                 ", "   -jUHUttCUkj.8..kjUihFMFut-iVFTFJUFTFJUy-F-biLU    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                hi!                                                 " + "'", str2.equals("                                                hi!                                                 "));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/", 2619);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "java hotspot(tm) 64-bit server vm", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (java.lang.CharSequence) "51B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7./");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java HotSpot(TM) 64-Bit Server ", (int) '#', "/Library/Java/JavaVirtualMachines/jdksun.lwawt.macosJava Platform API Specificationx.lwctoolkit.7.sun.lwawt.macosx.lwctoolkit_sun.lwawt.macosx.lwctoolkit.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server /Lib" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server /Lib"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "j/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiLenenenenenenenenenenenenenenenenen", 0, (int) '#');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("APHI");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "51B-08_0.7.1RACLS CORPORATIOURACLS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.81.11.51.11.8", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                 n                                                  ", 1245);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             n                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             n                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               "));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("sunlwawmacosxPr1nerJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sunlwawmacosxPr1nerJob" + "'", str1.equals("sunlwawmacosxPr1nerJob"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        double[] doubleArray1 = new double[] { 1.5f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5d + "'", double2 == 1.5d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.5d + "'", double3 == 1.5d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              ", (java.lang.CharSequence) "N", 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                    sun.lwawt.macosx.CPrinterJob      ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("al Mac", "                                                                java hotspot(tm) 64-bit server vm");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "UN.LWAWT.MACOSX.LWCTOOLKI");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "al Mac" + "'", str4.equals("al Mac"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "Corporation24.80-B11Corporation ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "sunlwawmacosxPr1nerJo");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.6", "i", "aaaaaaaaaaa1.4aaaaaaaaaaaa");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("ng.String;a.lavass [Ljang.String;cla.lavass [Ljang.String;cla.lavass [Ljac", "24.80-B11                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ng.String;a.lavass [Ljang.String;cla.lavass [Ljang.String;cla.lavass [Ljac" + "'", str2.equals("ng.String;a.lavass [Ljang.String;cla.lavass [Ljang.String;cla.lavass [Ljac"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("####################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("SOPHIE/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", "APHI", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SOPHIE/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str3.equals("SOPHIE/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("i", "10.14.3                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i" + "'", str2.equals("i"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("iUjk..8.jkUCttUHUj-##########################", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 53, (long) 27, 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 27L + "'", long3 == 27L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                                    sun.lwawt.mac...", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                    sun.lwawt.mac..." + "'", str2.equals("                                    sun.lwawt.mac..."));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("   ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aJ", (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "usiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdksun.lwawt.macosJava Platform API Specificationx.lwctoolkit.7.sun.lwawt.macosx.lwctoolkit_sun.lwawt.macosx.lwctoolkit.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Corporation Oracle", (int) (short) 10, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "n Oracle" + "'", str3.equals("n Oracle"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "/USER");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest8.test284");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
//        java.lang.String str3 = javaVersion1.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
//        java.lang.String str7 = javaVersion5.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean11 = javaVersion9.atLeast(javaVersion10);
//        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        java.lang.String str13 = javaVersion12.toString();
//        java.lang.String str14 = javaVersion12.toString();
//        java.lang.String str15 = javaVersion12.toString();
//        boolean boolean16 = javaVersion10.atLeast(javaVersion12);
//        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
//        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean20 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion19);
//        boolean boolean21 = javaVersion18.atLeast(javaVersion19);
//        boolean boolean22 = javaVersion10.atLeast(javaVersion19);
//        boolean boolean23 = javaVersion8.atLeast(javaVersion10);
//        boolean boolean24 = javaVersion5.atLeast(javaVersion8);
//        boolean boolean25 = javaVersion1.atLeast(javaVersion5);
//        boolean boolean26 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.5" + "'", str7.equals("1.5"));
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.4" + "'", str13.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.4" + "'", str14.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.4" + "'", str15.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      aaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      aaaaaaaaaa" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      aaaaaaaaaa"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "51b-08_0.7.1racle Corporationracle", (java.lang.CharSequence) "klootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "51b-08_0.7.1racle Corporationracle" + "'", charSequence2.equals("51b-08_0.7.1racle Corporationracle"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("tsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCTo");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCTo" + "'", str1.equals("tsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCTo"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lan/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("en", "sun.awt.CGraphicsEnvironment");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = new java.lang.String[] { "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" };
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "51b-08_0.7.1");
        java.lang.String[] strArray15 = new java.lang.String[] {};
        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "hi!", "hi!" };
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray15, strArray19);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiLenenenenenenenenenenenenenenenenen", strArray13, strArray15);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEach("Java HotSpot(TM) 64-Bit Server V", strArray4, strArray13);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray13);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray13);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiLenenenenenenenenenenenenenenenenen" + "'", str21.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiLenenenenenenenenenenenenenenenenen"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Java HotSpot(TM) 64-Bit Server V" + "'", str22.equals("Java HotSpot(TM) 64-Bit Server V"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str23.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str24.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Sun.lwawt.macosx.lwctoolkit                         ", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3                            n24.80-B11Corporation", charArray6);
        java.lang.Class<?> wildcardClass12 = charArray6.getClass();
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ":", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                 Corporation24.80-B11Corporation ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "#################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Tion4chine Specific4l M4 Virtu4v4J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("51b-08_0.7.1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"51b-08_0.7.1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sophie", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolki", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-B11                             ", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents(".CP");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".CP" + "'", str1.equals(".CP"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("################################java hotspot(tm) 64-bit server v################################", 97, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################java hotspot(tm) 64-bit server v################################4" + "'", str3.equals("################################java hotspot(tm) 64-bit server v################################4"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", "", 0, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str4.equals("S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                    ", "######################J#V#HOTSPOT(TM)#6-BIT#SERVER#V####################...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "######################J#V#HOTSPOT(TM)#6-BIT#SERVER#V####################..." + "'", str2.equals("######################J#V#HOTSPOT(TM)#6-BIT#SERVER#V####################..."));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                                hi!                                                 ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                hi!                                                 " + "'", str2.equals("                                                hi!                                                 "));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("51b-08_0.7.1racle Corporationracle                                                                  ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51b-08_0.7.1racle Corporationracle                                                                  " + "'", str2.equals("51b-08_0.7.1racle Corporationracle                                                                  "));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("jUHUttCUkj.8..kjUihFMFut-iVFTFJUFTFJUy-F-biLUaaaaaaaaaaaaaaaaaaaaaa", 53);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jUHUttCUkj.8..kjUihFMFut-iVFTFJUFTFJUy-F-biLUaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("jUHUttCUkj.8..kjUihFMFut-iVFTFJUFTFJUy-F-biLUaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "##################################################################", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) ":.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 94L, 35.0d, (double) 32L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 94.0d + "'", double3 == 94.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "[Ljacl [Ljang.String;cla.lavass [Ljang.String;cla.lavass ng.String;a.lavass", "usiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("aJaJaJaJaJaJa86_6aJaJaJaJaJaJa", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("################################java hotspot(tm) 64-bit server v################################4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################################java hotspot(tm) 64-bit server v################################4" + "'", str1.equals("################################java hotspot(tm) 64-bit server v################################4"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE CORPORATION" + "'", str1.equals("ORACLE CORPORATION"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCTo", (java.lang.CharSequence) "86_6", 65);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                hi!                                                ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("######################j#v#hotspot(tm)#64-bit#server#v###############################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#####################j#v#hotspot(tm)#64-bit#server#v###############################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("en", "sun.awt.CGraphicsEnvironment");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = new java.lang.String[] { "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" };
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "51b-08_0.7.1");
        java.lang.String[] strArray15 = new java.lang.String[] {};
        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "hi!", "hi!" };
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray15, strArray19);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiLenenenenenenenenenenenenenenenenen", strArray13, strArray15);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEach("Java HotSpot(TM) 64-Bit Server V", strArray4, strArray13);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray13);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray13, "users/sophie/documents/defects4j/tmp/run_randoop.pl_94747_156020954", (int) (short) 100, (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiLenenenenenenenenenenenenenenenenen" + "'", str21.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiLenenenenenenenenenenenenenenenenen"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Java HotSpot(TM) 64-Bit Server V" + "'", str22.equals("Java HotSpot(TM) 64-Bit Server V"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str23.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file1 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File file2 = org.apache.commons.lang3.SystemUtils.getJavaHome();
        java.io.File[] fileArray3 = new java.io.File[] { file0, file1, file2 };
        java.io.File file4 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file5 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File file6 = org.apache.commons.lang3.SystemUtils.getJavaHome();
        java.io.File[] fileArray7 = new java.io.File[] { file4, file5, file6 };
        java.io.File file8 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file9 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File file10 = org.apache.commons.lang3.SystemUtils.getJavaHome();
        java.io.File[] fileArray11 = new java.io.File[] { file8, file9, file10 };
        java.io.File file12 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file13 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File file14 = org.apache.commons.lang3.SystemUtils.getJavaHome();
        java.io.File[] fileArray15 = new java.io.File[] { file12, file13, file14 };
        java.io.File file16 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file17 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File file18 = org.apache.commons.lang3.SystemUtils.getJavaHome();
        java.io.File[] fileArray19 = new java.io.File[] { file16, file17, file18 };
        java.io.File[][] fileArray20 = new java.io.File[][] { fileArray3, fileArray7, fileArray11, fileArray15, fileArray19 };
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(fileArray20);
        org.junit.Assert.assertNotNull(file0);
        org.junit.Assert.assertNotNull(file1);
        org.junit.Assert.assertNotNull(file2);
        org.junit.Assert.assertNotNull(fileArray3);
        org.junit.Assert.assertNotNull(file4);
        org.junit.Assert.assertNotNull(file5);
        org.junit.Assert.assertNotNull(file6);
        org.junit.Assert.assertNotNull(fileArray7);
        org.junit.Assert.assertNotNull(file8);
        org.junit.Assert.assertNotNull(file9);
        org.junit.Assert.assertNotNull(file10);
        org.junit.Assert.assertNotNull(fileArray11);
        org.junit.Assert.assertNotNull(file12);
        org.junit.Assert.assertNotNull(file13);
        org.junit.Assert.assertNotNull(file14);
        org.junit.Assert.assertNotNull(fileArray15);
        org.junit.Assert.assertNotNull(file16);
        org.junit.Assert.assertNotNull(file17);
        org.junit.Assert.assertNotNull(file18);
        org.junit.Assert.assertNotNull(fileArray19);
        org.junit.Assert.assertNotNull(fileArray20);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "51b-08_0.7.1racle Corporationracle ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "hi!", 1245);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.1", (java.lang.CharSequence) " HotSpot(TM) 64-Bit Server");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Java HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER V" + "'", str1.equals("JAVA HOTSPOT(TM) 64-BIT SERVER V"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("orporation24.80-B11Corporation", "cosx.LWCToawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCT", "10.14.3                            n24.80-B11Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0rp0r   0 24480-B11 0rp0r   0 " + "'", str3.equals("0rp0r   0 24480-B11 0rp0r   0 "));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "44444444444444444", (java.lang.CharSequence) "51b-08_0.7.1racle Corporationracle                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] {};
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "racle Corporation", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ng.String;a.lavass [Ljang.String;cla.lavass [Ljang.String;cla.lavass [Ljacl", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "24.80-B11", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.81.11.5", charArray8);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/users/sophie/documents/defects4j/tmp/run_randoop.pl_94747_1560209543", "...j4stcefed/stnemucod/eihpos/sresu");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "_randoop.pl_94747_1560209543" + "'", str2.equals("_randoop.pl_94747_1560209543"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("_randoop.pl_94747_1560209543", "s/Home/jre");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("J/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarb", (float) 6);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0f + "'", float2 == 6.0f);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("#########################ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-##########################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#########################ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-##########################" + "'", str1.equals("#########################ULib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-##########################"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 10, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        long[] longArray5 = new long[] { '4', 100, 32L, (short) -1, (short) -1 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" HotSpot(TM) 64-Bit Server", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                 Corporation24.80-B11Corporation ", "javahotspot(tm)64-bitserverv", 15);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "  ", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "AWT.MACOSX.l");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("oraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"oraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("10.14.3                            n24.80-B11Corporation", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              ", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "##############...", (java.lang.CharSequence) "1.          ...", 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str4 = javaVersion3.toString();
        java.lang.String str5 = javaVersion3.toString();
        java.lang.String str6 = javaVersion3.toString();
        boolean boolean7 = javaVersion1.atLeast(javaVersion3);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.4" + "'", str5.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "sun.lwawt.macosx.CP");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str2.equals("/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(" HotSpot(TM) 64-Bit Server");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444" + "'", str1.equals("444"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/users/sophie/documents/defects4j/tmp/run_randoop.pl_94747_1560209543");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 179, (float) 73, 70.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 70.0f + "'", float3 == 70.0f);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation", 74, "                                 erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation" + "'", str3.equals("oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("iUjk..8.jkUCttUHUj-##########################", "Sun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.mal_94747_15awt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkit", 94, 74);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "iUjk..8.jkUCttUHUj-##########################Sun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.mal_94747_15awt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkit" + "'", str4.equals("iUjk..8.jkUCttUHUj-##########################Sun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.mal_94747_15awt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkit"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                 1.4", 179, "SUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTHI!SUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTO");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTHI!SUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOSUN.LWAWT.MACOSX.LWCTOOLKIT                                                 1.4" + "'", str3.equals("SUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTHI!SUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOSUN.LWAWT.MACOSX.LWCTOOLKIT                                                 1.4"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "...######", (java.lang.CharSequence) "1#.#7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("A.LAVASS [LJANG.STRING;CLA.LAVASS [LJANG.STRING;CLA.LAVASS [LJAC", 2699);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           A.LAVASS [LJANG.STRING;CLA.LAVASS [LJANG.STRING;CLA.LAVASS [LJAC" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           A.LAVASS [LJANG.STRING;CLA.LAVASS [LJANG.STRING;CLA.LAVASS [LJAC"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("al Mac");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"al Mac\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "10.14.3                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("l_94747_156020954", 1248);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "l_94747_156020954" + "'", str2.equals("l_94747_156020954"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Users/sophieUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("cosx.LWCToawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.ma", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cosx.LWCToawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.ma" + "'", str3.equals("cosx.LWCToawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.ma"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 100, (byte) 100, (byte) 1, (byte) 0 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.Class<?> wildcardClass11 = strArray10.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray12 = new java.lang.reflect.GenericDeclaration[] { wildcardClass3, wildcardClass7, wildcardClass11 };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray12);
        java.lang.Class<?> wildcardClass14 = genericDeclarationArray12.getClass();
        java.lang.reflect.Type[] typeArray15 = new java.lang.reflect.Type[] { wildcardClass14 };
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.Class<?> wildcardClass19 = strArray18.getClass();
        java.lang.String[] strArray22 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.Class<?> wildcardClass23 = strArray22.getClass();
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.Class<?> wildcardClass27 = strArray26.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray28 = new java.lang.reflect.GenericDeclaration[] { wildcardClass19, wildcardClass23, wildcardClass27 };
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray28);
        java.lang.Class<?> wildcardClass30 = genericDeclarationArray28.getClass();
        java.lang.reflect.Type[] typeArray31 = new java.lang.reflect.Type[] { wildcardClass30 };
        java.lang.reflect.Type[][] typeArray32 = new java.lang.reflect.Type[][] { typeArray15, typeArray31 };
        java.lang.String str33 = org.apache.commons.lang3.StringUtils.join(typeArray32);
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.join(typeArray32);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(genericDeclarationArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str13.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(typeArray15);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(genericDeclarationArray28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str29.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(typeArray31);
        org.junit.Assert.assertNotNull(typeArray32);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 2699);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("10.14.3                            n24.80-B11Corporation ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3                            n24.80-B11Corporation" + "'", str1.equals("10.14.3                            n24.80-B11Corporation"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        java.lang.String[] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("######################java hotspot(tm) 64-bit server v###############################", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx..", 35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543", "                                    sun.lwawt.mac...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("x86_6");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("51b-08_0.7.1racle Corporationracle                                                                  ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "44444444444444444", (java.lang.CharSequence) "#################44444444444444444##################", 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "######################java hotspot(tm) 64-bit server v###############################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("            ng.String;a.lavraphi", "######################J#V#HOTSPOT(TM)#6-BIT#SERVER#V###############################");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("n", "/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                               en", 2699, 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("51b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7.151b-08_0.7./", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("x/Library/Java/JavaVirtualMachines/jdksun.lwawt.macosx.lwctoolkit.7.sun.lwawt.macosx.lwctoolkit_sun.lwawt.macosx.lwctoolkit.jdk/Contents/Home/jrd/Library/Java/JavaVirtualMachines/jdksun.lwawt.macosx.lwctoolkit.7.sun.lwawt.macosx.lwctoolkit_sun.lwawt.macosx.lwctoolkit.jdk/Contents/Home/jrd");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x/Library/Java/JavaVirtualMachines/jdksun.lwawt.macosx.lwctoolkit.7.sun.lwawt.macosx.lwctoolkit_sun.lwawt.macosx.lwctoolkit.jdk/Contents/Home/jrd/Library/Java/JavaVirtualMachines/jdksun.lwawt.macosx.lwctoolkit.7.sun.lwawt.macosx.lwctoolkit_sun.lwawt.macosx.lwctoolkit.jdk/Contents/Home/jrd\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java HotSpot(TM) 64-Bit Server", "8_0.7.1racls Corporatiouracls ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "un.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT", charArray5);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "_randoop.pl_94747_1560209543", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51B-08_0.", "Java(TM) SE Runtime Environment", (int) (byte) 100);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "va hotspot(tm) 64-bit server v", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("en", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", '#');
        boolean boolean18 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence[]) strArray17);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKIT", (java.lang.CharSequence[]) strArray17);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT", strArray12, strArray17);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("JavaHotSpot(TM)64-BitServerV", strArray6, strArray17);
        int int22 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "iUjk..8.jkUCttUHUj-##########################Sun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.mal_94747_15awt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkit", (java.lang.CharSequence[]) strArray17);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT" + "'", str20.equals("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "JavaHotSpot(TM)64-BitServerV" + "'", str21.equals("JavaHotSpot(TM)64-BitServerV"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str4 = javaVersion3.toString();
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str6 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.1" + "'", str4.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("jUHUttCUkj.8..kjUihFMFut-iVFTFJUFTFJUy-F-biLU", "racle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jUHUttCUkj.8..kjUihFMFut-iVFTFJUFTFJUy-F-biLU" + "'", str2.equals("jUHUttCUkj.8..kjUihFMFut-iVFTFJUFTFJUy-F-biLU"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        float[] floatArray2 = new float[] { (short) -1, 0 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("corporation24.80-B11Corporation", "va hotspot(tm) 64-bit server v", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.8", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      aaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        float[] floatArray4 = new float[] { (-1), 0L, (byte) 1, (byte) 10 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.Class<?> wildcardClass7 = floatArray4.getClass();
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Sun.lwawt.macosx.lwctoolkit                         aaaaaaaaaaaaaaa", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.lwawt.macosx.lwctoolkit                         aaaaaaaaaaaaaaa" + "'", str2.equals("Sun.lwawt.macosx.lwctoolkit                         aaaaaaaaaaaaaaa"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                        11B-08.42");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        float[] floatArray5 = new float[] { (byte) 0, (byte) 0, 100.0f, (short) 0, (byte) 1 };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("51B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7./", "noitaroproC elcarO");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String", (java.lang.CharSequence) "51b-08_0.7.1raclsCorporatiouracls");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 3, (int) (byte) 0);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.1", "51b-08_0.7.1", 32);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("Java(TM) SE 1.e Environmen", strArray3, strArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "1.                              ", "CLASS [LJAVA.LANG");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("SUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKISUN.LWAWT.MACOSX.LWCTOOLKI", "                                 erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                                                                                 ", "51b-08_0.7.1", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                 51b-08_0.7.1                                                                                                 51b-08_0.7.1                                                                                                 51b-08_0.7.1                                                                                                 51b-08_0.7.1                                                                                                 51b-08_0.7.1                                                                                                 51b-08_0.7.1                                                                                                 51b-08_0.7.1                                                                                                 51b-08_0.7.1                                                                                                 51b-08_0.7.1                                                                                                 " + "'", str3.equals("                                                                                                 51b-08_0.7.1                                                                                                 51b-08_0.7.1                                                                                                 51b-08_0.7.1                                                                                                 51b-08_0.7.1                                                                                                 51b-08_0.7.1                                                                                                 51b-08_0.7.1                                                                                                 51b-08_0.7.1                                                                                                 51b-08_0.7.1                                                                                                 51b-08_0.7.1                                                                                                 "));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("UN.LWAWT.MACOSX.LWCTOOLKI", (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "n Oracle", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 6.0f, 1.7d, (double) 30);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 30.0d + "'", double3 == 30.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Sun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.mal_94747_15awt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkitSun.lwawt.macosx.lwctoolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("mixed mode", "sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("");
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence[]) strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("m) 64-bit server v", strArray4, strArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "m) 64-bit server v" + "'", str9.equals("m) 64-bit server v"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "51b-08_0.7.1", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":", (java.lang.CharSequence[]) strArray10);
        java.lang.Class<?> wildcardClass12 = strArray10.getClass();
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("51b-08_0.7.1", strArray5, strArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94747_1560209543/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "51b-08_0.7.1" + "'", str13.equals("51b-08_0.7.1"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(strArray15);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("l_94747_156020954", 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaal_94747_156020954" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaal_94747_156020954"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("cosx.LWCToawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.masun.lw", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      aaaaaaaaaa", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("O", "erj/emoH/stnetnoC/kdj.tiklootcwl.xsocam.twawl.nus_tiklootcwl.xsocam.twawl.nus.7.tiklootcwl.xsocam.twawl.nuskdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1#.#7                      ", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/users/sophie/documents/defects4j/tmp/run_randoop.pl_94747_156020954", (int) '#', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10.14.", 74);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "i");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("######################jv hotspot(tm) 64-bit server v##############################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "######################jv hotspot(tm) 64-bit server v##############################" + "'", str1.equals("######################jv hotspot(tm) 64-bit server v##############################"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "   -jUHUttCUkj.8..kjUihFMFut-iVFTFJUFTFJUy-F-biLU    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "...j4stcefed/stnemucod/eihpos/sresu", (java.lang.CharSequence) "[Ljacl [Ljang.Str");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAA" + "'", str1.equals("AAAAAAAAAA"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "oracle corpo...", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("en");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "444", (java.lang.CharSequence) "51b-08_0.7.1racle Corporationracle                                                                  ", 74);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                            UTF-8", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 30, (long) 53, (long) 9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ", "raphi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    "));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("...ava/JavaVirtualMachines/jdksun.lwawt.macosJava Platform API Specific...", "ng.String;a.lavass [Ljang.String;cla.lavass [Ljang.String;cla.lavass [Ljacl", "1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.                              1.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "      /J   V   u  M .h 1e / dk u1  w w  m .o J    P   fo m API  pe. f .   " + "'", str3.equals("      /J   V   u  M .h 1e / dk u1  w w  m .o J    P   fo m API  pe. f .   "));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("_94747_156020954  ", "Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "_94747_156020954  " + "'", str2.equals("_94747_156020954  "));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("usiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nus", "x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "usiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nus" + "'", str2.equals("usiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nus"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("...######", "_94747_156020954  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...######" + "'", str2.equals("...######"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        double[] doubleArray2 = new double[] { (-1L), '4' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 52.0d + "'", double5 == 52.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 52.0d + "'", double6 == 52.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "######################java hotspot(tm) 64-bit server v###############################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdksun.lwawt.macosx.lwctoolkit.7.sun.lwawt.macosx.lwctoolkit_sun.lwawt.macosx.lwctoolkit.jdk/Contents/Home/jr", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6", "erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbilenenenenenenenenenenenenenenenenen");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "n", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', (int) (short) 1, (int) (byte) 0);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "#################################################################");
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.8", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER V", 70);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 0, (byte) -1 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ome/jre", (java.lang.CharSequence) "[Ljacl [Ljang.String;cla.lavass [Ljang.String;cla.lavass ng.String;a.lavass");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) ":", (java.lang.CharSequence[]) strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "            ng.String;a.lavass [Ljang.String;cla.lavass [Ljang.String;cla.lavass [Ljacl             ");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiLenenenenenenenenenenenenenenenenen", (java.lang.CharSequence[]) strArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6N1.6", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", "Mac OS X");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit", strArray5, strArray13);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str14.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4444444444", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444" + "'", str3.equals("4444444444"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("su...", 66, "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444451.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "su...4444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("su...4444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("racle Corporation", (int) (short) 0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "su...", (java.lang.CharSequence) " noitaroproC11B-08.42noitaroproC                                                                 44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1#.#7", "i44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#.#7" + "'", str2.equals("1#.#7"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("usiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nus", (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "51b-08_0.7.1raclsCorporatiouracls51b-08_0.7.1racl1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophieUS", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "otcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("en");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE", "10.14.3", (int) (byte) 10);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) ":", (java.lang.CharSequence[]) strArray11);
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray11);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.lwawt.macosx.CPrinterJob", strArray7, strArray11);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10.14.3                            n24.80-B11Corporation ", strArray2, strArray7);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str14.equals("sun.lwawt.macosx.CPrinterJob"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10.14.3                            n24.80-B11Corporation " + "'", str15.equals("10.14.3                            n24.80-B11Corporation "));
        org.junit.Assert.assertNotNull(strArray16);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("uLib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "uLib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-" + "'", str1.equals("uLib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, ":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("M_R OS X", "ot(TM) 64-Bit Server ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M_R OS X" + "'", str2.equals("M_R OS X"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("i44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "8_0.7.1racls Corporatiouracls ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("usiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nusiklootcwl.xsocam.twawl.nus", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("JJJJJJ86_6JJJJJJ", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JJJJJJ86_6JJJJJJ" + "'", str2.equals("JJJJJJ86_6JJJJJJ"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("A.LAVASS [LJANG.STRING;CLA.LAVASS [LJANG.STRING;CLA.LAVASS [LJAC", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("            ng.String;a.lavass [Ljang.String;cla.lavass [Ljang.String;cla.lavass [Ljacl             ", "                                                 n                                                  ");
        java.lang.String[] strArray6 = null;
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80-b15", "1.7");
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "uLib-F-yUJFTFUJFTFVi-tuFMFhiUjk..8.jkUCttUHUj-", (java.lang.CharSequence[]) strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", strArray6, strArray10);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        boolean boolean18 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray17);
        int int19 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "51b-08_0.7.1", (java.lang.CharSequence[]) strArray17);
        java.lang.String[] strArray22 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        int int23 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":", (java.lang.CharSequence[]) strArray22);
        java.lang.Class<?> wildcardClass24 = strArray22.getClass();
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("51b-08_0.7.1", strArray17, strArray22);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray10, strArray22);
        try {
            java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", strArray3, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str12.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "51b-08_0.7.1" + "'", str25.equals("51b-08_0.7.1"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("x.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCTo", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", "51b-08_0.7.1racls Corporatiouracls ", 30);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "x.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCTo" + "'", str4.equals("x.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCTo"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("l_94747_15", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                           l_94747_15                                            " + "'", str2.equals("                                           l_94747_15                                            "));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("noitaroproC elcarO", 1761L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1761L + "'", long2 == 1761L);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.6", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            1.6            " + "'", str2.equals("            1.6            "));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Cdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/orporationdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Odesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/racle", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("su...", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "su..." + "'", str2.equals("su..."));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                 erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                 erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcMlutriVvJ/vJ/yrrbiL" + "'", str2.equals("                                 erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcMlutriVvJ/vJ/yrrbiL"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("################################java hotspot(tm) 64-bit server v################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "sun.lwawt.macosx.lwctoolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "[lJACL [lJANG.sTR");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                    ", 2699);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("444", 2699);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444" + "'", str2.equals("444"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("SOPHIE/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", "ng.String;a.lavass [Ljang.String;cla.lavass [Ljang.String;cla.lavass [Ljacl", (int) (byte) -1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 10, (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94747_1560209543/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SOPHIE/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str9.equals("SOPHIE/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.14.3                            n24.80-B11Corporation ", "################################java hotspot(tm) 64-bit server v################################4", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("va hotspot(tm) 64-bit server v", "10.14.3                            n24.80-B11Corporation ", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolkisun.lwawt.macosx.lwctoolk", "####################################################", 15);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "10.14.3                            1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "jUHUttCUkj.8..kjUihFMFut-iVFTFJUFTFJUy-F-biLU", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("280-B11                                                          ", 1245);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "280-B11                                                          " + "'", str2.equals("280-B11                                                          "));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(1248, (int) (byte) -1, 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1248 + "'", int3 == 1248);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("su...", "java hotspot(tm) 64-bit server v");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "su..." + "'", str2.equals("su..."));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) ".macosx.lwctoolki");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Java(TM) SE 1.e Environmen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE 1.e Environmen" + "'", str1.equals("Java(TM) SE 1.e Environmen"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#################################1#################################", ' ');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "Java HotSpot(TM) 64-Bit Server /Lib");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCThi!sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT", "##################################JavaHotSpot(TM)64-BitServerV###################################", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (java.lang.CharSequence) "      /J   V   u  M .h 1e / dk u1  w w  m .o J    P   fo m API  pe. f .   ", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", "####################################################", 67);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "24.80-B11");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray4, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str8.equals("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("##################################################################", "                                 erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcMlutriVvJ/vJ/yrrbiL", "racle Corporation", 27);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "##################################################################" + "'", str4.equals("##################################################################"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Corporation Oracle", (java.lang.CharSequence) "                                                                                        11b-08.42");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "sun.lwawt.macosx.lwctoolki", "1.5");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("##################################JavaHotSpot(TM)64-BitServerV###################################", "al Mac");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }
}

