import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = null;
        try {
            boolean boolean3 = javaVersion0.atLeast(javaVersion2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1a0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("0 0 -1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "10a011a011a010a011a0110a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 0 -1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("0 0 -1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) " 4#4#4 4 ", (java.lang.CharSequence) "                                                                                                    ", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.0#1.0", (java.lang.CharSequence) "0404-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Oracle#Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "4444444444444444444444444MIXED MODE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) 1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        java.lang.Class<?> wildcardClass5 = javaVersion2.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean7 = javaVersion2.atLeast(javaVersion6);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("   ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "51.7");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("100a0a-1a100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("4444444444444444444444...", " 4#4#4 4 ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sophie", "1.0a100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                      140", (java.lang.CharSequence) "100a0a-1a100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                                                 ", 0, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                         ..." + "'", str3.equals("                         ..."));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun#.#lwawt#.#macosx#.#LWCT#oolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun#.#lwawt#.#macosx#.#LWCT#oolki" + "'", str1.equals("sun#.#lwawt#.#macosx#.#LWCT#oolki"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "1a0                            ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1a0                            ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0404-1" + "'", str7.equals("0404-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "raj.tnerruc-poodnar/noit" + "'", str2.equals("raj.tnerruc-poodnar/noit"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 0, (int) (short) 100, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Mixedmode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100 0 -1 100", (java.lang.CharSequence) "sun#.#lwawt#.#macosx#.#LWCT#oolkit", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aaa#a#a4a", "1.0 1.0 32.0 25.0", "                      140");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.Byte byte0 = org.apache.commons.lang3.math.NumberUtils.BYTE_ZERO;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0.equals((byte) 0));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        long[] longArray1 = new long[] { (byte) 0 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("US");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"US\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        char[] charArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Oracle#Corporation", (int) (byte) 100, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1L, (-1.0d), (double) 9);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4a", charSequence1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Mixed mode");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((-1), 140, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 140 + "'", int3 == 140);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun#.#lwawt#.#macosx#.#lwct#oolkit", 100, "/Java Virtual Machine SpecificationUsersJava Virtual Machine Specification/Java Virtual Machine SpecificationsophieJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationNetworkJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationSystemJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationusrJava Virtual Machine Specification/Java Virtual Machine SpecificationlibJava Virtual Machine Specification/Java Virtual Machine SpecificationjavaJava Virtual Machine Specification:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun#.#lwawt#.#macosx#.#lwct#oolkit/Java Virtual Machine SpecificationUsersJava Virtual Machine Speci" + "'", str3.equals("sun#.#lwawt#.#macosx#.#lwct#oolkit/Java Virtual Machine SpecificationUsersJava Virtual Machine Speci"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0404-1", (java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                 \n                                                  ", (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        char[] charArray7 = new char[] { 'a', '#', '#', '4', ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mixed mode", charArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sophie#", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aa#a#a4a " + "'", str10.equals("aa#a#a4a "));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java HotSpot(TM) 64-Bit Server VM", "100 0 -1 10", "1a0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Oracle#Corporation", "", "1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.", (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Oracle#Corporation" + "'", str4.equals("Oracle#Corporation"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/", 0, 140);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "sun#.#lwawt#.#macosx#.#LWCT#oolki", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                                                    ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444444444444444...", (java.lang.CharSequence) "1.0 1.0 32.0 25.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("mixed mode", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("0a0a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0A0A-1" + "'", str1.equals("0A0A-1"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "", 100, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java(TM) SE Runtime Environment", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Environment Runtime SE Java(TM)" + "'", str2.equals("Environment Runtime SE Java(TM)"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("7", "100 0 -1 100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("100.0a1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0a1.0" + "'", str1.equals("100.0a1.0"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun#.#lwawt#sun#.#lwawt#", "##########", "aa#a#a4a ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun#.#lwawt#sun#.#lwawt#" + "'", str3.equals("sun#.#lwawt#sun#.#lwawt#"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Mixedmode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.7", "Java Platform API Specification");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444404041", "http://java.oracle.com/", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun.awt...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.." + "'", str1.equals("sun.awt.."));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("444444 4#44", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444 4#44" + "'", str2.equals("444444 4#44"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("hi!", "100 0 -1 10");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/", 140);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/                                                                                                                                           " + "'", str2.equals("/                                                                                                                                           "));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Oracle#Corporation", "1.0a100.0", "J#v# Pl#tform API Specific#tion", 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Oracle#Corporation" + "'", str4.equals("Oracle#Corporation"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01." + "'", str2.equals("1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01."));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1404044444L, 0.0d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0a0a1", 6, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a0a1#" + "'", str3.equals("0a0a1#"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("100 0 -1 100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 0 -1 100" + "'", str1.equals("100 0 -1 100"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double[] doubleArray4 = new double[] { 1, 1.0d, ' ', 25 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 32.0d + "'", double5 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.041.0432.0425.0" + "'", str7.equals("1.041.0432.0425.0"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("          ", "sun.awt..", "sun.awt..");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.1", "Mixedmode");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("http://java.oracle.com/", 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("http://java.oracle.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("4444444444", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444" + "'", str2.equals("4444444444"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "0 0 1", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip(":", "0a0a1#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "4444404041");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                         ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("SUN#.#LWAWT#.#MACOSX#.#LWCT#OOLKIT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN#.#LWAWT#.#MACOSX#.#LWCT#OOLKI" + "'", str1.equals("SUN#.#LWAWT#.#MACOSX#.#LWCT#OOLKI"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1#0", (int) (byte) 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sophie", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("J#v# Pl#tform API Specific#tion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "j#v# pl#tform api specific#tion" + "'", str1.equals("j#v# pl#tform api specific#tion"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("100 0 -1 10", "s#.#w1w#.#m1sx#.#LWCT#k");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                 \n                                                  ", "10a011a011a010a011a0110a0", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                 \n                                                  " + "'", str3.equals("                                                 \n                                                  "));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("   ", (int) (byte) 0, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   " + "'", str3.equals("   "));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("a#####4# ", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a#####4# " + "'", str2.equals("a#####4# "));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                                                                    ", "r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "en", 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("J#v# Pl#tform API Specific#tion", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J#v# Pl#tform API Specific#tion" + "'", str2.equals("J#v# Pl#tform API Specific#tion"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#" + "'", str1.equals("#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Oracle Corporation", "1.04100.0", 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0 0 -1", (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597", (java.lang.CharSequence[]) strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "51.0" + "'", str5.equals("51.0"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        double[] doubleArray4 = new double[] { 1, 1.0d, ' ', 25 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', 13, 0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 32.0d + "'", double5 == 32.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "0a0a1#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("0 0 1", "4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 0 1" + "'", str2.equals("0 0 1"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("##########", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########" + "'", str2.equals("##########"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "enenenenenenenenenenenenenenenenenenenenenenenenene7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4..." + "'", str2.equals("/var/folders/_v/6v597zmn4..."));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(" ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "4444444444444444444444...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.71.81.11.7", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Mixedmode", (int) ' ', 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aaa#a#a4a", (java.lang.CharSequence) "4444404041");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("04041", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Mixedmode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44" + "'", str3.equals("44"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "stcefed/stnemucoD/eihpos/sresU/4r_nur/pmt/j4#4 4225_lp.poodn4t/7959720651_14#4 4lc/tegr4#4 4stcefed/stnemucoD/eihpos/sresU/:sess4rf/j4#4 4reneg_tset/bil/krowem4#4 4reneg/noit4#4 4r/noit4#4 4j.tnerruc-poodn4#4 4r" + "'", str2.equals("stcefed/stnemucoD/eihpos/sresU/4r_nur/pmt/j4#4 4225_lp.poodn4t/7959720651_14#4 4lc/tegr4#4 4stcefed/stnemucoD/eihpos/sresU/:sess4rf/j4#4 4reneg_tset/bil/krowem4#4 4reneg/noit4#4 4r/noit4#4 4j.tnerruc-poodn4#4 4r"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("b");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Environment Runtime SE Java(TM)");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Environment Runtime SE Java(TM)" + "'", str1.equals("Environment Runtime SE Java(TM)"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7" + "'", str2.equals("rruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "140", (java.lang.CharSequence) "/                                                                                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 9, 140);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.5");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5d + "'", double1 == 1.5d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#", "1.0 1.0 32.0 25.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0A0A-1", (java.lang.CharSequence) "SUN#.#LWAWT#.#MACOSX#.#LWCT#OOLKIT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "0404-1", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 10, 0L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        int[] intArray2 = new int[] { (short) 1, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', (int) ' ', (int) (byte) -1);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', (int) (short) -1, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "140" + "'", str4.equals("140"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("a#####4# ", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597", (-1), "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597" + "'", str3.equals("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "J#v# Pl#tform API Specific#tion", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4", (java.lang.CharSequence) "#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("##########", "SUN#.#LWAWT#.#MACOSX#.#LWCT#OOLKIT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.7", "1#0", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "J#v# Pl#tform API Specific#tion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "rruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mixed mode");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "4444444444444444444444444MIXED MODE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("4444444444444444444444444mixed mode", "04041", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("51.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.7" + "'", str1.equals("51.7"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.0 1.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("0a0a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1-a0a0" + "'", str1.equals("1-a0a0"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", (int) (byte) 10, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "sun#.#lwawt#sun#.#lwawt#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4a4a4a a#a4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("sun.awt.CGraphicsEnvironment########################################################################", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment########################################################################" + "'", str2.equals("sun.awt.CGraphicsEnvironment########################################################################"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("4444404041s#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.7", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7" + "'", str2.equals("7"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("sun#.#lwawt#.#macosx#.#LWCT#oolki", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun#.#l" + "'", str2.equals("sun#.#l"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", 1, 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "r4..." + "'", str3.equals("r4..."));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "1.71.81.11.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "4a4a4a a#a4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun#.#lwawt#sun#.#lwawt#", 0, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4", "sun.lwawt.macosx.LWCToolkit1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) -1, (float) 6, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 6.0f + "'", float3 == 6.0f);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "sun#.#lwawt#sun#.#lwawt#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("4a4a4a a#a4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4a4a4a a#a4" + "'", str1.equals("4a4a4a a#a4"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.6" + "'", str3.equals("1.6"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", (java.lang.CharSequence) "J#v# Pl#tform API Specific#tion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun#.#lwawt#.#macosx#.#lwct#oolkit", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("4", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sun.lwawt.macosx.LWCToolkit1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("sun.awt.CGraphicsEnvironment########################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment########################################################################" + "'", str1.equals("sun.awt.CGraphicsEnvironment########################################################################"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "44", (int) 'a', 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.041.0432.0425.0", "          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun#.#lwawt#.#macosx#.#lwct#oolkit/Java Virtual Machine SpecificationUsersJava Virtual Machine Speci", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "100 0 -1 10", (java.lang.CharSequence) "Mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.0 1.0 1.0 0.0 1.0 10.0", (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4a", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun#.#lwawt#sun#.#lwawt#", (java.lang.CharSequence) "4a4a4a a#a4", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        char[] charArray7 = new char[] { ' ', ' ', 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597", charArray7);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', 24, 5);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun#.#lwawt#.#macosx#.#LWCT#oolkit", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "                      140");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("4444404041");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444440404" + "'", str1.equals("444440404"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.2", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        float[] floatArray6 = new float[] { 10L, (byte) 1, 1L, (byte) 0, 1L, 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4', (int) (short) -1, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 10.0f + "'", float8 == 10.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "10.041.041.040.041.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1 0", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("100#0#-1#100", "4444444444", ":", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100#0#-1#100" + "'", str4.equals("100#0#-1#100"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Java Virt...", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1 0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("4444444444444444444444444MIXED MODE", 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "r4...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "r4...", (java.lang.CharSequence) "4444444444444444444444...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "hi!");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: hi!");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0 0 -1" + "'", str7.equals("0 0 -1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("sun.awt.CGraphicsEnvironment########################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT########################################################################" + "'", str1.equals("SUN.AWT.cgRAPHICSeNVIRONMENT########################################################################"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun#.#l", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "sun.awt.CGraphicsEnvironment########################################################################");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "1404044444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', 100, 32);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0404-1" + "'", str7.equals("0404-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0a0a-1" + "'", str10.equals("0a0a-1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 0 + "'", byte15 == (byte) 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        long[] longArray3 = new long[] { 0, (byte) 0, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#0#1" + "'", str6.equals("0#0#1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 0 1" + "'", str8.equals("0 0 1"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(24, 0, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        char[] charArray7 = new char[] { ' ', ' ', 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Platform API Specification", charArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " # #a" + "'", str13.equals(" # #a"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "b", "10a011a011a010a011a0110a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Java Virtual Machine SpecificationUsersJava Virtual Machine Specification/Java Virtual Machine SpecificationsophieJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationNetworkJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationSystemJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationusrJava Virtual Machine Specification/Java Virtual Machine SpecificationlibJava Virtual Machine Specification/Java Virtual Machine SpecificationjavaJava Virtual Machine Specification:.", "sun.lwawt.macosx.LWCToolkit1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Java Virtual Machine SpecificationUsersJava Virtual Machine Specification/Java Virtual Machine SpecificationsophieJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationNetworkJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationSystemJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationusrJava Virtual Machine Specification/Java Virtual Machine SpecificationlibJava Virtual Machine Specification/Java Virtual Machine SpecificationjavaJava Virtual Machine Specification:." + "'", str2.equals("/Java Virtual Machine SpecificationUsersJava Virtual Machine Specification/Java Virtual Machine SpecificationsophieJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationNetworkJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationSystemJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationusrJava Virtual Machine Specification/Java Virtual Machine SpecificationlibJava Virtual Machine Specification/Java Virtual Machine SpecificationjavaJava Virtual Machine Specification:."));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("sun#.#lwawt#.#macosx#.#LWCT#oolki", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                                                 \n                                                  ", (java.lang.CharSequence) "sun#.#lwawt#.#macosx#.#lwct#oolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("", "0a0a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a0a1" + "'", str2.equals("0a0a1"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1404044444", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 10, (double) ' ', (double) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0.0A1.0A1.0A0.0A1.0A10.0", 6, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0A1.0A1.0A0.0A1.0A10.0" + "'", str3.equals("0.0A1.0A1.0A0.0A1.0A10.0"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("7.1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("7.1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("140                            ", "", "##########");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "140                            " + "'", str3.equals("140                            "));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1L), (double) 5L, (double) 31);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.0a100.0", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a100.0" + "'", str2.equals("1.0a100.0"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Mac OS X", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                                 ", (java.lang.CharSequence) "sun#.#lwawt#.#macosx#.#lwct#oolkit", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.71.81.11.7", (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("51.051.051.051.051./Java Virt...", "/", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.051.051.051.051.                                                                                                    Java Virt..." + "'", str3.equals("51.051.051.051.051.                                                                                                    Java Virt..."));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("10.0 1.0 1.0 0.0 1.0 10.0", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0 1.0 1.0 0.0 1.0 10.0" + "'", str2.equals("10.0 1.0 1.0 0.0 1.0 10.0"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("0 0 1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01." + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01."));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b1" + "'", str1.equals("1.7.0_80-b1"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "r4...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit1.7", "Mixedmode");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 10, 32L, (long) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "51.051.051.051.051.                                                                                                    Java Virt...", (java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0 0 1", "b");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("0#0#1", "####a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#0#1" + "'", str2.equals("0#0#1"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.awt...", (int) (byte) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt..." + "'", str3.equals("sun.awt..."));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java(TM) SE Runtime Environment", "          ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("sun#.#lwawt#.#macosx#.#lwct#oolkit", "51.0", "44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun#.#lwawt#.#macosx#.#lwct#oolkit" + "'", str4.equals("sun#.#lwawt#.#macosx#.#lwct#oolkit"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("0 0 -1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 0 -1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("0 0 -1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/", (java.lang.CharSequence) "51.051.051.051.051./Java Virt...");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/" + "'", charSequence2.equals("/"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '4', (int) 'a', (int) (short) 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '4', (int) 'a', (int) (byte) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "444440404");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0404-1" + "'", str7.equals("0404-1"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("51.051.051.051.051.                                                                                                    Java Virt...", "51.051.051.051.051./Java Virt...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.0a100.0", "sun.lwawt.macosx.LWCToolkit", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0a100.0" + "'", str3.equals("1.0a100.0"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " 4#4#4 4 ", (java.lang.CharSequence) "\n", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("10a011a011a010a011a0110a0", "UTF-8", "1.8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a011a011a010a011a0110a0" + "'", str3.equals("10a011a011a010a011a0110a0"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("sun.awt.CGraphicsEnvironment########################################################################ent########################################################################", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444444444444444444MIXED MODE", (java.lang.CharSequence) "r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("140                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "140" + "'", str1.equals("140"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        float[] floatArray6 = new float[] { 10L, (byte) 1, 1L, (byte) 0, 1L, 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', (int) (byte) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0a1.0a1.0a0.0a1.0a10.0" + "'", str9.equals("10.0a1.0a1.0a0.0a1.0a10.0"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444mixed mode", " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("####aa#a#a4a ", "http://java.oracle.com/", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                                 ", 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "sun#.#lwawt#sun#.#lwawt#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("s#.#w1w#.#m1sx#.#LWCT#k", ":", (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "s#.#w1w#.#m1sx#.#LWCT#k" + "'", str3.equals("s#.#w1w#.#m1sx#.#LWCT#k"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10a011a011a010a011a0110a", "####a", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.awt..", (java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("4444444444444444444444444mixed mode");
        java.lang.String[] strArray3 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                      140", strArray2, strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                      140" + "'", str4.equals("                      140"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("100a0a-1a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("444444444444444444444444444444451.0", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/                                                                                                                                           ", (int) (byte) -1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "a#####4# ", (java.lang.CharSequence) "                      140", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("10.041.041.040.041.0410.0", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.041.041.040.041.0410.0" + "'", str2.equals("10.041.041.040.041.0410.0"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) ' ', "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        char[] charArray3 = new char[] { ' ', '#', 'a' };
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray3, '4', 6, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("mixed mode", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 0, 10.0d, (double) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) -1, 0.0f, (float) 28);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 28.0f + "'", float3 == 28.0f);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        float[] floatArray6 = new float[] { 10L, (byte) 1, 1L, (byte) 0, 1L, 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 10.0f + "'", float8 == 10.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.041.041.040.041.0410.0" + "'", str10.equals("10.041.041.040.041.0410.0"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ', 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0404-1" + "'", str7.equals("0404-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0404-1" + "'", str11.equals("0404-1"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("aa#a#a4a ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa#a#a4a " + "'", str1.equals("aa#a#a4a "));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                         ...", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) " ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1a0                            ", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "Java Platform API Specification", "0 0 -1", 28);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "100.0a1.0", (java.lang.CharSequence) " ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "http://java.oracle.com/", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.0a100.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "140");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("4444444444444444444444444mixed mode", "SUN.AWT.cgRAPHICSeNVIRONMENT########################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444mixed mode" + "'", str2.equals("4444444444444444444444444mixed mode"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        long[] longArray1 = new long[] { (byte) 0 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', (int) (short) 10, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "10a011a011a010a011a0110a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("mixed mode", "4444444444444444444444444MIXED MODE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80", 6, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10a011a011a010a011a0110a0", (int) (short) 100, "4444404041");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444040414444404041444440404144444040414444404041444440404144444040414444410a011a011a010a011a0110a0" + "'", str3.equals("44444040414444404041444440404144444040414444404041444440404144444040414444410a011a011a010a011a0110a0"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        long[] longArray3 = new long[] { 0, (byte) 0, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) 'a', 32);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray3, '#', 28, 0);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-14141004041", (java.lang.CharSequence) "##########", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0A0A-1", "4444444444444444444444...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java(TM) SE Runtime Environment", "sun#.#lwawt#.#macosx#.#LWCT#oolki", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("4444444444444444444444...", "100a0a-1a100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444..." + "'", str2.equals("4444444444444444444444..."));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 28.0f, (double) 25, (double) 1404044444L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.404044444E9d + "'", double3 == 1.404044444E9d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "140", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                 \n                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun#.#lwawt#.#macosx#.#LWCT#oolkit", "1.7.0_80-b15", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 5, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0404-1" + "'", str7.equals("0404-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7", strArray2, strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7" + "'", str5.equals("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("10.0 1.0 1.0 0.0 1.0 10.0");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 32, 24);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "100 0 -1 100", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 11 + "'", int7 == 11);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sophie", "aaa#a#a4a ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Java Virt...", "4444444444444444444444444mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Java Virt..." + "'", str2.equals("/Java Virt..."));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ', (int) (short) 10, 10);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Java(TM) SE Runtime Environment");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("sun.awt.CGraphicsEnvironment########################################################################", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "awt.CGraphicsEnvironment########################################################################" + "'", str2.equals("awt.CGraphicsEnvironment########################################################################"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("0 0 -1");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("-1#1#100#0#1", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1#1#100#0" + "'", str2.equals("-1#1#100#0"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace(":", "aaa#a#a4a", "10a011a011a010a011a0110a", 11);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":" + "'", str4.equals(":"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray10 = new char[] { '4', '4', '4', ' ', '#', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray10, '4');
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "b", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray10);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ');
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "444444 4#44" + "'", str14.equals("444444 4#44"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "4 4 4   # 4" + "'", str18.equals("4 4 4   # 4"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "SUN#.#LWAWT#.#MACOSX#.#LWCT#OOLKI", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_5221_1560279597", 0, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 10.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("SUN#.#LWAWT#.#MACOSX#.#LWCT#OOLKI", "sun.awt.CGraphicsEnvironment", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("##########", "aaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 32, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "j/tmp/run_" + "'", str3.equals("j/tmp/run_"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("-14141004041", "raj.tnerruc-poodnar/noit", "1a0", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-14141004041" + "'", str4.equals("-14141004041"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        char[] charArray7 = new char[] { 'a', '#', '#', '4', ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mixed mode", charArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aa#a#a4a " + "'", str10.equals("aa#a#a4a "));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("4 4 4   # 4", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0a0a1", (java.lang.CharSequence) "4 4 4   # 4", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(9, 28, 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("7", (double) 25L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.0d + "'", double2 == 7.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("04041J#v# Pl#tform API Sp", 5, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "04041J#v# Pl#tform API Sp" + "'", str3.equals("04041J#v# Pl#tform API Sp"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "4444444444", (java.lang.CharSequence) "4444404041s#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("http://java.oracle.com/", "0.0A1.0A1.0A0.0A1.0A10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "0a0a-1", (java.lang.CharSequence) "1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("100 0 -1 10", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10" + "'", str2.equals("100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("51.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"51.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "7.1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.substringsBetween("", "hi!", "hi!");
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.io.Serializable[]) strArray5);
        java.lang.CharSequence charSequence9 = null;
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int12 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence9, (java.lang.CharSequence[]) strArray11);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment########################################################################", (java.lang.CharSequence[]) strArray11);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("0.0a1.0a1.0a0.0a1.0a10.0", strArray5, strArray11);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray16, "mixed mode");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0.0a1.0a1.0a0.0a1.0a10.0" + "'", str15.equals("0.0a1.0a1.0a0.0a1.0a10.0"));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun#.#lwawt#.#macosx#.#LWCT#oolkit", "enenenenenenenenenenenenenenenenenenenenenenenenene7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU" + "'", str1.equals("r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Mac OS X", 7.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.0d + "'", double2 == 7.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1-a0a0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("51.051.051.051.051.                                                                                                    Java Virt...", 0, "4444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.051.051.051.051.                                                                                                    Java Virt..." + "'", str3.equals("51.051.051.051.051.                                                                                                    Java Virt..."));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("####aa#a#a4a ", (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.0 1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.0 1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(":", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("0.0a1.0a1.0a0.0a1.0a10.0", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "0 0 -1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("44", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44" + "'", str2.equals("44"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("enenenenenenenenenenenenenenenenenenenenenenenenene7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "enenenenenenenenenenenenenenenenenenenenenenenenene7" + "'", str1.equals("enenenenenenenenenenenenenenenenenenenenenenenenene7"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.041.041.040.041.0410.0", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.041.041.040.041.0410.0" + "'", str3.equals("10.041.041.040.041.0410.0"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "####a", charSequence1, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_5221_1560279597");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "j#v# pl#tform api specific#tion", 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/                                                                                                                                           ", (java.lang.CharSequence) "44");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("sun#.#lwawt#.#macosx#.#LWCT#oolki", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolki" + "'", str2.equals("sun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolki"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", 25, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str3.equals("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.5", charSequence1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.0a1.0a1.0a0.0a1.0a10.0", (java.lang.CharSequence) "aaa#a#a4a ", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("aa#a#a4a ", "SUN#.#LWAWT#.#MACOSX#.#LWCT#OOLKI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "b", (java.lang.CharSequence) "-14-1452404100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10a011a011a010a011a0110a0", (java.lang.CharSequence) "sun#.#lwawt#sun#.#lwawt#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        double[] doubleArray2 = new double[] { (byte) 1, 1 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (short) 10, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0#1.0" + "'", str5.equals("1.0#1.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0#1.0" + "'", str7.equals("1.0#1.0"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "1.0 1.0 32.0 25.0", (java.lang.CharSequence) "sun#.#lwawt#.#macosx#.#lwct#oolkit");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1.0 1.0 32.0 25.0" + "'", charSequence2.equals("1.0 1.0 32.0 25.0"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-B1" + "'", str1.equals("1.7.0_80-B1"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '4', (int) (short) 10, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "10a011a011a010a011a0110a0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/var/folders/_v/6v597zmn4...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4..." + "'", str1.equals("/var/folders/_v/6v597zmn4..."));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "10a011a011a010a011a0110a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/7959720651_14225_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/1.7" + "'", str1.equals("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/7959720651_14225_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/1.7"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        int[] intArray2 = new int[] { (short) 1, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', (int) (short) 100, (int) (byte) 10);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "140" + "'", str4.equals("140"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7", (java.lang.CharSequence) "44444040414444404041444440404144444040414444404041444440404144444040414444410a011a011a010a011a0110a0", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(5L, (long) '#', 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Mixedmode", "100a0a-1a100", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mixedmode" + "'", str3.equals("Mixedmode"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.awt.CGraphicsEnvironment", 140, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                sun.awt.CGraphicsEnvironment" + "'", str3.equals("                                                                                                                sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Java Virtual Machine Specification", "enenenenenenenenenenenenenenenenenenenenenenenenene7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("0a0a-1", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a0a-1" + "'", str2.equals("0a0a-1"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "100#0#-1#100", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10a011a011a010a011a0110a", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/var/folders/_v/6v597zmn4...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.1", (int) (short) 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) " 4#4#4 4 ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("enenenenenenenenenenenenenenenenenenenenenenenenene7");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sophie#", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie#" + "'", str2.equals("sophie#"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (byte) 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sophie#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie#" + "'", str1.equals("sophie#"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", "sun#.#lwawt#.#macosx#.#lwct#oolkit/Java Virtual Machine SpecificationUsersJava Virtual Machine Speci");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "0a0a-1", (int) (byte) 10, 1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.", "sun.awt..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01." + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01."));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "140                            ", (java.lang.CharSequence) "Mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("http://java.oracle.com/", "100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("4", "100.0a1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0a1.0" + "'", str2.equals("100.0a1.0"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("0#0#1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#0#1" + "'", str1.equals("0#0#1"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("s#.#w1w#.#m1sx#.#LWCT#k", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s#.#w1w#.#m1sx#.#LWCT#k" + "'", str2.equals("s#.#w1w#.#m1sx#.#LWCT#k"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "0.0A1.0A1.0A0.0A1.0A10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt...", "J#v# Pl#tform API Specific#tion");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("http://java.oracle.com/", "##########");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment########################################################################ent########################################################################", (java.lang.CharSequence) "/                                                                                                                                           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.0a100.0", "/var/folders/_v/6v597zmn4...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a100.0" + "'", str2.equals("1.0a100.0"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("51.7");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "-14141004041", (java.lang.CharSequence) "/Java Virtual Machine SpecificationUsersJava Virtual Machine Specification/Java Virtual Machine SpecificationsophieJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationNetworkJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationSystemJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationusrJava Virtual Machine Specification/Java Virtual Machine SpecificationlibJava Virtual Machine Specification/Java Virtual Machine SpecificationjavaJava Virtual Machine Specification:.", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("j#v# pl#tform api specific#tion", "a#####4# ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a#####4# " + "'", str2.equals("a#####4# "));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("en", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4444404041", (int) '#', "####a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####a####a##4444404041####a####a###" + "'", str3.equals("####a####a##4444404041####a####a###"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaa#a#a4a", (java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0A100.0" + "'", str1.equals("1.0A100.0"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "j#v# pl#tform api specific#tion", (java.lang.CharSequence) "444444444444444444444444444444451.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/7959720651_14225_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/1.7", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BI..." + "'", str2.equals("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BI..."));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        char[] charArray9 = new char[] { 'a', '#', '#', '4', ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mixed mode", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "   ", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.041.041.040.041.0410.0", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (byte) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        int[] intArray2 = new int[] { (short) 1, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', (int) (short) 100, (int) (byte) 10);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "140" + "'", str4.equals("140"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1#0" + "'", str11.equals("1#0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1a0" + "'", str13.equals("1a0"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sun#.#lwawt#sun#.#lwawt#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun#.#lwawt#sun#.#lwawt#" + "'", str1.equals("sun#.#lwawt#sun#.#lwawt#"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("sophie", "SUN#.#LWAWT#.#MACOSX#.#LWCT#OOLKIT", "sun#.#lwawt#.#macosx#.#lwct#oolkit/Java Virtual Machine SpecificationUsersJava Virtual Machine Speci");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("sun.awt.CGraphicsEnvironment########################################################################", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment########################################################################" + "'", str2.equals("sun.awt.CGraphicsEnvironment########################################################################"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("100 0 -1 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sun.awt.CGraphicsEnvironment########################################################################ent########################################################################", "0a0a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment########################################################################ent########################################################################" + "'", str2.equals("sun.awt.CGraphicsEnvironment########################################################################ent########################################################################"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        boolean boolean5 = javaVersion1.atLeast(javaVersion3);
        boolean boolean6 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str7 = javaVersion3.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.2" + "'", str7.equals("1.2"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(25L, (long) 9, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.5");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaa#a#a4a ", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "444444444444444444444444444444451.0", (java.lang.CharSequence) "1-a0a0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Oracle#Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle#Corporation" + "'", str1.equals("Oracle#Corporation"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1.0#1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0#1.0" + "'", str1.equals("1.0#1.0"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.0#1.0", "4444444444444444444444...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444..." + "'", str2.equals("4444444444444444444444..."));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597" + "'", str2.equals("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun#.#l", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4a", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Mixed mode", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mixed mode" + "'", str2.equals("Mixed mode"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10.0 1.0 1.0 0.0 1.0 10.0", "51.051.051.051.051./Java Virt...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", 'a');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("0a0a-1", 'a');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "/Java Virtual Machine SpecificationUsersJava Virtual Machine Specification/Java Virtual Machine SpecificationsophieJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationNetworkJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationSystemJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationusrJava Virtual Machine Specification/Java Virtual Machine SpecificationlibJava Virtual Machine Specification/Java Virtual Machine SpecificationjavaJava Virtual Machine Specification:.");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "100 0 -1 100", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment########################################################################ent########################################################################", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("sun.awt.CGraphicsEnvironment########################################################################", "4444404041");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment########################################################################" + "'", str2.equals("sun.awt.CGraphicsEnvironment########################################################################"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "1-a0a0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("####a", "0#0#1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####a" + "'", str2.equals("####a"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "1.7.0_80-B1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "100a0a-1a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment########################################################################ent########################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "stcefed/stnemucoD/eihpos/sresU/4r_nur/pmt/j4#4 4225_lp.poodn4t/7959720651_14#4 4lc/tegr4#4 4stcefed/stnemucoD/eihpos/sresU/:sess4rf/j4#4 4reneg_tset/bil/krowem4#4 4reneg/noit4#4 4r/noit4#4 4j.tnerruc-poodn4#4 4r", (java.lang.CharSequence) "r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) (short) 0, (long) 7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sophie", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0a0a-1", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a0a-1" + "'", str3.equals("0a0a-1"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "1-a0a0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "0#0#1", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#", "100.0a1.0");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "100a0a-1a100", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        double[] doubleArray2 = new double[] { (byte) 1, 1 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0#1.0" + "'", str5.equals("1.0#1.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0 1.0" + "'", str8.equals("1.0 1.0"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "1.6", 24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/var/folders/_v/6v597zmn4...", (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "1.0 1.0 32.0 25.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("s#.#w1w#.#m1sx#.#LWCT#k", "4444444444444444444444...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s#.#w1w#.#m1sx#.#LWCT#k" + "'", str2.equals("s#.#w1w#.#m1sx#.#LWCT#k"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "444444 4#44");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1a0                            ", (int) (byte) 0, 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/                                                                                                                                           ", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.1", "awt.CGraphicsEnvironment########################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4444404041", "10.041.041.040.041.0410.0", "10a011a011a010a011a0110a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1111101011" + "'", str3.equals("1111101011"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Java Virtual Machine Specification");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "7");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "j#v# pl#tform api specific#tion", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Java Virtual Machine SpecificationUsersJava Virtual Machine Specification/Java Virtual Machine SpecificationsophieJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationNetworkJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationSystemJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationusrJava Virtual Machine Specification/Java Virtual Machine SpecificationlibJava Virtual Machine Specification/Java Virtual Machine SpecificationjavaJava Virtual Machine Specification:." + "'", str6.equals("/Java Virtual Machine SpecificationUsersJava Virtual Machine Specification/Java Virtual Machine SpecificationsophieJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationNetworkJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationSystemJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationusrJava Virtual Machine Specification/Java Virtual Machine SpecificationlibJava Virtual Machine Specification/Java Virtual Machine SpecificationjavaJava Virtual Machine Specification:."));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "/Java Virt...", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1111101011", "####a####a##4444404041####a####a###");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("444444 4#44");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }
}

