import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " 5  ", charSequence1, 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "b                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("100404-14100", "sun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolki");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100404-14100" + "'", str2.equals("100404-14100"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.8", "j/tmp/run");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "1.8", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("A1.0A1.0A0.0A1.0A10.0#########################################################################raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/A1.0A1.0A0.0A1.0A10.0#########################################################################raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/A1.0A1.0A0.0A1.0A10.0#########################################################################raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/A1.0A1.0A0.0A1.0A10.0#########################################################################raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/A1.0A1.0A0.0A1.0A10.0#########################################################################", "4-", "#/.u/.u#/.u/.u#/.u//u./4.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "A1.0A1.0A0.0A1.0A10.0#########################################################################raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/A1.0A1.0A0.0A1.0A10.0#########################################################################raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/A1.0A1.0A0.0A1.0A10.0#########################################################################raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/A1.0A1.0A0.0A1.0A10.0#########################################################################raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/A1.0A1.0A0.0A1.0A10.0#########################################################################" + "'", str3.equals("A1.0A1.0A0.0A1.0A10.0#########################################################################raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/A1.0A1.0A0.0A1.0A10.0#########################################################################raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/A1.0A1.0A0.0A1.0A10.0#########################################################################raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/A1.0A1.0A0.0A1.0A10.0#########################################################################raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/A1.0A1.0A0.0A1.0A10.0#########################################################################"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100a0a-1a100" + "'", str8.equals("100a0a-1a100"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.", " 5  ", 2, 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01." + "'", str4.equals("aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01."));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("100a0a-1a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a0a-1a100" + "'", str1.equals("100a0a-1a100"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "us");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("444444 4#44", 67);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                            444444 4#44                            " + "'", str2.equals("                            444444 4#44                            "));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolki", "sophie#  ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolki" + "'", str2.equals("sun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolki"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "fc0000gn/T/a/v                                              4_v31cq2n2x1n4                                             r/folders/_v/6v597zmn", (java.lang.CharSequence) "fc0000gn/T/a/v                                              4_v31cq2n2x1n4                                             r/folders/_v/6v597zmn");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "aaa#a#a4a", (java.lang.CharSequence) "4444404041s#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "", (int) (byte) 0);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "a#####4# ", (java.lang.CharSequence[]) strArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "1a0                            ", 24, 10);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1#1#100#0", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("        ...", "TIKLOOtcwl.XSOCAM.TWAWL.NUS", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("51.051.051.051.051./jAVA vIRT...");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "0SUN.AWT.cgRAPHICSeNVIRONMENT0SUN.AWT.cgRAPHICSeNVIRONMENT-1", (java.lang.CharSequence) "j#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tion");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "0SUN.AWT.cgRAPHICSeNVIRONMENT0SUN.AWT.cgRAPHICSeNVIRONMENT-1" + "'", charSequence2.equals("0SUN.AWT.cgRAPHICSeNVIRONMENT0SUN.AWT.cgRAPHICSeNVIRONMENT-1"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Mixedmode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXEDMODE" + "'", str1.equals("MIXEDMODE"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        float[] floatArray6 = new float[] { 10L, (byte) 1, 1L, (byte) 0, 1L, 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#');
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0a1.0a1.0a0.0a1.0a10.0" + "'", str9.equals("10.0a1.0a1.0a0.0a1.0a10.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 10.0f + "'", float10 == 10.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0#1.0#1.0#0.0#1.0#10.0" + "'", str12.equals("10.0#1.0#1.0#0.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 10.0f + "'", float13 == 10.0f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("aaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("Aaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("us", "edom dexim4444444444444444444444444", "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.0a1.0a1.0a0.0a1.0a10.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "us" + "'", str3.equals("us"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophie#", ' ');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) " 4#4#4 4 ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "stcefed/stnema#####4# c-poodn4#4 4r");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444451.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.", (java.lang.CharSequence) "                         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Oracle Corporation", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 31, (long) 1, 25L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 31L + "'", long3 == 31L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Eihpos/sresU/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "0 0 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("##########", (int) 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        char[] charArray10 = new char[] { 'a', '#', '#', '4', ' ' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mixed mode", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "s#.#w1w#.#m1sx#.#LWCT#k", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaa", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.041.0432.0425.0aaaaaaaaaaaaaa", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.0a1.0a32.0a100.0", (java.lang.CharSequence) "10.041.041.040.041.0410.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        float[] floatArray6 = new float[] { 10L, (byte) 1, 1L, (byte) 0, 1L, 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0a1.0a1.0a0.0a1.0a10.0" + "'", str9.equals("10.0a1.0a1.0a0.0a1.0a10.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0a1.0a1.0a0.0a1.0a10.0" + "'", str11.equals("10.0a1.0a1.0a0.0a1.0a10.0"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 25, (long) 10, (long) 131);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sun.awt...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...twa.nus" + "'", str1.equals("...twa.nus"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "100.0a1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("51.051.051.051.051.                                                                                                    Java Virt...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.051.051.051.051.                                                                                                    Java Virt..." + "'", str1.equals("51.051.051.051.051.                                                                                                    Java Virt..."));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("SUN#.#LWAWT#.#MACOSX#.#LWCT#OOLKIT/JAVA VIRTUAL MACHINE SPECIFICATIONUSERSJAVA VIRTUAL MACHINE SPECI", "a##### #", "44", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "SUN#.#LWAWT#.#MACOSX#.#LWCT#OOLKIT/JAVA VIRTUAL MACHINE SPECIFICATIONUSERSJAVA VIRTUAL MACHINE SPECI" + "'", str4.equals("SUN#.#LWAWT#.#MACOSX#.#LWCT#OOLKIT/JAVA VIRTUAL MACHINE SPECIFICATIONUSERSJAVA VIRTUAL MACHINE SPECI"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Java Virtual Machine SpecificationUsersJava Virtual Machine Speci", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Java Virtual Machine SpecificationUsersJava Virtual Machine Speci" + "'", str3.equals("/Java Virtual Machine SpecificationUsersJava Virtual Machine Speci"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("B");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"B\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean6 = javaVersion2.atLeast(javaVersion5);
        java.lang.String str7 = javaVersion2.toString();
        java.lang.String str8 = javaVersion2.toString();
        java.lang.String str9 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.2" + "'", str7.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.2" + "'", str8.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.2" + "'", str9.equals("1.2"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ', (int) (short) 10, 10);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0a0a-1" + "'", str12.equals("0a0a-1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0#0#-1" + "'", str14.equals("0#0#-1"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("51.0");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) -1, "aaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("j#v# pl#tform api specific#tion", 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("#.#lwct#oo", (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.0a1.0a1.0a0.0a1.0a10.0", ' ');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0a1.0a1.0a0.0a1.0a10.0" + "'", str3.equals("0.0a1.0a1.0a0.0a1.0a10.0"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#", "444444444444444444444444444444451.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUTF-8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUTF-8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUTF-8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUTF-8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "0.0A1.0A1.0A0.0A1.0A10.0########################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sun#.#lwawt#.#macosx#.#LWCT#oolkit", "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.0a1.0a1.0a0.0a1.0a10.0", 140, 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun#.#lwawt#.#macosx#.#LWCT#oolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.0a1.0a1.0a0.0a1.0a10.0" + "'", str4.equals("sun#.#lwawt#.#macosx#.#LWCT#oolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.0a1.0a1.0a0.0a1.0a10.0"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1", 10, "1.8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1" + "'", str3.equals("0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1                         0.52 0.23 0.1 0.1"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("SUN.AWT.CGRAPHICSENVIRONMENT", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str2.equals("SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("4-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.lwawt.macosx.LWCToolkit1.7");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("-14141004041###############################################################", 35.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.7.0_80-B1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("x86_64", "0a0a1a1", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "4444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        char[] charArray5 = new char[] { ' ', ' ', 'a' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', (int) ' ', (int) (short) 10);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".31.0#1.01.0#1.01.0#", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.041.0432.04100.0", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.01.032.0100.0" + "'", str2.equals("1.01.032.0100.0"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.01.032.0100.0", (java.lang.CharSequence) "Java Platform API Specification", 60);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwc");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split(" a#a#a a ", "1.7.0_80-b15", (int) (byte) 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray2, strArray7);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "J#V# PL#TFORM API SPECIFIC#TION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "#/.u/.u#/.u/.u#/.u//u./4.3/.u#/.u/.u#/.u/.u#", (java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) ' ', (double) 11, (double) 7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "444440404/Users/sophie/Documents/de", 49);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull(".31.0#1.01.0#1.01.0#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".31.0#1.01.0#1.01.0#" + "'", str1.equals(".31.0#1.01.0#1.01.0#"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', 100, 32);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', (int) (short) 10, 0);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0404-1" + "'", str7.equals("0404-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0a0a-1" + "'", str10.equals("0a0a-1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0404-1" + "'", str20.equals("0404-1"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Aaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("Aaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        double[] doubleArray4 = new double[] { 1.0d, (short) 1, ' ', 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0#1.0#32.0#100.0" + "'", str9.equals("1.0#1.0#32.0#100.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "0#0#-1", (java.lang.CharSequence) "1.0a1.0a32.0a100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java Virtual Machine Specification", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ication" + "'", str2.equals("ication"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "-1a1a100a0a1", (java.lang.CharSequence) "10.0#1.0#1.0#0.0#1.0#10.", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597", (java.lang.CharSequence) "####a####a##4444404041####a####a###", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment########################################################################ent########################################################################", "-1a1a100a0a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("sophie#                            ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
        boolean boolean7 = javaVersion3.atLeast(javaVersion5);
        boolean boolean8 = javaVersion2.atLeast(javaVersion5);
        boolean boolean9 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str10 = javaVersion0.toString();
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.1" + "'", str10.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "4444444444444444444444444mixed mode", "                      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0#0#-1", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4#4#4 4 ", (java.lang.CharSequence) "6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "0a0a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                            444444 4#44                            ", (java.lang.CharSequence) " 4 4#4#4 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt...", "sun.lwawt.macosx.LWCToolkit1.7", 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "s#.#w1w#.#m1sx#.#LWCT#k", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Environment Runtime SE Java(TM)");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 34, (float) (short) 10, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0, (double) 6.0f, (double) 7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        char[] charArray10 = new char[] { ' ', '#', '#', ' ', ' ' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444444444444444444MIXED MODE", charArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray10, '4');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_80", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4", charArray10);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.0a1.0a32.0a100.0", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " 4#4#4 4 " + "'", str13.equals(" 4#4#4 4 "));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("4#4#4# ###4", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("#/.u/.u#/.u/.u#/.u//u./4.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sunawtCGraphicsEnvironment", "       sun.awt..        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sunawtCGraphicsEnvironment" + "'", str2.equals("sunawtCGraphicsEnvironment"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        double[] doubleArray4 = new double[] { 1.0d, (short) 1, ' ', 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', (int) (short) 100, (int) ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', (int) (byte) 1, 1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.", 4.4444042E9f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.4444042E9f + "'", float2 == 4.4444042E9f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        long[] longArray3 = new long[] { 0, (byte) 0, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "04041" + "'", str6.equals("04041"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a0a1" + "'", str8.equals("0a0a1"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        double[] doubleArray4 = new double[] { 1.0d, (short) 1, ' ', 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.041.0432.04100.0" + "'", str7.equals("1.041.0432.04100.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0#1.0#32.0#100.0" + "'", str9.equals("1.0#1.0#32.0#100.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.0 1.0 32.0 100.0" + "'", str11.equals("1.0 1.0 32.0 100.0"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        float[] floatArray6 = new float[] { 10L, (byte) 1, 1L, (byte) 0, 1L, 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0 1.0 1.0 0.0 1.0 10.0" + "'", str9.equals("10.0 1.0 1.0 0.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0a1.0a1.0a0.0a1.0a10.0" + "'", str11.equals("10.0a1.0a1.0a0.0a1.0a10.0"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("4 4 4   # 4", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.0a1.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10", "1.8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                                                                 ", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/uSERS/SOPHIE/dOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_5221_1560279597");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) ".041.0432.04100.0", (java.lang.CharSequence) "awt.CGraphicsEnvironment########################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("4444444444444444444444...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("04041");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "04041" + "'", str1.equals("04041"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwc", "sun.awt.CGraphicsEnvironment########################################################################ent########################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        long[] longArray3 = new long[] { 0, (byte) 0, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) 'a', 32);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0 0 1" + "'", str11.equals("0 0 1"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0a0a1" + "'", str14.equals("0a0a1"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "####aa#a#a4a#", (java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_5221_1560279597");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("sun.awt...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "dk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("dk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray10 = new char[] { '4', '4', '4', ' ', '#', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "    ", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "#-14-14#-14-14#-14--41-413-14#-14-14#-14-14#", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str1.equals("SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(34, 131, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 131 + "'", int3 == 131);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("http://java.oracle.com/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"http:\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "a##### # ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("###");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(".31.0#1.01.0#1.01.0#");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.5", (int) (byte) 100, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachi" + "'", str3.equals("1.5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachi"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(51.7f, 4.44440416E8f, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 51.7f + "'", float3 == 51.7f);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray12 = new char[] { '4', '4', '4', ' ', '#', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "    ", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.041.0432.0425.0", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4 4 4   # 4", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/run_");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/run_" + "'", str1.equals("/run_"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "0#0#1", (java.lang.CharSequence) "444444 4#44");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "4444444444444444444444444MIXED MODE", (java.lang.CharSequence) "10.0#1.0#1.0#0.0#1.0#10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "4 4 4   # 4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "j/tmp/run_", (java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("#/.u/.u#/.u/.u#/.u//u./4.3/.u#/.u/.u#/.u/.u#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#/.u/.u#/.u/.u#/.u//u./4.3/.u#/.u/.u#/.u/.u#" + "'", str1.equals("#/.u/.u#/.u/.u#/.u//u./4.3/.u#/.u/.u#/.u/.u#"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Java Virt...", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Java Virt..." + "'", str2.equals("/Java Virt..."));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        java.lang.Class<?> wildcardClass5 = javaVersion2.getClass();
        char[] charArray14 = new char[] { ' ', ' ', 'a' };
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray14);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray14);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597", charArray14);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Platform API Specification", charArray14);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100 0 -1 100", charArray14);
        java.lang.Class<?> wildcardClass20 = charArray14.getClass();
        java.lang.CharSequence charSequence22 = null;
        char[] charArray30 = new char[] { '4', '4', '4', ' ', '#', '4' };
        boolean boolean31 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray30);
        int int32 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence22, charArray30);
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.join(charArray30, '4');
        boolean boolean35 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.0a100.0", charArray30);
        java.lang.String str37 = org.apache.commons.lang3.StringUtils.join(charArray30, ' ');
        java.lang.Class<?> wildcardClass38 = charArray30.getClass();
        java.lang.String[] strArray41 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ' ');
        java.lang.Class<?> wildcardClass42 = strArray41.getClass();
        java.lang.String[] strArray46 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.CPrinterJob", "Oracle Corporation", (int) (short) -1);
        java.lang.Class<?> wildcardClass47 = strArray46.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray48 = new java.lang.reflect.GenericDeclaration[] { wildcardClass5, wildcardClass20, wildcardClass38, wildcardClass42, wildcardClass47 };
        java.lang.String str49 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray48);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "444444 4#44" + "'", str34.equals("444444 4#44"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "4 4 4   # 4" + "'", str37.equals("4 4 4   # 4"));
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(genericDeclarationArray48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass [Cclass [Cclass [Ljava.lang.String;class [Ljava.lang.String;" + "'", str49.equals("class org.apache.commons.lang3.JavaVersionclass [Cclass [Cclass [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern(" 4#4#4 4 ", "J#v# Pl#tform API Specific#tion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 4#4#4 4 " + "'", str2.equals(" 4#4#4 4 "));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15 1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("4444444444444444444444444mixed mode");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 100, 67L, 52L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        double[] doubleArray4 = new double[] { 1.0d, (short) 1, ' ', 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#', 1, (int) (byte) -1);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1#0", "####a", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1/0" + "'", str3.equals("1/0"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "4444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444" + "'", str2.equals("4444444444444444444444444"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8" + "'", str3.equals("1.8"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("24.80-b1", 67, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 0, (double) 4.4444042E9f, (double) 4.4444446E32f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.444444591917127E32d + "'", double3 == 4.444444591917127E32d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) ":4...", (java.lang.CharSequence) "ophie#", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("edom dexim4444444444444444444444444", "0a0a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "edom dexim4444444444444444444444444" + "'", str2.equals("edom dexim4444444444444444444444444"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "1.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01./Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("-14-14#-14-14#-14--41-413-14#-14-14#-14-14#");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.", (java.lang.CharSequence) "enenenenenenenenenenenenenenenenenenenenenenenenene7", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BI...", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        float[] floatArray0 = new float[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a', (int) '4', 7);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray0, ' ');
        try {
            float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_80");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 97, 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 7, (int) (short) 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.split("1.7.0_80");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("1404044444", strArray2, strArray16);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.7.0_80" + "'", str8.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.7.0_80" + "'", str14.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1404044444" + "'", str17.equals("1404044444"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(":4...", "/Java Virtual Machine SpecificationUsersJava Virtual Machine Specification/Java Virtual Machine SpecificationsophieJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationNetworkJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationSystemJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationusrJava Virtual Machine Specification/Java Virtual Machine SpecificationlibJava Virtual Machine Specification/Java Virtual Machine SpecificationjavaJava Virtual Machine Specification:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":4..." + "'", str2.equals(":4..."));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\n\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.", "b     ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        char[] charArray11 = new char[] { 'a', '#', '#', '4', ' ' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mixed mode", charArray11);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray11, 'a');
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0a1.0a1.0a0.0a1.0a10.0", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0 1.0 1.0 0.0 1.0 10.0", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "444440404/Users/sophie/Documents/de", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "CGraphicsEnvironment########################################################################", charArray11);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "a#####4# ", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "aa#a#a4a " + "'", str14.equals("aa#a#a4a "));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun#.#lwawt#.#macosx#.#LWCT#oolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.0a1.0a1.0a0.0a1.0a10.0", "Java HotSpot(TM) 64-Bit Server VM", "51.051.051.051.051./jAVA vIRT...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun#.#lw1w0#.#m1c.sx#.#LWC1#..lkA01.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.011.011.010.011.0110.0" + "'", str3.equals("sun#.#lw1w0#.#m1c.sx#.#LWC1#..lkA01.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.011.011.010.011.0110.0"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        java.lang.String str4 = javaVersion1.toString();
        boolean boolean5 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        boolean boolean10 = javaVersion6.atLeast(javaVersion8);
        java.lang.Class<?> wildcardClass11 = javaVersion8.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean15 = javaVersion13.atLeast(javaVersion14);
        boolean boolean16 = javaVersion12.atLeast(javaVersion14);
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean18 = javaVersion14.atLeast(javaVersion17);
        boolean boolean19 = javaVersion8.atLeast(javaVersion17);
        boolean boolean20 = javaVersion0.atLeast(javaVersion8);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.5" + "'", str4.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "444444444444444444444444444444451.0", (java.lang.CharSequence) "ophie#", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "J#V# PL#TFORM API SPECIFIC#TION", (java.lang.CharSequence) "stcefed/stnema#####4# c-poodn4#4 4r");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("04041J#v# Pl#tform API Sp", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a0a1J#v# Pl#tform API Sp" + "'", str3.equals("0a0a1J#v# Pl#tform API Sp"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10a011a011a010a011a0110a", "                                                 \n                                                  ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "sun#.#l##########################################################################################");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10a011a011a010a011a0110a" + "'", str4.equals("10a011a011a010a011a0110a"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#.#w1w#.#m1sx#.#LWCT#k", (int) (byte) 100, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle Co\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("100404-14100", "0#0#1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#0#1" + "'", str2.equals("0#0#1"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("SUN.LWAWT.MACOSX.LWCTOOLKIT", 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        char[] charArray8 = new char[] { ' ', ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51.7", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specification", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        char[] charArray8 = new char[] { ' ', ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Platform API Specification", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100 0 -1 100", charArray8);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "    a" + "'", str15.equals("    a"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        double[] doubleArray2 = new double[] { (byte) 1, 1 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', 32, 32);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0#1.0" + "'", str6.equals("1.0#1.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "SUN#.#L");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "ophie#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "mAC os x", (int) '4', 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
        boolean boolean7 = javaVersion3.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean9 = javaVersion5.atLeast(javaVersion8);
        boolean boolean10 = javaVersion0.atLeast(javaVersion8);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/JaSTCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/7959720651_1a225_LP.POODNAR_NUR/PMT/JaSTCEFED/STNEMUCOD/EIHPOS/SRESU/1.7", "SUN#.#LWAWT#.#MACOSX#.#LWCT#OOLKI", 133);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(32L, 28L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ', (int) (short) 10, 10);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0 0 -1" + "'", str12.equals("0 0 -1"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("10.01.01.00.01.010.0", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 2, (double) (short) 100, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5" + "'", str1.equals("5"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0a0a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#", 33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#1.0110.14.31.0#1.01.0#1.01.0#" + "'", str2.equals("1.0#1.0110.14.31.0#1.01.0#1.01.0#"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                                                                                 ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ', (int) (short) 10, 10);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "s#.#w1w#.#m1sx#.#LWCT#k");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: s#.#w1w#.#m1sx#.#LWCT#k");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                      140          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                      140          " + "'", str1.equals("                      140          "));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        int[] intArray2 = new int[] { (short) 1, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "140" + "'", str4.equals("140"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1a0" + "'", str8.equals("1a0"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.71.81.11.7", (java.lang.CharSequence) "J#v# Pl#tform API Specific#tion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("0 0 1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" 0 1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str4 = javaVersion0.toString();
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.5" + "'", str4.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("EDOM DEXIM4444444444444444444444444", "1.7.0_80-B1", "a#####4# ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("####a####a##4444404041####a####a###", (int) (short) -1, 75);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####a####a##4444404041####a####a###" + "'", str3.equals("####a####a##4444404041####a####a###"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("us");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "#/.u/.u#/.u/.u#/.u//u./4.3/.u#/.u/.u#/.u/.u#", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 44 + "'", int3 == 44);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "phicsEnvironmentawt.CGra                                                                                                                sun.", (java.lang.CharSequence) "Mixedmode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 137 + "'", int2 == 137);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01./Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(" # #a", 100, 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " # #a" + "'", str3.equals(" # #a"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "4444444444444444444444444MIXED MODE", (java.lang.CharSequence) "r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "4444444444444444444444444MIXED MODE" + "'", charSequence2.equals("4444444444444444444444444MIXED MODE"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        long[] longArray3 = new long[] { 0, (byte) 0, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) 'a', 32);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "-14-14#-14-14#-14--41-413-14#-14-14#-14-14#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4a", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4a" + "'", str2.equals("aaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4a"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        long[] longArray3 = new long[] { 0, (byte) 0, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ', 10, (int) (byte) -1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 0, (int) (short) -1);
        long long16 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#0#1" + "'", str6.equals("0#0#1"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        boolean boolean5 = javaVersion1.atLeast(javaVersion3);
        boolean boolean6 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
        boolean boolean12 = javaVersion7.atLeast(javaVersion10);
        boolean boolean13 = javaVersion3.atLeast(javaVersion10);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        int[] intArray5 = new int[] { (short) 1, '#', (byte) 1, (byte) -1, 7 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ', (int) (short) 0, (int) (byte) -1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ', 140, 7);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                                                                                 ", (java.lang.CharSequence) "04041J#v# Pl#tform API S");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1#1#100#0#1");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1#1#100#0#1" + "'", str3.equals("-1#1#100#0#1"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        java.lang.Class<?> wildcardClass5 = javaVersion2.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        boolean boolean10 = javaVersion6.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean12 = javaVersion8.atLeast(javaVersion11);
        boolean boolean13 = javaVersion2.atLeast(javaVersion11);
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str15 = javaVersion14.toString();
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean20 = javaVersion18.atLeast(javaVersion19);
        boolean boolean21 = javaVersion17.atLeast(javaVersion19);
        boolean boolean22 = javaVersion16.atLeast(javaVersion19);
        boolean boolean23 = javaVersion14.atLeast(javaVersion16);
        boolean boolean24 = javaVersion11.atLeast(javaVersion14);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.1" + "'", str15.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        char[] charArray7 = new char[] { ' ', '#', '#', ' ', ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444444444444444444MIXED MODE", charArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "x86_64", charArray7);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', 426, 0);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " a#a#a a " + "'", str10.equals(" a#a#a a "));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" 4#4#4 4 ", "4444444444444444444444444444444444444444444444448-FTU44444444444444444444444444444444444444444444444");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "");
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence[]) strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "Mixedmode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 172 + "'", int2 == 172);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EIHPOS/SRESu/" + "'", str1.equals("EIHPOS/SRESu/"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("#########################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "########################" + "'", str1.equals("########################"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        int[] intArray2 = new int[] { (short) 1, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "140" + "'", str4.equals("140"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a0" + "'", str7.equals("1a0"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("0.001a0.23a0.1a0.1", 133);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                   0.001a0.23a0.1a0.1" + "'", str2.equals("                                                                                                                   0.001a0.23a0.1a0.1"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                                                                                                                                                                                                                                                                                          ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "100 0 -1 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1.2f, (double) 67, 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.2000000476837158d + "'", double3 == 1.2000000476837158d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 49, 4444404041L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "-1#1#100#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("\n\n\n\n\n\n\n\n\n\n\n\n\n", "", "444444444444444444444444444444451.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0" + "'", str3.equals("444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0\n444444444444444444444444444444451.0"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("b     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "b     " + "'", str1.equals("b     "));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("a#a#a a", "4444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("SUN.AWT.CGRAPHICSENVIRONMENT", "raj.tne...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "raj.tne..." + "'", str2.equals("raj.tne..."));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ', 10, (int) (short) 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 426, 0);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0#0#-1" + "'", str10.equals("0#0#-1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 0 + "'", byte15 == (byte) 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "100#0#-1#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("0404-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0404-1" + "'", str1.equals("0404-1"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/4Users4/4sophie4/4Library4/4Java4/4Extensions4:/4Library4/4Java4/4Extensions4:/4Network4/4Library4/4Java4/4Extensions4:/4System4/4Library4/4Java4/4Extensions4:/4usr4/4lib4/4java4:", (java.lang.CharSequence) "0a0a1#", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "51.7", (java.lang.CharSequence) "awt.CGraphicsEnvironment########################################################################", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        double[] doubleArray4 = new double[] { 1.0d, (short) 1, ' ', 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', (int) (short) 100, (int) ' ');
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', 137, (int) '#');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1a0                            ", "a0                            ", "sophie#  ...");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', 426, 137);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a0a-1a100" + "'", str9.equals("100a0a-1a100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun#.#lwawt#.#macosx#.#LWCT#oolki", "ophie#", 137);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("J#v# pl#tform api specific#tionts4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ":4...", "0a0a1J#v# Pl#tform API Sp");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT########################################################################", (java.lang.CharSequence) "4444404041", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", "0.0A1.0A1.0A0.0A1.0A10.0#########################################################################");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(".71.81.11.7", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".71.81.11.7" + "'", str2.equals(".71.81.11.7"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "0#0#-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("J#V# PL#TFORM API SPECIFIC#TION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J#V# PL#TFORM API SPECIFIC#TION" + "'", str1.equals("J#V# PL#TFORM API SPECIFIC#TION"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1a0", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4a" + "'", str1.equals("aaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4a"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("    ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3, (double) 1.40404442E9f, (double) 0L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        char[] charArray5 = new char[] { ' ', ' ', 'a' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ', (int) (short) -1, (int) (short) -1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', (int) (byte) 100, 31);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1404044444", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("0 0 ", "", "############################################################################################################################################");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        short short14 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a0a-1a100" + "'", str9.equals("100a0a-1a100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100 0 -1 100" + "'", str11.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a0a-1a100" + "'", str13.equals("100a0a-1a100"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 100 + "'", short14 == (short) 100);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("0404-1");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.2", "aaaaaaaaaaaaaaaaaaaaaaa:");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("########################", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/                                                                                                                                           ", "1.041.0432.0425.0aaaaaaaaaaaaaa", "24.80-b1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/                                                                                                                                           " + "'", str3.equals("/                                                                                                                                           "));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "####aa#a#a4a#", (java.lang.CharSequence) "1.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 13, (long) 133, 25L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 13L + "'", long3 == 13L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("0.0a1.0a1.0a0.0a1.0a10.0", (int) '4', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "6", "                            444444 4#44                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", "4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE", 8, 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/library4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODEdk1.7.0_80.jdk/contents/home/jre/lib/endorsed" + "'", str4.equals("/library4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODEdk1.7.0_80.jdk/contents/home/jre/lib/endorsed"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                  \n                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                                   /", (java.lang.CharSequence) "aaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        long[] longArray3 = new long[] { 0, (byte) 0, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ', 10, (int) (byte) -1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ', (int) '#', 0);
        long long16 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#0#1" + "'", str6.equals("0#0#1"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        long[] longArray3 = new long[] { 0, (byte) 0, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "04041" + "'", str7.equals("04041"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0#0#1" + "'", str11.equals("0#0#1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0a0a1" + "'", str13.equals("0a0a1"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.010.01.01.00.01.010.0", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(52, (int) (short) 100, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80-b15", 0, "444440404/Users/sophie/Documents/de");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "ophie#", (java.lang.CharSequence) "            0a0a-1             ", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, " a# # ");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("ndoop.pl_52241_1560279597a/Users/sophie/Documents/defects4j/tmp/run_r", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ndoop.pl_52241_1560279597a/Users/sophie/Documents/defects4j/tmp/run_r" + "'", str2.equals("ndoop.pl_52241_1560279597a/Users/sophie/Documents/defects4j/tmp/run_r"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mAC os x", "sun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolk", 133);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 131);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "SUN#.#LWAW...", (java.lang.CharSequence) " 4 4#4#4 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "444444 4#44");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str4.equals("r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "r#j.tnerruc-poodn#r/noit#reneg/noit#reneg_tset/bil/krowem#rf/j4stcefed/stnemucoD/eihpos/sresU/:sess#lc/tegr#t/7959720651_14225_lp.poodn#r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str6.equals("r#j.tnerruc-poodn#r/noit#reneg/noit#reneg_tset/bil/krowem#rf/j4stcefed/stnemucoD/eihpos/sresU/:sess#lc/tegr#t/7959720651_14225_lp.poodn#r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("sun#.#l##########################################################################################");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-1 100 32", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ndoop.pl_52241_1560279597a/Users/sophie/Documents/defects4j/tmp/run_r", (int) '#', 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("raj.tnerruc-poodnar/noit", "aaaaaaaaaaa4 4 4   # 4aaaaaaaaaaaa", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("US", "1.0A100.0", 92);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Users/sophie/Documents/defects4j/tmp/run_r44#4 444444ndoop.pl_52241_1560279597/t44#4 444444rget/cl44#4 444444sses:/Users/sophie/Documents/defects4j/fr44#4 444444mework/lib/test_gener44#4 444444tion/gener44#4 444444tion/r44#4 444444ndoop-current.j44#4 444444r" + "'", str1.equals("Users/sophie/Documents/defects4j/tmp/run_r44#4 444444ndoop.pl_52241_1560279597/t44#4 444444rget/cl44#4 444444sses:/Users/sophie/Documents/defects4j/fr44#4 444444mework/lib/test_gener44#4 444444tion/gener44#4 444444tion/r44#4 444444ndoop-current.j44#4 444444r"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.04100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1a0", (java.lang.CharSequence) "sun.awt...", 92);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        float[] floatArray1 = new float[] { '#' };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 35.0f + "'", float4 == 35.0f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        long[] longArray3 = new long[] { 0, (byte) 0, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a0a1" + "'", str8.equals("0a0a1"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "4444444444444444444444...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 25 + "'", int1 == 25);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("stcefed/stnemucoD/eihpos/sresU/4r_nur/pmt/j4#4 4225_lp.poodn4t/7959720651_14#4 4lc/tegr4#4 4stcefed/stnemucoD/eihpos/sresU/:sess4rf/j4#4 4reneg_tset/bil/krowem4#4 4reneg/noit4#4 4r/noit4#4 4j.tnerruc-poodn4#4 4r", 8, "JavaPlatfrAPISpcfcatn");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "stcefed/stnemucoD/eihpos/sresU/4r_nur/pmt/j4#4 4225_lp.poodn4t/7959720651_14#4 4lc/tegr4#4 4stcefed/stnemucoD/eihpos/sresU/:sess4rf/j4#4 4reneg_tset/bil/krowem4#4 4reneg/noit4#4 4r/noit4#4 4j.tnerruc-poodn4#4 4r" + "'", str3.equals("stcefed/stnemucoD/eihpos/sresU/4r_nur/pmt/j4#4 4225_lp.poodn4t/7959720651_14#4 4lc/tegr4#4 4stcefed/stnemucoD/eihpos/sresU/:sess4rf/j4#4 4reneg_tset/bil/krowem4#4 4reneg/noit4#4 4r/noit4#4 4j.tnerruc-poodn4#4 4r"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.01.032.0100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("444440404", "0 0 -1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 1, "raj.tne...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray10 = new char[] { '4', '4', '4', ' ', '#', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "    ", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.04100.0", charArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "4a4a4a a#a4" + "'", str16.equals("4a4a4a a#a4"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("444440404", "1.7.0_80-b15", "                                                 \n                                                  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444440404" + "'", str3.equals("444440404"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("0.001a0.23a0.1a0.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.001a0.23a0.1a0.1" + "'", str1.equals("0.001a0.23a0.1a0.1"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100 0 -1 100", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 100, (long) ' ', (long) 25);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 25L + "'", long3 == 25L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("4#4#4# ###4", "                                                  \n                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4#4#4# ###4" + "'", str2.equals("4#4#4# ###4"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0404-1" + "'", str7.equals("0404-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0404-1" + "'", str11.equals("0404-1"));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1a0                            ", "", "SUN#.#L");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1a0                            " + "'", str3.equals("1a0                            "));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("Mixed mode", "sun#.#lwawt#.#macosx#.#lwct#oolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mixed mode" + "'", str2.equals("Mixed mode"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7at/7959720651_14225_lp.poodnalc/tegrarf/j4stcefed/stnemucoD/eihpos/sresU/:sessareneg_tset/bil/krowemareneg/noitar/noitarruc-poodn", "0.52 0.23 0.1 0.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7at/7959720651_14225_lp.poodnalc/tegrarf/j4stcefed/stnemucoD/eihpos/sresU/:sessareneg_tset/bil/krowemareneg/noitar/noitarruc-poodn" + "'", str2.equals("r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7at/7959720651_14225_lp.poodnalc/tegrarf/j4stcefed/stnemucoD/eihpos/sresU/:sessareneg_tset/bil/krowemareneg/noitar/noitarruc-poodn"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("       ", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       " + "'", str3.equals("       "));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                                                                                                                                                                                                                                                                                          ", "0a0a1J#v# Pl#tform API Sp");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "51.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "-14-14#-14-14#-14--41-413-14#-14-14#-14-14#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("J#v# Pl#tform API Specific#tion", 25, 98);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J#v# Pl#tform API Specific#tion" + "'", str3.equals("J#v# Pl#tform API Specific#tion"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        long[] longArray3 = new long[] { 0, (byte) 0, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0a0a1" + "'", str6.equals("0a0a1"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("4444444444444444444444444MIXED MODE", 75);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444MIXED MODE" + "'", str2.equals("4444444444444444444444444MIXED MODE"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.71.81.11.7", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.7" + "'", str2.equals("1.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.7"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 172, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.substringsBetween("", "hi!", "hi!");
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.io.Serializable[]) strArray6);
        java.lang.CharSequence charSequence10 = null;
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence10, (java.lang.CharSequence[]) strArray12);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment########################################################################", (java.lang.CharSequence[]) strArray12);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("0.0a1.0a1.0a0.0a1.0a10.0", strArray6, strArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0.0a1.0a1.0a0.0a1.0a10.0" + "'", str16.equals("0.0a1.0a1.0a0.0a1.0a10.0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("          ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.CPrinterJob", "", (int) '4');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "10.041.041.040.041.0410.0");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("1.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01./Users/sophie", strArray1, strArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01./Users/sophie" + "'", str8.equals("1.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01./Users/sophie"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("#.#w1w#.#m1sx#.#LWCT#k", "44444040414444404041444440404144444040414444404041444440404144444040414444410a011a011a010a011a0110a0", "#.#lwct#oo");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("#/.u/.u#/.u/.u#/.u//u./4.", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#/.u/.u#/.u/.u#/.u//u./4.       " + "'", str2.equals("#/.u/.u#/.u/.u#/.u//u./4.       "));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        char[] charArray9 = new char[] { ' ', ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Platform API Specification", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.0A1.0A1.0A0.0A1.0A10.0#########################################################################", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUTF-8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUTF-8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUTF-8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUTF-8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "", ":4 4 4   # 4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUTF-8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUTF-8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUTF-8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUTF-8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUTF-8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUTF-8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUTF-8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUTF-8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100a0a-1a100", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1a0", 133, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("fc0000gn/T/a/v                                              4_v31cq2n2x1n4                                             r/folders/_v/6v597zmn");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "fc0000gn/T/a/v                                              4_v31cq2n2x1n4                                             r/folders/_v/6v597zmn" + "'", str1.equals("fc0000gn/T/a/v                                              4_v31cq2n2x1n4                                             r/folders/_v/6v597zmn"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        int[] intArray2 = new int[] { (short) 1, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "140" + "'", str4.equals("140"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a0" + "'", str7.equals("1a0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 44);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                            " + "'", str2.equals("                                            "));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("4444444444444444444444...", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "1.5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachi", (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("100#0#-1#100", "0.0a1.0a1.0a0.0a1.0a10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("SUN#.#LWAWT#.#MACOSX#.#LWCT#OOLKIT", "0#0#1", 172);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("4a4a4a a#a4", "J#v# pl#tform api specific#tionts4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4a4a4a a#a4" + "'", str2.equals("4a4a4a a#a4"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1", (java.lang.CharSequence) "1.0 1.0", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ', 5, (int) (byte) 1);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a0a-1a100" + "'", str9.equals("100a0a-1a100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100 0 -1 100" + "'", str11.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100a0a-1a100" + "'", str10.equals("100a0a-1a100"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1/0", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment########################################################################ent########################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("444440404");
        java.math.BigDecimal[] bigDecimalArray2 = new java.math.BigDecimal[] { bigDecimal1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) bigDecimalArray2, '#', (-1), (int) (byte) -1);
        org.junit.Assert.assertNotNull(bigDecimal1);
        org.junit.Assert.assertNotNull(bigDecimalArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444440404" + "'", str3.equals("444440404"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("a##### #", 5, 426);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a##### #" + "'", str3.equals("a##### #"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart(" 4#4#4 4 ", "1.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 4#4#4 4 " + "'", str2.equals(" 4#4#4 4 "));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("-1#1#100#0", "", "http://java.oracle.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1#1#100#0" + "'", str3.equals("-1#1#100#0"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "1.7.0_80-B15");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.0a1.0a1.0a0.0a1.0a10.0", (int) '#', 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3L, (double) 52.0f, (double) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("444440404/Users/sophie/Documents/de Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...", (int) '4', "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444440404/Users/sophie/Documents/de Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt..." + "'", str3.equals("444440404/Users/sophie/Documents/de Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt..."));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.52 0.23 0.1 0.1", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0a0a1a1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(60, 8, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 60 + "'", int3 == 60);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sun#.#lwawt#.#macosx#.#lwct#oolkit");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1/0", "0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1/0" + "'", str2.equals("1/0"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "-14100", (java.lang.CharSequence) "####a####a##4444404041####a####a###");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.7" + "'", str1.equals("1.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.71.71.81.11.7"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("100 0 -1 100");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        boolean boolean6 = javaVersion2.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean8 = javaVersion4.atLeast(javaVersion7);
        java.lang.String str9 = javaVersion7.toString();
        boolean boolean10 = javaVersion0.atLeast(javaVersion7);
        java.lang.String str11 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.4" + "'", str9.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.2" + "'", str11.equals("1.2"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("b     ", "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "b     " + "'", str2.equals("b     "));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ', 35, (int) ' ');
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100a0a-1a100" + "'", str10.equals("100a0a-1a100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 100 + "'", short15 == (short) 100);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                                                                                 ", (java.lang.CharSequence) "edom dexim4444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("0a0a-1", "444440404/Users/sophie/Documents/de", "4444444444444444444444444444", 131);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0a0a-1" + "'", str4.equals("0a0a-1"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "MIXEDMODE", (java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "MIXEDMODE" + "'", charSequence2.equals("MIXEDMODE"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("10.14.3", "sun#.#lwawt#.#macosx#.#lwct#oolkit4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "sun#.#lwawt#.#macosx#.#lwct#oolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "0.0A1.0A1.0A0.0A1.0A10.0#########################################################################   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "s#.#w1w#.#m1sx#.#LWCT#k");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("#.#w1w#.#m1sx#.#LWCT#k");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#.#W1W#.#M1SX#.#LWCT#K" + "'", str1.equals("#.#W1W#.#M1SX#.#LWCT#K"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     " + "'", str2.equals("     "));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("        ...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-14141004041###############################################################", "4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("4444404041s#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100a0a-1a100" + "'", str8.equals("100a0a-1a100"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(52L, (long) 172, (long) 60);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 172L + "'", long3 == 172L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        char[] charArray9 = new char[] { '4', '4', '4', ' ', '#', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "        a#a#a a         ", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "44444444444", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " 4 4#4#4 ", (java.lang.CharSequence) "1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.#1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1 0                                                                                                 ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0#0#1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("", "1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01." + "'", str2.equals("1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01."));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        char[] charArray9 = new char[] { ' ', ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Platform API Specification", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100 0 -1 100", charArray9);
        java.lang.Class<?> wildcardClass15 = charArray9.getClass();
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "##########", charArray9);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', (int) ' ', 98);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        float[] floatArray6 = new float[] { 10L, (byte) 1, 1L, (byte) 0, 1L, 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ', 49, (int) (byte) 0);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0a1.0a1.0a0.0a1.0a10.0" + "'", str9.equals("10.0a1.0a1.0a0.0a1.0a10.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "1.7.0_80-b15", 7);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', (int) 'a', 60);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(" a ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        " + "'", str2.equals("        "));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        long[] longArray3 = new long[] { 0, (byte) 0, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ', 5, 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 34, 0);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "04041" + "'", str7.equals("04041"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        char[] charArray8 = new char[] { '4', '4', '4', ' ', '#', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "        a#a#a a         ", charArray8);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', (int) (byte) 0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "10.041.041.040.041.0410.0", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT########################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("            0a0a-1             ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:             0a0a-1              is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.0a1.0a1.0a0.0a1.0a10.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80-B15", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-B15" + "'", str2.equals("1.7.0_80-B15"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("sun.awt.CGraphicsEnvironment", "4a4a4a a#a", "1.0A100.0", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str4.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("4 4 4   # 4", "44444444444", "j/tmp/run_");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4 4 4   # 4" + "'", str3.equals("4 4 4   # 4"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("b                                                                                                   ", "                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                       " + "'", str2.equals("                                                       "));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-14-14#-14-14#-14--41-413-14#-14-14#-14-14#", (java.lang.CharSequence) "4444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("0 0 1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 0 1" + "'", str1.equals("0 0 1"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', (int) (short) 100, (-1));
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', (int) (short) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0404-1" + "'", str7.equals("0404-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 0 + "'", byte14 == (byte) 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "#########################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        long[] longArray3 = new long[] { 0, (byte) 0, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ', 10, (int) (byte) -1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ', (int) '#', 0);
        long long16 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long17 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#0#1" + "'", str6.equals("0#0#1"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "4-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1a0                            ", 98);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                 1a0                                                              " + "'", str2.equals("                                 1a0                                                              "));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.04100.0451.741.041.0435.0", 11, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.741.041.0435.0" + "'", str3.equals("1.741.041.0435.0"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        double[] doubleArray2 = new double[] { (short) 1, 100.0f };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.04100.0" + "'", str4.equals("1.04100.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a100.0" + "'", str7.equals("1.0a100.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.04100.0" + "'", str12.equals("1.04100.0"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart(":4 4 4   # 4", "/Java Virtual Machine SpecificationUsersJava Virtual Machine Specification/Java Virtual Machine SpecificationsophieJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationNetworkJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationSystemJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationusrJava Virtual Machine Specification/Java Virtual Machine SpecificationlibJava Virtual Machine Specification/Java Virtual Machine SpecificationjavaJava Virtual Machine Specification:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4 4 4   # 4" + "'", str2.equals("4 4 4   # 4"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(" # #a ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "# #a" + "'", str1.equals("# #a"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7at/7959720651_14225_lp.poodnalc/tegrarf/j4stcefed/stnemucoD/eihpos/sresU/:sessareneg_tset/bil/krowemareneg/noitar/noitarruc-poodn", (java.lang.CharSequence) "enenenenenenenenenenenenenenenenenenenenenenenenene7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                            1.0#1.0", "/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...1a0/Java Virt...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 0 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) (short) -1, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "sun.lwawt.macosx.CPrinterJob", "51.7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "rAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BI...", 100, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("444440404");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444440404" + "'", str1.equals("444440404"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "####a####a##4444404041####a####a###");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Oracle#Corporation", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle#Corporation" + "'", str2.equals("Oracle#Corporation"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("51.051.051.051.051./Java Virt...", (int) 'a', 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 7, 0.0f, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.0 1.0 32.0 25.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        float[] floatArray6 = new float[] { 10L, (byte) 1, 1L, (byte) 0, 1L, 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0a1.0a1.0a0.0a1.0a10.0" + "'", str9.equals("10.0a1.0a1.0a0.0a1.0a10.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 10.0f + "'", float10 == 10.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0 1.0 1.0 0.0 1.0 10.0" + "'", str12.equals("10.0 1.0 1.0 0.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt...", "sun.lwawt.macosx.LWCToolkit1.7", 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "4444444444", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#", 28);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "-14141004041###############################################################");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 92, 4.444444591917127E32d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        int[] intArray5 = new int[] { (-1), (short) -1, 52, (short) 0, (short) 100 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray5, '4');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-14-1452404100" + "'", str8.equals("-14-1452404100"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun#.#lwawt#.#macosx#.#LWCT#oolkit", (int) '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " sun#.#lwawt#.#macosx#.#LWCT#oolkit" + "'", str3.equals(" sun#.#lwawt#.#macosx#.#LWCT#oolkit"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "0a0a1J#v# Pl#tform API Sp");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) " a ", (java.lang.CharSequence) "1.04100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.0A100.0", "####aa#a#a4a#", (-1));
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1a0", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("sun#.#lwawt#.#macosx#.#LWCT#oolki", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun#.#lwaw..." + "'", str2.equals("sun#.#lwaw..."));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.0a1.0a32.0a100.", "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/7959720651_14225_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a1.0a32.0a" + "'", str2.equals("a1.0a32.0a"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                 1a0                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a0" + "'", str1.equals("1a0"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1", "-14100", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "aaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4a", (java.lang.CharSequence) "##");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("#-14-14#-14-14#-14--41-413-14#-14-14#-14-14#");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("-14-1452404100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-14-1452404100" + "'", str1.equals("-14-1452404100"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str4 = javaVersion3.toString();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        boolean boolean10 = javaVersion6.atLeast(javaVersion8);
        boolean boolean11 = javaVersion5.atLeast(javaVersion8);
        boolean boolean12 = javaVersion3.atLeast(javaVersion5);
        boolean boolean13 = javaVersion0.atLeast(javaVersion3);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.1" + "'", str4.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "JavaPlatfrAPISpcfcatn", (java.lang.CharSequence) "51.051.051.051.051./Java Virt...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "raj.tnerruc-poodnar/noit", charSequence1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, charSequence1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                       ", (int) (short) 1, " a4a#a#a####");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                       " + "'", str3.equals("                                                       "));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100 0 -1 100" + "'", str11.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100#0#-1#100" + "'", str14.equals("100#0#-1#100"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        float[] floatArray5 = new float[] { 7.0f, 52, 49, 7.0f, 2 };
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.0a100.0", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("#/.u/.u#/.u/.u#/.u//u./4.3/.u#/.u/.u#/.u/.u#", "sun#.#lwawt#.#macosx#.#LWCT#oolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/.u/.u#/.u/.u#/.u//u./4.3/.u#/.u/.u#/.u/.u#" + "'", str2.equals("/.u/.u#/.u/.u#/.u//u./4.3/.u#/.u/.u#/.u/.u#"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("10.0#1.0#1.0#0.0#1.0#10.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0#1.0#1.0#0.0#1.0#10." + "'", str1.equals("10.0#1.0#1.0#0.0#1.0#10."));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0a1.0a32.0a100.0", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("##", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        float[] floatArray6 = new float[] { 10L, (byte) 1, 1L, (byte) 0, 1L, 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', 32, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0 1.0 1.0 0.0 1.0 10.0" + "'", str9.equals("10.0 1.0 1.0 0.0 1.0 10.0"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Java Virtual Machine SpecificationUsersJava Virtual Machine Speci");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/JavaVirtualMachineSpecificationUsersJavaVirtualMachineSpeci" + "'", str1.equals("/JavaVirtualMachineSpecificationUsersJavaVirtualMachineSpeci"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.", "1.7.0_80-b1", (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01." + "'", str3.equals("aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.1.7.0_80-b1aa 5  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01."));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("4#4#4 4 ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4#4#4 4 " + "'", str2.equals("4#4#4 4 "));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                          ", (java.lang.CharSequence) "a#a#a a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ', 35, (int) ' ');
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100a0a-1a100" + "'", str10.equals("100a0a-1a100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) -1 + "'", short15 == (short) -1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "Mixed mode");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4444444444444444444444444mixed mode", "10.14.3", (int) 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("http://java.oracle.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray4, strArray8);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("1.7.0_80");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, '4', 97, 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, 'a');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, ' ', 7, (int) (short) 0);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, 'a');
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("4-", strArray4, strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "http://java.oracle.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str9.equals("http://java.oracle.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.7.0_80" + "'", str17.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1.7.0_80" + "'", str23.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "4-" + "'", str24.equals("4-"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("#-14-14#-14-14#-14--41-413-14#-14-14#-14-14#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#-14-14#-14-14#-14--41-413-14#-14-14#-14-14#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("##########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########" + "'", str1.equals("##########"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray10 = new char[] { '4', '4', '4', ' ', '#', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "    ", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "rAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BI...", 32, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("0A0A-1", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0A0A-1" + "'", str2.equals("0A0A-1"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "a1.0a32.0a", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 75, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0#-1#100" + "'", str8.equals("100#0#-1#100"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100#0#-1#100" + "'", str11.equals("100#0#-1#100"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("-1a-1a52a0a100", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a-1a52a0a100" + "'", str2.equals("-1a-1a52a0a100"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("\n", "0a0a1", (int) (short) 100);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        long[] longArray3 = new long[] { 0, (byte) 0, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) 'a', 32);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', 0, (int) (short) -1);
        long long15 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        int[] intArray2 = new int[] { (short) 1, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', (int) (short) 100, (int) (byte) 10);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "140" + "'", str4.equals("140"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(" # #a", 0, "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " # #a" + "'", str3.equals(" # #a"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "-1a1a100a0a1", (java.lang.CharSequence) "                                   ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(" a4a#a#a####", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a4a#a#a####" + "'", str2.equals("a4a#a#a####"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("####aa#a#a4a", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/var/folders/_v/6v597zmn4...", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] { ' ', ' ', 'a' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', (int) ' ', (int) (short) 10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "j#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tion", charArray6);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("J#v# Pl#tform API Specific#tion", "");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sun#.#l##########################################################################################", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) " a4a#a#a####");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("0a0a1#", "00-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a0a1#" + "'", str2.equals("0a0a1#"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.0a1.0a1.0a0.0a1.0a10.0", "1.04100.0", (int) '4');
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sun#.#lw1w0#.#m1c.sx#.#LWC1#..lkA01.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.011.011.010.011.0110.0", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ', 44, 0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.", "sun#.#lw1w0#.#m1c.sx#.#LWC1#..lkA01.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.011.011.010.011.0110.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }
}

