import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.0a1.0", "0a0a1", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("4#4#4# ###4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#4#4# ###4" + "'", str1.equals("4#4#4# ###4"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("04041", "sophie#", 25);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Java Virt...", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.0A1.0A1.0A0.0A1.0A10.0", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.0A1.0A1.0A0.0A1.0A10.0" + "'", str2.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.0A1.0A1.0A0.0A1.0A10.0"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("7.15", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) -1, (long) 67, (long) 32);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 67L + "'", long3 == 67L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("a##### #", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("51.7", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "awt.CGraphicsEnvironment########################################################################", (java.lang.CharSequence) "100 0 -1 100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0a0a1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test011");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                              /uSERS/SOPHIE/dOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_5221_1560279597");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/uSERS/SOPHIE/dOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_5221_1560279597\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 426 + "'", int1 == 426);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("# #a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "# #a" + "'", str1.equals("# #a"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ', (int) (short) 10, 10);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', (int) (byte) 100, 67);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray3, " ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:  ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("444444444444444444444444444444451.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444451.0" + "'", str1.equals("444444444444444444444444444444451.0"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("0.52 0.23 0.1 0.1", 131);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.52 0.23 0.1 0.1" + "'", str2.equals("0.52 0.23 0.1 0.1"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(" a#a#a a ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) 'a', 28, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "100 0 -1 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "stcefed/stnema#####4# c-poodn4#4 4r", 35, 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "1.041.0432.04100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "b", (java.lang.CharSequence) "CGraphicsEnvironment########################################################################", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                                sun.awt.CGraphicsEnvironment", (int) '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                sun.awt.CGraphicsEnvironment" + "'", str3.equals("                                                                                                                sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0.0A1.0A1.0A0.0A1.0A10.0#########################################################################", 7, "          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0A1.0A1.0A0.0A1.0A10.0#########################################################################" + "'", str3.equals("0.0A1.0A1.0A0.0A1.0A10.0#########################################################################"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("51.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 51.0f + "'", float1 == 51.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0 0 1", 5, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 0 1" + "'", str3.equals("0 0 1"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("B", "sun#.#lwawt#.#macosx#.#lwct#oolkit/Java Virtual Machine SpecificationUsersJava Virtual Machine Speci");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("          ", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("US", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "ophie#", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("0.0a1.0a1.0a0.0a1.0a10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0A1.0A1.0A0.0A1.0A10.0" + "'", str1.equals("0.0A1.0A1.0A0.0A1.0A10.0"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        int[] intArray2 = new int[] { (short) 1, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', 10, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "140" + "'", str4.equals("140"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Eihpos/sresU/" + "'", str1.equals("Eihpos/sresU/"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("100 0 -1 10", "0 0 1", "4444444444444444444444444444444444444444444444448-FTU44444444444444444444444444444444444444444444444", 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100 0 -1 10" + "'", str4.equals("100 0 -1 10"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mixed mode", "/Users/sophie", (int) (short) 10);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "stcefed/stnemucoD/eihpos/sresU/4r_nur/pmt/j4#4 4225_lp.poodn4t/7959720651_14#4 4lc/tegr4#4 4stcefed/stnemucoD/eihpos/sresU/:sess4rf/j4#4 4reneg_tset/bil/krowem4#4 4reneg/noit4#4 4r/noit4#4 4j.tnerruc-poodn4#4 4r", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("sun.awt...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt..." + "'", str2.equals("sun.awt..."));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "51.051.051.051.051.                                                                                                    Java Virt...", (java.lang.CharSequence) "4#4#4# ###4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15", 32, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwc" + "'", str3.equals("#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwc"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("    ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        float[] floatArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ndoop.pl_52241_1560279597a/Users/sophie/Documents/defects4j/tmp/run_r" + "'", str2.equals("ndoop.pl_52241_1560279597a/Users/sophie/Documents/defects4j/tmp/run_r"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("-14-1452404100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-14-1452404100" + "'", str1.equals("-14-1452404100"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597", (java.lang.CharSequence) "04041J#v# Pl#tform API Sp");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ', (-1), 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0#-1#100" + "'", str8.equals("100#0#-1#100"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "140", (java.lang.CharSequence) "sun#.#lwawt#.#macosx#.#LWCT#oolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "0.52 0.23 0.1 0.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "sun.awt...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0404-1", "100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10", (-1));
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.7.0_80-B1");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7.0_80-B141.7.0_80-B141.7.0_80-B11.7.0_80-B1" + "'", str5.equals("1.7.0_80-B141.7.0_80-B141.7.0_80-B11.7.0_80-B1"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "hi!", "hi!");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("US", "4444444444444444444444444MIXED MODE");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(" ", strArray4, strArray7);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + " " + "'", str8.equals(" "));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("####aa#a#a4a ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####aa#a#a4a" + "'", str1.equals("####aa#a#a4a"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporation", "");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0a0a1#", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Oracle#Corporation" + "'", str5.equals("Oracle#Corporation"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                                                                    ", "-1#1#100#0#1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("####aa#a#a4a ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4 4 4   # 4", "444444444444444444444444444444451.0", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("        ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "..." + "'", str1.equals("..."));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                                    ", 7, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                    " + "'", str3.equals("                                                                                                    "));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "J#v# Pl#tform API Specific#tion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sophie", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" # #a", "                              /uSERS/SOPHIE/dOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_5221_1560279597");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        int[] intArray2 = new int[] { (short) 1, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', (int) (short) 100, (int) (byte) 10);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "140" + "'", str4.equals("140"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1#0" + "'", str11.equals("1#0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("44444040414444404041444440404144444040414444404041444440404144444040414444410a011a011a010a011a0110a0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444040414444404041444440404144444040414444404041444440404144444040414444410a011a011a010a011a0110a0" + "'", str1.equals("44444040414444404041444440404144444040414444404041444440404144444040414444410a011a011a010a011a0110a0"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Java HotSpot(TM) 64-Bit Server VM", "0a0a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Java Virt...", "-1#1#100#0#1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Java Virt..." + "'", str2.equals("/Java Virt..."));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("24.80-b11", 97, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.", "                                             r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01." + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01."));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sun.awt..", 100, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Mac OS X", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        double[] doubleArray2 = new double[] { (short) 1, 100.0f };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4', 32, (int) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.04100.0" + "'", str4.equals("1.04100.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a100.0" + "'", str7.equals("1.0a100.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1a0", ":4 4 4   # 4", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " 4 4#4#4 ", 31, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', (int) (byte) 10, (int) ' ');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java(TM) SE Runtime Environment", "sun#.#l");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mixed mode" + "'", str1.equals("Mixed mode"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.04100.0", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        long[] longArray3 = new long[] { 0, (byte) 0, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) 'a', 32);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "100 0 -1 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "UTF-8");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1.0#1.0");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01./Users/sophie");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#', 8, 426);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0#-1#100" + "'", str8.equals("100#0#-1#100"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1a0                            ", "10.0 1.0 1.0 0.0 1.0 10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0#-1#100" + "'", str8.equals("100#0#-1#100"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("r4...", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r4..." + "'", str2.equals("r4..."));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(140.0d, (double) 5, (double) 97);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 140.0d + "'", double3 == 140.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80-B1", (java.lang.CharSequence) "SUN#.#LWAWT#.#MACOSX#.#LWCT#OOLKIT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                         " + "'", str2.equals("                         "));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "a#####4# ", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "0.0A1.0A1.0A0.0A1.0A10.0#########################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("sun#.#l");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN#.#L" + "'", str1.equals("SUN#.#L"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Oracle#Corporation", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("7.1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7.1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("7.1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Jv7va_8a-bJ5");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Users/sophie", "4 4 4   # 4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "####aa#a#a4a ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test100");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10", (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1111101011", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) '4', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 2, 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("444441.041.0432.0425.0aaaaaaaaaaaaaa", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444441.041.0432.0425.0aaaaaaaaaaaaaa" + "'", str2.equals("444441.041.0432.0425.0aaaaaaaaaaaaaa"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sun#.#lwawt#.#macosx#.#LWCT#oolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun#.#lwawt#.#macosx#.#LWCT#oolkit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sun.awt.CGraphicsEnvironment########################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment########################################################################" + "'", str1.equals("sun.awt.CGraphicsEnvironment########################################################################"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "#-14-14#-14-14#-14--41-413-14#-14-14#-14-14#", (java.lang.CharSequence) " # #a");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "#-14-14#-14-14#-14--41-413-14#-14-14#-14-14#" + "'", charSequence2.equals("#-14-14#-14-14#-14--41-413-14#-14-14#-14-14#"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("####aa#a#a4a ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0 0 -1" + "'", str7.equals("0 0 -1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/JaSTCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/7959720651_1a225_LP.POODNAR_NUR/PMT/JaSTCEFED/STNEMUCOD/EIHPOS/SRESU/1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/JaSTCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/7959720651_1a225_LP.POODNAR_NUR/PMT/JaSTCEFED/STNEMUCOD/EIHPOS/SRESU/1.7" + "'", str1.equals("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/JaSTCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/7959720651_1a225_LP.POODNAR_NUR/PMT/JaSTCEFED/STNEMUCOD/EIHPOS/SRESU/1.7"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "raj.tne...", 28);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihpos/sresU" + "'", str1.equals("eihpos/sresU"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        int[] intArray2 = new int[] { (short) 1, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', (int) ' ', (int) (byte) -1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', 1, 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        int int16 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "140" + "'", str4.equals("140"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1 0" + "'", str15.equals("1 0"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("a##### # ", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("0.0A1.0A1.0A0.0A1.0A10.0#########################################################################", "1.0#1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "A1.0A1.0A0.0A1.0A10.0#########################################################################" + "'", str2.equals("A1.0A1.0A0.0A1.0A10.0#########################################################################"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444444444444444444444444444451.0", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", "#-14-14#-14-14#-14--41-413-14#-14-14#-14-14#", "140", (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v" + "'", str4.equals("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.2");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.2f + "'", float1.equals(1.2f));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("SUN.AWT.cgRAPHICSeNVIRONMENT########################################################################", "en", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("100a0a-1a100", 7, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test122");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("rruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "rruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7" + "'", str1.equals("rruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("51.051.051.051.051./jAVA vIRT...", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.051.051.051.051./jAVA vIRT..." + "'", str2.equals("51.051.051.051.051./jAVA vIRT..."));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test124");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("raj.tnerruc-poodnar/noit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"raj.tnerruc-poodnar/noit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test125");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "j/tmp/run", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test126");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) " # #a ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test127");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10.0a1.0a1.0a0.0a1.0a10.0", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0a1.0a1.0a0.0a1.0a10.0" + "'", str3.equals("10.0a1.0a1.0a0.0a1.0a10.0"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("sun.lwawt.macosx.LWCToolkit1.7", "0a0a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit1.7" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit1.7"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test129");
        int[] intArray5 = new int[] { (-1), (short) -1, 52, (short) 0, (short) 100 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray5, '#', (int) (short) 100, 10);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray5, '4');
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-14-1452404100" + "'", str8.equals("-14-1452404100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-14-1452404100" + "'", str15.equals("-14-1452404100"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test130");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "          ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test131");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("stcefed/stnema#####4# c-poodn4#4 4r");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test132");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', 100, 32);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', (int) (short) 10, 0);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: r444444 4#44j.tnerruc-poodn444444 4#44r/noit444444 4#44reneg/noit444444 4#44reneg_tset/bil/krowem444444 4#44rf/j4stcefed/stnemucoD/eihpos/sresU/:sess444444 4#44lc/tegr444444 4#44t/7959720651_14225_lp.poodn444444 4#44r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0404-1" + "'", str7.equals("0404-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0a0a-1" + "'", str10.equals("0a0a-1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(" 4 4#4#4 ", "44", "0.0A1.0A1.0A0.0A1.0A10.0#########################################################################");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 426);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                          " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                          "));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test136");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "/run_");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test137");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("# #a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "# #a" + "'", str1.equals("# #a"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test138");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("0.52 0.23 0.1 0.1");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10" + "'", str1.equals("100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test140");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test141");
        double[] doubleArray2 = new double[] { (byte) 1, 1 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test142");
        char[] charArray9 = new char[] { '4', '4', '4', ' ', '#', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BI...", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test143");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("#########################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"########################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test144");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4444444444", "", 7);
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.0A1.0A1.0A0.0A1.0A10.0", strArray4, strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.0A1.0A1.0A0.0A1.0A10.0" + "'", str6.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.0A1.0A1.0A0.0A1.0A10.0"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test145");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-1#1#100#0", (java.lang.CharSequence) "0.0A1.0A1.0A0.0A1.0A10.0", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test146");
        char[] charArray5 = new char[] { 'a', '4', 'a', '4', '#' };
        char[][] charArray6 = new char[][] { charArray5 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test147");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "4444444444", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("0.0A1.0A1.0A0.0A1.0A10.0#########################################################################", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0A1.0A1.0A0.0A1.0A10.0#########################################################################   " + "'", str2.equals("0.0A1.0A1.0A0.0A1.0A10.0#########################################################################   "));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test150");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("A1.0A1.0A0.0A1.0A10.0#########################################################################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test151");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "    ", (java.lang.CharSequence) "0a0a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test152");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test153");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("1404044444", "44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", (int) 'a');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("1.0a100.0", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 56 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test154");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01./Users/sophie", charSequence1, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test155");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("mixed mode", "1.7.0_80");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence1, (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "4#4#4 4 ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test156");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "-1#1#100#0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "-1#1#100#0" + "'", charSequence2.equals("-1#1#100#0"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test157");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { '4', '4', '4', ' ', '#', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray11);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray11, '4');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                    ", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun#.#lwawt#sun#.#lwawt#", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "444444 4#44" + "'", str15.equals("444444 4#44"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test158");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "4444404041s#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test159");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("awt.CGraphicsEnvironment########################################################################", 34, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test160");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test161");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597", (java.lang.CharSequence) "1.0#1.0#32.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test162");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "        ...", (java.lang.CharSequence) "####aa#a#a4a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test163");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        java.lang.Class<?> wildcardClass12 = shortArray4.getClass();
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a0a-1a100" + "'", str9.equals("100a0a-1a100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100 0 -1 100" + "'", str11.equals("100 0 -1 100"));
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sun#.#lwawt#.#macosx#.#LWCT#oolkit", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun#.#lwawt#.#macosx#.#LWCT#oolkit" + "'", str2.equals("sun#.#lwawt#.#macosx#.#LWCT#oolkit"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 4, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test166");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0 0 ", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".31.0#1.01.0#1.01.0#" + "'", str2.equals(".31.0#1.01.0#1.01.0#"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("...", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "..." + "'", str3.equals("..."));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Java(TM) SE Runtime Environment", 140);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("TIKLOOtcwl.XSOCAM.TWAWL.NUS", 31, 22);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test171");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("140", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("j#v# pl#tform api specific#tionts4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J#v# pl#tform api specific#tionts4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("J#v# pl#tform api specific#tionts4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test173");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4a4a4a a#a4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test174");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10a011a011a010a011a0110a0", (java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test175");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("####aa#a#a4a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"####aa#a#a4a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test176");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test177");
        int[] intArray2 = new int[] { (short) 1, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', (int) (short) 100, (int) (byte) 10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', 7, 4);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray2, '#', 34, 140);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 34");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "140" + "'", str4.equals("140"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test178");
        int[] intArray5 = new int[] { (-1), (short) -1, 52, (short) 0, (short) 100 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray5, '4');
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-14-1452404100" + "'", str10.equals("-14-1452404100"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test179");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("##########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.0a1.0a32.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0a1.0a32.0a100." + "'", str1.equals("1.0a1.0a32.0a100."));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("10.0#1.0#1.0#0.0#1.0#10.0", "0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0#1.0#1.0#0.0#1.0#10." + "'", str2.equals("10.0#1.0#1.0#0.0#1.0#10."));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("sun.awt..");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.." + "'", str1.equals("sun.awt.."));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test183");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 25, (double) 7, 7.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 25.0d + "'", double3 == 25.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test184");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.04100.0", (java.lang.CharSequence) "4444444444444444444444...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test185");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test186");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.041.0432.04100.0", "1.0 1.0 32.0 25.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test187");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ', (int) (short) 10, 10);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 98, 4);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test188");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test189");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                          ", (java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.710.0A1.0A1.0A0.0A1.0A10.0", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test190");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "Oracle#Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("1111101011", "4-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1111101011" + "'", str2.equals("1111101011"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun#.#lwawt#.#macosx#.#lwct#oolkit/Java Virtual Machine SpecificationUsersJava Virtual Machine Speci", 24, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun#.#lwawt#.#macosx#.#lwct#oolkit/Java Virtual Machine SpecificationUsersJava Virtual Machine Speci" + "'", str3.equals("sun#.#lwawt#.#macosx#.#lwct#oolkit/Java Virtual Machine SpecificationUsersJava Virtual Machine Speci"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test193");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) " 4#4#4 4 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test194");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.0A100.0", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0A100.0" + "'", str3.equals("1.0A100.0"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("51.051.051.051.051./Java Virt...", "04041J#v# Pl#tform API Sp");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.051.051.051.051./Java Virt..." + "'", str2.equals("51.051.051.051.051./Java Virt..."));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test197");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-1a1a100a0a1", 8, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1a1a100a0a1" + "'", str3.equals("-1a1a100a0a1"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test198");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("us", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "us" + "'", str3.equals("us"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test200");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4', 67, (-1));
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a0a-1a100" + "'", str9.equals("100a0a-1a100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100 0 -1 100" + "'", str11.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100#0#-1#100" + "'", str18.equals("100#0#-1#100"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test201");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test202");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "UTF-8", 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test203");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4', (int) (byte) 0, 98);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a0a-1a100" + "'", str9.equals("100a0a-1a100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100 0 -1 100" + "'", str11.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100 0 -1 100" + "'", str13.equals("100 0 -1 100"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test204");
        float[] floatArray0 = new float[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#', (int) (byte) 10, 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray0, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray0, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray0, ' ');
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test205");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(11, (int) '#', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test206");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Oracle#Corporation", (java.lang.CharSequence) "04041J#v# Pl#tform API Sp");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test207");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("J#v# Pl#tform API Specific#tion", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "4#4#4 4 ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "J#v# Pl#tform API Specific#tion" + "'", str4.equals("J#v# Pl#tform API Specific#tion"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("4#4#4 4 ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4#4#4 4 " + "'", str2.equals("4#4#4 4 "));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test209");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test210");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (-1), 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 67 + "'", int3 == 67);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test211");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("sophie", "x86_64", "1.0A100.0", 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sophie" + "'", str4.equals("sophie"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test212");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "####aa#a#a4a#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test213");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0 0 ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test214");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7", (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test215");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun#.#lwawt#.#macosx#.#LWCT#oolki");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("100#0#-1#100", "##########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#0#-1#100" + "'", str2.equals("100#0#-1#100"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "10a011a011a010a011a0110a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test219");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(32.0d, (double) 28.0f, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test220");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test221");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1a0                            ");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase(":4...", "1.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01.0 1.0 32.0 25.01./Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":4..." + "'", str2.equals(":4..."));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("j#v# pl#tform api specific#tion", "sophie#", "0.0a1.0a1.0a0.0a1.0a10.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "j#v# pl#tform api specific#tion" + "'", str3.equals("j#v# pl#tform api specific#tion"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test224");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.0a100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test225");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7" + "'", str1.equals("7"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test226");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("444440404");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.44440416E8f + "'", float1 == 4.44440416E8f);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test227");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray2 = null;
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#", strArray1, strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#" + "'", str3.equals("#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test229");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "1.7.0_80", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test230");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "stcefed/stnema#####4# c-poodn4#4 4r");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test231");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test232");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.041.0432.0425.0aaaaaaaaaaaaaa", "100 0 -1 10", "sun#.#lwawt#.#macosx#.#lwct#oolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.041.0432.0425.0aaaaaaaaaaaaaa" + "'", str3.equals("1.041.0432.0425.0aaaaaaaaaaaaaa"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test234");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("44444040414444404041444440404144444040414444404041444440404144444040414444410a011a011a010a011a0110a0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444040414444404041444440404144444040414444404041444440404144444040414444410a011a011a010a011a0110a0" + "'", str1.equals("44444040414444404041444440404144444040414444404041444440404144444040414444410a011a011a010a011a0110a0"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test235");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(426, 10, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 426 + "'", int3 == 426);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test236");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.71.81.11.7", "44444040414444404041444440404144444040414444404041444440404144444040414444410a011a011a010a011a0110a0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test237");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "4 4 4   # 4", (java.lang.CharSequence) "1.0 1.0", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test238");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "J#v# pl#tform api specific#tionts4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/                                                                                                                                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/                                                                                                                                           " + "'", str1.equals("/                                                                                                                                           "));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test240");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1111101011");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test241");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "rruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/1.7", charSequence1, 49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "0.0A1.0A1.0A0.0A1.0A10.0#########################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("tiklooTCWL.xsocam.twawl.nus", (int) 'a', 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test244");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("140                            ", "0a0a1#", (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "140                            " + "'", str3.equals("140                            "));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test245");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(31, 11, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test246");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test247");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51.7", "sun.lwawt.macosx.CPrinterJob", 32);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach(":", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + ":" + "'", str6.equals(":"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test248");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("444440404", "4444444444444444444444444MIXED MODE", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444440404" + "'", str3.equals("444440404"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test249");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "hi!", "hi!");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                 1.8", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test250");
        char[] charArray5 = new char[] { ' ', ' ', 'a' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ', (int) (short) -1, (int) (short) -1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', (int) (byte) 100, 31);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "\n", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test251");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ' ');
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.7.0_80-B141.7.0_80-B141.7.0_80-B11.7.0_80-B1", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("j#v# pl#tform api specific#tion", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tion" + "'", str2.equals("j#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tionj#v# pl#tform api specific#tion"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test253");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(" a#a#a a ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test254");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 1, 11, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test255");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Java Virtual Machine SpecificationUsersJava Virtual Machine Specification/Java Virtual Machine SpecificationsophieJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationNetworkJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationSystemJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationusrJava Virtual Machine Specification/Java Virtual Machine SpecificationlibJava Virtual Machine Specification/Java Virtual Machine SpecificationjavaJava Virtual Machine Specification:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.0a1.0a32.0a100.0", "", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0a1.0a32.0a100.0" + "'", str3.equals("1.0a1.0a32.0a100.0"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test257");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1404044444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test259");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test260");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test261");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "TIKLOOtcwl.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test262");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Java Virtual Machine Specification");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "7");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Java Virtual Machine SpecificationUsersJava Virtual Machine Specification/Java Virtual Machine SpecificationsophieJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationNetworkJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationSystemJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationusrJava Virtual Machine Specification/Java Virtual Machine SpecificationlibJava Virtual Machine Specification/Java Virtual Machine SpecificationjavaJava Virtual Machine Specification:." + "'", str6.equals("/Java Virtual Machine SpecificationUsersJava Virtual Machine Specification/Java Virtual Machine SpecificationsophieJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationNetworkJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationSystemJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationusrJava Virtual Machine Specification/Java Virtual Machine SpecificationlibJava Virtual Machine Specification/Java Virtual Machine SpecificationjavaJava Virtual Machine Specification:."));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "/4Users4/4sophie4/4Library4/4Java4/4Extensions4:/4Library4/4Java4/4Extensions4:/4Network4/4Library4/4Java4/4Extensions4:/4System4/4Library4/4Java4/4Extensions4:/4usr4/4lib4/4java4:." + "'", str11.equals("/4Users4/4sophie4/4Library4/4Java4/4Extensions4:/4Library4/4Java4/4Extensions4:/4Network4/4Library4/4Java4/4Extensions4:/4System4/4Library4/4Java4/4Extensions4:/4usr4/4lib4/4java4:."));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test263");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("CGraphicsEnvironment########################################################################", (int) (short) 0, "444440404");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CGraphicsEnvironment########################################################################" + "'", str3.equals("CGraphicsEnvironment########################################################################"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/7959720651_14225_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/7959720651_14225_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/1.7" + "'", str1.equals("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/7959720651_14225_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/1.7"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test265");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" 4#4#4 4 ", "4444444444444444444444444444444444444444444444448-FTU44444444444444444444444444444444444444444444444");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test266");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.6", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test267");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "eihpos/sresU", "mode Mixed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test268");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java HotSpot(TM) 64-Bit Server V", "140");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server V" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server V"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test270");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "140", (java.lang.CharSequence) "A1.0A1.0A0.0A1.0A10.0#########################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test271");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.awt.CGraphicsEnvironment########################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.awt.CGraphicsEnvironment########################################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test272");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "sun#.#lwawt#.#macosx#.#LWCT#oolkit", (java.lang.CharSequence) "444441.041.0432.0425.0aaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test273");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test274");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test275");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/var/folders/_v/6v597zmn4...", "sun#.#lwawt#.#macosx#.#LWCT#oolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4..." + "'", str2.equals("/var/folders/_v/6v597zmn4..."));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test277");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("sun#.#lwawt#.#macosx#.#lwct#oolkit/Java Virtual Machine SpecificationUsersJava Virtual Machine Speci");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: sun#.#lwawt#.#macosx#.#lwct#oolkit/Java Virtual Machine SpecificationUsersJava Virtual Machine Speci is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test278");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "r4...", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test279");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', 100, 32);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0404-1" + "'", str7.equals("0404-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0a0a-1" + "'", str10.equals("0a0a-1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0a0a-1" + "'", str16.equals("0a0a-1"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test280");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray12 = new char[] { '4', '4', '4', ' ', '#', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray12);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray12, '4');
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "b", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray12);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4444444444444444444444...", charArray12);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "r4...", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "444444 4#44" + "'", str16.equals("444444 4#44"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test281");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "0 0 -1", (java.lang.CharSequence) "1a0                            ", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test283");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("SUN#.#L", (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test284");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE", (int) (short) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test285");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4', 35, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a0a-1a100" + "'", str9.equals("100a0a-1a100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100 0 -1 100" + "'", str11.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) -1 + "'", short13 == (short) -1);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100 0 -1 100" + "'", str15.equals("100 0 -1 100"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("j#v# pl#tform api specific#tionts4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "a##### #");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j#v# pl#tform api specific#tionts4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("j#v# pl#tform api specific#tionts4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test287");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) ' ', (long) (-1), (long) 'a');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test288");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray12 = new char[] { '4', '4', '4', ' ', '#', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray12);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray12, '4');
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "b", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10a011a011a010a011a0110a0", charArray12);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-B1", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "444444 4#44" + "'", str16.equals("444444 4#44"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test289");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (byte) -1, (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#', 35, 140);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 0 -1 100" + "'", str6.equals("100 0 -1 100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0#-1#100" + "'", str8.equals("100#0#-1#100"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test290");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "100 0 -1 10", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test291");
        double[] doubleArray2 = new double[] { (byte) 1, 1 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0#1.0" + "'", str5.equals("1.0#1.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0#1.0" + "'", str7.equals("1.0#1.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0#1.0" + "'", str9.equals("1.0#1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test292");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.0A100.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test293");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "4444404041s#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT#ks#.#w1w#.#m1sx#.#LWCT", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test294");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(67, (int) (short) 10, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test295");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(140.0d, (double) 32.0f, 98.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 140.0d + "'", double3 == 140.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test296");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.1", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test297");
        float[] floatArray6 = new float[] { 10L, (byte) 1, 1L, (byte) 0, 1L, 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ', 13, 11);
        float float15 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 10.0f + "'", float8 == 10.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 10.0f + "'", float10 == 10.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test298");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "0a0a-1", (java.lang.CharSequence) "s#.#w1w#.#m1sx#.#LWCT#k");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", (int) (short) -1, 98);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test300");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong(" 4#4#4 4 ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test301");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "aaaaaaaaaaaaaaaaaaaaaaaaa", "100#0#-1#100");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test302");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Platform API Specification", "4444444444444444444444444mixed mode", "####a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaPlatfrAPISpcfcatn" + "'", str3.equals("JavaPlatfrAPISpcfcatn"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test303");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "100#0#-1#100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test304");
        float[] floatArray0 = new float[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#', (int) (byte) 10, 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray0, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray0, '4');
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("j#v# pl#tform api specific#tion", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j#v# pl#tform api specific#tion" + "'", str2.equals("j#v# pl#tform api specific#tion"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test306");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1#0", "0.52 0.23 0.1 0.1", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.5", 140, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test308");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10.0#1.0#1.0#0.0#1.0#10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test309");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) -1, (long) 32, (long) 13);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("   ", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   " + "'", str2.equals("   "));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test311");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_80");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       " + "'", str2.equals("       "));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test313");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                  \n                                                 ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test314");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test315");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.0A100.0", (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("10.0#1.0#1.0#0.0#1.0#10.0", "Eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0#1.0#1.0#0.0#1.0#10.0" + "'", str2.equals("10.0#1.0#1.0#0.0#1.0#10.0"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test317");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("444444 4#44", "0.0a1.0a1.0a0.0a1.0a10.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test318");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test319");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("j/tmp/run", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test320");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("enenenenenenenenenenenenenenenenenenenenenenenenene7", "b");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "4444444444444444444444444mixed mode", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/uSERS/SOPHIE/dOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_5221_1560279597", 2, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_5221_1560279597" + "'", str3.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_5221_1560279597"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test322");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaamAC os x", "aaa#a#a4a ", "1.04100.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("0 0 -1", "1.0a100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 0 -1" + "'", str2.equals("0 0 -1"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test324");
        double[] doubleArray4 = new double[] { 1, 1.0d, ' ', 25 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 6, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 32.0d + "'", double5 == 32.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("0sun.awt.CGraphicsEnvironment0sun.awt.CGraphicsEnvironment-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0SUN.AWT.cgRAPHICSeNVIRONMENT0SUN.AWT.cgRAPHICSeNVIRONMENT-1" + "'", str1.equals("0SUN.AWT.cgRAPHICSeNVIRONMENT0SUN.AWT.cgRAPHICSeNVIRONMENT-1"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("s#.#w1w#.#m1sx#.#LWCT#k", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s#.#w1w#.#m1sx#.#LWCT#k" + "'", str2.equals("s#.#w1w#.#m1sx#.#LWCT#k"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test327");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "enenenenenenenenenenenenenenenenenenenenenenenenene7", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/Java Virtual Machine SpecificationUsersJava Virtual Machine Specification/Java Virtual Machine SpecificationsophieJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationNetworkJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationSystemJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationusrJava Virtual Machine Specification/Java Virtual Machine SpecificationlibJava Virtual Machine Specification/Java Virtual Machine SpecificationjavaJava Virtual Machine Specification:.", "4444444444444444444444...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Java Virtual Machine SpecificationUsersJava Virtual Machine Specification/Java Virtual Machine SpecificationsophieJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationNetworkJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationSystemJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationusrJava Virtual Machine Specification/Java Virtual Machine SpecificationlibJava Virtual Machine Specification/Java Virtual Machine SpecificationjavaJava Virtual Machine Specification:." + "'", str2.equals("/Java Virtual Machine SpecificationUsersJava Virtual Machine Specification/Java Virtual Machine SpecificationsophieJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationNetworkJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationSystemJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationusrJava Virtual Machine Specification/Java Virtual Machine SpecificationlibJava Virtual Machine Specification/Java Virtual Machine SpecificationjavaJava Virtual Machine Specification:."));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sun#.#l##########################################################################################", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##" + "'", str2.equals("##"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "Environment Runtime SE Java(TM)", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test331");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 22, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                      " + "'", str3.equals("                      "));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test332");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed./library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsedlwawt/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed./library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsedmacosx/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed./library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsedLWCT/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsedoolkit", "SUN#.#L", 140);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test333");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment########################################################################ent########################################################################", (java.lang.CharSequence) "1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwct#oolkit1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test334");
        float[] floatArray6 = new float[] { 10L, (byte) 1, 1L, (byte) 0, 1L, 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 10.0f + "'", float8 == 10.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 10.0f + "'", float9 == 10.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.041.041.040.041.0410.0" + "'", str11.equals("10.041.041.040.041.0410.0"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 10.0f + "'", float12 == 10.0f);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test335");
        double[] doubleArray4 = new double[] { 1.0d, (short) 1, ' ', 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 140, 0);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.0a1.0a32.0a100.0" + "'", str14.equals("1.0a1.0a32.0a100.0"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test336");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "        a#a#a a         ", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test337");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Jv7va_8a-bJ5", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Jv7va_8a-bJ5" + "'", str3.equals("Jv7va_8a-bJ5"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 5, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaa" + "'", str3.equals("aaaaa"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test339");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "4", (java.lang.CharSequence) "/Java Virt...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("0.52 0.23 0.1 0.1", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.52 0.23 0.1 0.1" + "'", str2.equals("0.52 0.23 0.1 0.1"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test341");
        int[] intArray2 = new int[] { (short) 1, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', (int) (short) 100, (int) (byte) 10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', 7, 4);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "140" + "'", str4.equals("140"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1#0" + "'", str15.equals("1#0"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test342");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "10.0#1.0#1.0#0.0#1.0#10.", (java.lang.CharSequence) "aaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test343");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun#.#l", (java.lang.CharSequence) "10.0#1.0#1.0#0.0#1.0#10.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test344");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10.0a1.0a1.0a0.0a1.0a10.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test345");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("mixed mode", "1.7.0_80");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence1, (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray7 = null;
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(":4 4 4   # 4", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + ":4 4 4   # 4" + "'", str8.equals(":4 4 4   # 4"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test346");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" # #a ", "444444 4#44");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test347");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        boolean boolean5 = javaVersion1.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean7 = javaVersion3.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str9 = javaVersion8.toString();
        boolean boolean10 = javaVersion3.atLeast(javaVersion8);
        boolean boolean11 = javaVersion0.atLeast(javaVersion3);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.7" + "'", str9.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test348");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7.0_80-b15", (float) 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test349");
        char[] charArray9 = new char[] { 'a', '#', '#', '4', ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mixed mode", charArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0a1.0a1.0a0.0a1.0a10.0", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0 1.0 1.0 0.0 1.0 10.0", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_5221_1560279597", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "aa#a#a4a " + "'", str12.equals("aa#a#a4a "));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test350");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.0a1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.2", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("sun#.#lwawt#.#macosx#.#LWCT#oolki", "04041J#v# Pl#tform API Sp");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun#.#lwawt#.#macosx#.#LWCT#oolki" + "'", str2.equals("sun#.#lwawt#.#macosx#.#LWCT#oolki"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test353");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("140                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "140                           " + "'", str1.equals("140                           "));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("aaaaaaaaaaaaaaaaaaaaaaaaa", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test355");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, ' ', 98, 97);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test356");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 7.0f, (double) 28L, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.0d + "'", double3 == 28.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7" + "'", str1.equals("7"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test359");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("0#0#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#0#-1" + "'", str1.equals("0#0#-1"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("mAC os x", "/Java Virtual Machine SpecificationUsersJava Virtual Machine Specification/Java Virtual Machine SpecificationsophieJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationNetworkJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationSystemJava Virtual Machine Specification/Java Virtual Machine SpecificationLibraryJava Virtual Machine Specification/Java Virtual Machine SpecificationJavaJava Virtual Machine Specification/Java Virtual Machine SpecificationExtensionsJava Virtual Machine Specification:/Java Virtual Machine SpecificationusrJava Virtual Machine Specification/Java Virtual Machine SpecificationlibJava Virtual Machine Specification/Java Virtual Machine SpecificationjavaJava Virtual Machine Specification:.");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test361");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ', (int) (short) 10, 10);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test362");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("sun#.#lwawt#.#macosx#.#LWCT#oolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun#.#lwawt#.#macosx#.#LWCT#oolkit" + "'", str1.equals("sun#.#lwawt#.#macosx#.#LWCT#oolkit"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("0.52 0.23 0.1 0.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.52 0.23 0.1 0.1" + "'", str1.equals("0.52 0.23 0.1 0.1"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test364");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test365");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "eihpos/sresU");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test366");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test367");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 10, 5, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("44444040414444404041444440404144444040414444404041444440404144444040414444410a011a011a010a011a0110a0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444040414444404041444440404144444040414444404041444440404144444040414444410a011a011a010a011a0110a0" + "'", str1.equals("44444040414444404041444440404144444040414444404041444440404144444040414444410a011a011a010a011a0110a0"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test369");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun#.#l##########################################################################################", 32.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test370");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("4a4a4a a#a4");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10" + "'", str1.equals("100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10100 0 -1 10"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test372");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("http://java.oracle.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", (int) (short) 10, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("140", "                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "140" + "'", str2.equals("140"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test375");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) (short) -1, (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test376");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("http://java.oracle.com/", "sophie#", "#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test377");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 32, (float) 52, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test378");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "51.0", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test379");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test380");
        float[] floatArray6 = new float[] { 10L, (byte) 1, 1L, (byte) 0, 1L, 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0a1.0a1.0a0.0a1.0a10.0" + "'", str9.equals("10.0a1.0a1.0a0.0a1.0a10.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0 1.0 1.0 0.0 1.0 10.0" + "'", str11.equals("10.0 1.0 1.0 0.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 10.0f + "'", float12 == 10.0f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/", (int) (byte) 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                   /" + "'", str3.equals("                                                                                                   /"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test382");
        double[] doubleArray4 = new double[] { 1.0d, (short) 1, ' ', 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test383");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "US", (java.lang.CharSequence) "j#v# pl#tform api specific#tionts4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test384");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str3 = javaVersion2.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        boolean boolean8 = javaVersion4.atLeast(javaVersion6);
        java.lang.Class<?> wildcardClass9 = javaVersion6.getClass();
        boolean boolean10 = javaVersion2.atLeast(javaVersion6);
        boolean boolean11 = javaVersion0.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        java.lang.String str14 = javaVersion12.toString();
        boolean boolean15 = javaVersion0.atLeast(javaVersion12);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8" + "'", str3.equals("1.8"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.7" + "'", str14.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test385");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test386");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', (int) (short) 100, (-1));
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0404-1" + "'", str7.equals("0404-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0 0 -1" + "'", str14.equals("0 0 -1"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.0A100.0", 8, "aaa#a#a4a ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0A100.0" + "'", str3.equals("1.0A100.0"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test388");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", 28L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28L + "'", long2 == 28L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#1.01.", 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test390");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0d), (double) 32.0f, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test391");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.CPrinterJob", "", (int) '4');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "10.041.041.040.041.0410.0");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaa#a#a4a ", "aaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4aaaa#a#a4a");
        java.lang.CharSequence charSequence11 = null;
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence11, (java.lang.CharSequence[]) strArray13);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray13);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("CGraphicsEnvironment########################################################################", strArray10, strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("4444404041", strArray6, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "CGraphicsEnvironment########################################################################" + "'", str16.equals("CGraphicsEnvironment########################################################################"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4444404041" + "'", str17.equals("4444404041"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test392");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 426, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("0sun.awt.CGraphicsEnvironment0sun.awt.CGraphicsEnvironment-1", "####aa#a#a4a ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test394");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray10 = new char[] { ' ', ' ', 'a' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597", charArray10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ', (int) 'a', (int) ' ');
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray10);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray10);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " a#a#a a ", charArray10);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test395");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("100a0a-1a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100a0a-1a100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.1", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test397");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7.0_80");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test398");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#.#lwct#oolkit1.7.0_80-b15sun#.#lwawt#.#macosx#.#lwc", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test399");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("0a0a1", 13, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test400");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" 4#4#4 4 ", "51.051.051.051.051.                                                                                                    Java Virt...", 5);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test401");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("0a0a1#", '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("0 0 1", "0 0 1", 0);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit", strArray4, strArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun#.#lwawt#.#macosx#.#LWCT#oolkit", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str10.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("a0                            ", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a0                            " + "'", str2.equals("a0                            "));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test403");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("0.52 0.23 0.1 0.1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".52 0.23 0.1 0.1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test404");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("sun#.#lwawt#.#macosx#.#LWCT#oolki");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun#.#lwawt#.#macosx#.#LWCT#oolki\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test405");
        long[] longArray3 = new long[] { 0, (byte) 0, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, '#', 67, (int) '#');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0 0 1" + "'", str7.equals("0 0 1"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test406");
        char[] charArray7 = new char[] { ' ', ' ', 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444444mixed mode", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51.7", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mode Mixed", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("444440404", "   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444440404" + "'", str2.equals("444440404"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test408");
        int[] intArray2 = new int[] { (short) 1, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "140" + "'", str4.equals("140"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test409");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(".31.0#1.01.0#1.01.0#");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test410");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/7959720651_14225_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test411");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Oracle#Corporation");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test412");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(35.0f, (float) (short) 100, (float) 11);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test413");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "444441.041.0432.0425.0aaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate(" 4 4#4#4 ", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 4 4#..." + "'", str2.equals(" 4 4#..."));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test415");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597", 25, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test416");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Java Virt...", (java.lang.CharSequence) "4 4 4   # 4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test417");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test418");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolki");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolk" + "'", str1.equals("sun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolk"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE4444444444444444444444444MIXED MODE", "sun.awt...", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test420");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0.0f, (double) 10L, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/                                                                                                                                           ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/                                                                                                                                           " + "'", str2.equals("/                                                                                                                                           "));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test422");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("#.#w1w#.#m1sx#.#LWCT#k");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#.#w1w#.#m1sx#.#LWCT#k" + "'", str1.equals("#.#w1w#.#m1sx#.#LWCT#k"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test423");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(22, (int) (byte) 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 22 + "'", int3 == 22);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test424");
        double[] doubleArray2 = new double[] { (byte) 1, 1 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', 1, (int) (short) -1);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.0#1.0" + "'", str10.equals("1.0#1.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test425");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolkisun#.#lwawt#.#macosx#.#LWCT#oolki", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test426");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0 0 1", (java.lang.CharSequence) "A1.0A1.0A0.0A1.0A10.0#########################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test427");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test428");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporation", "");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("04041", ' ');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "100 0 -1 10", (java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0 1.0 1.0 0.0 1.0 10.0", 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, "1.0a100.0");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597", strArray8, strArray15);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("10.0#1.0#1.0#0.0#1.0#10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray3, strArray15);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10.0 1.0 1.0 0.0 1.0 10.0" + "'", str17.equals("10.0 1.0 1.0 0.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597" + "'", str18.equals("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_5221_1560279597"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10.0#1.0#1.0#0.0#1.0#10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str19.equals("10.0#1.0#1.0#0.0#1.0#10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test429");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("4444444444444444444444444444444444444444444444448-FTU44444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                                 \n                                                  ", 25, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test431");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("        a#a#a a         ", "                                                                                                    ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "        a#a#a a         " + "'", str3.equals("        a#a#a a         "));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test432");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("####aa#a#a4a#", "1.71.81.11.7", "1.2");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####aa#a#a4a#" + "'", str3.equals("####aa#a#a4a#"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("-1#1#100#0", "sun#.#lwawt#.#macosx#.#LWCT#oolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1#1#100#0" + "'", str2.equals("-1#1#100#0"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test434");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test435");
        char[] charArray6 = new char[] { ' ', '#', '#', ' ', ' ' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444444444444444444MIXED MODE", charArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray6, ' ', (int) '#', 0);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + " a#a#a a " + "'", str9.equals(" a#a#a a "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test436");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test437");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("####aa#a#a4a ", " ");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("0 0 1", "0 0 1", 0);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("stcefed/stnemucoD/eihpos/sresU/4r_nur/pmt/j4#4 4225_lp.poodn4t/7959720651_14#4 4lc/tegr4#4 4stcefed/stnemucoD/eihpos/sresU/:sess4rf/j4#4 4reneg_tset/bil/krowem4#4 4reneg/noit4#4 4r/noit4#4 4j.tnerruc-poodn4#4 4r", strArray3, strArray9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "stcefed/stnemucoD/eihpos/sresU/4r_nur/pmt/j4#4 4225_lp.poodn4t/7959720651_14#4 4lc/tegr4#4 4stcefed/stnemucoD/eihpos/sresU/:sess4rf/j4#4 4reneg_tset/bil/krowem4#4 4reneg/noit4#4 4r/noit4#4 4j.tnerruc-poodn4#4 4r" + "'", str10.equals("stcefed/stnemucoD/eihpos/sresU/4r_nur/pmt/j4#4 4225_lp.poodn4t/7959720651_14#4 4lc/tegr4#4 4stcefed/stnemucoD/eihpos/sresU/:sess4rf/j4#4 4reneg_tset/bil/krowem4#4 4reneg/noit4#4 4r/noit4#4 4j.tnerruc-poodn4#4 4r"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test438");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(28, (int) (short) 0, 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test439");
        short[] shortArray5 = new short[] { (byte) -1, (byte) 1, (short) 100, (short) 0, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 31, (int) (short) 0);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.Class<?> wildcardClass15 = shortArray5.getClass();
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1a1a100a0a1" + "'", str12.equals("-1a1a100a0a1"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("##########", "140                           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########" + "'", str2.equals("##########"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test442");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 100, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test443");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4#4#4 4 ", "1a0                            ", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Mac OS X", "Java HotSpot(TM) 64-Bit Server V", 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X" + "'", str3.equals("Mac OS X"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test445");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("SUN.AWT.cgRAPHICSeNVIRONMENT########################################################################");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test446");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Environment Runtime SE Java(TM)", "0a0a1#");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun#.#lwawt#sun#.#lwawt#", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test447");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1111101011", 9, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test448");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1a1a100a0a1", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test449");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "140                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test450");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1a0                            ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test451");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "#1.01.0#1.01.0#1.0110.14.31.0#1.01.0#1.01.0#", (java.lang.CharSequence) "Jv7va_8a-bJ5", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test452");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Java Virt...");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test453");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (-1), (long) 'a', 67L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test454");
        float[] floatArray6 = new float[] { 10L, (byte) 1, 1L, (byte) 0, 1L, 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0a1.0a1.0a0.0a1.0a10.0" + "'", str9.equals("10.0a1.0a1.0a0.0a1.0a10.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 10.0f + "'", float10 == 10.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0 1.0 1.0 0.0 1.0 10.0" + "'", str12.equals("10.0 1.0 1.0 0.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 10.0f + "'", float13 == 10.0f);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("        ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "..." + "'", str1.equals("..."));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("j#v# pl#tform api specific#tion", (int) (short) 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "j#v# pl#tform api specific#tion" + "'", str3.equals("j#v# pl#tform api specific#tion"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("7.15", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test458");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Java Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Platform API Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test459");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "SUN#.#LWAWT#.#MACOSX#.#LWCT#OOLKI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test460");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "444440404");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test461");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "# #a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test462");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/                                                                                                                                           ", (java.lang.CharSequence) "4444444444444444444444...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "10a011a011a010a011a0110a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test464");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mixed mode", "aaa#a#a4a", 11);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test465");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(6, 67, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test466");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4#4#4# ###4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test467");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) (byte) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test468");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.substringsBetween("", "hi!", "hi!");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("US", "4444444444444444444444444MIXED MODE");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(" ", strArray5, strArray8);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.CPrinterJob", "Oracle Corporation", (int) (short) -1);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52241_1560279597/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence[]) strArray15);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray15);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("100 0 -1 10", strArray5, strArray15);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + " " + "'", str9.equals(" "));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100 0 -1 10" + "'", str18.equals("100 0 -1 10"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test469");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.0a1.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test470");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 7, (float) ' ', 51.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 7.0f + "'", float3 == 7.0f);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test471");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("US");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: US is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test472");
        char[] charArray11 = new char[] { '4', '4', '4', ' ', '#', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Mixed mode", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaa", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test473");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Eihpos/sresU/", (java.lang.CharSequence) "#-14-14#-14-14#-14--41-413-14#-14-14#-14-14#", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 44 + "'", int3 == 44);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test474");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "100.0a1.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "mixed mode" + "'", charSequence2.equals("mixed mode"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test475");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7959720651_14225_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("140                            ", "sun#.#l##########################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "140                            " + "'", str2.equals("140                            "));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test477");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("-1a1a100a0a1", "Java HotSpot(TM) 64-Bit Server VM", "                                                                                                   /");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test478");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ":4 4 4   # 4", "10.0#1.0#1.0#0.0#1.0#10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("aaaaa", "-1#1#100#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test480");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1." + "'", str3.equals("1."));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test481");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaa:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test482");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0 0 ", 28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("-14141004041");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-14141004041" + "'", str1.equals("-14141004041"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test484");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "raj.tne...", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaa:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("r4...", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r4..." + "'", str2.equals("r4..."));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test486");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(".31.0#1.01.0#1.01.0#", "r4...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test487");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str5 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.5" + "'", str5.equals("1.5"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test488");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "sun#.#l", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test489");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Jv7va_8a-bJ5", 11, 25);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5" + "'", str3.equals("5"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("44", "/uSERS/SOPHIE/dOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_5221_1560279597");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44" + "'", str2.equals("44"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test491");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                 \n                                                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test492");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0a0a1#");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("CGraphicsEnvironment########################################################################", "04041");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CGraphicsEnvironment########################################################################" + "'", str2.equals("CGraphicsEnvironment########################################################################"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test494");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0 0 -1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test496");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " a#a#a a ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaa:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test497");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test498");
        double[] doubleArray2 = new double[] { (byte) 1, 1 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0#1.0" + "'", str5.equals("1.0#1.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0#1.0" + "'", str7.equals("1.0#1.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0#1.0" + "'", str9.equals("1.0#1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.0#1.0" + "'", str11.equals("1.0#1.0"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test499");
        short[] shortArray5 = new short[] { (byte) -1, (byte) 1, (short) 100, (short) 0, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 31, (int) (short) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-14141004041" + "'", str11.equals("-14141004041"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("####aa#a#a4a ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####aa#a#a4a" + "'", str1.equals("####aa#a#a4a"));
    }
}

