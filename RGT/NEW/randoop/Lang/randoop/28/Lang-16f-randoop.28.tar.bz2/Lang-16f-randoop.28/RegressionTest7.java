import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " " + "'", str1.equals(" "));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rver24.80-b11c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Mac4OS4XMac4OS4XMac4OS4XMac4OS4XMac", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(6.0d, (double) (-1), (double) 51.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 51.0d + "'", double3 == 51.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/U1.7", 216, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################################################################################################################################################################################################/U1.7" + "'", str3.equals("###################################################################################################################################################################################################################/U1.7"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("c os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rver24.80-b11c os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os", "1.6");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/var/folde");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "        ", (java.lang.CharSequence) "ts4j/t uments/defe /Users/sophie/Do", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                             #######");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(50.0f, (float) 4, (float) 34L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 50.0f + "'", float3 == 50.0f);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4xed mode", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/foldeedom dexim", "          Java Platform API Specification           ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4cc cc" + "'", str3.equals("4cc cc"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("c OSaM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4.80-b1144444444444444444444444444", ".7.0_80-B15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11", "44444444444444444444444444444444", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11" + "'", str3.equals("...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/USERS/SOPHIE/VAR/FOLDERS/_V/6V");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "vgS01g;BB [Lv", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("x86_64");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x86_64\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("edom dex", ' ');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "Mac OS X");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "7.0_");
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray3, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("!ih");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"!ih\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7.0_804.");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("C OS XaMc OS XaM", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Java Virtual Machine Specification                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification                                                              " + "'", str1.equals("Java Virtual Machine Specification                                                              "));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("51b-08_0.7.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51b-08_0.7.1" + "'", str1.equals("51b-08_0.7.1"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("class [Fclass [Dclass org.apache.commons.lang3.JavaVersion", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 9, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(" SO cM X SO c", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " SO cM X SO c" + "'", str2.equals(" SO cM X SO c"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"n\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1b-08_0.7.", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 0, (double) '4', (double) 5);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/US", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 50, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "51b-08_0.7", (java.lang.CharSequence) "1.1", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("#######");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(215, 121, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.1", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96608_1560211995", "t");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(".ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja1.7.0_80hie/Libr", "Mac OS X", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja1.7.0_80hie/Libr" + "'", str3.equals(".ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja1.7.0_80hie/Libr"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        char[] charArray11 = new char[] { '4', ' ', ' ', ' ' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mode", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specification", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "####################################################", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "!orm API Specification", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "###################################################################################################################################################################################################################/U1.7", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                           /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE                           ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 121 + "'", int1 == 121);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("fc0000gn/T4_v31cq2n2x1n4/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/folders/_v/6v597zmn", "          Java Platform API Specification           ", 512);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("SUN.LWAWT.MACOSX.LWCTOOLKIT", "          Java Platform API Specification           ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/         .80-b11");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 100, (float) (byte) 100, (float) 3200);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3200.0f + "'", float3 == 3200.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("####################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################" + "'", str1.equals("####################################################"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.7.0_804.", (java.lang.CharSequence) "              .80-B11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie", "caMX SO caMX SO caMX Mac OS caMX SO caMX SO caMX S", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                                                                                                                                        ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 49, (long) 10, 9L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96608_1560211995/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j/tmp/run_randoop.pl_96608_1560211995/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("j/tmp/run_randoop.pl_96608_1560211995/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Java Virtual Machine Specification                                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("xedmode", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "51b-08_0.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rver24.80-b11c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS", (java.lang.CharSequence) "1.7.0_80-b15aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "51b-08_0.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("!ih", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!ih" + "'", str2.equals("!ih"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        long[] longArray2 = new long[] { 10L, 32 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java Virtual Machine Specification                                                               ", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("c OS XaM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"c OS XaM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("  5   ", (int) (short) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  5   " + "'", str3.equals("  5   "));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1560211995");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1560211995 + "'", int1 == 1560211995);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "0.", (java.lang.CharSequence) "4.80-b1", 125);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                                                                                                                                                                                                        ", (java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96608_1560211995");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "edom dex                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:4.80-b1144444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:4.80-b1144444444444444444444444444" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:4.80-b1144444444444444444444444444"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "!orm API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                "));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "8-b", (java.lang.CharSequence) "UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Do uments/defe ts4j/t", 5.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("...rver VM...rver VM...rver VM...rver VM...10.14.3");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ".80-b", (java.lang.CharSequence) "caMX SO caMX SO caMX SO caMX SO caM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("a.80-b1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1u7u._n.uJDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96608_1560211995/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "4.80-b1144444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96608_1560211995/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96608_1560211995/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                  " + "'", str2.equals("                                  "));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie/Do uments/defe ts4j/tmp/runr ndooppl9666299/t rget/ l sses:/Users/sophie/Do uments/defe ts4j/fr mework/li/testgener tion/gener tion/r ndoop urrentj r", (java.lang.CharSequence) "          Java Platform API Specification           ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mac OS ", 1560211995);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("mAC os xmAC os xmAC os xmAC os xmAC", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporation", ".80-b11");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("#########################################oRACLE cORPmixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#########################################oRACLE cORPmixed mode" + "'", str1.equals("#########################################oRACLE cORPmixed mode"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Virtual Machine Specification", "/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/", "C OS XaM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J Vitu MhiS SpiitiS" + "'", str3.equals("J Vitu MhiS SpiitiS"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("A.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "                                                  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/         ", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                          /         " + "'", str2.equals("                                                                                          /         "));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("9.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.aaaaaaa0.99.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("ot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ot(TM) 64-Bit Server V" + "'", str1.equals("ot(TM) 64-Bit Server V"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("51b-08_0.7", " OS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51b-08_0.7" + "'", str2.equals("51b-08_0.7"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sophie", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("mixed mod", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("51b-08_0.7.", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTEOracle Corporation/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51b-08_0.7." + "'", str2.equals("51b-08_0.7."));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31", 0, 139);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("ers/sophie/Library/Java/Extensions:/Library/Java/E");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ers/sophie/Library/Java/Extensions:/Library/Java/E\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("a4xed modeaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "              .80-b11", ":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja1.7.0_80hie/Libr");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a4xed modeaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("a4xed modeaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter(".7.0_80-B15", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".7.0_80-B15" + "'", str2.equals(".7.0_80-B15"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "                i!                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("7.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"7.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) (byte) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "51b-08_0.7", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rver24.80-b1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Jav/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a Platform API Specification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("EDOM DEXIM", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "              .80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 10, (float) 217L, 52.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 217.0f + "'", float3 == 217.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                i!                ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#" + "'", str1.equals("mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) (byte) 100, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5" + "'", str1.equals("5"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "i", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "edom dex                                            ", 125);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "su");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("51B-08_0.7.1", "j/tmp/run_randoop.pl_96608_1560211995/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "B-08_0.7.1" + "'", str2.equals("B-08_0.7.1"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "mxdmd", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/foldeedom dexim");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("UoF-8", "MaXaSOacMaXaSOac");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UoF-8" + "'", str2.equals("UoF-8"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("lwawt.macosx.LWCToolkit", "j/tmp/run_randoop.pl_96608_1560211995/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "lwawt.macosx.LWCToolkit" + "'", str2.equals("lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96608_1560211995/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", 3200);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96608_1560211995/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             " + "'", str2.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96608_1560211995/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             "));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4.80-b1144444444444444444444444444", "                                                                                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        char[] charArray8 = new char[] { '4', ' ', ' ', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mode", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "...rver VM", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaa0.9                                                                                                               ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 7 + "'", int11 == 7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("UoF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UoF-8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.9", (java.lang.CharSequence) " SO cMaX SO c");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 4444444444L, (float) '4', (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.4444447E9f + "'", float3 == 4.4444447E9f);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "C OS XaM", 2);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("24.80-b11");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "!orm API Specifiction");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rver24.80-b1", "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("51b-08_0.7.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51B-08_0.7.1" + "'", str1.equals("51B-08_0.7.1"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS X", (java.lang.CharSequence) "Java Virtual Machine Specification", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("C OS XaM", "sophie", "1.71.71                     1.71.71");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "C OS XaM" + "'", str3.equals("C OS XaM"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "0.15      ", (java.lang.CharSequence) "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "[Ljava.l", (java.lang.CharSequence) "edom dexim");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("J v  HotSpot(TM) 64-Bit Server VM", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 79 + "'", int1 == 79);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "C OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVER24.80-B11C OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS", (java.lang.CharSequence) "1.71.71                     1.71.71", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rver24.80-b11", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.1", (java.lang.CharSequence) "c OS XaM", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "51b-08_0.7.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("mac OS ", "1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mac OS " + "'", str2.equals("mac OS "));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java HotSpot(TM) 64-Bit Server VM", (double) 5.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Mac OS", ":Mac4OS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS" + "'", str2.equals("Mac OS"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sun.awt.CGraphicsEnvironment", "ot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        int[] intArray1 = new int[] { 49 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49 + "'", int2 == 49);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                                                                                                                                                                                 ", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                 " + "'", str2.equals("                                                                                                                                                                                                                 "));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                          /         ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "mac OS ", (java.lang.CharSequence) "9.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "C OS XaMc OS XaM", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96608_1560211995/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lw4wt.m4cosx.LWCToolkit", "###############################################################n################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("              .80-b11", 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("44444444444444444444444444444444444444444444444444", 215);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                  44444444444444444444444444444444444444444444444444                                                                                   " + "'", str2.equals("                                                                                  44444444444444444444444444444444444444444444444444                                                                                   "));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                  ", 3, 3200);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 10L, (float) (byte) -1, (float) 32);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 121);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "#", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/foldeedom dexim", "J");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/foldeedom dexim" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/foldeedom dexim"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (byte) 10, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#", (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase(":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja1.7.0_80hie/Libr", " OS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja1.7.0_80hie/Libr" + "'", str2.equals(":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja1.7.0_80hie/Libr"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("          Java Platform API Specification           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("C OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVER24.80-B11C OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "COSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOS...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVER24.80-B11COSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOS" + "'", str2.equals("COSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOS...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVER24.80-B11COSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOS"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 215, "Class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Class [Ljava.lang.String;class [Ljava.lang.String;class [aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaClass [Ljava.lang.String;class [Ljava.lang.String;class [L" + "'", str3.equals("Class [Ljava.lang.String;class [Ljava.lang.String;class [aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaClass [Ljava.lang.String;class [Ljava.lang.String;class [L"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                                                                                                                                                                                                                         ", (java.lang.CharSequence) "1.7.0_807.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                            MacaOSaX                                             ", "c os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rver24.80-b11c os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os", 52, 3200);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                            MacaOSaXc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rver24.80-b11c os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os" + "'", str4.equals("                                            MacaOSaXc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rver24.80-b11c os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96608_1560211995", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("7.0", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(32, 21, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", "J Vitu MhiS SpiitiS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str2.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1560211995, 32.0d, (double) 121);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.560211995E9d + "'", double3 == 1.560211995E9d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "c OSaM");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "http://java.oracle.com/");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        long[] longArray3 = new long[] { (byte) 0, (short) 1, (short) -1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("####################################################################################################", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/var/folde");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folde" + "'", str1.equals("/var/folde"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "a4xed modeaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 43 + "'", int1 == 43);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/USERS/SOPHIE/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/EIHPOS/SRESU/ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/" + "'", str1.equals("T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/EIHPOS/SRESU/ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("              x86_64              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "              x86_64             " + "'", str1.equals("              x86_64             "));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("a.80-b1", "A8-B::", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/   ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sun.awt.CGrapcsEnvronment", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "pcsEnvronmentawt.CGrasun." + "'", str2.equals("pcsEnvronmentawt.CGrasun."));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "9.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                  ", "1b-08_0.7.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                             #######", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0.9");
        java.math.BigDecimal bigDecimal3 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0.9");
        java.math.BigDecimal bigDecimal5 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0.9");
        java.math.BigDecimal bigDecimal7 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0.9");
        java.math.BigDecimal[] bigDecimalArray8 = new java.math.BigDecimal[] { bigDecimal1, bigDecimal3, bigDecimal5, bigDecimal7 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray8);
        org.junit.Assert.assertNotNull(bigDecimal1);
        org.junit.Assert.assertNotNull(bigDecimal3);
        org.junit.Assert.assertNotNull(bigDecimal5);
        org.junit.Assert.assertNotNull(bigDecimal7);
        org.junit.Assert.assertNotNull(bigDecimalArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.90.90.90.9" + "'", str9.equals("0.90.90.90.9"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.90.90.90.9" + "'", str10.equals("0.90.90.90.9"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("i!", "class [Fclass [Dclass org.apache.commons.lang3.JavaVersion", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        char[] charArray5 = new char[] { '#', '4' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "x86_64", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "a.80-b11", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " OS", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.2", "                           /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE                           ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2" + "'", str3.equals("2"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "        ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("a.80-b1");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "51b-08_0.7.");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a51b-08_0.7..51b-08_0.7.8051b-08_0.7.-51b-08_0.7.b51b-08_0.7.1" + "'", str3.equals("a51b-08_0.7..51b-08_0.7.8051b-08_0.7.-51b-08_0.7.b51b-08_0.7.1"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                  Java Platform API Specification                                   ", 9, "edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rac OS XaM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                  Java Platform API Specification                                   " + "'", str3.equals("                                  Java Platform API Specification                                   "));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("sun.lw4wt.m4cosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lw4wt.m4cosx.LWCToolkit" + "'", str1.equals("sun.lw4wt.m4cosx.LWCToolkit"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Mac OS X");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "7.0_");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence[]) strArray7);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#", (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"        \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(" OS");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/var/folders/_v/6v597zmn4_v31", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", '4');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("1.7", "1.7");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                        hi!                         ", strArray7, strArray10);
        java.lang.Class<?> wildcardClass12 = strArray7.getClass();
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                                     Java Platform API Specification", (java.lang.CharSequence[]) strArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification                                                               ", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "                        hi!                         " + "'", str11.equals("                        hi!                         "));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("a.80-b11", "...aaaaa...aaaaa...aaaaa...aaaaa...aaaaa...aa1b-08_0.7....aaaaa...aaaaa...aaaaa...aaaaa...aaaaa...aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a.80-b11" + "'", str2.equals("a.80-b11"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/   ", "/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ers/sophie/Library/Java/Extensions:/Library/Java/E", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "PI Specification");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ers/sophie/LibrPI Specificationry/JPI SpecificationvPI Specification/Extensions:/LibrPI Specificationry/JPI SpecificationvPI Specification/E" + "'", str4.equals("ers/sophie/LibrPI Specificationry/JPI SpecificationvPI Specification/Extensions:/LibrPI Specificationry/JPI SpecificationvPI Specification/E"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "JJJJJJJJJJJJJJ4JJJJJJJJJJJJJJx86_");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444", "a51b-08_0.7..51b-08_0.7.8051b-08_0.7.-51b-08_0.7.b51b-08_0.7.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "a51b-08_0.7..51b-08_0.7.8051b-08_0.7.-51b-08_0.7.b51b-08_0.7.1", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("pcsEnvronmentawt.CGrasun.", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Do uments/defe ts4j/tmp/run_r ndoop.pl_96608_1560211995/t rget/ l sses:/Users/sophie/Do uments/defe ts4j/fr mework/lib/test_gener tion/gener tion/r ndoop- urrent.j r", "4cc cc", "4.80-b1", (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Do uments/defe ts4j/tmp/run_r ndoop.pl_96608_1560211995/t rget/ l sses:/Users/sophie/Do uments/defe ts4j/fr mework/lib/test_gener tion/gener tion/r ndoop- urrent.j r" + "'", str4.equals("/Users/sophie/Do uments/defe ts4j/tmp/run_r ndoop.pl_96608_1560211995/t rget/ l sses:/Users/sophie/Do uments/defe ts4j/fr mework/lib/test_gener tion/gener tion/r ndoop- urrent.j r"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("...aaaaa...aaaaa...aaaaa...aaaaa...aaaaa...aa1b-08_0.7....aaaaa...aaaaa...aaaaa...aaaaa...aaaaa...aa", "                     mixed mod#                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...aaaaa...aaaaa...aaaaa...aaaaa...aaaaa...aa1b-08_0.7....aaaaa...aaaaa...aaaaa...aaaaa...aaaaa...aa" + "'", str2.equals("...aaaaa...aaaaa...aaaaa...aaaaa...aaaaa...aa1b-08_0.7....aaaaa...aaaaa...aaaaa...aaaaa...aaaaa...aa"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("              .80-B11", "", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96608_1560211995/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) ":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja1.7.0_80hie/Libr", (java.lang.CharSequence) "4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("o");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "o" + "'", str1.equals("o"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V", 79);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("US", 0, 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444" + "'", str2.equals("4444444"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("              4              x86_6", "#######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              4              x86_6" + "'", str2.equals("              4              x86_6"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("EDOM DEXIM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EDOM DEXI" + "'", str1.equals("EDOM DEXI"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "c OS XaMc OS XaM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("4444444444444444444444444411b-08.4:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444411b-08.4:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU" + "'", str1.equals("4444444444444444444444444411b-08.4:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                          /         ", 9, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                          /         " + "'", str3.equals("                                                                                          /         "));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a', 49, (int) 'a');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("c OSaM", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "MIXED MOD#", (java.lang.CharSequence) "                                  Java Platform API Specification                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#" + "'", str3.equals("Mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.1", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("\n", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("#####", "...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11", "mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#####" + "'", str3.equals("#####"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Jav/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a Platform API Specification", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1u7u._n.uJDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("lass [Fc", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(50L, 0L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 50L + "'", long3 == 50L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11", (java.lang.CharSequence) "lwawt.macosx.LWCToolkit", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd(" OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS X", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS X" + "'", str2.equals(" OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS X"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) ":", (java.lang.CharSequence) "a.80-b1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(121L, (long) 217, (long) 125);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 121L + "'", long3 == 121L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("MIXED MOD#", (int) (byte) -1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MIXED MOD#" + "'", str3.equals("MIXED MOD#"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTEOracle Corporation/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("XED MODE", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "XED MODE" + "'", str3.equals("XED MODE"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rac OS XaM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "US", (java.lang.CharSequence) "                                                             4                                                             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("j v  HotSpot(TM) 64-Bit Server VM", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "j v  HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("j v  HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", ".ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja1.7.0_80hie/Libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11", "sun.awt.CGrapcsEnvronment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11" + "'", str2.equals("...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        short[] shortArray5 = new short[] { (byte) 1, (short) 100, (byte) 10, (short) 0, (byte) 0 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 49, 79);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "n.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                            Mac4OS4X                                             ", 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 0, (long) 3200, 8L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Java Virtual Machine Specification                                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Virtual Machine Specification                                                              \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("MaXaSOacMaXaSOac", 512);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                MaXaSOacMaXaSOac" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                MaXaSOacMaXaSOac"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                MaXaSOacMaXaSOac");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MaXaSOacMaXaSOac" + "'", str1.equals("MaXaSOacMaXaSOac"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "lwawt.macosx.LWCToolkit", " SO cM X SO c");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", 132, 1560211995);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1." + "'", str1.equals("1."));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        long[] longArray2 = new long[] { 10L, 32 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Mac OS XA8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B:", "...rver VM", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("###################################################################################################################################################################################################################/U1.7");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/EIHPOS/SRESU/ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("A.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1", "/Users/sophie/Do uments/defe ts4j/tmp/runr ndooppl9666299/t rget/ l sses:/Users/sophie/Do uments/defe ts4j/fr mework/li/testgener tion/gener tion/r ndoop urrentj r");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "A.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1" + "'", str2.equals("A.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1a.80-b1"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                                             4                                                             ", 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaa0.9", "U", 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("aaaaaaa0.9                                                                                                               ", "mixed mod", "Class [Ljava.lang.String;class [Ljava.lang.String;class [aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaClass [Ljava.lang.String;class [Ljava.lang.String;class [L", 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaa0.9                                                                                                               " + "'", str4.equals("aaaaaaa0.9                                                                                                               "));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "UoF-8", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("44444444444444444444444444444444", "UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/         .80-b11", 9, 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96608_1560211995");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96608_1560211995\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#mixed mod#", "edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rav/edlof/rac OS XaM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("COSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOS...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVER24.80-B11COSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOS", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                  Java Platform API Specification                                   ", "1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                  Java Platform API Specification                                   " + "'", str2.equals("                                  Java Platform API Specification                                   "));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("hi!");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.7.0_80-b15aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) ' ', 128);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                     Java Platform API Specification", 3200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3200 + "'", int2 == 3200);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/UShttp://java.oracle.com/US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaa0.9", (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("#...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#..." + "'", str2.equals("#..."));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "edom dex                                            ", charSequence1, 512);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (int) (short) 100, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str3.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.", 35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaa0.9                                                                                                               ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaa0.9                                                                                                               " + "'", str2.equals("aaaaaaa0.9                                                                                                               "));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("su", "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rver24.80-b11c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "su" + "'", str2.equals("su"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "...rver vm...rver vm...rver vm...rver vm...rver vm...rver vm...rver vm...rver vm...rver 24.80-b11", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 132, (double) 132.0f, (double) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Mac OS", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("          ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "ot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "c OS XaM", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("ers/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Java Virtual Machine Specification                                                              ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("java(TM) SE Runtime Environment");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96608_1560211995/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                     Java Platform API Specification", (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(216, 8, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("xedmode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"xedmode\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(32, 29, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 29 + "'", int3 == 29);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "i!orm API Specification", (java.lang.CharSequence) "VA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(34, 43, 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 34 + "'", int3 == 34);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("5", "1.7.0_80hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5" + "'", str2.equals("5"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                ", (int) ' ', 50);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class [Lj" + "'", str2.equals("class [Ljava.lang.String;class [Lj"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", '4');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("...aaaaa", "Java(TM) SE Runtime Environment");
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("  5   ", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 1, 8, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.lw4wt.m4cosx.LWCToolkit", (int) (short) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lw4wt.m4cosx.LWCToolkit" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lw4wt.m4cosx.LWCToolkit"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("10.1.3", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("[Ljava.l");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[lJAVA.L" + "'", str1.equals("[lJAVA.L"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "class [Fclass [Dclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS XMac OS XMac OS XMac OS XMac", '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac" + "'", str4.equals("Mac OS XMac OS XMac OS XMac OS XMac"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.6", "                                                                                                                                                                                                                                                                                                                                                                                                ###############################################################n################################################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("              .80-b11", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lw4wt.m4cosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lw4wt.m4cosx.LWCToolkit" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lw4wt.m4cosx.LWCToolkit"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                                          java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"    \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7.0_804.", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("JJJJJJJJJJJJJJ4JJJJJJJJJJJJJJx86_6");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("4444444", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444" + "'", str2.equals("4444444"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "1.2", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("a", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray11 = new char[] { '#', '#', '4', 'a', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence5, charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed mode", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96608_1560211995", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51B-08_0.7.1", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "c OS XaMcAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rverVM...rver24.80-b11c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/users/sophie/libraryc OSaM/users/sophie/library/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/libraryc OSaM/users/sophie/library/" + "'", str2.equals("/users/sophie/libraryc OSaM/users/sophie/library/"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("####################################sun.awt.CGrapcsEnvronment####################################", ":Mac4OS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "!orm api specification", (java.lang.CharSequence) "/users/sophie/libraryc OSaM/users/sophie/library/", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "A.80-b1", 3, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("a.80-b11", "44444444444444444444444444444444444444444444444444", "Java HotSpot(TM) 64-Bit Server V", 217);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "a.80-b11" + "'", str4.equals("a.80-b11"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        char[] charArray6 = new char[] { '4', ' ', ' ', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mode", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray6);
        java.lang.Class<?> wildcardClass9 = charArray6.getClass();
        char[] charArray16 = new char[] { '4', ' ', ' ', ' ' };
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mode", charArray16);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray16);
        java.lang.Class<?> wildcardClass19 = charArray16.getClass();
        java.lang.Class[] classArray21 = new java.lang.Class[2];
        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray22 = (java.lang.Class<?>[]) classArray21;
        wildcardClassArray22[0] = wildcardClass9;
        wildcardClassArray22[1] = wildcardClass19;
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join(wildcardClassArray22);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(classArray21);
        org.junit.Assert.assertNotNull(wildcardClassArray22);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "class [Cclass [C" + "'", str27.equals("class [Cclass [C"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left(" ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "              x86_64              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("ers/sophie/Library/Java/Extensions:/Library/Java/E", "51B-08_0.7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51B-08_0.7.1" + "'", str2.equals("51B-08_0.7.1"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80-B15", 132, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 6L, (float) 100, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("9.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "9.0" + "'", str1.equals("9.0"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("\n");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("1.6", "4");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("...aaaaa", strArray2, strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "...aaaaa" + "'", str6.equals("...aaaaa"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\n" + "'", str8.equals("\n"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaaaaaa0.9", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("51B-08_0.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51b-08_0.7" + "'", str1.equals("51b-08_0.7"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray10 = new char[] { '#', '#', '4', 'a', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence4, charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed mode", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96608_1560211995", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "9.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09.09", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "7.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("i!", "J Vitu MhiS SpiitiS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!" + "'", str2.equals("i!"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { '4', ' ', ' ', ' ' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mode", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4.80-b", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.14.3", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Jav/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a Platform API Specification", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(".ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja1.7.0_80hie/Libr", 512);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "                        hi!                         ");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "C OS XaM", 0, 123);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("pcsEnvronmentawt.CGrasun.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "pcsEnvronmentawt.CGrasun." + "'", str1.equals("pcsEnvronmentawt.CGrasun."));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "B-08_0.7.1", 29);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("51b-08_0.7.1", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("c OS XaMc OS XaM", "1.1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Virtual Machine Specification                                                              ", (int) 'a', 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "i!orm API Specification", 128);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("          Java Platform API Specification           ", "              .80-B11", 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          Java Platform API Specification           " + "'", str3.equals("          Java Platform API Specification           "));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", "lwawt.macosx.LWCToolkit");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str3.equals("Class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sophie", "Class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str2.equals("Class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(4, (int) (byte) -1, 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 21 + "'", int3 == 21);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("vL[ BB;g10Sgv", (double) 8L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("A.80-B11");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("!orm API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!orm API Specification" + "'", str1.equals("!orm API Specification"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("#########################################oRACLEcORPmixedmode", "...aaaaa...aaaaa...aaaaa...aaaaa...aaaaa...aa1b-08_0.7....aaaaa...aaaaa...aaaaa...aaaaa...aaaaa...aa", "ers/sophie/LibrPI Specificationry/JPI SpecificationvPI Specification/Extensions:/LibrPI Specificationry/JPI SpecificationvPI Specification/E", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#########################################oRACLEcORPmixedmode" + "'", str4.equals("#########################################oRACLEcORPmixedmode"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("              .80-b11", "                   ", 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "              .80-b11" + "'", str3.equals("              .80-b11"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("7.0_", "444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 139);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1", 216);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                           1                                                                                                            " + "'", str2.equals("                                                                                                           1                                                                                                            "));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4.80-b", "A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1", 34);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a.80-b1", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 127 + "'", int1 == 127);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("              4              x86_6", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "  -1.0 # -1", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("4444444444444444444444444411b-08.4:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", "7.0", 215);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444411b-08.4:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str3.equals("4444444444444444444444444411b-08.4:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("n", 100, "                                                                                                                                                                                                                                                                                                                                                                                                ###############################################################n################################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                 n                                                  " + "'", str3.equals("                                                 n                                                  "));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ", (java.lang.CharSequence) "###################################################################################################################################################################################################################/U1.7", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("C OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVER24.80-B11C OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS XAMC OS", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("51.0", "1.");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "!orm api specification", 128);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                            MacaOSaXc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rver24.80-b11c os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.4", (java.lang.CharSequence) "AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("J");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J" + "'", str1.equals("J"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/foldeedom dexim");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/var/foldeedom dexim\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("rver vm...rver vm...rver vm...rver vm...rver vm...rver vm...rver vm...rver vm...rver 24", 96);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("n.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "51b-08_0.7", 127);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("su");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"su\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { '#', '#', '4', 'a', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed mode", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac4OS4X", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("MAC OS ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MAC OS " + "'", str2.equals("MAC OS "));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("rver vm...rver vm...rver vm...rver vm...rver vm...rver vm...rver vm...rver vm...rver 24", "                           /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE                           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rver vm...rver vm...rver vm...rver vm...rver vm...rver vm...rver vm...rver vm...rver 24" + "'", str2.equals("rver vm...rver vm...rver vm...rver vm...rver vm...rver vm...rver vm...rver vm...rver 24"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("XED MODE", '#');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("caMX SO caMX SO caMX SO caMX SO caM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "caMX SO caMX SO caMX SO caMX SO caM" + "'", str1.equals("caMX SO caMX SO caMX SO caMX SO caM"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                 n                                                  ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("c os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rver24.80-b11c os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96608_1560211995", 139);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "caMX SO caMX SO caMX SO caMX SO caM", (java.lang.CharSequence) "aaaaaaa0.9                                                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/#", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 15);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("t");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "t" + "'", str1.equals("t"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaa0.9", "0.15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(1.0d, (double) 29, (double) 49);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:4.80-b1144444444444444444444444444", "aaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:4.80-b1144444444444444444444444444" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:4.80-b1144444444444444444444444444"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("A.80-B11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a.80-b11" + "'", str1.equals("a.80-b11"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7", ' ');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ers/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ers/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str3.equals("ers/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("          Java Platform API Specification           ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java Platform API Specificatio", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                                            10.14.3                                                             ", "512");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                            10.14.3                                                             " + "'", str2.equals("                                                            10.14.3                                                             "));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("9.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "9.0" + "'", str1.equals("9.0"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("caMX SO caMX SO caMX SO caMX SO caM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "caMX SO caMX SO caMX SO caMX SO caM" + "'", str1.equals("caMX SO caMX SO caMX SO caMX SO caM"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:4.80-b1144444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                     ", 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "4.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b114.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("4.80-b1", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lw4wt.m4cosx.LWCToolkit", 79, 217);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion1.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray4 = new java.lang.reflect.GenericDeclaration[] { wildcardClass3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(genericDeclarationArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "class org.apache.commons.lang3.JavaVersion" + "'", str5.equals("class org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("PI Specification", 139);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PI Specification" + "'", str2.equals("PI Specification"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", (java.lang.CharSequence) "aa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                            Mac4OS4X                                             ", 217, "xed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "xed modexed modexed modexed modexed modexed modexed modexed                                             Mac4OS4X                                             xed modexed modexed modexed modexed modexed modexed modexed " + "'", str3.equals("xed modexed modexed modexed modexed modexed modexed modexed                                             Mac4OS4X                                             xed modexed modexed modexed modexed modexed modexed modexed "));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("###########n############");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java Platform API Specificatio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Jav\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.15      ", "0.15      ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4444444444", "...rver VM...rver VM...rver VM...rver VM...10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", 100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("http://java.oracle.com/", 8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java HotSpot(TM) 64-Bit Server V", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                                                           1                                                                                                            ", 512);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                           1                                                                                                            " + "'", str2.equals("                                                                                                           1                                                                                                            "));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 10, 3200.0f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3200.0f + "'", float3 == 3200.0f);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "              Oracle Corporation", (java.lang.CharSequence) "o");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaa", (double) 34L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.0d + "'", double2 == 34.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Mac4OS4X", 4, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 0, 0L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "[lJAVA.L");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("class org.apache.commons.lang3.JavaVersion", "51B-08_0.7");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Mac OS XA8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B::A8-B:", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "B-08_0.7.1", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("9.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                     Java Platform API Specification", "Mac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS X", (int) (byte) -1);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS X", "xed mode", 34);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("\n", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 34");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("#########################################oRACLE cORPORATION#########################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                                                          caMX SO caMX SO caMX SO caMX SO caM", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 3200);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                          caMX SO caMX SO caMX SO caMX SO caM" + "'", str3.equals("                                                                                          caMX SO caMX SO caMX SO caMX SO caM"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.Class<?> wildcardClass5 = byteArray1.getClass();
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "Java Platform API Specification", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                                                                                                                                                                                       i!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "XED MODE", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                            MacaOSaX                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                            MacaOSaX                                             " + "'", str1.equals("                                            MacaOSaX                                             "));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0.15", (java.lang.CharSequence) "ers/sophie/LibrPI Specificationry/JPI SpecificationvPI Specification/Extensions:/LibrPI Specificationry/JPI SpecificationvPI Specification/E");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("COSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOS...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVER24.80-B11COSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOS");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"COSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOS...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVERVM...RVER24.80-B11COSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOSXAMCOS\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("4", ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray3, strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, 'a');
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver VM...rver 24.80-b11", "1.");
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("                   ", strArray6, strArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 80");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str7.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4" + "'", str9.equals("4"));
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(".ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja1.7.0_80hie/Libr");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".80-b", "Mac OS ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10.1.3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                                                                  44444444444444444444444444444444444444444444444444                                                                                   ", "#########################################Oracle Corporation#########################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("444", "-1.0 # -1", (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444" + "'", str3.equals("444"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(" OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS XMac4OS4XMac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSX" + "'", str1.equals("OSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSXMac4OS4XMacOSX"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/         ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:4.80-b1144444444444444444444444444", "A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1A.80-b1", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:4.80-b1144444444444444444444444444" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:4.80-b1144444444444444444444444444"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "i");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                            MacaOSaXc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rver24.80-b11c os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".7.0_80-B15", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "###############################################################4################################################################", (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}

