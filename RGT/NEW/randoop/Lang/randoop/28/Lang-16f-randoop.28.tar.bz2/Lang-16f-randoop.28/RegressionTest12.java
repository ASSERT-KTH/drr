import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test01");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "o");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test02");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) " SO cMaX SO c", (java.lang.CharSequence) "c os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rvervm...rver24.80-b11c os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os xamc os");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test03");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test04");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96608_1560211995/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "1.5", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test05");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerV");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test06");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("XED Java(TM) SE Runtime Environment", "MAC OS ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XED Java(TM) SE Runtime Environment" + "'", str2.equals("XED Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test07");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "class [Cclass [C", 46);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test08");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("mxdmd");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test09");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("caMX SO caMX SO caMX SO caMX SO caM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac" + "'", str1.equals("Mac OS XMac OS XMac OS XMac OS XMac"));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test10");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                             4                                                             ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test11");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("51.0", "4.80-b11", (int) (byte) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "c OS XaMc OS XaM");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "", 0, 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "5" + "'", str5.equals("5"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test12");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }
}

