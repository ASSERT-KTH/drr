import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("24.80-b1124.80-b1124.80-b1124.80", "Mac OS X", "10.14.3", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80" + "'", str4.equals("24.80-b1124.80-b1124.80-b1124.80"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("...                  en                              en                              en", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...                  en                              en                              en" + "'", str2.equals("...                  en                              en                              en"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                                                                                    ", "MacJava Platform API SpecificationOSJava Platform API SpecificationX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 106, (double) 52L, 106.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Users/sophie/Documents/defects4j/t                              en_94100_1560208707");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/t en_94100_1560208707" + "'", str1.equals("/Users/sophie/Documents/defects4j/t en_94100_1560208707"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("51.0", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("//U F 8///", "aaaaUaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "//U F 8///" + "'", str2.equals("//U F 8///"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("  UTF-8   ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sun.lwawt.macosx.CPrinterJob", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "LWCToolkit" + "'", str2.equals("LWCToolkit"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 80);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 200, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str3.equals("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("  UTF-8   ", "mac ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  UTF-8   " + "'", str2.equals("  UTF-8   "));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94100_1560208707/target/classes:/Users/sophie/D", (java.lang.CharSequence) "               en           51.0", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 217, 10L, (long) 282);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("7.0_80-b15", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "en", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 217, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                         " + "'", str3.equals("                                                                                                                                                                                                                         "));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("mixedmode", "e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mix" + "'", str2.equals("mix"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray6 = new char[] { '4', 'a', '#' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                 ", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                                                                                                                                     51.0", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie/Documents/defects4j/t                              en_94100_1560208707", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!JavaHotSpot(TM)64-BitServerVMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/t                              en_94100_1560208707" + "'", str2.equals("/Users/sophie/Documents/defects4j/t                              en_94100_1560208707"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("http://java.oracle.com/", "46_68x:", 106);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("\n");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaaaaaaaaaa24.80-b11aaaaaaaaaaaa", "46_68x:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaa24.80-b11aaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaa24.80-b11aaaaaaaaaaaa"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("          HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", 0, "sun.lwawt.macosx.lwctoolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H" + "'", str3.equals("          HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("sun.awt.CGraphicsEnvironment", 50);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.7", "sun.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (-1L), 10.0f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (short) 100, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/users/sophie", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie" + "'", str2.equals("/users/sophie"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Oracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Documents/defects4j/t                              en_94100_1560208707");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Java VirtuU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3", "t");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "uU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3" + "'", str2.equals("uU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "wawt.macosx.CPrinterJob", (java.lang.CharSequence) "Oracle CorporationOracle sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass java.io.Fileclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "10.14.3" + "'", charSequence2.equals("10.14.3"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "sun.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", (java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "U");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Mac OS X", "/users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4" + "'", str2.equals("4"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.awt.CGraphicsEnvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring(":", 7, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("MacJava Platform API SpecificationOSJava Platform API SpecificationX", "U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U", "6_68x:");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MacJava Platform API SpecificationOSJava Platform API SpecificationX" + "'", str3.equals("MacJava Platform API SpecificationOSJava Platform API SpecificationX"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Oracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("Oracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "wawt.macosx.CPrinterJob", (java.lang.CharSequence) "\n444444", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 0, 10, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Oracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit", "", (int) (short) 1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit" + "'", str6.equals("Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.lwctoolkit", "/Users/sophie/DOracle CorporationOracle sun.lwawt.macosx.LWCToolki100_1560208707", "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "\n444444", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11" + "'", str1.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("en", "Oracle CorporationOracle sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("e", 3, "mix");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mie" + "'", str3.equals("mie"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sophie");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 80);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                " + "'", str2.equals("                                                                                "));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", "class [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass java.io.Fileclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "LWCToolkit", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U" + "'", str2.equals("U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 100, (float) 52);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "6_68x:", 282);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", "LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie/Documents/defects4j/t                              en_94100_1560208707");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/T                              EN_94100_1560208707" + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/T                              EN_94100_1560208707"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:           hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("mixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mixed mode\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.1", (java.lang.CharSequence) "                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("mixedmode", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedmod" + "'", str2.equals("mixedmod"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sun#.#lwawt#.#macosx#.#C#Printer#Job", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun#.#lwawt#.#macosx#.#C#Printer#Job" + "'", str2.equals("sun#.#lwawt#.#macosx#.#C#Printer#Job"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", 52.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Oracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("macJava Platform API SpecificationOSJava Platform API SpecificationX", "24.80-b1124.80-b1124.80-b1124.80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "macJava Platform API SpecificationOSJava Platform API SpecificationX" + "'", str2.equals("macJava Platform API SpecificationOSJava Platform API SpecificationX"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java Virtual Machine Specification", (int) (short) -1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "ophie", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(34, 80, 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 80 + "'", int3 == 80);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sun#.#lwawt#.#macosx#.#C#Printer#Job");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun#.#lwawt#.#macosx#.#C#Printer#Job" + "'", str1.equals("sun#.#lwawt#.#macosx#.#C#Printer#Job"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                                                                                                                                                                                                     51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "6_68x:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) 80);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 80L + "'", long2 == 80L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "1.7");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Us1rs/sophi1/Library/Java/Ext1.sio.s:/Library/Java/JavaVirtualMachi.1s/jdk1.7.0_80.jdk/Co.t1.ts/Hom1/jr1/lib/1xt:/Library/Java/Ext1.sio.s:/N1twork/Library/Java/Ext1.sio.s:/Syst1m/Library/Java/Ext1.sio.s:/usr/lib/java", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit", "                                                                 ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java(TM) SE Runtime Environment", 106);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment                                                                           " + "'", str2.equals("Java(TM) SE Runtime Environment                                                                           "));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("LWCToolkit", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaHotSpot(TM)64-BitServerV" + "'", str1.equals("JavaHotSpot(TM)64-BitServerV"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Java VirtuU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java VirtuU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U1" + "'", str2.equals("Java VirtuU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U1"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", (java.lang.CharSequence) "                              en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("mix", (int) (short) 10, "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwamix" + "'", str3.equals("sun.lwamix"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "sun.lwamix");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sun#.#lwawt#.#macosx#.#C#Printer#Job", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun#.#lwawt#.#macosx#.#C#Printer#Job" + "'", str2.equals("sun#.#lwawt#.#macosx#.#C#Printer#Job"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Us1rs/sophi1/Library/Java/Ext1.sio.s:/Library/Java/JavaVirtualMachi.1s/jdk1.7.0_80.jdk/Co.t1.ts/Hom1/jr1/lib/1xt:/Library/Java/Ext1.sio.s:/N1twork/Library/Java/Ext1.sio.s:/Syst1m/Library/Java/Ext1.sio.s:/usr/lib/java", "24.80-b1124.80-b1124.80-b1124.80", 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Us1rs/sophi1/Library/Java/Ext1.sio.s:/Library/Java/JavaVirtualMachi.1s/jdk1.7.0_80.jdk/Co.t1.ts/Hom1/jr1/lib/1xt:/Library/Java/Ext1.sio.s:/N1twork/Library/Java/Ext1.sio.s:/Syst1m/Library/Java/Ext1.sio.s:/usr/lib/java" + "'", str3.equals("/Us1rs/sophi1/Library/Java/Ext1.sio.s:/Library/Java/JavaVirtualMachi.1s/jdk1.7.0_80.jdk/Co.t1.ts/Hom1/jr1/lib/1xt:/Library/Java/Ext1.sio.s:/N1twork/Library/Java/Ext1.sio.s:/Syst1m/Library/Java/Ext1.sio.s:/usr/lib/java"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "LWCToolkit", "                                                                                                                                                                                                                     51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str2.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (java.lang.CharSequence) ".");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("4444444", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444" + "'", str2.equals("4444444"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "wawt.macosx.CPrinterJob", 217, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("  UTF-8   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  UTF-8  " + "'", str1.equals("  UTF-8  "));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 10L, (double) (-1), (double) 200.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 200.0d + "'", double3 == 200.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94100_1560208707", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94100_1560208707" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94100_1560208707"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("JavaHotSpot(TM)64-BitServerV", (float) 7L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.0f + "'", float2 == 7.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Java(TM) SE Runtime Environment", "", (int) ' ', 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Jav" + "'", str4.equals("Jav"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        float[] floatArray6 = new float[] { 106L, 100.0f, 34L, 100L, (short) 1, 1.8f };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 106.0f + "'", float8 == 106.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.5", 282, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) -1, 106L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 106L + "'", long3 == 106L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double[][][][] doubleArray0 = new double[][][][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/Users/sophie/DOracle CorporationOracle sun.lwawt.macosx.LWCToolki100_1560208707");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/DOracle CorporationOracle sun.lwawt.macosx.LWCToolki100_1560208707" + "'", str1.equals("/Users/sophie/DOracle CorporationOracle sun.lwawt.macosx.LWCToolki100_1560208707"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.7", "                                                                 ", "", (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7" + "'", str4.equals("1.7"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                                                                                                                                                                                         ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "", "mac ...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(":x86_64", "/Users/sophie/Documents/defects4j/t                              en_94100_1560208707", 30);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        int[] intArray2 = new int[] { ' ', (short) 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("XnoitacificepS IPA mroftalP avaJSOnoitacificepS IPA mroftalP avaJcam", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "acificepS IPA mroftalP avaJcam" + "'", str2.equals("acificepS IPA mroftalP avaJcam"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "U", 200);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "24.80-b1124.80-b1124.80-b1124.80");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("  UTF-8   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] { '#', 'a', '#', 'a' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "sun#.#lwawt#.#macosx#.#C#Printer#Job");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sun.awt.CGraphicsEnvironment", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/users/sophie", (java.lang.CharSequence) "MacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationX", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94100_1560208707/target/classes:/Users/sophie/D");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "D/eihpos/sresU/:sessalc/tegrat/7078020651_00149_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("D/eihpos/sresU/:sessalc/tegrat/7078020651_00149_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("6_68x:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "         " + "'", str1.equals("         "));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("t", "Java(TM) SE Runtime Environment", 0, 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str4.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkit", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.8", "/", (int) (short) 100);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "1.7.0_80-b15");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                 ", (java.lang.CharSequence[]) strArray8);
        java.lang.Class<?> wildcardClass10 = strArray8.getClass();
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "1.7.0_80-b15");
        boolean boolean15 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                 ", (java.lang.CharSequence[]) strArray14);
        java.lang.Class<?> wildcardClass16 = strArray14.getClass();
        java.lang.Class[] classArray18 = new java.lang.Class[3];
        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray19 = (java.lang.Class<?>[]) classArray18;
        wildcardClassArray19[0] = wildcardClass4;
        wildcardClassArray19[1] = wildcardClass10;
        wildcardClassArray19[2] = wildcardClass16;
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(wildcardClassArray19);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join((java.lang.reflect.GenericDeclaration[]) wildcardClassArray19);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(classArray18);
        org.junit.Assert.assertNotNull(wildcardClassArray19);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str26.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str27.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "1.7.0_80-b15");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                 ", (java.lang.CharSequence[]) strArray5);
        java.lang.Class<?> wildcardClass7 = strArray5.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("6_68x", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "6_68x" + "'", str8.equals("6_68x"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UTF-8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                              en                              en                              en          ", "enenen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java Virtual Machine Specification", "sun#.#lwawt#.#macosx#.#C#Printer#Job");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("46XnoitacificepS IPA mroftalP avaJSOnoitacificepS IPA mroftalP avaJcam_XnoitacificepS IPA mroftalP avaJSOnoitacificepS IPA mroftalP avaJcam68XnoitacificepS IPA mroftalP avaJSOnoitacificepS IPA mroftalP avaJcamxXnoitacificepS IPA mroftalP avaJSOnoitacificepS IPA mroftalP avaJcam:", "");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("mix", "wawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mix" + "'", str2.equals("mix"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("http://java.oracle.com/", (int) '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444http://java.oracle.com/" + "'", str3.equals("44444444444444444444444444444http://java.oracle.com/"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("http://java.oracle.com/", "                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java(TM) SE Runtime Environment                                                                           ", "mie", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sun.awt.CGraphicsEnvironment", "e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironm" + "'", str2.equals("sun.awt.CGraphicsEnvironm"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("sun.awt.CGraphicsEnvironm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironm" + "'", str1.equals("sun.awt.CGraphicsEnvironm"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "          HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("D/eihpos/sresU/:sessalc/tegrat/7078020651_00149_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "aaaaaaaaaaa24.80-b11aaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "D/eihpos/sresU/:sessalc/tegrat/7078020651_00149_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("D/eihpos/sresU/:sessalc/tegrat/7078020651_00149_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("MacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationX", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Us1rs/sophi1/Library/Java/Ext1.sio.s:/Library/Java/JavaVirtualMachi.1s/jdk1.7.0_80.jdk/Co.t1.ts/Hom1/jr1/lib/1xt:/Library/Java/Ext1.sio.s:/N1twork/Library/Java/Ext1.sio.s:/Syst1m/Library/Java/Ext1.sio.s:/usr/lib/java", "UTF-8", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Us1rs/sophi1/Library/Java/Ext1.sio.s:/Library/Java/JavaVirtualMachi.1s/jdk1.7.0_80.jdk/Co.t1.ts/Hom1/jr1/lib/1xt:/Library/Java/Ext1.sio.s:/N1twork/Library/Java/Ext1.sio.s:/Syst1m/Library/Java/Ext1.sio.s:/usr/lib/java" + "'", str3.equals("/Us1rs/sophi1/Library/Java/Ext1.sio.s:/Library/Java/JavaVirtualMachi.1s/jdk1.7.0_80.jdk/Co.t1.ts/Hom1/jr1/lib/1xt:/Library/Java/Ext1.sio.s:/N1twork/Library/Java/Ext1.sio.s:/Syst1m/Library/Java/Ext1.sio.s:/usr/lib/java"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(30, 67, 80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 80 + "'", int3 == 80);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("JavaHotSpot(TM)64-BitServerV", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                        JavaHotSpot(TM)64-BitServerV" + "'", str2.equals("                        JavaHotSpot(TM)64-BitServerV"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!JavaHotSpot(TM)64-BitServerVMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) "                                                                                                    ", 276);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("...                  en                              en                              en          ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...                  en                              en                              en          " + "'", str2.equals("...                  en                              en                              en          "));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("6_68x", "Java VirtuU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6_68x" + "'", str2.equals("6_68x"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.8", "/", (int) (short) 100);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "aaaaUaaaaa");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.8" + "'", str6.equals("1.8"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.8" + "'", str8.equals("1.8"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", 0, "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen" + "'", str3.equals("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                                                                ", "macJava Platform API SpecificationOSJava Platform API SpecificationX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                " + "'", str2.equals("                                                                                "));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle CorporationOracle sun.lwawt.macosx.LWCToolki");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80-b15", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence[]) strArray6);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("acificepS IPA mroftalP avaJcam", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("macJava Platform API SpecificationOSJava Platform API SpecificationX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "macJava Platform API SpecificationOSJava Platform API SpecificationX" + "'", str1.equals("macJava Platform API SpecificationOSJava Platform API SpecificationX"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/T                              EN_94100_1560208707", (int) (byte) 1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "/Users/sophie/DOracle CorporationOracle sun.lwawt.macosx.LWCToolki100_1560208707");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.lwawt.macosx.LWCToolkit", (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("enenen", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "444444444444444444444444444444444444444444444444Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                                                                                                                                         ", (int) '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                         " + "'", str3.equals("                                                                                                                                                                                                                         "));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"LWCToolkit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.cprinterjob", "  UTF-8   ", ":");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) ":x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                                                                                                                        ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", 106);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("...                  en                              en                              en", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 0L, (long) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 0, (double) 97.0f, (double) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', 64, 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(".");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ".", (java.lang.CharSequence) "24.80-b1124.80-b1124.80-b1124.80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/users/sophie", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.5", (int) (short) 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        long[] longArray5 = new long[] { 106, 106, 7, (short) 10, 100L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 106L + "'", long6 == 106L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 106L + "'", long7 == 106L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 217, 97L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "  UTF-8   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace(":x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":x86_64" + "'", str1.equals(":x86_64"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "1.7.0_80-b15");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                 ", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "x86_64");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sun.lwamix", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                    ", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("//U F 8///", ".");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "uU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3", (java.lang.CharSequence) "         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) ":x86_64", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                                                                                                                                                                                     51.0", "Java VirtuU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U1", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                     51.0" + "'", str3.equals("                                                                                                                                                                                                                     51.0"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "          ", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", (java.lang.CharSequence) "Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit", 7, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie", "sun.lwawt.macosx.cprinterjob", (int) (short) 1, 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/sun.lwawt.macosx.cprinterjobsers/sophie" + "'", str4.equals("/sun.lwawt.macosx.cprinterjobsers/sophie"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("  UTF-8   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("uU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"uU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ophie", "         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str1.equals("sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                              en", (java.lang.CharSequence) "1.8", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                              en                              en                              en          ", "acificepS IPA mroftalP avaJcam", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Java VirtuU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U1", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java VirtuU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U1" + "'", str2.equals("Java VirtuU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U1"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("          HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "MacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationX", "1.5");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                                 ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("t");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("7.0_80-b15");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("sun.lwawt.macosx.LWCToolkit", "U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Mac OS X", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        char[] charArray6 = new char[] { '#', 'a', '#', 'a' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                              en                              en                              en          ", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.5", "1.1");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4" + "'", str2.equals("4"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("sun.lwamix", "class [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass java.io.Fileclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwamix" + "'", str2.equals("sun.lwamix"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) ' ', (long) 'a', (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "Oracle CorporationOracle sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "7.0_80-b15", (java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                                                                 ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "mac ...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 10, 0L, (long) 52);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Us1rs/sophi1/Library/Java/Ext1.sio.s:/Library/Java/JavaVirtualMachi.1s/jdk1.7.0_80.jdk/Co.t1.ts/Hom1/jr1/lib/1xt:/Library/Java/Ext1.sio.s:/N1twork/Library/Java/Ext1.sio.s:/Syst1m/Library/Java/Ext1.sio.s:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "          HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94100_1560208707");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Oracle CorporationOracle sun.lwawt.macosx.LWCToolki");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle CorporationOracle sun.lwawt.macosx.LWCToolki" + "'", str3.equals("Oracle CorporationOracle sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironm", 50, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray7 = new char[] { '4', 'a', '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "e", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "uU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                                                                                    ", "t");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("24.80-b11", "sun.", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!JavaHotSpot(TM)64-BitServerVMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 282);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "24.80-b11" + "'", str4.equals("24.80-b11"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Java VirtuU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3", "mix");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java VirtuU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3" + "'", str2.equals("Java VirtuU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/DOracle CorporationOracle sun.lwawt.macosx.LWCToolki100_1560208707", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/DOrcle CorportionOrcle sun.lwwt.mcosx.LWCToolki100_1560208707" + "'", str2.equals("/Users/sophie/DOrcle CorportionOrcle sun.lwwt.mcosx.LWCToolki100_1560208707"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("class [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass java.io.Fileclass [Ljava.lang.String;", "Java(TM) SE Runtime Environment", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ".", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94100_1560208707/target/classes:/Users/sophie/D", 276);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sun.lwamix", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwamix" + "'", str2.equals("sun.lwamix"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!JavaHotSpot(TM)64-BitServerVMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java VirtuU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3", (java.lang.CharSequence) "mixedmode", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaUaaaaa", "Oracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaUaaaaa", (int) 'a', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                   ", (java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "D/eihpos/sresU/:sessalc/tegrat/7078020651_00149_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "mac os x", (java.lang.CharSequence) "                                                                                                                                                                                                                     51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 80, (double) 100L, (double) 282);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 282.0d + "'", double3 == 282.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("4444444", (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4444444L + "'", long2 == 4444444L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 106L, (long) 30);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 106L + "'", long3 == 106L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 10, (long) 'a', (long) 64);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        short[] shortArray6 = new short[] { (byte) 10, (byte) -1, (byte) 10, (byte) 100, (byte) 0, (byte) -1 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("...                  en                              en                              en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: ...                  en                              en                              en is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users/sophie/Documents/defects4j/t                              en_94100_1560208707");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("class [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass java.io.Fileclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class[Ljava.lang.String;class[Ljava.lang.String;classjava.io.Fileclassjava.io.Fileclass[Ljava.lang.String;" + "'", str1.equals("class[Ljava.lang.String;class[Ljava.lang.String;classjava.io.Fileclassjava.io.Fileclass[Ljava.lang.String;"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!JavaHotSpot(TM)64-BitServerVMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 0, (long) 100, (long) 217);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/users/sophie", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "/Users/sophie/Documents/defects4j/t en_94100_1560208707");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "Java Platform API Specification");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "x86_64", (int) (short) 100);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("...                  en                              en                              en          ", strArray4, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "               en           51.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "...                  en                              en                              en          " + "'", str9.equals("...                  en                              en                              en          "));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("46_68x:", "//U F 8///");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "46_68x:" + "'", str2.equals("46_68x:"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U" + "'", str2.equals("U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "mixedmode", (java.lang.CharSequence) "macJava Platform API SpecificationOSJava Platform API SpecificationX");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64 + "'", int2 == 64);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "Java VirtuU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", (java.lang.CharSequence) "sun.lwamix", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                              en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "         ", (java.lang.CharSequence) "sun.lwamix", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        short[] shortArray2 = new short[] { (short) 100, (byte) 1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("hi!", "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "Java Virtual Machine Specification");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.5", "46XnoitacificepS IPA mroftalP avaJSOnoitacificepS IPA mroftalP avaJcam_XnoitacificepS IPA mroftalP avaJSOnoitacificepS IPA mroftalP avaJcam68XnoitacificepS IPA mroftalP avaJSOnoitacificepS IPA mroftalP avaJcamxXnoitacificepS IPA mroftalP avaJSOnoitacificepS IPA mroftalP avaJcam:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("\n444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n444444" + "'", str1.equals("\n444444"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "mac os x", (java.lang.CharSequence) "\n444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", (java.lang.CharSequence) "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "mac ...", (java.lang.CharSequence) ":x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java Virtual Machine Specification", "MacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("51.0", 282, "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironme" + "'", str3.equals("51.0sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironme"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "  UTF-8   ", (java.lang.CharSequence) "macJava Platform API SpecificationOSJava Platform API SpecificationX", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/T                              EN_94100_1560208707");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/T                              EN_94100_1560208707" + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/T                              EN_94100_1560208707"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str1.equals("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("//U F 8///", 282);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "//U F 8///" + "'", str2.equals("//U F 8///"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("http://java.oracle.com/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Documents/defects4j/t en_94100_1560208707");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/t en_94100_1560208707" + "'", str1.equals("/Users/sophie/Documents/defects4j/t en_94100_1560208707"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "1.7.0_80-b15");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/sun.lwawt.macosx.cprinterjobsers/sophie", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94100_1560208707");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.awt.CGraphicsEnvironm", (java.lang.CharSequence) "macJava Platform API SpecificationOSJava Platform API SpecificationX");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Us1rs/sophi1/Library/Java/Ext1.sio.s:/Library/Java/JavaVirtualMachi.1s/jdk1.7.0_80.jdk/Co.t1.ts/Hom1/jr1/lib/1xt:/Library/Java/Ext1.sio.s:/N1twork/Library/Java/Ext1.sio.s:/Syst1m/Library/Java/Ext1.sio.s:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Us1rs/sophi1/Library/Java/Ext1.sio.s:/Library/Java/JavaVirtualMachi.1s/jdk1.7.0_80.jdk/Co.t1.ts/Hom1/jr1/lib/1xt:/Library/Java/Ext1.sio.s:/N1twork/Library/Java/Ext1.sio.s:/Syst1m/Library/Java/Ext1.sio.s:/usr/lib/jav" + "'", str1.equals("/Us1rs/sophi1/Library/Java/Ext1.sio.s:/Library/Java/JavaVirtualMachi.1s/jdk1.7.0_80.jdk/Co.t1.ts/Hom1/jr1/lib/1xt:/Library/Java/Ext1.sio.s:/N1twork/Library/Java/Ext1.sio.s:/Syst1m/Library/Java/Ext1.sio.s:/usr/lib/jav"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("44444444444444444444444444444http://java.oracle.com/", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444http://java.oracle.com/" + "'", str2.equals("44444444444444444444444444444http://java.oracle.com/"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Mac OS X", 34, "mixedmod");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixedmodmixedmodmixedmodmiMac OS X" + "'", str3.equals("mixedmodmixedmodmixedmodmiMac OS X"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Us1rs/sophi1/Library/Java/Ext1.sio.s:/Library/Java/JavaVirtualMachi.1s/jdk1.7.0_80.jdk/Co.t1.ts/Hom1/jr1/lib/1xt:/Library/Java/Ext1.sio.s:/N1twork/Library/Java/Ext1.sio.s:/Syst1m/Library/Java/Ext1.sio.s:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "44444444444444444444444444444http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                                                                                                                                                                                        ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java VirtuU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "aaaaUaaaaa", "                                ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "15", (java.lang.CharSequence) "uU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "MacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Jav" + "'", str1.equals("Jav"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 106L, (float) 7, (float) 6);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 106.0f + "'", float3 == 106.0f);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444http://java.oracle.com/", (java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/users/sophie", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                              en                              en                              en          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en                              en                              en" + "'", str1.equals("en                              en                              en"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java VirtuU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U", "t");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Vir" + "'", str2.equals("Java Vir"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "15", charSequence1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "10.14.3", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "aaaaaaaaaaa24.80-b11aaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Oracle Corporation", 100, "               en           51.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               en           51.0               en           51.0               en Oracle Corporation" + "'", str3.equals("               en           51.0               en           51.0               en Oracle Corporation"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b1124.80-b1124.80-b1124.80");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("class[Ljava.lang.String;class[Ljava.lang.String;classjava.io.Fileclassjava.io.Fileclass[Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("...                  en                              en                              en", '4');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...                  en                              en                              en" + "'", str3.equals("...                  en                              en                              en"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "mac os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94100_1560208707/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 2, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkit", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                ", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!JavaHotSpot(TM)64-BitServerVMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                              " + "'", str1.equals("                              "));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                              en                              en                              en          ", (int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixedmod", "                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen                              en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("               en           51.0", 32, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Oracle CorporationOracle sun.lwawt.macosx.LWCToolki", (java.lang.CharSequence) "/Users/sophie", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("wawt.macosx.CPrinterJob", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Users/sophie/DOracle CorporationOracle sun.lwawt.macosx.LWCToolki100_1560208707");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "acificepS IPA mroftalP avaJcam", (java.lang.CharSequence) ".");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "/", "/");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", (java.lang.CharSequence[]) strArray4);
        java.lang.Class<?> wildcardClass6 = strArray4.getClass();
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.substringsBetween("", "/", "/");
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", (java.lang.CharSequence[]) strArray11);
        java.lang.Class<?> wildcardClass13 = strArray11.getClass();
        java.io.File file14 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.lang.Class<?> wildcardClass15 = file14.getClass();
        java.io.File file16 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.lang.Class<?> wildcardClass17 = file16.getClass();
        java.lang.String[] strArray22 = org.apache.commons.lang3.StringUtils.substringsBetween("", "/", "/");
        int int23 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", (java.lang.CharSequence[]) strArray22);
        java.lang.Class<?> wildcardClass24 = strArray22.getClass();
        java.lang.reflect.Type[] typeArray25 = new java.lang.reflect.Type[] { wildcardClass6, wildcardClass13, wildcardClass15, wildcardClass17, wildcardClass24 };
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(typeArray25);
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) typeArray25, 'a');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(file14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(file16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(typeArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass java.io.Fileclass [Ljava.lang.String;" + "'", str26.equals("class [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass java.io.Fileclass [Ljava.lang.String;"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "class [Ljava.lang.String;aclass [Ljava.lang.String;aclass java.io.Fileaclass java.io.Fileaclass [Ljava.lang.String;" + "'", str28.equals("class [Ljava.lang.String;aclass [Ljava.lang.String;aclass java.io.Fileaclass java.io.Fileaclass [Ljava.lang.String;"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("46_68x:");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "x86_64", (int) (short) 100);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", strArray3, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 5 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "/sun.lwawt.macosx.cprinterjobsers/sophie");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.8", "/", (int) (short) 100);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "1.7.0_80-b15");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                 ", (java.lang.CharSequence[]) strArray8);
        java.lang.Class<?> wildcardClass10 = strArray8.getClass();
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "1.7.0_80-b15");
        boolean boolean15 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                 ", (java.lang.CharSequence[]) strArray14);
        java.lang.Class<?> wildcardClass16 = strArray14.getClass();
        java.lang.Class[] classArray18 = new java.lang.Class[3];
        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray19 = (java.lang.Class<?>[]) classArray18;
        wildcardClassArray19[0] = wildcardClass4;
        wildcardClassArray19[1] = wildcardClass10;
        wildcardClassArray19[2] = wildcardClass16;
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(wildcardClassArray19);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join((java.lang.reflect.AnnotatedElement[]) wildcardClassArray19);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(classArray18);
        org.junit.Assert.assertNotNull(wildcardClassArray19);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str26.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str27.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("sun.", "Java VirtuU10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun." + "'", str2.equals("sun."));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        short[] shortArray6 = new short[] { (byte) -1, (short) 10, (short) 10, (short) 100, (byte) 0, (short) -1 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                                ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("46_68x:", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("               en           51.0               en           51.0               en Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.substringsBetween("", "/", "/");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", (java.lang.CharSequence[]) strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "...                  en                              en                              en          ", (java.lang.CharSequence[]) strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java(TM) SE Runtime Environment", strArray1, strArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str10.equals("Java(TM) SE Runtime Environment"));
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                                                                                                                                     51.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        double[] doubleArray1 = new double[] { 1.5d };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5d + "'", double2 == 1.5d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.5d + "'", double3 == 1.5d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.5d + "'", double4 == 1.5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.5d + "'", double5 == 1.5d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("sun.awt.CGraphicsEnvironment", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "un.awt.CGraphicsEnvironment" + "'", str2.equals("un.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("4", 30, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("444444444444444444444444444444444444444444444444Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("444444444444444444444444444444444444444444444444Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Java HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Java HotSpot(TM) 64-Bit Server VM is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "aaaaaaaaaaa24.80-b11aaaaaaaaaaaa", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("               en           51.0               en           51.0               en Oracle Corporation", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "               en           51.0               en           51.0               en Oracle Corporation" + "'", str2.equals("               en           51.0               en           51.0               en Oracle Corporation"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "enenen", (java.lang.CharSequence) "Oracle CorporationOracle sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(282, 106, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 282 + "'", int3 == 282);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("en                              en                              en", 10, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en                              en                              en" + "'", str3.equals("en                              en                              en"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/Users/sophie/Documents/defects4j/t en_94100_1560208707");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen                              en", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\n444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(97.0f, 97.0f, 200.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "                              ", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("sun.awt.CGraphicsEnvironm", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironm" + "'", str2.equals("sun.awt.CGraphicsEnvironm"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Jav", "44444444444444444444444444444http://java.oracle.com/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("mix");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mix\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sun.lwawt.macosx.LWCToolkit", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 0.0d, 276.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, charSequence1, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("  UTF-8   ", "444444444444444444444444444444444444444444444444Oracle CorporationOracle sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  UTF-8   " + "'", str2.equals("  UTF-8   "));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("...                  en                              en                              en          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...                  EN                              EN                              EN          " + "'", str1.equals("...                  EN                              EN                              EN          "));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                   ", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaa24.80-b11aaaaaaaaaaaa", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "tionXatform API Specifica PlavationOSJatform API Specifica PlavacJam");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaa24.80-b11aaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaa24.80-b11aaaaaaaaaaaa"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                                                                                                                                                                                                         ", (java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94100_1560208707/target/classes:/Users/sophie/D", 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "tionXatform API Specifica PlavationOSJatform API Specifica PlavacJam");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("MacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationX" + "'", str1.equals("MacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationXMacJavaPlatformAPISpecificationOSJavaPlatformAPISpecificationX"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 100, 64, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 64);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.5", "                                                                                                                                                                                                        ", 67);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("class [Ljava.lang.String;aclass [Ljava.lang.String;aclass java.io.Fileaclass java.io.Fileaclass [Ljava.lang.String;", 67, "/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Ljava.lang.String;aclass [Ljava.lang.String;aclass java.io.Fileaclass java.io.Fileaclass [Ljava.lang.String;" + "'", str3.equals("class [Ljava.lang.String;aclass [Ljava.lang.String;aclass java.io.Fileaclass java.io.Fileaclass [Ljava.lang.String;"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("44444444444444444444444444444http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444HTTP://JAVA.ORACLE.COM/" + "'", str1.equals("44444444444444444444444444444HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (double) 30);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 30.0d + "'", double2 == 30.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("mixedmode", "JavaHotSpot(TM)64-BitServerVM", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/T                              EN_94100_1560208707");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixedmode" + "'", str3.equals("mixedmode"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.1", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("aaaaUaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5.1" + "'", str1.equals("5.1"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "class [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass java.io.Fileclass [Ljava.lang.String;");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("sun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkitophiesun.lwawt.macosx.LWCToolkit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("x so cam");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x so cam" + "'", str1.equals("x so cam"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.14.3", "aaaaUaaaaa");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', (int) (short) 1, 200);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "51.0sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironme", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                ", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie/DOracle CorporationOracle sun.lwawt.macosx.LWCToolki100_1560208707");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/doRACLE cORPORATIONoRACLE SUN.LWAWT.MACOSX.lwctOOLKI100_1560208707" + "'", str1.equals("/uSERS/SOPHIE/doRACLE cORPORATIONoRACLE SUN.LWAWT.MACOSX.lwctOOLKI100_1560208707"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 9, 276);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie/DOrcle CorportionOrcle sun.lwwt.mcosx.LWCToolki100_1560208707", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7" + "'", str2.equals("7"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94100_1560208707/target/classes:/Users/sophie/D", 7, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94100_1560208707/target/classes:/Users/sophie/D" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94100_1560208707/target/classes:/Users/sophie/D"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("         ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "                                                                                                                                                                                                                     51.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                        JavaHotSpot(TM)64-BitServerV", "sun.lwamix");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("MacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationXMacJava Platform API SpecificationOSJava Platform API SpecificationX", "//U F 8///", (-1));
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass java.io.Fileclass [Ljava.lang.String;", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7" + "'", str1.equals("7"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "         ", (java.lang.CharSequence) "  UTF-8  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "UTF-8", 0, 106);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 1, 0L, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.lwawt.macosx.lwctoolkit", (java.lang.CharSequence) "                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/DOrcle CorportionOrcle sun.lwwt.mcosx.LWCToolki100_1560208707");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/DOrcle CorportionOrcle sun.lwwt.mcosx.LWCToolki100_1560208707" + "'", str1.equals("/Users/sophie/DOrcle CorportionOrcle sun.lwwt.mcosx.LWCToolki100_1560208707"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U10.14.3U", "", (int) (byte) 1);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "sun.lwawt.macosx.LWCToolkit");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("15", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "15" + "'", str8.equals("15"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Us1rs/sophi1/Library/Java/Ext1.sio.s:/Library/Java/JavaVirtualMachi.1s/jdk1.7.0_80.jdk/Co.t1.ts/Hom1/jr1/lib/1xt:/Library/Java/Ext1.sio.s:/N1twork/Library/Java/Ext1.sio.s:/Syst1m/Library/Java/Ext1.sio.s:/usr/lib/jav", "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Us1rs/sophi1/Library/Java/Ext1.sio.s:/Library/Java/JavaVirtualMachi.1s/jdk1.7.0_80.jdk/Co.t1.ts/Hom1/jr1/lib/1xt:/Library/Java/Ext1.sio.s:/N1twork/Library/Java/Ext1.sio.s:/Syst1m/Library/Java/Ext1.sio.s:/usr/lib/j" + "'", str2.equals("/Us1rs/sophi1/Library/Java/Ext1.sio.s:/Library/Java/JavaVirtualMachi.1s/jdk1.7.0_80.jdk/Co.t1.ts/Hom1/jr1/lib/1xt:/Library/Java/Ext1.sio.s:/N1twork/Library/Java/Ext1.sio.s:/Syst1m/Library/Java/Ext1.sio.s:/usr/lib/j"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("24.80-b1124.80-b1124.80-b1124.80", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.80" + "'", str2.equals("24.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.8024.80-b1124.80-b1124.80-b1124.80"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "               en           51.0               en           51.0               en Oracle Corporation", (java.lang.CharSequence) "sun.lwawt.macosx.lwctoolkit", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "  UTF-8  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(1.0f, (float) 282, (float) 6);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("class[Ljava.lang.String;class[Ljava.lang.String;classjava.io.Fileclassjava.io.Fileclass[Ljava.lang.String;", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "x so cam", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "x so cam" + "'", charSequence2.equals("x so cam"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "          ", (java.lang.CharSequence) ".");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Jav", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jav" + "'", str2.equals("Jav"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94100_1560208707/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) (byte) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(7L, (long) 34, 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Oracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "class[Ljava.lang.String;class[Ljava.lang.String;classjava.io.Fileclassjava.io.Fileclass[Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("//U F 8///", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "//U F 8/////U F 8/////U F 8///" + "'", str2.equals("//U F 8/////U F 8/////U F 8///"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray6 = new char[] { '4', 'a', '#' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 34 + "'", int9 == 34);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "mix");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("sun.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun." + "'", str1.equals("sun."));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("6_68x:", 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6_68x:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("6_68x:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Jav", "1.7", 2, 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Ja1.7" + "'", str4.equals("Ja1.7"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.8", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Documents/defects4j/t en_94100_1560208707", "/Us1rs/sophi1/Library/Java/Ext1.sio.s:/Library/Java/JavaVirtualMachi.1s/jdk1.7.0_80.jdk/Co.t1.ts/Hom1/jr1/lib/1xt:/Library/Java/Ext1.sio.s:/N1twork/Library/Java/Ext1.sio.s:/Syst1m/Library/Java/Ext1.sio.s:/usr/lib/j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/t en_94100_1560208707" + "'", str2.equals("/Users/sophie/Documents/defects4j/t en_94100_1560208707"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94100_1560208707", "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Java HotSpot(TM) 64-Bit Server VMhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}

