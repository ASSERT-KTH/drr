import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "hi#!#4444#hi#!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi#!#4444#hi#!" + "'", str1.equals("Hi#!#4444#hi#!"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", "dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("###################################################################################oracle corporatio", "                                  444444444444444/4444444444444444                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################################################################oracle corporatio" + "'", str2.equals("###################################################################################oracle corporatio"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("iooHI!ioor", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("                US                 ", "                                                                     444444444444444/4444444444444444                                                                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Oracle Corporation", "444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("jAVA vIRTUAL mACHINE sPECIFICATION##################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph" + "'", str1.equals("sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad(":", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       :" + "'", str2.equals("       :"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.7./1.7.0", "HI!4444HI!", "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7./1.7.0" + "'", str3.equals("1.7./1.7.0"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.14.3", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("Oracle corporatio", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) (byte) 100, 18L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("sun.awt.CGraphicsEnvironment", "                US                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("US", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("   /   ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   /   " + "'", str2.equals("   /   "));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java" + "'", str2.equals("/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("   /   ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("####################################################java hotspot(tm) 64-bit server vmjava hotspot(tm", "Java HotSpot(TM) 64-Bit Server VM", "                    444444444444444/4444444444444444");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, charSequence1);
        org.junit.Assert.assertNull(charSequence2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("", "/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!", "UTF-");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1 7 0_80- 15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", "SUN.LWAWT.MACOSX.cpRINTERjOB");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("Mac OS X", "");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concatWith("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", (java.lang.Object[]) strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny(":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:", strArray8);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray3, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 176 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Mac OS X" + "'", str9.equals("Mac OS X"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!", "jAVA vIRTUAL mACHINE sPECIFICATION##################", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("sun.lwawt.macosx.LWCToolkit", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 55, 100.0d, (double) 16);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################4444/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!" + "'", str1.equals("hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/xed mode", (int) (byte) -1, "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/xed mode" + "'", str3.equals("/xed mode"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("64", "HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "64" + "'", str2.equals("64"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("", "24.80-B11", 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/", (java.lang.CharSequence) "hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java" + "'", str1.equals("/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java", "/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java" + "'", str2.equals("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", " OS X OS X OS X OS X4 OS X3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("ac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ac OS " + "'", str1.equals("ac OS "));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("/USERS/SOPHIE", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("Java Platform API Specification", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("roaroproc elcaoit", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie", 1, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!" + "'", str1.equals("Hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray5);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7./1.7.0", '#');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("Hi#!#4444#hi#!", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java" + "'", str3.equals("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("###################################################################################oracle corporatio", "io");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("hi!", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("I!", "!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80", " OS X", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Hi#!#4444#hi#!", "!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi#!#4444#hi#" + "'", str2.equals("Hi#!#4444#hi#"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("ac OS ", ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", 0, 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/libr" + "'", str3.equals("/libr"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE cORPORATIO" + "'", str1.equals("oRACLE cORPORATIO"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H", "hi#!#4444#hi#!", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H" + "'", str3.equals("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "racle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (-1), 8L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        double[] doubleArray4 = new double[] { 0.0d, (byte) 1, (short) -1, (-1) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/Users/sophie", (int) (short) -1);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "", 1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("/USERS/SOPHIE", strArray5, strArray9);
        java.lang.String[] strArray11 = null;
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray5, strArray11);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, ' ');
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/USERS/SOPHIE" + "'", str10.equals("/USERS/SOPHIE"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str12.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/", "hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Java HotSpot(TM) 64-Bit Server VM", 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/libr", "oracle corporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java", 217, "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java44444444444444444444444444444444444444444444444" + "'", str3.equals("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java44444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Mac OS X", "                                                                     444444444444444/4444444444444444                                                                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.7", "sun.lwawt.macosx.CPrinterJob", "racle corporatio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!4444hi!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("en");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80-b15", strArray2, strArray4);
        java.lang.Class<?> wildcardClass6 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7.0_80-b15" + "'", str5.equals("1.7.0_80-b15"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("oRACLE cORPORATIO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE cORPORATIO" + "'", str1.equals("oRACLE cORPORATIO"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444", "sun.awt.CGraphicsEnvironment", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444" + "'", str3.equals("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "170_80-15" + "'", str3.equals("170_80-15"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Java Platform API Specification", (int) (short) 1, 1366);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("###################################################################################oracle corporatio", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("OracleCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproCelcarO" + "'", str1.equals("noitaroproCelcarO"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 32L, 0.0d, (double) 1L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mac OS X", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mac OS X" + "'", str4.equals("Mac OS X"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Mac OS X" + "'", str5.equals("Mac OS X"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("en", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                         en                         " + "'", str2.equals("                         en                         "));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("IOOR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java HotSpot(TM) 64-Bit Server VM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                      Oracle corporatio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 10, (float) 100, (float) 18L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Hi#!#4444#hi#", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi#!#4444#hi#" + "'", str2.equals("Hi#!#4444#hi#"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("24.80-B11", 1364);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("                         en                         ", 0, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("oRACLE cORPORATIO");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"oRACLE cORPORATIO\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.7", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!" + "'", str2.equals("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 10, (long) 2, (long) 31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 31L + "'", long3 == 31L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java Virtual Machine Specification##################", "086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification##################" + "'", str3.equals("Java Virtual Machine Specification##################"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.14.3", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("/libr", (java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.14.3" + "'", str5.equals("10.14.3"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("", "hi#!#4444#hi#!", 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java", (int) '4', "HI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java" + "'", str3.equals("/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!", 1364);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("java hotspot(tm) 64-bit server vm", "/libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str2.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                             hi!", (int) (byte) 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        float[] floatArray1 = new float[] { (-1) };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("444444444444444/444444444444444", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Mac OS X", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents(":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:" + "'", str1.equals(":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize(charSequence0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Oracle corporatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("444444444444444/444444444444444", "       :");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/!sd oids", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/!sd oids" + "'", str2.equals("/!sd oids"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "444444444444444/4444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!" + "'", str2.equals("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("####################################################java hotspot(tm) 64-bit server vmjava hotspot(tm", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("ioor", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Oracle corporatio", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle corporatio" + "'", str2.equals("Oracle corporatio"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!", "Java Platform API Specification", 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("hi!", "sophie", 1);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong(":");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("racle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatio", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray2 = null;
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceEach("hi!#######################################################################################################################################", strArray1, strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!#######################################################################################################################################" + "'", str3.equals("hi!#######################################################################################################################################"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/", "                                      Oracle corporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi#!#4444#hi#!", "64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        java.lang.Object[] objArray1 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concatWith("                US                                 US                                 US                                 US        10.14.3", objArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!", (double) 2.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Hi#!#4444#hi#!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi#!#4444#hi#!" + "'", str1.equals("Hi#!#4444#hi#!"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("hi#!#4444#hi#!", (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Hi#!#4444#hi#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi#!#4444#hi#" + "'", str1.equals("Hi#!#4444#hi#"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java", (-1), "1.7./1.7.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str1.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", 310, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("US", "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/", "oracle corporatio");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444", (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("US", (int) (short) 0, 217);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        long[] longArray5 = new long[] { (short) -1, 2, 0, (short) 100, 'a' };
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("sun.lwawt.macosx.LWCToolkit", "                                                                     444444444444444/4444444444444444                                                                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ava\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "24.80-B11", 31);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("x86_64", "/libr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "noitaroproCelcarO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph", "                                  444444444444444/4444444444444444                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph" + "'", str2.equals("sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(" OS X", 0, "ac OS ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " OS X" + "'", str3.equals(" OS X"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '#', (long) 10, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("I!", 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "I!" + "'", str3.equals("I!"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("roaroproc elcaoit", "HI!4444HI!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Java Virtual Machine Specification", "I!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("HI!4444HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!4444hi!" + "'", str1.equals("hi!4444hi!"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("I!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "I!" + "'", str1.equals("I!"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("hi!#######################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!#######################################################################################################################################" + "'", str1.equals("HI!#######################################################################################################################################"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Oracle Corporatio", "java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporatio" + "'", str2.equals("Oracle Corporatio"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 100, (byte) -1, (byte) -1, (byte) 0, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!", "hi#!#4444#hi#!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!" + "'", str2.equals("HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("sun.lwawt.macosx.CPrinterJob", "oitaroproc elcaro");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Platform API Specification", 1366L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1366L + "'", long2 == 1366L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(":", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                US                                 US                                 US                                 US        10.14.3", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!4444hi!");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("Java Virtual Machine Specification", strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("444444444444444/4444444444444444", (java.lang.Object[]) strArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny("1.7.0_80-b15", strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!" + "'", str6.equals("hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!" + "'", str9.equals("hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!", "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("noitaroproCelcarO", 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803", "hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod", 16);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("JAVA HOTSPOT(TM) 64-BIT SERVER VM", "10.14.3                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("UTF-", ":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-" + "'", str3.equals("UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("###################################################################################Oracle corporatio", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################################################################Oracle corporatio" + "'", str2.equals("###################################################################################Oracle corporatio"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("iooHI!ioor", '#');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) (byte) -1, (float) 310);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 310.0f + "'", float3 == 310.0f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("HI!#######################################################################################################################################", "racle corporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!#######################################################################################################################################" + "'", str2.equals("HI!#######################################################################################################################################"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("io");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("51.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("1.7./1.7.0", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 14, 1.7f, (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 14.0f + "'", float3 == 14.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!", "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java44444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!" + "'", str2.equals("hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("10.14.3                                                                                          ", "###################################################################################oracle corporatio", 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "sophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesoph");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("   /    ", "sun.lwawt.macosx.CPrinterJob", "444444444444444/4444444444444444");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Hi#!#4444#hi#!", "sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("sun.lwawt.macosx.LWCToolkit", "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("###################################################################################oracle corporatio", "HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################################################################oracle corporatio" + "'", str2.equals("###################################################################################oracle corporatio"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "jAVA vIRTUAL mACHINE sPECIFICATION##################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("###################################################################################Oracle corporatio", "444444444444444/4444444444444444", 100);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!", "UTF-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!" + "'", str2.equals("HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                    444444444444444/4444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                    444444444444444/4444444444444444" + "'", str1.equals("                    444444444444444/4444444444444444"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("racle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatio", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Oracle Corporatio", "hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str1.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("10.14.3", "hi#!#4444#hi#!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(" OS X OS X OS X OS X4 OS X3", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X3 OS X4 OS X OS X OS X OS" + "'", str2.equals("X3 OS X4 OS X OS X OS X OS"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java44444444444444444444444444444444444444444444444", "", 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java44444444444444444444444444444444444444444444444" + "'", str3.equals("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java44444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444", 217, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444" + "'", str3.equals("444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("/USERS/SOPHIE", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("Java Platform API Specification", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HI!", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        java.lang.String[] strArray3 = new java.lang.String[] { "" };
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("", strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", ' ');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.7.0_80", strArray3, strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.7.0_80" + "'", str10.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod", "Hi#!#4444#hi#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod" + "'", str2.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "   /   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("X3 OS X4 OS X OS X OS X OS", "###################################################################################Oracle corporatio", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java(TM) SE Runtime Environment", "UTF-8", 100);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("                             hi!", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sun.awt.CGraphicsEnvironment", "                                      Oracle corporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("1 7 0_80- 15", "444444444444444/4444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!", "sophie", 1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hi!#######################################################################################################################################", 32, "441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!#######################################################################################################################################" + "'", str3.equals("hi!#######################################################################################################################################"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("en", "I!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        char[] charArray1 = new char[] {};
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/", charArray1);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hi#!#ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr#hi#!", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi#!#ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr#hi#!" + "'", str3.equals("hi#!#ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr#hi#!"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("sophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesoph", strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7./1.7.0", "io", 35);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", strArray3, strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim" + "'", str9.equals("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("", "                                      Oracle corporatio", 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) (byte) -1, (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!", " OS X OS X OS X OS X4 OS X3", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM", charArray5);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "ac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("oitaroproc elcaro", 310);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oitaroproc elcaro                                                                                                                                                                                                                                                                                                     " + "'", str2.equals("oitaroproc elcaro                                                                                                                                                                                                                                                                                                     "));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("", "170_80-15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("!", "Oracle corporatio", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                US                                 US                                 US                                 US        10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US                                 US                                 US                                 US        10.14.3" + "'", str1.equals("US                                 US                                 US                                 US        10.14.3"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", (java.lang.CharSequence) "oracle corporatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "hi#!#ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr#hi#!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi#!#ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr#hi#!" + "'", str1.equals("hi#!#ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr#hi#!"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("                    444444444444444/4444444444444444", 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("                         en                         ", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("hi/Users/sophie!/Users/sophiehhhh/Users/sophiehi/Users/sophie!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "hi!4444hi!", (int) (short) -1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str5.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("", "444444444444444/444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("HI!#######################################################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: HI!####################################################################################################################################### is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(1366, 138, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specification##################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("UTF-8", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H", 138);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.14.3", (double) 4.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("X3 OS X4 OS X OS X OS X OS", "/xed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "http://jaO", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 138, (long) (short) 10, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("!", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "                                      Oracle corporatio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!" + "'", str3.equals("!"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '#', (int) (short) 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hi#!#4444#hi#!", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65 + "'", int2 == 65);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", "Oracle Corporatio", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "HI!#######################################################################################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/Users/sophie", (int) (short) -1);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("hi!4444hi!", strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny("O", strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "HI!4444HI!");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 0, (int) '#', 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        double[] doubleArray6 = new double[] { 216.0f, 35L, 31, 18, 35.0d, 0.0d };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat(" OS X OS X OS X OS X4 OS X3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"OS X OS X OS X OS X4 OS X3\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "10.14.3                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle Corporation" + "'", str1.equals("oracle Corporation"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("51.0", "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/Users/sophie", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim" + "'", str2.equals("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("/USERS/SOPHIE", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("1.7.0_80-b15", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("HI!#######################################################################################################################################", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/USERS/SOPHIE", "                US                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                             hi!", "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("java hotspot(tm) 64-bit server vm", "", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/xed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/xed mode" + "'", str1.equals("/xed mode"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("mixed mode", "US                                 US                                 US                                 US        10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaaaaaaa:aaaaaaaaa", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaa:aaaaaaaaa" + "'", str2.equals("aaaaaaaa:aaaaaaaaa"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) '4', 0L, 4L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 18L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/!sd oids", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!", "US                                 US                                 US                                 US        10.14.3", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI/uER/OPHIE!/uER/OPHIE/uER/OPHIEHI/uER/OPHIE!" + "'", str3.equals("HI/uER/OPHIE!/uER/OPHIE/uER/OPHIEHI/uER/OPHIE!"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1 7 0_80- 15" + "'", str4.equals("1 7 0_80- 15"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 100, 8, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporatio", "                    444444444444444/4444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        float[] floatArray3 = new float[] { 10.0f, 1, 2 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 10.0f + "'", float4 == 10.0f);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                    444444444444444/4444444444444444", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("####################################################");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sophie", "                US                 ", 216);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle corporatio", "\n");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle corporatio" + "'", str3.equals("Oracle corporatio"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", 31, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!" + "'", str3.equals("Hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod" + "'", str1.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim" + "'", str1.equals("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("oracle corporatio", "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                      Oracle corporatio");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                                     444444444444444/4444444444444444                                                                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("/USERS/SOPHIE", charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "OracleCorporation", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!" + "'", str1.equals("hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("!", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny(" OS X OS X OS X OS X4 OS X3", strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concatWith("", (java.lang.Object[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "!" + "'", str7.equals("!"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("", "Java(TM) SE Runtime Environment", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.7", "hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!" + "'", str2.equals("hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/libr", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (byte) -1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "hi/Users/sophie!/Users/sophiehhhh/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:", "24.80-b11", 10, 216);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":10.14.3:124.80-b11" + "'", str4.equals(":10.14.3:124.80-b11"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!", "", 170);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "oitaroproc elcaro");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("/", "UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-", "OracleCorporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("US", "UTF-8", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\n\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:" + "'", str2.equals(".3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("IOOR", "sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!" + "'", str1.equals("!"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.7.0_80", 65);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_80" + "'", str2.equals("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_80"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", 4, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str3.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("oracle corporatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java", "Mc O X", 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", ":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("       :");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "       :" + "'", str1.equals("       :"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1 7 0_80- 15", "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1 7 0_80- 15" + "'", str2.equals("1 7 0_80- 15"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("UTF-8", " OS X OS X OS X OS X4 OS X3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aaaaaaaa:aaaaaaaaa", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("x86_64", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', 35, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hihi/Users/soph/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/Users/sophie!!" + "'", str3.equals("hihi/Users/soph/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/Users/sophie!!"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.7./1.7.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7./1.7.0" + "'", str1.equals("1.7./1.7.0"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "racle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "   /   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "java HotSpot(TM) 64-Bit Server VM", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                      Oracle corporatio", 310);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                     Oracle corporatio" + "'", str2.equals("                                                                                                                                                                                                                                                                                                     Oracle corporatio"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "", (int) '4');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.7./1.7.0");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str5.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph" + "'", str1.equals("sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################4444/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################4444/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!" + "'", str1.equals("hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################4444/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("oitaroproc elcaro                                                                                                                                                                                                                                                                                                     ", "oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oitaroproc elcaro                                                                                                                                                                                                                                                                                                     " + "'", str2.equals("oitaroproc elcaro                                                                                                                                                                                                                                                                                                     "));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "sophie", 5, 216);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("hi/Users/sophie!/Users/sophiehhhh/Users/sophiehi/Users/sophie!", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "I!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("Hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", "oracle corporatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                         en                         ", "HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!", "1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java Virtual Machine Specification##################", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(138, 138, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesoph", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                         en                         ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/libr", "HI!", 35, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "HI!" + "'", str4.equals("HI!"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("http://jaO", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (int) (short) -1, 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str4.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("24.80-b11", "                US                                 US                                 US                                 US        10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                US                                 US                                 US                                 US        10.14.3" + "'", str2.equals("                US                                 US                                 US                                 US        10.14.3"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.7", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7                                " + "'", str2.equals("1.7                                "));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM", "170_80-15", (int) (short) 10, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "J170_80-15ot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM" + "'", str4.equals("J170_80-15ot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "oitaroproc elcaro", "Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                                                                                                                                                                                                                                     Oracle corporatio");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("SUN.LWAWT.MACOSX.cpRINTERjOB", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(":", "1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/!sd oids", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/!sd oids                                                                                        " + "'", str2.equals("/!sd oids                                                                                        "));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("oracle corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporatio" + "'", str1.equals("oracle corporatio"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph", " OS X OS X OS X OS X4 OS X3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny("", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!4444hi!");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("mixed mode", strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 35, 170);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("       :", "/xed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       :" + "'", str2.equals("       :"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444" + "'", str2.equals("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java", "oRACLE cORPORATIO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("hihi/Users/soph/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/Users/sophie!!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hihi/Users/soph/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/Users/sophie!!" + "'", str1.equals("hihi/Users/soph/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/Users/sophie!!"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("   /   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("Hi#!#4444#hi#!", "   /    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("http://java.oracle.com/", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                     http://java.oracle.com/                                     " + "'", str2.equals("                                     http://java.oracle.com/                                     "));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444" + "'", str1.equals("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/", '4');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("HI!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("oRACLE cORPORATIO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java", "                                     http://java.oracle.com/                                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("                                      Oracle corporatio", "J170_80-15ot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("###################################################################################Oracle corporatio", "                         en                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################################################################Oracle corporatio" + "'", str2.equals("###################################################################################Oracle corporatio"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        float[] floatArray2 = new float[] { 10L, 4.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 10.0f + "'", float4 == 10.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 4.0f + "'", float5 == 4.0f);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "Mc O X", "racle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 2L, (double) 1366, 1.7000000476837158d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1366.0d + "'", double3 == 1366.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Hi#!#4444#hi#!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Hi#!#4444#hi#!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("sophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesoph", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiesopj v  HotSpot(TM) 64-Bi" + "'", str2.equals("sophiesopj v  HotSpot(TM) 64-Bi"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "####################################################java hotspot(tm) 64-bit server vmjava hotspot(tm", (java.lang.CharSequence) "oitaroproc elcaro                                                                                                                                                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1 7 0_80- 15", "Hi#!#4444#hi#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!", "Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "IOOR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1.7");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/libr", ".3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("en", "J170_80-15ot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J170_80-15ot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("J170_80-15ot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("http://jaO", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("1.7.0_80", "racle corporatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.14.3", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("1.7.0_80-b15", strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.14.3" + "'", str6.equals("10.14.3"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 55L, (double) 4.0f, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 55.0d + "'", double3 == 55.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("170_80-15", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", "\n", 217);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "io");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mixed m\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("OracleCorporation", "", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("!", "Oracle corporatio", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803", "noitaroproCelcarO", "!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H", "170_80-15", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Platform API Specification", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("UTF-", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                     http://java.oracle.com/                                     ", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("sophiesopj v  HotSpot(TM) 64-Bi", "racle corporatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", "hi!4444hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!" + "'", str2.equals("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "441.7.0_80-b15hi!hi!hi!OracleCorporationhi!1.7.0_80444444444444/4444444444444444" + "'", str1.equals("441.7.0_80-b15hi!hi!hi!OracleCorporationhi!1.7.0_80444444444444/4444444444444444"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "", (int) '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "1.7.0_80");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray8, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str6.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.7.0_80" + "'", str11.equals("1.7.0_80"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(".3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:", 55, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:" + "'", str3.equals(".3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EIHPOS/SRESU/" + "'", str1.equals("EIHPOS/SRESU/"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("OracleCorporation", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation" + "'", str2.equals("OracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("mixed mode", "Mac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("oitaroproc elcaro                                                                                                                                                                                                                                                                                                     ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 1366L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', (int) (short) 100, 1366);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!" + "'", str2.equals("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("64");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("OracleCorporation", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OrcleCorportion" + "'", str2.equals("OrcleCorportion"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 55, 55L, (long) 31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 31L + "'", long3 == 31L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 2.0f, (double) 310, (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("hihi/Users/soph/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/Users/sophie!!", "hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 14, (long) ' ', (long) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("oitaroproc elcaro", "                                  444444444444444/4444444444444444                                  ", "oracle corporatio");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("sophiesopj v  HotSpot(TM) 64-Bi");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7.0_80");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "", 14);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str4.equals("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("hi#!#ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr#hi#!", 138);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("J170_80-15ot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J170_80-15OT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str1.equals("J170_80-15OT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("java hotspot(tm) 64-bit server vm", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!hi!", "EIHPOS/SRESU/", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/moc.elcaro.avaj//:ptth" + "'", str1.equals("/moc.elcaro.avaj//:ptth"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("US", "OrcleCorportion", "hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("!", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "####################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7                                ", (-1), ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7                                " + "'", str3.equals("1.7                                "));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!" + "'", str1.equals("hi!hi!"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/libr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/libr" + "'", str1.equals("/libr"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("UTF-8", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H", 217);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("24.80-B11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B1" + "'", str1.equals("24.80-B1"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "", "", "", "hi!" };
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("hi!", strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!4444hi!" + "'", str9.equals("hi!4444hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!hi!" + "'", str10.equals("hi!hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!hi!" + "'", str11.equals("hi!hi!"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/", 14, "                                                                     444444444444444/4444444444444444                                                                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "             /" + "'", str3.equals("             /"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        char[] charArray8 = new char[] {};
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("/USERS/SOPHIE", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("Java Platform API Specification", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray8);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "racle corporatio", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str2.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("444444444444444/4444444444444444", "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444/4444444444444444" + "'", str2.equals("444444444444444/4444444444444444"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", charSequence2.equals("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }
}

