import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("hi!#######################################################################################################################################", 1364, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("                US                                 US                                 US                                 US        10.14.3", "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph", "io", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph" + "'", str3.equals("sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 100, 18, 138);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 138 + "'", int3 == 138);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("US", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10L, (double) 10, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.7./1.7.0", "10.14.3                                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7./1.7.0" + "'", str2.equals("1.7./1.7.0"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("IOOR", "   /    ", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!4444hi!");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("Java Virtual Machine Specification", strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!");
        java.lang.String[] strArray7 = null;
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("java hotspot(tm) 64-bit server vm", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!" + "'", str6.equals("hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str8.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.awt.CGraphicsEnvironment", 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        char[] charArray5 = new char[] { 'a', 'a', '#', '4' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mac OS X", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) '#', (long) (short) 1, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 217 + "'", int1 == 217);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/USERS/SOPHIE", 2, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE" + "'", str3.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("####################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("", "dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("###################################################################################oracle corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###################################################################################oracle corporatio" + "'", str1.equals("###################################################################################oracle corporatio"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 1L, (float) 1, (float) 2L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "oitaroproc elcaro", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("10.14.3                                                                                          ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java Virtual Machine Specification##################", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification##################" + "'", str2.equals("Java Virtual Machine Specification##################"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("http://java.oracle.com/", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", (java.lang.CharSequence) "http://jaO");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!" + "'", charSequence2.equals("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java Virtual Machine Specification##################", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680", "###################################################################################Oracle corporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################################################################Oracle corporatio" + "'", str2.equals("###################################################################################Oracle corporatio"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java HotSpot(TM) 64-Bit Server VM", 0, "dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str1.equals("SUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) 100, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(4.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", "", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("oracle corporatio", 170);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("US", "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.7.0_80-b15", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("x86_64", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("http://jaO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://jaO" + "'", str1.equals("http://jaO"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("hi!", 0, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", "Oracle corporatio");
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) (-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!hi!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.7.0_80", "hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1366 + "'", int1 == 1366);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("HI!", 4, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("24.80-b11", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat(":");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("hi#!#4444#hi#!", "10.14.3                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                             hi!", "http://jaO", 217);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "   /    ", "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("x86_64", "                             hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("24.80-b11", (int) (short) 10, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("O", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java", "1.7.0_80-b15", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java" + "'", str3.equals("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("IOOR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("io", "hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "io" + "'", str2.equals("io"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 100, 100, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " OS X", "hi#!#4444#hi#!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat(":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80-b15", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("####################################################", "", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################" + "'", str3.equals("####################################################"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("\n", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Mac OS X", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mc O X" + "'", str4.equals("Mc O X"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("hi!", 1364, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7.0_80", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Mc O X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java(TM) SE Runtime Environment", "UTF-8", 100);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str5.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "                             hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                             hi!" + "'", str1.equals("                             hi!"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", (java.lang.CharSequence) "Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55 + "'", int2 == 55);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", charSequence2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B11" + "'", str1.equals("24.80-B11"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("io", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "io" + "'", str3.equals("io"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("####################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#######\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("SUN.LWAWT.MACOSX.cpRINTERjOB", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str2.equals("SUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:", "10.14.3                                                                                          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Oracle corporatio", "http://jaO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "racle corporatio" + "'", str2.equals("racle corporatio"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi/Users/sophie!/Users/sophiehhhh/Users/sophiehi/Users/sophie!" + "'", str3.equals("hi/Users/sophie!/Users/sophiehhhh/Users/sophiehi/Users/sophie!"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("x86_64", (int) (short) 1, "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!", "10.14.3                                                                                          ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("java HotSpot(TM) 64-Bit Server VM", "hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (byte) 100);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("HI!", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", "1.7", 138);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!" + "'", str1.equals("HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 1366, (long) (short) 100, 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1366L + "'", long3 == 1366L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "sophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesoph");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/xed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/xed mode" + "'", str1.equals("/xed mode"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Virtual Machine Specification", "OracleCorporation", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80", 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 0.0f, (float) 10L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java", "1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!4444hi!");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "/Users/sophie");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!" + "'", str3.equals("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 10, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!", "hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444", "!", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod" + "'", str1.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/", (int) (short) 1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("Java Virtual Machine Specification", "###################################################################################oracle corporatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "", 1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("10.14.3                                                                                          ", (java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "iooHI!ioor");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("oitaroproc elcaro", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "roaroproc elcaoit" + "'", str2.equals("roaroproc elcaoit"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '#', (int) '4', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 55);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                  444444444444444/4444444444444444                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680", "                US                 ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str4.equals("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("US", "dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80", "io");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.7.0_80-b15", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("hi#!#4444#hi#!", "Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/USERS/SOPHIE", "sophie", 4);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny("oitaroproc elcaro", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/USERS/SOPHIE" + "'", str5.equals("/USERS/SOPHIE"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("IOOR", (int) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "1.7.0_80", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie", 170);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Oracle corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle corporatio" + "'", str1.equals("Oracle corporatio"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "HI!", "1.7.0_80", 55);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str4.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!", "x86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("###################################################################################Oracle corporatio", (int) (byte) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################################################################Oracle corporatio" + "'", str3.equals("###################################################################################Oracle corporatio"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim" + "'", str2.equals("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!", "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "http://jaO", (java.lang.CharSequence) "                US                                 US                                 US                                 US        10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 138 + "'", int2 == 138);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("####################################################");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(52.0f, (float) 1L, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "iooHI!ioor");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", "sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("http://jaO");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("444444444444444/4444444444444444", "sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444/4444444444444444" + "'", str2.equals("444444444444444/4444444444444444"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "", "", "", "hi!" };
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("hi!", strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny("   /    ", strArray7);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "", "", "", "hi!" };
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("hi!", strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '4');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.concatWith("", (java.lang.Object[]) strArray7);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!4444hi!" + "'", str10.equals("hi!4444hi!"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!hi!" + "'", str12.equals("hi!hi!"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                             hi!", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                             hi!" + "'", str2.equals("                             hi!"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", (int) (short) -1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("444444444444444/4444444444444444", "dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", "iooHI!ioor");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444/4444444444444444" + "'", str3.equals("444444444444444/4444444444444444"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim" + "'", str2.equals("dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring(" OS X", (int) (byte) 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " OS X" + "'", str3.equals(" OS X"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!" + "'", str1.equals("hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("iooHI!ioor", "", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(1.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sun.lwawt.macosx.CPrinterJob", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("ioor", "", "###################################################################################oracle corporatio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ioor" + "'", str3.equals("ioor"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("444444444444444/444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444/444444444444444" + "'", str1.equals("444444444444444/444444444444444"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("444444444444444/444444444444444", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444" + "'", str2.equals("444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", 1364);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 170, (double) 1364, (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "####################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("x86_64", "                US                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     " + "'", str2.equals("     "));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 0L, (long) 8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.7", "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java", "http://java.oracle.com/");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("Java(TM) SE Runtime Environment", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("en", "/Users/sophie", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sun.awt.CGraphicsEnvironment", 31, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("51.0", (int) (short) 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Oracle Corporatio", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod" + "'", str2.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("x86_64", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("     ", 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Java HotSpot(TM) 64-Bit Server VM", "64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim" + "'", str2.equals("dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 0, "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        float[] floatArray1 = new float[] { (-1.0f) };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("sun.awt.CGraphicsEnvironment", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("IOOR");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Mc O X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mc O X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14." + "'", str3.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14."));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680", (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!4444HI!", "", 8);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java", 4, 55);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        double[] doubleArray4 = new double[] { 1.0d, 10.0f, 35, 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/xed mode", 0, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/xed mode" + "'", str3.equals("/xed mode"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", ":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:" + "'", str2.equals(":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) 'a', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "oracle corporatio", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("roaroproc elcaoit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "roaroproc elcaoit" + "'", str1.equals("roaroproc elcaoit"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM", ":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:", "OracleCorporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "10.14.3                                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3                                                                                          " + "'", str1.equals("10.14.3                                                                                          "));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java", "hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!", "Oracle Corporatio");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!" + "'", str1.equals("hi!hi!"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("oitaroproc elcaro", "hi!#######################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "HI!4444HI!", (java.lang.CharSequence) "Oracle corporatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "1 7 0_80- 15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51 + "'", int2 == 51);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        char[] charArray7 = new char[] {};
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("/USERS/SOPHIE", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("1.7.0_80-b15", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "racle corporatio", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "oitaroproc elcaro");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80", "###################################################################################Oracle corporatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-" + "'", str1.equals("UTF-"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Mc O X");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("   /    ", ":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                             hi!", "oracle corporatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) ' ', 1366L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1366L + "'", long3 == 1366L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("roaroproc elcaoit", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("O", "                US                 ", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/xed mode");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "racle corporatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double[] doubleArray4 = new double[] { 1.0d, 10.0f, 35, 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 35.0d + "'", double6 == 35.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        char[] charArray8 = new char[] { '#', '#', '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Platform API Specification", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7./1.7.0", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                  444444444444444/4444444444444444                                  ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("ioor", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Java Virtual Machine Specification", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java", "444444444444444/4444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("64", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "64" + "'", str2.equals("64"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("###################################################################################oracle corporatio", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################################################################oracle corporatio" + "'", str2.equals("###################################################################################oracle corporatio"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "HI!4444HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e" + "'", str2.equals("e"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("SUN.LWAWT.MACOSX.cpRINTERjOB");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SUN.LWAWT.MACOSX.cpRINTERjOB\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                  444444444444444/4444444444444444                                  ", (long) 1364);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1364L + "'", long2 == 1364L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("####################################################", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################" + "'", str2.equals("####################################################"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0, (double) 217, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("x86_64");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                  444444444444444/4444444444444444                                  ", "51.0");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "iooHI!ioor");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java", 8, 138);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                  444444444444444/4444444444444444                                  " + "'", str4.equals("                                  444444444444444/4444444444444444                                  "));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!" + "'", str1.equals("hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("x86_64", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 3, 4L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4L + "'", long3 == 4L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) '4', (float) 6, (float) 'a');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 6.0f + "'", float3 == 6.0f);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("O", "HI!", "US");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 55, (double) (byte) 10, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 55.0d + "'", double3 == 55.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("/USERS/SOPHIE", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("Java Platform API Specification", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("1.7", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(35.0f, 0.0f, (float) 16);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("UTF-", 0, "sophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesoph");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-" + "'", str3.equals("UTF-"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("1.7.0_80-b15", "1.7.0_80-b15", 55);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 16, (long) 5, (long) 55);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 55L + "'", long3 == 55L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("hi!", "sophie", 1);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concatWith("####################################################", (java.lang.Object[]) strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, ":");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("1.7.0_80", 170);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny("\n", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java Platform API Specification", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("http://java.oracle.com/");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", 138);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "UTF-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/xed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/xed mode\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("sophie", "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("                                  444444444444444/4444444444444444                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 100, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mixed mode", '4');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        int[] intArray4 = new int[] { 170, '#', 100, 100 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 170 + "'", int5 == 170);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 170 + "'", int6 == 170);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("HI!", 4, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("http://jaO", "51.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 100.0f, 0.0d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("sun.awt.CGraphicsEnvironment", "444444444444444/444444444444444", "Java Virtual Machine Specification", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str4.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(1366);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("hi#!#4444#hi#!", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 1364);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 10, (long) 10, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        char[] charArray7 = new char[] { '#', '#', '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "O", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesoph", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("racle corporatio", "", 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "racle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatio" + "'", str3.equals("racle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatio"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444" + "'", str1.equals("444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("hi!4444hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!4444hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("SUN.LWAWT.MACOSX.cpRINTERjOB", "24.80-B11", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "/xed mode");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("mixed mode", strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "roaroproc elcaoit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "64" + "'", str1.equals("64"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/", "hi!4444hi!", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie", "sophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesoph");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("51.0", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java", "racle corporatio", "444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java" + "'", str3.equals("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("hi!", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "hi#!#4444#hi#!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 14 + "'", int1 == 14);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "   /    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("hi!", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sophie", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("http://java.oracle.com/", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("O", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("hi!4444hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) ":", (java.lang.CharSequence) "/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 216 + "'", int2 == 216);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H" + "'", str2.equals("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        short[] shortArray3 = new short[] { (short) 0, (short) 10, (short) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                US                                 US                                 US                                 US        10.14.3", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Mc O X", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "hi#!#4444#hi#!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        float[] floatArray1 = new float[] { 3 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 3.0f + "'", float4 == 3.0f);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("http://java.oracle.com/", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("                             hi!", "ioor");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 6, (double) '#', (double) 1.7f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java HotSpot(TM) 64-Bit Server VM", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 100, 100.0f, 1.7f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.7f + "'", float3 == 1.7f);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", "Oracle corporatio");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("Java Virtual Machine Specification##################", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################4444/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!" + "'", str4.equals("hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################4444/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("64", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "64" + "'", str3.equals("64"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 18, (float) 32, 4.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("OracleCorporation", (int) (byte) 0, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/xed mode", "Java Virtual Machine Specification##################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/xed mode" + "'", str2.equals("/xed mode"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!", "1.7./1.7.0", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("1 7 0_80- 15", 170);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("java hotspot(tm) 64-bit server vm", 138);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Oracle corporatio", "HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle corporatio" + "'", str2.equals("Oracle corporatio"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("io", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "io" + "'", str2.equals("io"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "", (int) '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str5.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!", (int) ' ', "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!" + "'", str3.equals("HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java HotSpot(TM) 64-Bit Server VM", "sophie", " OS X");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("e", "   /    ", "hi!hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e" + "'", str3.equals("e"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) -1, (int) 'a', 1364);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE", "", 35);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny("Mac OS X", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/USERS/SOPHIE" + "'", str6.equals("/USERS/SOPHIE"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 31, (long) 100, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                             hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(8, 3, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("     ", (int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "IOOR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                  444444444444444/4444444444444444                                  ", "51.0");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "iooHI!ioor");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                  444444444444444/4444444444444444                                  " + "'", str4.equals("                                  444444444444444/4444444444444444                                  "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "                                  444444444444444/4444444444444444                                  " + "'", str5.equals("                                  444444444444444/4444444444444444                                  "));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803", "racle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("   /    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   /   " + "'", str1.equals("   /   "));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("   /    ", "hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("UTF-8");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporatio" + "'", str1.equals("Oracle Corporatio"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 100, (byte) -1, (byte) -1, (byte) 0, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!" + "'", str1.equals("hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("oracle corporatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("e");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "e" + "'", str1.equals("e"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph" + "'", str2.equals("sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(":", 18, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaa:aaaaaaaaa" + "'", str3.equals("aaaaaaaa:aaaaaaaaa"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Oracle corporatio", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("aaaaaaaa:aaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "###################################################################################Oracle corporatio", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Oracle Corporation", 16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680", "   /    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("24.80-B11", "O");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-B11" + "'", str2.equals("24.80-B11"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        short[] shortArray2 = new short[] { (byte) -1, (byte) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1 7 0_80- 15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim" + "'", str2.equals("dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("java hotspot(tm) 64-bit server vm", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str2.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny("Java Platform API Specification", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("hi!4444hi!", 1, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) -1, (float) 14, (float) 55L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 55.0f + "'", float3 == 55.0f);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 310 + "'", int1 == 310);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Mac OS X", (int) (byte) 1, 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ac OS X" + "'", str3.equals("ac OS X"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph", "                                  444444444444444/4444444444444444                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph" + "'", str2.equals("sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "hi/Users/sophie!/Users/sophiehhhh/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java", (float) 216);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 216.0f + "'", float2 == 216.0f);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 310, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.7.0_80", "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "!", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("IOOR", "sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "IOOR" + "'", str2.equals("IOOR"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("HI!4444HI!", "dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!4444HI!" + "'", str2.equals("HI!4444HI!"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("UTF-8", "hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTF-8" + "'", str4.equals("UTF-8"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                             hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.7./1.7.0", "hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7./1.7.0" + "'", str2.equals("1.7./1.7.0"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "hi!hi!", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("HI!", "java HotSpot(TM) 64-Bit Server VM", "1.7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "I!" + "'", str3.equals("I!"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("!", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0);
        java.lang.String[] strArray7 = new java.lang.String[] { ":", "hi#!#4444#hi#!" };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "http://jaO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (long) 18);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 18L + "'", long2 == 18L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("444444444444444/4444444444444444", 170);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                     444444444444444/4444444444444444                                                                     " + "'", str2.equals("                                                                     444444444444444/4444444444444444                                                                     "));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("ac OS X", "mixed mode", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("10.14.3                                                                                          ", "Java Platform API Specification");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "10.14.3                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("ac OS X", "oracle corporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ac OS X" + "'", str2.equals("ac OS X"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("hi!hi!", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("iooHI!ioor");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("IOOR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ioor" + "'", str1.equals("ioor"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("roaroproc elcaoit", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "roaroproc elcaoit" + "'", str2.equals("roaroproc elcaoit"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "UTF-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                                     444444444444444/4444444444444444                                                                     ", 170);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                     444444444444444/4444444444444444                                                                     " + "'", str2.equals("                                                                     444444444444444/4444444444444444                                                                     "));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "hi/Users/sophie!/Users/sophiehhhh/Users/sophiehi/Users/sophie!", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 217, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 217.0f + "'", float3 == 217.0f);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!", (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("####################################################", (int) (byte) 100, "java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################java hotspot(tm) 64-bit server vmjava hotspot(tm" + "'", str3.equals("####################################################java hotspot(tm) 64-bit server vmjava hotspot(tm"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sun.awt.CGraphicsEnvironment", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("24.80-B11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"24.80-B11\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("O", "###################################################################################oracle corporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "O" + "'", str2.equals("O"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("hi!hi!", "hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!", "Java Platform API Specification");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod", "IOOR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod" + "'", str2.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        short[] shortArray2 = new short[] { (byte) -1, (byte) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.Class<?> wildcardClass4 = shortArray2.getClass();
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("java hotspot(tm) 64-bit server vm", "sophie", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/xed mode", "sun.lwawt.macosx.CPrinterJob", "hi/Users/sophie!/Users/sophiehhhh/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/!sd oids" + "'", str3.equals("/!sd oids"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("SUN.LWAWT.MACOSX.cpRINTERjOB", "java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/", 35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                     444444444444444/4444444444444444                                                                     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.7./1.7.0", "Java Virtual Machine Specification", "####################################################java hotspot(tm) 64-bit server vmjava hotspot(tm");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("444444444444444/444444444444444", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Java Virtual Machine Specification##################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA vIRTUAL mACHINE sPECIFICATION##################" + "'", str1.equals("jAVA vIRTUAL mACHINE sPECIFICATION##################"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 138);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/Users/sophie", (int) (short) -1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java(TM) SE Runtime Environment", strArray4, strArray8);
        java.lang.Class<?> wildcardClass10 = strArray8.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str9.equals("Java(TM) SE Runtime Environment"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str11.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14." + "'", str1.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14."));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("444444444444444/4444444444444444", 52, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                    444444444444444/4444444444444444" + "'", str3.equals("                    444444444444444/4444444444444444"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", 55);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Oracle corporatio", 55, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                      Oracle corporatio" + "'", str3.equals("                                      Oracle corporatio"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7./1.7.0", "###################################################################################oracle corporatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("", "Oracle corporatio", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("UTF-");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("http://java.oracle.com/", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}

