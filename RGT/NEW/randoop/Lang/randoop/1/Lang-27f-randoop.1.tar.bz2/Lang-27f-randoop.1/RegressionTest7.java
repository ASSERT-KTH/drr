import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 138);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#################o", "hi#!##hi#!", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", "SUN.LWAWT.MACOSX.cpRINTERjOB");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "                                      Oracle corporatio");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny("ac OS ", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hi!4444hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t", "               :                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t" + "'", str2.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((-1.0f), (float) 103, (float) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 103.0f + "'", float3 == 103.0f);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("HI!4444HI!", "ioor");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!4444HI!" + "'", str2.equals("HI!4444HI!"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("aaaaaaaaaaaaaaaaaaaaJavaaHotSpot(TM)a64-BitaServeraVMaaaaaaaaa", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                 " + "'", str1.equals("                 "));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/t/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /t/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "hihi/Users/soph/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/Users/sophie!!", (java.lang.CharSequence) "hihi/Users/soph/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/Users/sophie!!");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "hihi/Users/soph/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/Users/sophie!!" + "'", charSequence2.equals("hihi/Users/soph/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/Users/sophie!!"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("sun.lwawt.macosx.CPrinterJob", "####################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("I!", "hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################4444/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("JavaOracle corporatioOracle corporatioVirtualOracle corporatioOracle corporatioMachineOracle corporatioOracle corporatioSpecification##################", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("               :                                                                                 ", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ava Virtual Machine Specification##################", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("HI!#######################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#######################################################################################################################################!IH" + "'", str1.equals("#######################################################################################################################################!IH"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("####################################################", "sun.awt.CGraphicsEnvironment", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("java hotspot(tm) 64-bit server vm", "     ot(tm) 6a-bit server vm1.01", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str3.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("HI!4444HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!4444HI!" + "'", str1.equals("HI!4444HI!"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 165);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "oracle corporatio", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("oracle corporatio", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        short[] shortArray2 = new short[] { (byte) -1, (byte) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.Class<?> wildcardClass4 = shortArray2.getClass();
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Oracle corporatio", "JAVA HOTSPOT(TM) 6 -BIT SERVER VM                US                                 US                                 US                                 US        10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle corporatio" + "'", str2.equals("Oracle corporatio"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("4Users4sophie4Documents4defects4j4tmp4run_randoopipl_88h3_h56!2268!3", 217);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4Users4sophie4Documents4defects4j4tmp4run_randoopipl_88h3_h56!2268!3                                                                                                                                                     " + "'", str2.equals("4Users4sophie4Documents4defects4j4tmp4run_randoopipl_88h3_h56!2268!3                                                                                                                                                     "));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.String[] strArray7 = new java.lang.String[] { "1.7.0_80-b15", "hi!", "Oracle Corporation", "1.7.0_80" };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concatWith("hi!", (java.lang.Object[]) strArray7);
        java.lang.String[] strArray15 = new java.lang.String[] { "1.7.0_80-b15", "hi!", "Oracle Corporation", "1.7.0_80" };
        boolean boolean16 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("Java(TM) SE Runtime Environment", strArray7, strArray15);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, "sun.lwawt.macosx.cprinterjob", 51, 165);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 51");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80" + "'", str9.equals("1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str17.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(55, 64, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                     http://java.oracle.com/                                     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(".3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(5L, 53L, (long) 57);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1364L, (float) 52L, (float) 3L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/xed mode", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/xed mode" + "'", str2.equals("/xed mode"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("4", "Oracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(" OOR", "JavaOracle corporatioOracle corporatioVirtualOracle corporatioOracle corporatioMachineOracle corporatioOracle corporatioSpecification##################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " OOR" + "'", str2.equals(" OOR"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("", "HI!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-", "http:/", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/XED MODE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/XED MODE" + "'", str1.equals("/XED MODE"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "I!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("ava Virtual Machine Specification#################", 74);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 74 + "'", int2 == 74);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("10.14.3", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_80");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("oracle Corporation", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "orcle Corportion" + "'", str2.equals("orcle Corportion"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("               :", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("", "mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', 62, 103);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "machine4 4specification4##################4java4 4virtual4 4machine4 4specification4##################4s4/4sjava4 4virtual4 4machine4 4specification4##################4java4 4virtual4 4machine4 4specification4##################4hjava4 4virtual4 4machine4 4specification4##################4java4 4virtual" + "'", str5.equals("machine4 4specification4##################4java4 4virtual4 4machine4 4specification4##################4s4/4sjava4 4virtual4 4machine4 4specification4##################4java4 4virtual4 4machine4 4specification4##################4hjava4 4virtual4 4machine4 4specification4##################4java4 4virtual"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("24.80-B1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("HI!#######################################################################################################################################", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!#######################################################################################################################################" + "'", str3.equals("HI!#######################################################################################################################################"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 35L, (float) 1, (float) 53L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) '#', (double) 5, (double) 31L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("444444444444444/444444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("X3 OS X4 OS X OS X OS X OS");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"X3 OS X4 OS X OS X OS X OS\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1.0f), (double) 14.0f, (double) 74);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 74.0d + "'", double3 == 74.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################4444/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!", "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/USERS/SOPHIE");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "", (int) (byte) 10);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "HI!4444HI!");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a');
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "");
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("java HotSpot(TM) 64-Bit Server VM", strArray12);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                 " + "'", str1.equals("                 "));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("java hotspot(tm) 64-bit server vm", "                                      Oracle corporatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("orcle Corportion", "#################o", "1.7.0_8...");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        double[] doubleArray4 = new double[] { 0.0d, (byte) 1, (short) -1, (-1) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("ava Virtual Machine Specification##################", "4", "Mc O X");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 216, (double) 97, 170.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...                                              ...", "...                                              ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("hi#4444#!#Hi", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ac OS ", "hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ac OS " + "'", str2.equals("ac OS "));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!", "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_80");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 520 + "'", int1 == 520);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "HI!4444HI!");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("aaaaaaaaaaaaaaaaaaaaJavaaHotSpot(TM)a64-BitaServeraVMaaaaaaaaa", "hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################4444/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################4444/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################4444/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!" + "'", str1.equals("hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################4444/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "     ot(tm) 6a-bit server vm1.01", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java Platform API Specification", 35, "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/VJava Platform API Specification/V" + "'", str3.equals("/VJava Platform API Specification/V"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("                 ", "ava Virtual Machine Specification#################", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("ava Virtual Machine Specification##################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                                    Oracle corporatio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                    444444444444444/4444444444444444", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                    444444444444444/4444444444444444" + "'", str2.equals("                    444444444444444/4444444444444444"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(":10.14.3:124.80-b11", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVM", "", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         Java HotSpot(TM) 64-Bit Server VM                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("UTF-8", "hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("sun.lwawt.macosx.LWCToolkit        ", strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "#################o");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#################o" + "'", str1.equals("#################o"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(310, (int) (short) 10, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("10.14.3                                                                                          ", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3                                                                                          " + "'", str2.equals("10.14.3                                                                                          "));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) (-1), (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("####################################################", "hi/Users/sophie!/Users/sophiehhhh/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                  444444444444444/4444444444444444                                  ", 64);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                  444444444444444/4444444444444444                                  " + "'", str2.equals("                                  444444444444444/4444444444444444                                  "));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("machine4 4specification4##################4java4 4virtual4 4machine4 4specification4##################4s4/4sjava4 4virtual4 4machine4 4specification4##################4java4 4virtual4 4machine4 4specification4##################4hjava4 4virtual4 4machine4 4specification4##################4java4 4virtual");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MACHINE4 4SPECIFICATION4##################4JAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4S4/4SJAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4JAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4HJAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4JAVA4 4VIRTUAL" + "'", str1.equals("MACHINE4 4SPECIFICATION4##################4JAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4S4/4SJAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4JAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4HJAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4JAVA4 4VIRTUAL"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.7.0_80-b15hi!hi!hi!OracleCorporationhi!1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("US                                 US                                 US                                 US        10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "", 1, 143);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!", "UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14....");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444", "       :", 1215);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sM HV-", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sM HV-" + "'", str2.equals("sM HV-"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 57);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("h/Users/sophiehi/Users/sophie!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("24.80-b11", (int) (short) 10, 57);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        float[] floatArray1 = new float[] { (-1) };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny("                                  444444444444444/4444444444444444                                  ", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny("     ", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4Users4sophie4Documents4defects4j4tmp4run_randoopipl_88h3_h56!2268!3                                                                                                                                                     ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!", (double) 349);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 349.0d + "'", double2 == 349.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/XED MODE", "US                                 US                                 US                                 US        10.14.3", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/XEDMODE" + "'", str3.equals("/XEDMODE"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("aaaaaaaaaaaaaaaaaa", ":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:", 513);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sM HV-", 51, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "UTF-8");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "jAVA vIRTUAL mACHINE sPECIFICATION##################");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_jAVA vIRTUAL mACHINE sPECIFICATION##################0.jdk/Contents/Home/jre" + "'", str5.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_jAVA vIRTUAL mACHINE sPECIFICATION##################0.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_0.jdk/Contents/Home/jre" + "'", str6.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_0.jdk/Contents/Home/jre"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 35, (float) 6, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("sophiesopj v  HotSpot(TM) 64-Bi", (double) 31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.0d + "'", double2 == 31.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", "                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("ava Virtual Machine Specification##################", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(216.0f, 1215.0f, (float) 2L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/", "iooHI!ioor");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", 65, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("http://j4O", "UserssopeDocumentsdefectsjtmprun_randoop.pl_8813_156022680", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://j4O" + "'", str3.equals("http://j4O"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/!sd oids", "", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H", "...                                              ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "hi!#######################################################################################################################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 138 + "'", int1 == 138);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("UserssopeDocumentsdefectsjtmprun_randoop.pl_8813_156022680");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UserssopeDocumentsdefectsjtmprun_randoop.pl_8813_156022680" + "'", str1.equals("UserssopeDocumentsdefectsjtmprun_randoop.pl_8813_156022680"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        java.lang.Object[] objArray1 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concatWith("hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!", objArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray8 = new char[] { '#', '#', '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "O", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mode", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("#######################################################################################################################################!IH");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#######################################################################################################################################!IH" + "'", str1.equals("#######################################################################################################################################!IH"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!", "/Users/sophie24.80-b1124.80-b112", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!4444hi!");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("####################################################", (java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!4444hi!" + "'", str3.equals("hi!4444hi!"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "roaroproc elcaoit");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 17 + "'", int1 == 17);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("", "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444", "J170_80-15OT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VM", (int) (short) -1);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "                                                                                                                                   3.41.01");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444" + "'", str6.equals("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.7                                ", (int) 'a', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/t/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/" + "'", str1.equals("/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("170_80-15");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("sun.lwawt.macosx.CPrinterJob", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("/USERS/SOPHIE", charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "OracleCorporation", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("machine4 4specification4##################4java4 4virtual4 4machine4 4specification4##################4s4/4sjava4 4virtual4 4machine4 4specification4##################4java4 4virtual4 4machine4 4specification4##################4hjava4 4virtual4 4machine4 4specification4##################4java4 4virtual", "iooHI!ioo");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("24.80-B1", "sun.lwawt.macosx.LWCToolkit        ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                US                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(" OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OS X" + "'", str1.equals("OS X"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) ' ', 1, 55);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!", 137);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!" + "'", str2.equals("hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("I!", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444", "iooHI!ioo", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444" + "'", str3.equals("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ot(tm) 64-bit server vm", "mixed mode", "sophiesopjava HotSpot(TM) 64-Bit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ot(ts)e64-boteshrvhrevs" + "'", str3.equals("ot(ts)e64-boteshrvhrevs"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(143);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("orcle Corportion", (float) 310);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 310.0f + "'", float2 == 310.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "###################################################################################Oracle corporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################################################################Oracle corporatio" + "'", str2.equals("###################################################################################Oracle corporatio"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.7                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7                                " + "'", str1.equals("1.7                                "));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "       :");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", '4');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444", 3, 1366);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("io", 14, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("", "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("noitaroproCelcarOaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 31, 17);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", " OS X", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("JAVA HOTSPOT(TM) 6 -BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA HOTSPOT(TM) 6 -BIT SERVER VM" + "'", str1.equals("JAVA HOTSPOT(TM) 6 -BIT SERVER VM"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "4Users4sophie4Documents4defects4j4tmp4run_randoopipl_88h3_h56!2268!3                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhOraclehcorporatio", 35, 51);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh..." + "'", str3.equals("...hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh..."));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sophie", 103, 217);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/", "OracleCorporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("   /    ", "");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/USERS/SOPHIE", "sophie", 4);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny("SUN.LWAWT.MACOSX.cpRINTERjOB", strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray9);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("170_80-15");
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray4, strArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(strArray13);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#################", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("", "1.7                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("hi!4444hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("EIHPOS/SRESU/", 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.LWCToolkit        ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                sun.lwawt.macosx.LWCToolkit                                         " + "'", str2.equals("                                sun.lwawt.macosx.LWCToolkit                                         "));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################4444/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!", "hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################", "       :");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("...hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh..." + "'", str2.equals("...hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh..."));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("4444444444444444444444444444444444/", "sophiesopj v  HotSpot(TM) 64-Bi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiesopj v  HotSpot(TM) 64-Bi" + "'", str2.equals("sophiesopj v  HotSpot(TM) 64-Bi"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7./1.7.0", (float) 16);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 16.0f + "'", float2 == 16.0f);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("x3 os x4 os x os x os x osHI!4444HI!x3 os x4 os x os x os x os", 310);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("hi!", "sophie", 1);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80");
        java.lang.String[] strArray7 = null;
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.lwawt.macosx.cprinterjob", strArray6, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str8.equals("sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 0, (long) 165, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "64" + "'", str1.equals("64"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "racle corporatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", "1.7./1.7.0", 100);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/", strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny("/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/", strArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "X3 OS X4 OS X OS X OS X OS");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "X3 OS X4 OS X OS X OS X OSX3 OS X4 OS X OS X OS X OSX3 OS X4 OS X OS X OS X OSX3 OS X4 OS X OS X OS X OS4X3 OS X4 OS X OS X OS X OS3" + "'", str9.equals("X3 OS X4 OS X OS X OS X OSX3 OS X4 OS X OS X OS X OSX3 OS X4 OS X OS X OS X OSX3 OS X4 OS X OS X OS X OS4X3 OS X4 OS X OS X OS X OS3"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "170_80-15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("1.7./1.7.0", "086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("OS X", "EIHPOS/SRESU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("RS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Oracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatio" + "'", str1.equals("Oracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatio"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "UTF-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11" + "'", str2.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.7./1.7.0", "hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!", "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java", 8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7./1.7.0" + "'", str4.equals("1.7./1.7.0"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Oracle Corporatio", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Orcle Corportio" + "'", str2.equals("Orcle Corportio"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                      Oracle corporatio", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "corporatio Oracle" + "'", str2.equals("corporatio Oracle"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("http:/", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/4sers/sophie/Library/Java/Extensio              1.7.0_80                                  brary/Java/Extensions:/usr/lib/java", 62);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                             brary/Java/Extensions:/usr/lib/java" + "'", str2.equals("                             brary/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("jAVA vIRTUAL mACHINE sPECIFICATION##################", ":10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:", 57);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("441.7.0_80-b15hi!hi!hi!oraclecorporationhi!1.7.0_80444444444444/4444444444444444");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "...                                              ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("1.7", "444444444444444/4444444444444444", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk/library/java/javavirtualmachines/jdk");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("http://java.oracle.com/", 4, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("", "hi#!#4444#hi#!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                             brary/Java/Extensions:/usr/lib/java", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("hi!4444hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!4444hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("     ", "ot(ts)e64-boteshrvhrevs");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     " + "'", str2.equals("     "));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("JavaOracle corporatioOracle corporatioVirtualOracle corporatioOracle corporatioMachineOracle corporatioOracle corporatioSpecification##################", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("EIHPOS/SRESU/", "####################################################JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "machine4 4specification4##################4java4 4virtual4 4machine4 4specification4##################4s4/4sjava4 4virtual4 4machine4 4specification4##################4java4 4virtual4 4machine4 4specification4##################4hjava4 4virtual4 4machine4 4specification4##################4java4 4virtual");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/Library/Java/JavaVirtualMachines/jdk1.7.0_jAVA vIRTUAL mACHINE sPECIFICATION##################0.jdk/Contents/Home/jre", "/!sd oids");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!", "OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java(TM) SE Runtime Environment", 165, 1364);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "I170_80-15OT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1362 + "'", int2 == 1362);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("         Java HotSpot(TM) 64-Bit Server VM         ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "####################################################java hotspot(tm) 64-bit server vmjava hotspot(tm");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("x3 os x4 os x os x os x osHI!4444HI!x3 os x4 os x os x os x os", "US                                 US                                 US                                 US        10.14.3", "JAVA PLATFORM API SPECIF", 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "x3 os x4 os x os x os x osHI!4444HI!x3 os x4 os x os x os x os" + "'", str4.equals("x3 os x4 os x os x os x osHI!4444HI!x3 os x4 os x os x os x os"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(216, 2, 55);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "sophiesopjava HotSpot(TM) 64-Bit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("oitaroprocelcaro", "                                           noitaroproCelcarO                                           ");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod", "Oracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE", "!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7./1.7.0", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7./1.7.0" + "'", str3.equals("1.7./1.7.0"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!" + "'", str2.equals("hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ot(tm) 6a-bit server vm", "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "roaroproc elcaoit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!4444hi!");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("Java Virtual Machine Specification", strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concatWith("444444444444444/4444444444444444", (java.lang.Object[]) strArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny("1.7.0_80-b15", strArray5);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "", 1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray13);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8");
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray16, "");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################!/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################4444/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################", strArray13, strArray18);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("io", strArray5, strArray13);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!" + "'", str7.equals("hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################!/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################4444/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################" + "'", str19.equals("HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################!/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################4444/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "io" + "'", str20.equals("io"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("OracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation", "HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################!/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################4444/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        double[] doubleArray4 = new double[] { 0.0d, (byte) 1, (short) -1, (-1) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", "####################################################java hotspot(tm) 64-bit server vmjava hotspot(tm", 349);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Oracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarO" + "'", str1.equals("oitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarO"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim" + "'", str2.equals("dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!4444hi!");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("Java Virtual Machine Specification", strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################4444/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!4444hi!" + "'", str6.equals("hi!4444hi!"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixed mode");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("OrcleCorportion", 3, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OrcleCorportion" + "'", str3.equals("OrcleCorportion"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("HI!", "                                           noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "1 7 0_80- 15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1 7 0_80- 15" + "'", str1.equals("1 7 0_80- 15"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("enaaaaaaaaaaaaaaaa", "e");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Mac OS X", "10.14.3", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X" + "'", str3.equals("Mac OS X"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Oracle corporatioOracle corporatio", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1364L, 10.0d, (double) 52);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "444444444444444/4444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("corporatio Oracle", (float) 103L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 103.0f + "'", float2 == 103.0f);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("170_80-15", 32, "/t/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "170_80-15/t/ng0000cf4n1x2n2qc13v" + "'", str3.equals("170_80-15/t/ng0000cf4n1x2n2qc13v"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", (int) (byte) 100, "       :");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          " + "'", str3.equals("mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          "));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("EIHPOS/SRESU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: EIHPOS/SRESU/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("mixed mode", "x3 os x4 os x os x os x os", "/VJava Platform API Specification/V");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "UserssopeDocumentsdefectsjtmprun_randoop.pl_8813_156022680");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sophiesopj v  HotSpot(TM) 64-Bi", "hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(":10.14.3:124.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":10.14.3:124.80-b11" + "'", str1.equals(":10.14.3:124.80-b11"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi#!#ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr#hi#!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/XED MODE", "/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.14.3", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("1.7.0_80-b15", strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "...hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "!", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                                                   3.41.01", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/!sd oids                                                                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/!sd oids                                                                                        " + "'", str1.equals("/!sd oids                                                                                        "));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!" + "'", str1.equals("HI!"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("24.80-B11", "", 53);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("oRACLE cORPORATIO", "/VAR/FOLDERS/_V/6V597ZMNa_V31CQ2N2X1NaFC0000GN/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMNa_V31CQ2N2X1NaFC0000GN/" + "'", str2.equals("/VAR/FOLDERS/_V/6V597ZMNa_V31CQ2N2X1NaFC0000GN/"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("io", "               :                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "io" + "'", str2.equals("io"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Oracle corporatio", 74);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                         Oracle corporatio" + "'", str2.equals("                                                         Oracle corporatio"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("hi!", "sophie", 1);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny("", strArray4);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ', 0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("roaroproc elcaoit", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "roaroproc elcaoit" + "'", str2.equals("roaroproc elcaoit"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/library/java/javavirtualmachines/jdk/library/java/javavirtualmachines/jdk", 64, 520);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("...                                              ...");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "noitaroproCelcarOaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("hi#4444#!#Hi", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("170_80-15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("170_80-15/t/ng0000cf4n1x2n2qc13v", 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajh##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajs/s##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajsu/##################noitacificeps enihcam lautriv avajh##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajh##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajs/s##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajsu/4444##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajh##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajs/s##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajsu/!##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajh##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajs/s##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajsu/##################noitacificeps enihcam lautriv avajH", (java.lang.CharSequence) "!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 0, (float) 74, 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 1, (float) 10L, (float) 513);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "ac OS ", (java.lang.CharSequence) "ac OS ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!", "                                                                                                                                                                                                                                                                                                                      /moc.elcaro.avaj//:ptth                                                                                                                                                                                                                                                                                                                      /moc.elcaro.avaj//:ptth                                                                                                                                                                                                                                                                                                                      /moc.elcaro.avaj//:ptth                                                                                                                                                                                                                                                                                                                      ", 310);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sophiesopjava HotSpot(TM) 64-Bit", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophiesopjava HotSpot(TM) 64-Bit" + "'", str3.equals("sophiesopjava HotSpot(TM) 64-Bit"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart(" OS X", "/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " OS X" + "'", str2.equals(" OS X"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("             /", "HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "oitaroprocelcaro");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("http://jaO", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 6L, 0.0d, 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("HHIHH!HH!444!IH", "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HHIHH!HH!444!IH" + "'", str2.equals("HHIHH!HH!444!IH"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("UserssopeDocumentsdefectsjtmprun_randoop.pl_8813_156022680", "441.7.0_80-B15HI!HI!HI!ORACLE CORPORATIONHI!1.7.0_80444444444444/4444444444444444SUN.AWT.CGRAPHICSENVIRONMENT441.7.0_80-B15HI!HI!HI!ORACLE CORPORATIONHI!1.7.0_80444444444444/4444444444444444SUN.AWT.CGRAPHICSENVIRONMENT441.7.0_80-B15HI!HI!HI!ORACLE CORPORATIONHI!1.7.0_80444444444444/4444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "441.7.0_80-B15HI!HI!HI!ORACLE CORPORATIONHI!1.7.0_80444444444444/4444444444444444SUN.AWT.CGRAPHICSENVIRONMENT441.7.0_80-B15HI!HI!HI!ORACLE CORPORATIONHI!1.7.0_80444444444444/4444444444444444SUN.AWT.CGRAPHICSENVIRONMENT441.7.0_80-B15HI!HI!HI!ORACLE CORPORATIONHI!1.7.0_80444444444444/4444444444444444" + "'", str2.equals("441.7.0_80-B15HI!HI!HI!ORACLE CORPORATIONHI!1.7.0_80444444444444/4444444444444444SUN.AWT.CGRAPHICSENVIRONMENT441.7.0_80-B15HI!HI!HI!ORACLE CORPORATIONHI!1.7.0_80444444444444/4444444444444444SUN.AWT.CGRAPHICSENVIRONMENT441.7.0_80-B15HI!HI!HI!ORACLE CORPORATIONHI!1.7.0_80444444444444/4444444444444444"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("SUN.LWAWT.MACOSX.cpRINTERjOB", 64);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB                                    " + "'", str2.equals("SUN.LWAWT.MACOSX.cpRINTERjOB                                    "));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "oRACLE cORPORATIO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE cORPORATIO" + "'", str1.equals("oRACLE cORPORATIO"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                                           noitaroproCelcarO                                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproCelcarO" + "'", str1.equals("noitaroproCelcarO"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("e", "http://j4O", 1362);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/HI!4444HI!", "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhOraclehcorporatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("170_80-15", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("jAVA vIRTUAL mACHINE sPECIFICATION##################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA vIRTUAL mACHINE sPECIFICATION##################" + "'", str1.equals("jAVA vIRTUAL mACHINE sPECIFICATION##################"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("1.7.0_80-b15hi!hi!hi!OracleCorporationhi!1.7.0_80", 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("hJavaVirtualMachineSpecification##################/UsJavaVirtu");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", "hi!4444hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("                 ", "/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("64", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "64" + "'", str2.equals("64"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 100, (byte) -1, (byte) -1, (byte) 0, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie", "                                     http://java.oracle.com/                                     ", "hi#4444#!#Hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Usssi" + "'", str3.equals("Usssi"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        long[] longArray6 = new long[] { (short) 1, 0L, (short) 100, 3, 0, 0L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java", 216, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                    Java HotSpot(TM) 64-Bit Server VM         ", "                US                 ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                         en                         ", "hJavaVirtualMachine/Users/sophie#######/UsJavaVirtu");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                         en                         " + "'", str2.equals("                         en                         "));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                           ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                           ..." + "'", str1.equals("                                           ..."));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!", "(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!" + "'", str2.equals("/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!4444hi!", "               :                                                                                 ", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("I", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I" + "'", str2.equals("I"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Orcle Corportio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("0-b11");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                         Oracle corporatio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                                                          Oracle corporatio is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("x3 os x4 os x os x os x os", 1366);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x3 os x4 os x os x os x os" + "'", str2.equals("x3 os x4 os x os x os x os"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        long[] longArray6 = new long[] { (short) 1, 0L, (short) 100, 3, 0, 0L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 411 + "'", int1 == 411);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("x86_64", "JAVA HOTSPOT(TM) 6 -BIT SERVER VM                US                                 US                                 US                                 US        10.14.3", "X3 OS X4 OS X OS X OS X OS");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "             /");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("oitaroproc elcaro                                                                                                                                                                                                                                                                                                     ", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", "1.7./1.7.0", 100);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/", strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, " OS X");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + " OS X OS X OS X OS X4 OS X3" + "'", str7.equals(" OS X OS X OS X OS X4 OS X3"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "####4#3" + "'", str9.equals("####4#3"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hihi/Users/soph/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/Users/sophie!!", (java.lang.CharSequence) "Ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3039 + "'", int2 == 3039);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "10.14.3                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (byte) 10, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("HI/uER/OPHIE!/uER/OPHIE/uER/OPHIEHI/uER/OPHIE!", "                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI/uER/OPHIE!/uER/OPHIE/uER/OPHIEHI/uER/OPHIE!" + "'", str2.equals("HI/uER/OPHIE!/uER/OPHIE/uER/OPHIEHI/uER/OPHIE!"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("#################");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize(charSequence0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 520);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                                                                                                                                                                                                                                                                                                                                                                                       " + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                                                                                                                                                                                                                                                                                                                                                                                       "));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!", "sophie", 1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', (int) (byte) 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!" + "'", str4.equals("!"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("tioacle corpora###################################################################################Or", "dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tioacle corpora###################################################################################Or" + "'", str3.equals("tioacle corpora###################################################################################Or"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H" + "'", str1.equals("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("       :", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80", 520);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/U...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "M         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("J170_80-15OT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VM", "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(":", "oracle corporatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        char[] charArray8 = new char[] {};
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "24.80-b11", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", charArray8);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "441.7.0_80-B15HI!HI!HI!ORACLE CORPORATIONHI!1.7.0_80444444444444/4444444444444444SUN.AWT.CGRAPHICSENVIRONMENT441.7.0_80-B15HI!HI!HI!ORACLE CORPORATIONHI!1.7.0_80444444444444/4444444444444444SUN.AWT.CGRAPHICSENVIRONMENT441.7.0_80-B15HI!HI!HI!ORACLE CORPORATIONHI!1.7.0_80444444444444/4444444444444444", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        double[] doubleArray3 = new double[] { 0, 'a', 8L };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 97.0d + "'", double4 == 97.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("hi#4444#!#Hi", "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("       :", 28, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444       :4444444444" + "'", str3.equals("4444444444       :4444444444"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                                    Oracle corporatio", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("#################o");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        int[] intArray4 = new int[] { 170, '#', 100, 100 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 170 + "'", int5 == 170);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Mc O X", "   /    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE" + "'", str2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("I170_80-15OT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VM", 10, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "I170_80-15OT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str3.equals("I170_80-15OT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("   /   ", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   /   " + "'", str3.equals("   /   "));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("24.80-B1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B1" + "'", str1.equals("24.80-B1"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("JAVA PLATFORM API SPECIF");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/", "roaroproc elcaoit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("hi!4444hi!", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!4444hi!" + "'", str2.equals("hi!4444hi!"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("tioacle corpora###################################################################################Or");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tioacle corpora###################################################################################Or" + "'", str1.equals("tioacle corpora###################################################################################Or"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        float[] floatArray1 = new float[] { 3 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 3.0f + "'", float4 == 3.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 3.0f + "'", float5 == 3.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 3.0f + "'", float6 == 3.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 3.0f + "'", float7 == 3.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 3.0f + "'", float8 == 3.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 3.0f + "'", float9 == 3.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 3.0f + "'", float10 == 3.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 3.0f + "'", float11 == 3.0f);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("4", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sun.lwawt.macosx.cprinterjobHJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################J", 1215, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...L MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################J" + "'", str3.equals("...L MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################J"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/XEDMODE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/XEDMODE" + "'", str1.equals("/XEDMODE"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("441.7.0_80-b15hi!hi!hi!oraclecorporationhi!1.7.0_80444444444444/4444444444444444", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 3039);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Hi#!#4444#hi#!", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Hi#!#4444#hi#! " + "'", str2.equals(" Hi#!#4444#hi#! "));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("JAVA HOTSPOT(TM) 6 -BIT SERVER VM                US                                 US                                 US                                 US        10.14.3", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4Users4sophie4Documents4defects4j4tmp4run_randoopipl_88h3_h56!2268!3                                                                                                                                                     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!", "mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("hi#!##hi#!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi#!##hi#" + "'", str1.equals("hi#!##hi#"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("sun.lwawt.macosx.CPrinterJ/!sd oids", 52, 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.awt.CGraphicsEnvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(411);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("http :// java . oracle . com /", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.7.0_80-b15hi!hi!hi!OracleCorporationhi!1.7.0_80");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("J170_80-15OT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VM", 310, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J170_80-15OT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str3.equals("J170_80-15OT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 100, (byte) -1, (byte) -1, (byte) 0, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ava Virtual Machine Specification##################", 9, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ava Virtual Machine Specification##################" + "'", str3.equals("ava Virtual Machine Specification##################"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "         Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "HI/uER/OPHIE!/uER/OPHIE/uER/OPHIEHI/uER/OPHIE!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46 + "'", int2 == 46);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        char[] charArray5 = new char[] { '#', '#', '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray5);
        java.lang.Class<?> wildcardClass7 = charArray5.getClass();
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "             /", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "####4#3");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "...                                              ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!4444HI!", "", 8);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "OracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny("10.14.3                                                                                          ", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("####################################################", "441.7.0_80-b15hi!hi!hi!oraclecorporationhi!1.7.0_80444444444444/4444444444444444", 65);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("mixed mode", "10.14.3                                                                                                                                   ", "ac OS ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("####################################################java hotspot(tm) 64-bit server vmjava hotspot(tm", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################java hotspot(tm) 64-bit server vmjava hotspot(tm" + "'", str2.equals("####################################################java hotspot(tm) 64-bit server vmjava hotspot(tm"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("/XED MODE", "iooHI!ioor", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "OracleCorporation");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-", strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!", 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "Hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################", (int) (byte) 10, (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("M         ", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("JAVA PLATFORM API SPECIF");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA PLATFORM API SPECIF" + "'", str1.equals("JAVA PLATFORM API SPECIF"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        double[] doubleArray2 = new double[] { 170, 32L };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 170.0d + "'", double3 == 170.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.0d + "'", double4 == 32.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 32.0d + "'", double5 == 32.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi!hi!", "086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!" + "'", str2.equals("hi!hi!"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("24.80-B1", 0, 137);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-B1" + "'", str3.equals("24.80-B1"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/", "1.7.0_80-b15hi!hi!hi!OracleCorporationhi!1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/" + "'", str2.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("java hotspot(tm) 64-bit server vm", "hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str2.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray3);
        java.lang.Class<?> wildcardClass6 = charArray3.getClass();
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################!/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################4444/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################!", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                         Oracle corporatio", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.7.0_80-B15HI!HI!HI!oRACLE cORPORATIONHI!1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-B15HI!HI!HI!oRACLE cORPORATIONHI!1.7.0_80" + "'", str1.equals("1.7.0_80-B15HI!HI!HI!oRACLE cORPORATIONHI!1.7.0_80"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        float[] floatArray1 = new float[] { 3 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 3.0f + "'", float4 == 3.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 3.0f + "'", float5 == 3.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 3.0f + "'", float6 == 3.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 3.0f + "'", float7 == 3.0f);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!", "OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!" + "'", str2.equals("hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680", "tioacle corpora###################################################################################Or");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/library/java/javavirtualmachines/jdk/library/java/javavirtualmachines/jdk");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIEHI/uSERS/SOPHIE!4HI/uSERS/SOPHIE!/uSERS/SOPHIE" + "'", str2.equals("/uSERS/SOPHIEHI/uSERS/SOPHIE!4HI/uSERS/SOPHIE!/uSERS/SOPHIE"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hJavaVirtualMachine/Users/sophie#######/UsJavaVirtu", 138);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hJavaVirtualMachine/Users/sophie#######/UsJavaVirtu" + "'", str2.equals("hJavaVirtualMachine/Users/sophie#######/UsJavaVirtu"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("###################################################################################oracle corporatio", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################################################################oracle corporatio" + "'", str2.equals("###################################################################################oracle corporatio"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", "oitaroproc elcaro");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-", "JAVA HOTSPOT(TM) 6 -BIT SERVER VM", " Hi#!#4444#hi#! ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-" + "'", str3.equals("UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "                                                                                                                                   3.41.01", 9);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!", 2, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!" + "'", str3.equals("hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.7", 4, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7#" + "'", str3.equals("1.7#"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        short[] shortArray3 = new short[] { (short) 0, (short) 10, (short) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 10 + "'", short8 == (short) 10);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat(" OOR");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"OOR\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("JavaOracle corporatioOracle corporatioVirtualOracle corporatioOracle corporatioMachineOracle corporatioOracle corporatioSpecification##################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM", charArray5);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ot(ts)e64-boteshrvhrevs", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                           ...", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                     444444444444444/4444444444444444                                                                     ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "Usssi", "   /   ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("sun.lwawt.macosx.cprinterjob", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str2.equals("sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepS enihcaM lautriV avaJ" + "'", str1.equals("noitacificepS enihcaM lautriV avaJ"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(51);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-", "", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("####################################################JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM", 0, "JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM" + "'", str3.equals("####################################################JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sM HV-", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sM HV-" + "'", str2.equals("sM HV-"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/                                                                                        ", "hi#!#ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr#hi#!", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Hi#!#4444#hi#!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi#!#4444#hi#!" + "'", str1.equals("Hi#!#4444#hi#!"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 217L, (float) 32L, (float) 31L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 217.0f + "'", float3 == 217.0f);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE", "sun.lwawt.macosx.cprinterjobHJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################J");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE" + "'", str2.equals("/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ioor", 3039, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaiooraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaiooraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/USERS/SOPHIE", "sophie", 4);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("hi!", strArray4);
        java.lang.Class<?> wildcardClass6 = strArray4.getClass();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "Java Platform API Specif");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("####################################################java hotspot(tm) 64-bit server vmjava hotspot(tm", 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java HotSpot(TM) 64-Bit Server VM");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", (java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseHot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseSpot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse(/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseTM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse)/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse64/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse-/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseBit/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseServer/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseVM" + "'", str3.equals("Java/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseHot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseSpot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse(/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseTM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse)/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse64/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse-/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseBit/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseServer/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseVM"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_jAVA vIRTUAL mACHINE sPECIFICATION##################0.jdk/Contents/Home/jre", 411);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                     /Library/Java/JavaVirtualMachines/jdk1.7.0_jAVA vIRTUAL mACHINE sPECIFICATION##################0.jdk/Contents/Home/jre" + "'", str2.equals("                                                                                                                                                                                                                                                                                                     /Library/Java/JavaVirtualMachines/jdk1.7.0_jAVA vIRTUAL mACHINE sPECIFICATION##################0.jdk/Contents/Home/jre"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("JAVA HOTSPOT(TM) 64-BIT SERVER VM", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA HOTSPOT(TM) 6-BIT SERVER VM" + "'", str2.equals("JAVA HOTSPOT(TM) 6-BIT SERVER VM"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/Library/Java/JavaVirtualMachines/jdk1.7.0_jAVA vIRTUAL mACHINE sPECIFICATION##################0.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_jAVA vIRTUAL mACHINE sPECIFICATION##################0.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_jAVA vIRTUAL mACHINE sPECIFICATION##################0.jdk/Contents/Home/jre"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java Platform API Specification", "hi444444444444444/444444...", 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!", 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                     http://java.oracle.com/                                     ");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                     http://java.oracle.com/                                     " + "'", str2.equals("                                     http://java.oracle.com/                                     "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                     http://java.oracle.com/                                     " + "'", str3.equals("                                     http://java.oracle.com/                                     "));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("UserssopeDocumentsdefectsjtmprun_randoop.pl_8813_156022680", "Oracle corporatio", "java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("   /    ", (double) 411);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 411.0d + "'", double2 == 411.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaJavaaHotSpot(TM)a64-BitaServeraVMaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("OracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation", "tioacle corpora###################################################################################Or", 5);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CnCnCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation" + "'", str4.equals("CnCnCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("machine4 4specification4##################4java4 4virtual4 4machine4 4specification4##################4s4/4sjava4 4virtual4 4machine4 4specification4##################4java4 4virtual4 4machine4 4specification4##################4hjava4 4virtual4 4machine4 4specification4##################4java4 4virtual", "sun.lwawt.macosx.cprinterjobHJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################J");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaJavaaHotSpot(TM)a64-BitaServeraVMaaaaaaaaa", "vVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Servvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Serv", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("I170_80-15OT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("                         en                         ", "http:/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "10.14.3");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!4444HI!", "", 8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444", strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("Java(TM) SE Runtime Environment", strArray4, strArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny("/moc.elcaro.avaj//:ptth", strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str11.equals("Java(TM) SE Runtime Environment"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("vVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Servvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Serv");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "", 1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "####################################################JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM", (java.lang.CharSequence) "oitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        short[] shortArray3 = new short[] { (short) 0, (short) 10, (short) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 10 + "'", short8 == (short) 10);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "roaroproc elcaoit");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-", 51, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444" + "'", str1.equals("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("   /    ", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/Library/Java/JavaVirtualMachines/jdk1.7.0_jAVA vIRTUAL mACHINE sPECIFICATION##################0.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "   /    " + "'", str4.equals("   /    "));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("OracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation", "hi#4444#!#Hi", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "io");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                  444444444444444/4444444444444444                                  ", "51.0");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "iooHI!ioor");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                  444444444444444/4444444444444444                                  " + "'", str4.equals("                                  444444444444444/4444444444444444                                  "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "                                  444444444444444/4444444444444444                                  " + "'", str5.equals("                                  444444444444444/4444444444444444                                  "));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("US", (float) 55L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 55.0f + "'", float2 == 55.0f);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 143, 0.0f, (float) 35);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 143.0f + "'", float3 == 143.0f);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("JAVA HOTSPOT(TM) 6-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}

