import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str1.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test002");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", "/USERS/SOPHIE");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("oitaroprocelcaro", "ioor");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str7.equals("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################4444/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################4444/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!" + "'", str1.equals("hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################4444/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test004");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("                             brary/Java/Extensions:/usr/lib/java", "444444444444444/444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test005");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 103L, (double) 4L, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 103.0d + "'", double3 == 103.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test006");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hi#!##hi#", 14, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  hi#!##hi#   " + "'", str3.equals("  hi#!##hi#   "));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test007");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "", 103);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 103 + "'", int3 == 103);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test008");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/libr");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sophiesopjava HotSpot(TM) 64-Bit", 520);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiesopjava HotSpot(TM) 64-Bit" + "'", str2.equals("sophiesopjava HotSpot(TM) 64-Bit"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Java/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseHot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseSpot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse(/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseTM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse)/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse64/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse-/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseBit/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseServer/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseVM", "http :// java . oracle . com /");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseHot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseSpot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse(/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseTM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse)/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse64/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse-/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseBit/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseServer/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseVM" + "'", str2.equals("Java/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseHot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseSpot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse(/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseTM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse)/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse64/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse-/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseBit/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseServer/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseVM"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test011");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "M         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "M         " + "'", str1.equals("M         "));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test012");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 3L, 18L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test013");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("ot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test014");
        long[] longArray5 = new long[] { 100L, 0L, 100L, 100, (-1) };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("4444444444444444444444444444444444/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444/" + "'", str1.equals("4444444444444444444444444444444444/"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test016");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                    Java HotSpot(TM) 64-Bit Server VM         ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                     Java HotSpot(TM) 64-Bit Server VM          is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test017");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test018");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob", '#');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test019");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/USERS/SOPHIE", "sophie", 4);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("racle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatio", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/USERS/SOPHIE" + "'", str5.equals("/USERS/SOPHIE"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "racle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatio" + "'", str9.equals("racle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatio"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test020");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("RS/SOPHIE!/USERS/SOPHIE4444/USERS/SOPHIEHI/USERS/SOPHIE!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RS/SOPHIE!/USERS/SOPHIE4444/USERS/SOPHIEHI/USERS/SOPHIE!" + "'", str1.equals("RS/SOPHIE!/USERS/SOPHIE4444/USERS/SOPHIEHI/USERS/SOPHIE!"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test021");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                  444444444444444/4444444444444444                                  ", "51.0");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                  444444444444444/4444444444444444                                  " + "'", str4.equals("                                  444444444444444/4444444444444444                                  "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "                                  444444444444444/4444444444444444                                  " + "'", str5.equals("                                  444444444444444/4444444444444444                                  "));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test022");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("         Java HotSpot(TM) 64-Bit Server VM         ", 350);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/                                                                                        ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test024");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java", 28, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test025");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 1215);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test026");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("hi/users/sophie!/users/sophie4444/users/sophiehi/users/sophie!", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29 + "'", int2 == 29);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test027");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/", "hjava");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test028");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("io");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "io" + "'", str1.equals("io"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test029");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "10.14.3                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test030");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Java Virtual Machine Specification##################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Virtual Machine Specification##################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test031");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 97);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test032");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " OS X OS X OS X OS X4 OS X3", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test033");
        char[] charArray8 = new char[] {};
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("/USERS/SOPHIE", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("1.7.0_80-b15", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80", charArray8);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification##################", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test034");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test035");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test036");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test037");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", "java hotspot(tm) 64-bit server vm", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80-B15HI!HI!HI!oRACLE cORPORATIONHI!1.7.0_80", 51, "0-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "01.7.0_80-B15HI!HI!HI!oRACLE cORPORATIONHI!1.7.0_80" + "'", str3.equals("01.7.0_80-B15HI!HI!HI!oRACLE cORPORATIONHI!1.7.0_80"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test039");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(348);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("h", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh" + "'", str2.equals("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test041");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 216L, (double) 35, (double) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 216.0d + "'", double3 == 216.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test042");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("HI!4444HI!", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test043");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test044");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("HHIHH!HH!444!IH", "                                  444444444444444/4444444444444444                                  ", "HJAVA VIRTUAL MACHINE SPECIFICATIO                                           noitaroproCelcarO                                           ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test045");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "e");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test046");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi#!#ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr#hi#!", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test047");
        float[] floatArray1 = new float[] { (-1.0f) };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test048");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4444444444       :4444444444", "Usssi", 103);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.7                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test050");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test051");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(216.0f, 32.0f, (float) 46);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test052");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(16, 1215, 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 14 + "'", int3 == 14);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test053");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "10.14.3");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("sun.lwawt.macosx.CPrinterJob", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 28, 1362);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi#!#4444#hi#!", 65);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi#!#4444#hi#!" + "'", str2.equals("hi#!#4444#hi#!"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test056");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("US                                 US                                 US                                 US        10.14.3pot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM", "hi!#######################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test057");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                         en                                                                                                     ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test058");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("sophie");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("racle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatio", "/VAR/FOLDERS/_V/6V597ZMNa_V31CQ2N2X1NaFC0000GN/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test060");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 46.0f, (double) 1215.0f, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test062");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("", "JHSpTM4BSVM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.7#", "Oracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatio", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7#" + "'", str3.equals("1.7#"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test064");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/", "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test065");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                                                                                                                                                                                                                                                                                                      ", "hi/users/sophie!/users/sophie4444/users/sophiehi/users/sophie!", 1366);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test066");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################!/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################4444/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test067");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("###################################################################################oracle corporatio");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("machine4 4specification4##################4java4 4virtual4 4machine4 4specification4##################4s4/4sjava4 4virtual4 4machine4 4specification4##################4java4 4virtual4 4machine4 4specification4##################4hjava4 4virtual4 4machine4 4specification4##################4java4 4virtual", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test068");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test069");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "oit roproc elc rOoit roproc elc rOoit roproc elc rOoit roproc elc rOoit roproc elc rOoit roproc elc rOoit roproc elc rOoit roproc elc rO");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 136 + "'", int1 == 136);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Oracle corporatioOracle corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle corporatioOracle corporatio" + "'", str1.equals("Oracle corporatioOracle corporatio"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                    Java HotSpot(TM) 64-Bit Server VM         ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                    Java HotSpot(TM) 64-Bit Server VM         " + "'", str2.equals("                    Java HotSpot(TM) 64-Bit Server VM         "));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_0.jdk/Contents/Home/jre", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_0.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_0.jdk/Contents/Home/jre"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test073");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "UTF-8");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 82 + "'", int4 == 82);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test074");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "OrcleCorportion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("oitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarO" + "'", str1.equals("oitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarO"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                         Oracle corporatio", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                         Oracle corporatio" + "'", str2.equals("                                                         Oracle corporatio"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test077");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("24.80-b11", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2 .80-b11" + "'", str3.equals("2 .80-b11"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test078");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java", "RS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "vVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Servvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvun.awt.CGraphicvEnvirVnmentvVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Server VMvVphievVphvVphievVpj v  HVtSpVt(TM) 64-Bit Serv");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "#######################################################################################################################################!IH");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#######################################################################################################################################!IH" + "'", str2.equals("#######################################################################################################################################!IH"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test082");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test083");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1362L, (float) 349, (float) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Mc O X", "64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mc O X" + "'", str2.equals("Mc O X"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Hi#!#4444#hi#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi#!#4444#hi#" + "'", str1.equals("Hi#!#4444#hi#"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test086");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/VJava Platform API Specification/V", "hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!", "441.7.0_80-b15hi!hi!hi!oraclecorporationhi!1.7.0_80444444444444/4444444444444444", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/VJava Platform API Specification/V" + "'", str4.equals("/VJava Platform API Specification/V"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test087");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test088");
        long[] longArray6 = new long[] { (short) 1, 0L, (short) 100, 3, 0, 0L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("I", 310, 217);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "I" + "'", str3.equals("I"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test090");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                           ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test091");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("hi!#######################################################################################################################################", 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "01.7.0_80-B15HI!HI!HI!oRACLE cORPORATIONHI!1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test093");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test094");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test095");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("hi#4444#!#Hi", 3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test096");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(57, 1366, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test097");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aaaaaaaa:aaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test098");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 35, 55L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 55L + "'", long3 == 55L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test099");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob", '#');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str5.equals("sun.lwawt.macosx.CPrinterJob"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str6.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test100");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/VJava Platform API Specification/V", "                                           ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/VJava Platform API Specification/V" + "'", str2.equals("/VJava Platform API Specification/V"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test102");
        double[] doubleArray2 = new double[] { 170, 32L };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 170.0d + "'", double3 == 170.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.0d + "'", double4 == 32.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 170.0d + "'", double5 == 170.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test103");
        double[] doubleArray2 = new double[] { 170, 32L };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 170.0d + "'", double3 == 170.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 170.0d + "'", double4 == 170.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("racle corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "racle corporatio" + "'", str1.equals("racle corporatio"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test105");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 10, (float) 170, (float) 97L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 170.0f + "'", float3 == 170.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test106");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("SUN.LWAWT.MACOSX.cpRINTERjOB", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("oitaropoRACLE cORPORATIO elcaro", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "poRACLE cORPORATIO " + "'", str2.equals("poRACLE cORPORATIO "));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test108");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("#################O");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "HI!4444HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test110");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("hi!");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test111");
        short[] shortArray2 = new short[] { (byte) -1, (byte) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.Class<?> wildcardClass4 = shortArray2.getClass();
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test112");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "sophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesophsophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesophsophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesophsophiesopj v  HotSpot(TM) 64-Bit Servsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesophsophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesophsophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesophsophiesopj v  HotSpot(TM) 64-Bit Serv");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test113");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("441.7.0_80-b15hi!hi!hi!oraclecorporationhi!1.7.0_80444444444444/4444444444444444", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "441.7.0_80-b15hi!hi!hi!oraclecorporationhi!1.7.0_80444444444444/4444444444444444" + "'", str3.equals("441.7.0_80-b15hi!hi!hi!oraclecorporationhi!1.7.0_80444444444444/4444444444444444"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("h", "hi!4444hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test115");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!", "hi!", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test116");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("i#!#JViuMinsdk170_80dkCnnsH#i#!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "i#!#jviuminsdk170_80dkcnnsh#i#!" + "'", str1.equals("i#!#jviuminsdk170_80dkcnnsh#i#!"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test117");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(310);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test118");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 100, (byte) -1, (byte) -1, (byte) 0, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test119");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "             /", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test120");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 53L, (double) 16.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 53.0d + "'", double3 == 53.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("444444444444444/4444444444444444", "/library/java/javavirtualmachines/jdk/library/java/javavirtualmachines/jdk");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444/4444444444444444" + "'", str2.equals("444444444444444/4444444444444444"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test122");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "http://j4O");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test123");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(1, 29, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 29 + "'", int3 == 29);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test124");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("4444444444444444444444444444444444/", (double) 18L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.0d + "'", double2 == 18.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("http:/", "UTF-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http:/" + "'", str2.equals("http:/"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test126");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("44444444444444444", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Java Virtual Machine Specification##################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification##################" + "'", str2.equals("Java Virtual Machine Specification##################"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test128");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", 103);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test129");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!4444hi!");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("1.7                                ", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test130");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("hi!hi!");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/U...", "noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/U..." + "'", str2.equals("/U..."));
    }
}

