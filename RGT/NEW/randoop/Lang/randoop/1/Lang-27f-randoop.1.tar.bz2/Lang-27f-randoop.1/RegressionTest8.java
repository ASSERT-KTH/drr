import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################4444/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!", "4Users4sophie4Documents4defects4j4tmp4run_randoopipl_88h3_h56!2268!3                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################4444/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!" + "'", str2.equals("hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################4444/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sophiesopjava HotSpot(TM) 64-Bit", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiesopjava HotSpot(TM) 64-Bit" + "'", str2.equals("sophiesopjava HotSpot(TM) 64-Bit"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "http://jaO");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(32, 17, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java44444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java44444444444444444444444444444444444444444444444" + "'", str1.equals("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java44444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                US                                 US                                 US                                 US        10.14.3", "hi#!##hi#!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                US                                 US                                 US                                 US        10.14.3" + "'", str2.equals("                US                                 US                                 US                                 US        10.14.3"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("               :");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0, (double) 217, (double) 1L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 217.0d + "'", double3 == 217.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Hi#!#4444#hi#!");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("UTF-", "                         en                         ", 520);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("i#!#JViuMinsdk170_80dkCnnsH#i#!", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i#!#JViuMinsdk170_80dkCnnsH#i#!" + "'", str2.equals("i#!#JViuMinsdk170_80dkCnnsH#i#!"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("J170_80-15OT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VM", "http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", 411);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporatio", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "OrcleCorportion", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("1 7 0_80- 15", 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("ot(ts)e64-boteshrvhrevs", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "iooHI!ioor");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "iooHI!ioor" + "'", str1.equals("iooHI!ioor"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie", "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        long[] longArray6 = new long[] { (short) 1, 0L, (short) 100, 3, 0, 0L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "i#!#JViuMinsdk170_80dkCnnsH#i#!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("http://java.oracle.com/", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "US", "#################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("hi!", "###################################################################################oracle corporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseHot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseSpot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse(/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseTM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse)/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse64/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse-/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseBit/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseServer/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseVM", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseHot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseSpot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse(/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseTM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse)/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse64/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse-/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseBit/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseServer/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseVM" + "'", str3.equals("Java/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseHot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseSpot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse(/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseTM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse)/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse64/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse-/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseBit/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseServer/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseVM"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.7.0_80-b15hi!hi!hi!OracleCorporationhi!1.7.0_80", "Java Virtual Machine Specification##################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15hi!hi!hi!OracleCorporationhi!1.7.0_80" + "'", str2.equals("1.7.0_80-b15hi!hi!hi!OracleCorporationhi!1.7.0_80"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803", 62, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...0226803" + "'", str3.equals("...0226803"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H", (int) 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H" + "'", str3.equals("Ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("J170_80-15OT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VM", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(10, 137, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 137 + "'", int3 == 137);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("hi#!##hi#!");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        char[] charArray8 = new char[] {};
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("/USERS/SOPHIE", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("1.7.0_80-b15", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM", charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80", charArray8);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny("", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        double[] doubleArray4 = new double[] { 1.0d, 10.0f, 35, 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################!/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################4444/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################", "hi#!#4444#hi#!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob", '#');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("h...", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", "1 7 0_80- 15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("noitaroproCelcarO", "IOOR");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("sophiesopjava HotSpot(TM) 64-Bit");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("racle corporatio", "HHIHH!HH!444!IH");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Oracle corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oitaroproc elcarO" + "'", str1.equals("oitaroproc elcarO"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("#################", "", "hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################4444/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#################" + "'", str3.equals("#################"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("hi#!##hi#", 55, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90 + "'", int2 == 90);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) -1, "hihi/Users/soph/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/Users/sophie!!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mixed mode", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (short) -1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("Oracle Corporation", (java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation Oracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str5.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation Oracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase(":10.14.3:124.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":10.14.3:124.80-B11" + "'", str1.equals(":10.14.3:124.80-B11"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("ot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OT(TM) 64-BIT SERVER VM" + "'", str1.equals("OT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("http://j4O", 14, "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/lhttp://j4O/l" + "'", str3.equals("/lhttp://j4O/l"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("h...", "", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(170.0d, 1.7000000476837158d, (double) 55.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.7000000476837158d + "'", double3 == 1.7000000476837158d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14....", "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("oitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarO");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: oitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarO is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "24.80-B1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "#################o", "UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ot(ts)e64-boteshrvhrevs", "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("oitaroproc elcaro", "oRACLE cORPORATIO", (int) (byte) 10, 7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "oitaropoRACLE cORPORATIO elcaro" + "'", str4.equals("oitaropoRACLE cORPORATIO elcaro"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "oracle corporatio", charArray5);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Usssi", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://j4O", "1.7.0_80");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!", "sophie", 1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80");
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "io", (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("                US                                 US                                 US                                 US        10.14.3", "Java/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseHot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseSpot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse(/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseTM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse)/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse64/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse-/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseBit/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseServer/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseVM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!" + "'", str3.equals("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        char[] charArray7 = new char[] {};
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("/USERS/SOPHIE", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("1.7.0_80-b15", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhOraclehcorporatio", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(":", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) -1, (float) 46, (float) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 46.0f + "'", float3 == 46.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 100, (int) (byte) 1, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(1364, (int) 'a', 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1364 + "'", int3 == 1364);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE" + "'", str1.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java", "oitaroprocelcaro");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java" + "'", str2.equals("/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(32);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80-b15", "sun.lwawt.macosx.CPrinterJob444444444444444444444444");
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("#################o");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"################o\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(10.0f, 46.0f, (float) 6L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 46.0f + "'", float3 == 46.0f);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "/VAR/FOLDERS/_V/6V597ZMNa_V31CQ2N2X1NaFC0000GN/");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                   ", "mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("#################O", 64);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################O" + "'", str2.equals("#################O"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "l# c#r##rat##");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("h", "hihi/Users/soph/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/Users/sophie!!", 217);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("oitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarOoitaroproc elcarO", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oit roproc elc rOoit roproc elc rOoit roproc elc rOoit roproc elc rOoit roproc elc rOoit roproc elc rOoit roproc elc rOoit roproc elc rO" + "'", str3.equals("oit roproc elc rOoit roproc elc rOoit roproc elc rOoit roproc elc rOoit roproc elc rOoit roproc elc rOoit roproc elc rOoit roproc elc rO"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("UTF-", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/libr");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("###################################################################################oracle corporatio", "ava Virtual Machine Specification#################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-" + "'", str1.equals("ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java44444444444444444444444444444444444444444444444", 31, 1215);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "EIHPOS/SRESU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "JAVA PLATFORM API SPECIF");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("170_80-15/t/ng0000cf4n1x2n2qc13v", "441.7.0_80-b15hi!hi!hi!Oraclesun.lwawt.macosx.LWCToolkitCorporationhi!1.7.0_80444444444444/4444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 'a', (double) (short) 0, (double) 16.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "jAVA vIRTUAL mACHINE sPECIFICATION", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "4Users4sophie4Documents4defects4j4tmp4run_randoopipl_88h3_h56!2268!3                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4Users4sophie4Documents4defects4j4tmp4run_randoopipl_88h3_h56!2268!3                                                                                                                                                     " + "'", str1.equals("4Users4sophie4Documents4defects4j4tmp4run_randoopipl_88h3_h56!2268!3                                                                                                                                                     "));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("Oracle Corporation", "Hi#!#4444#hi#!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi444444444444444/444444...", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi444444444444444/444444..." + "'", str2.equals("hi444444444444444/444444..."));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                           ...", (double) 31L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.0d + "'", double2 == 31.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vm", "http://j4O");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 128, (long) 1362, (long) 53);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1362L + "'", long3 == 1362L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, 0, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          " + "'", str1.equals("mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          "));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Hi#!#4444#hi#", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("51.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("", "US                                 US                                 US                                 US        10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Library/Java/JavaVirtualMachines/jdk1.7.0_jAVA vIRTUAL mACHINE sPECIFICATION##################0.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_jAVA vIRTUAL mACHINE sPECIFICATION##################0.jdk/Contents/Home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Mc O X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mc O " + "'", str1.equals("Mc O "));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle corporatio", "sun.lwawt.macosx.LWCToolkit");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!", "ioor", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "roaroproc elcaoit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("444444444444444/444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Oracle corporatioOracle corporatio", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("oitaroproc elcarO", "hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("RS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RS/SOPHIE!/USERS/SOPHIE4444/USERS/SOPHIEHI/USERS/SOPHIE!" + "'", str1.equals("RS/SOPHIE!/USERS/SOPHIE4444/USERS/SOPHIEHI/USERS/SOPHIE!"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hi#4444#!#Hi", (java.lang.CharSequence) "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 348 + "'", int2 == 348);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("####################################################java hotspot(tm) 64-bit server vmjava hotspot(tm", "UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################java hotspot(tm) 64-bit server vmjava hotspot(tm" + "'", str2.equals("####################################################java hotspot(tm) 64-bit server vmjava hotspot(tm"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        double[] doubleArray2 = new double[] { (byte) -1, 100 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("1.7.0_80-b15", "i#!#JViuMinsdk170_80dkCnnsH#i#!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("x3 os x4 os x os x os x os", 9, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("J170_80-15OT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VM", 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.lang.Class<?> wildcardClass1 = file0.getClass();
        org.junit.Assert.assertNotNull(file0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE", "hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################4444/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(":aaaaaaaaa", "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":aaaaaaaaa" + "'", str2.equals(":aaaaaaaaa"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("                US                                 US                                 US                                 US        10.14.3pot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM", "170_80-15/t/ng0000cf4n1x2n2qc13v", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                   ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("racl# c#r##rat##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaa:aaaaaaaaa", ":");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("!", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith(" OOR", (java.lang.Object[]) strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("   /   ", " OS X", 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("Mc O X", strArray5, strArray10);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "!" + "'", str6.equals("!"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Mc O X" + "'", str11.equals("Mc O X"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp(":", "hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 6L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/USERS/SOPHIE", 3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("aaaaaaaa:aaaaaaaaa", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaa:aaaaaaaaa" + "'", str2.equals("aaaaaaaa:aaaaaaaaa"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(" OOR", 0, 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/libr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/libr" + "'", str1.equals("/libr"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepS enihcaM lautriV avaJ" + "'", str1.equals("noitacificepS enihcaM lautriV avaJ"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation Oracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("sophie");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("sun.lwawt.macosx.LWCToolkit", (java.lang.Object[]) strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!", strArray2, strArray5);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "i#!#JViuMinsdk170_80dkCnnsH#i#!", 138, 513);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 138");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sophie" + "'", str6.equals("sophie"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!" + "'", str7.equals("hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "hi#4444#!#Hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                         Oracle corporatio", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                         Oracle corporatio" + "'", str3.equals("                                                         Oracle corporatio"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sun.lwawt.macosx.CPrinterJob", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("       :", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("               :                                                                                 ", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("en", "Hi#!#4444#hi#", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(".3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:" + "'", str3.equals(".3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("/VAR/FOLDERS/_V/6V597ZMNa_V31CQ2N2X1NaFC0000GN/", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("HHIHH!HH!444!IH", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HHIHH!HH!444!IH" + "'", str2.equals("HHIHH!HH!444!IH"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("roaroproc elcaoit", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 4);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "roaroproc elcaoit" + "'", str5.equals("roaroproc elcaoit"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) " ", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("HHIHH!HH!444!IH");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter(" Hi#!#4444#hi#! ", "e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (byte) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("SUN.LWAWT.MACOSX.cpRINTERjOB                                    ", "1.7#");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 'a', (long) 1215, (long) 513);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444" + "'", str1.equals("444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/moc.elcaro.avaj//:ptth", "1.7.0_80-b15hi!hi!hi!OracleCorporationhi!1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVM", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVM" + "'", str3.equals("JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("hJavaVirtualMachine/Users/sophie#######/UsJavaVirtu", 138);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hJavaVirtualMachine/Users/sophie#######/UsJavaVirtu                                                                                       " + "'", str2.equals("hJavaVirtualMachine/Users/sophie#######/UsJavaVirtu                                                                                       "));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                                    Oracle corporatio", (java.lang.CharSequence) "/t/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("OracleCorporation", "sun.lwawt.macosx.LWCToolkit");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("HI!", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ava Virtual Machine Specification##################", "JAVA PLATFORM API SPECIF");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################!/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################4444/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################", 216, "orcle Corportion");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################!/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################4444/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################" + "'", str3.equals("HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################!/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################4444/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("         Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("441.7.0_80-b15hi!hi!hi!oraclecorporationhi!1.7.0_80444444444444/4444444444444444", "/Library/Java/JavaVirtualMachines/jdk1.7.0_0.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 62);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 62.0d + "'", double2 == 62.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVMhi!4444hi!JavaHotSpot(TM)64-BitServerVM", "441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444", 90);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("/USERS/SOPHIE", charArray5);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("machine4 4specification4##################4java4 4virtual4 4machine4 4specification4##################4s4/4sjava4 4virtual4 4machine4 4specification4##################4java4 4virtual4 4machine4 4specification4##################4hjava4 4virtual4 4machine4 4specification4##################4java4 4virtual", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!4444hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hihi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/", "dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!", 137);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!" + "'", str2.equals("hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "   /    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1 7 0_80- 15", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1 7 0_80- 15" + "'", str2.equals("1 7 0_80- 15"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444sun.awt.CGraphicsEnvironment441.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80444444444444/4444444444444444", 7);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "noitaroproCelcarOaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.awt.CGraphicsEnvironment" + "'", str1.equals("Sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("hi/Users/sophie!/Users/sophiehhhh/Users/sophiehi/Users/sophie!", 1362);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          hi/Users/sophie!/Users/sophiehhhh/Users/sophiehi/Users/sophie!                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          hi/Users/sophie!/Users/sophiehhhh/Users/sophiehi/Users/sophie!                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          "));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                sun.lwawt.macosx.LWCToolkit                                         ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                                 sun.lwawt.macosx.LWCToolkit                                          is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "sophie");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) '#', (double) 46.0f, (double) 170L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 170.0d + "'", double3 == 170.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("/XEDMODE", "UX3 OS X4 OS X OS X OS X OS.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hi/Users/sophie!/Users/sophiehhhh/Users/sophiehi/Users/sophie!", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Java/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseHot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseSpot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse(/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseTM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse)/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse64/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse-/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseBit/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseServer/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseVM", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi#!##hi#!", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("HI/uSERS/SOPHIE!/uSERS/SOPHIE4444/uSERS/SOPHIEHI/uSERS/SOPHIE!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "M         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("               :", "4444444444444444444444444444444444/", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("racle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatioracle corporatio", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("\n", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680", 0);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("                                           noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                           ", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 105 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", ' ');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/U...", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str5.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "24.80-B1");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7.0_80-b15" + "'", str5.equals("1.7.0_80-b15"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("         Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "         Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("         Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("ac OS X", "noitacificepS enihcaM lautriV avaJ", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("oitaroproc elcaro", "mixed mode");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', (int) (short) 0, 0);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("iooHI!ioor", "noitaroproCelcarO");
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", strArray3, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 8");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("mixed mode", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("sun.lwawt.macosx.cprinterjobHJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################J");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        double[] doubleArray4 = new double[] { 0.0d, (byte) 1, (short) -1, (-1) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE" + "'", str1.equals("/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE/XED MODE"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 32, (long) 350, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 350L + "'", long3 == 350L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!4444hi!", "1.7.0_80", (-1));
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "CnCnCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "http://j4O", 1364, 3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                     http://java.oracle.com/                                     ");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!", "!", 0);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("                                sun.lwawt.macosx.LWCToolkit                                         ", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 10 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/XED MODE", "UTF-8", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "http://j4O");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                US                                 US                                 US                                 US        10.14.3pot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US                                 US                                 US                                 US        10.14.3pot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("US                                 US                                 US                                 US        10.14.3pot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java", "Hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        char[] charArray10 = new char[] { '#', '#', '#' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "O", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "roaroproc elcaoit", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                sun.lwawt.macosx.LWCToolkit                                         ", charArray10);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                   ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("hi/Users/sophie!/Users/sophiehhhh/Users/sophiehi/Users/sophie!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi/Users/sophie!/Users/sophiehhhh/Users/sophiehi/Users/sophie!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM", "hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################4444/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("hi#!#4444#hi#!", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("racle corporatio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: racle corporatio is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("RS/SOPHIE!/USERS/SOPHIE4444/USERS/SOPHIEHI/USERS/SOPHIE!", "HI!4444HI!", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RS/SOPHIE!/USERS/SOPHIE4444/USERS/SOPHIEHI/USERS/SOPHIE!" + "'", str3.equals("RS/SOPHIE!/USERS/SOPHIE4444/USERS/SOPHIEHI/USERS/SOPHIE!"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("   /    ", 1215, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("####4#3", "JAVA HOTSPOT(TM) 6 -BIT SERVER VM                US                                 US                                 US                                 US        10.14.3");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                         en                         ", (java.lang.CharSequence) "!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("oitaroproc elcaro                                                                                                                                                                                                                                                                                                     ", "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/libr", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################4444/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################/UsJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################s/sJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################hJavaVirtualMachineSpecification##################JavaVirtualMachineSpecification##################!", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("ioor", "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                                    Oracle corporatio", 53);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                         en                                                                                                     ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100, (float) 216, (float) 7);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 216.0f + "'", float3 == 216.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM", "HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################!/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################4444/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################S/SJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################HJAVA VIRTUAL MACHINE SPECIFICATION##################JAVA VIRTUAL MACHINE SPECIFICATION##################!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("RS/SOPHIE!/USERS/SOPHIE4444/USERS/SOPHIEHI/USERS/SOPHIE!");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sophie", "1.7");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) (short) 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "oRACLE cORPORATIO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("http://jaO", "#################o");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://jaO" + "'", str2.equals("http://jaO"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("24.80-B11", "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "", 1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("                US                 ", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(" OOR");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" OOR\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 65, 0.0f, (float) 170L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 170.0f + "'", float3 == 170.0f);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Mc O X", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 349, (float) 64, (float) 31L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 31.0f + "'", float3 == 31.0f);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 55, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("", (java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.14.3", "ioor");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("####################################################", strArray4, strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "####################################################" + "'", str6.equals("####################################################"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Users/sophie24.80-b1124.80-b112", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie24.80-b1124.80-b112" + "'", str2.equals("/Users/sophie24.80-b1124.80-b112"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(" Hi#!#4444#hi#! ", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " Hi#!#4444#hi#! " + "'", str3.equals(" Hi#!#4444#hi#! "));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(" OOR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " OOR" + "'", str1.equals(" OOR"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 3039, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3039 + "'", int3 == 3039);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!", "UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!" + "'", str2.equals("/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80", "CnCnCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("SUN.LWAWT.MACOSX.cpRINTERjOB                                    ", "                                   ", "     ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("ot(tm) 6a-bit server vm", "####################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-", 27, 350);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "....14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14...." + "'", str3.equals("....14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14...."));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "OracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation", "oitaroproc elcaro                                                                                                                                                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hihi/Users/soph/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/Users/sophie!!", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Virtual Machine Specification", "HI!4444HI!");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("       :", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("UTF-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        short[] shortArray2 = new short[] { (byte) -1, (byte) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.Class<?> wildcardClass4 = shortArray2.getClass();
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/moc.elcaro.avaj//:ptth");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /moc.elcaro.avaj//:ptth is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("         Java HotSpot(TM) 64-Bit Server VM         ", "1.7.0_80-b15");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", 'a');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("Hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("ava Virtual Machine Specification##################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ava Virtual Machine Specification##################" + "'", str1.equals("ava Virtual Machine Specification##################"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        char[] charArray8 = new char[] {};
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VMhi!4444hi!Java HotSpot(TM) 64-Bit Server VM", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "24.80-b11", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", charArray8);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny("/lhttp://j4O/l", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1" + "'", str1.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("racl# c#r##rat##", "h...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/xed mod", 90);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90 + "'", int2 == 90);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("###################################################################################oracle corporatio", "hi!", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "racl# c#r##rat##", (java.lang.CharSequence) "/xed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                         Oracle corporatio", "                                                                     444444444444444/4444444444444444                                                                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                         Oracle corporatio" + "'", str2.equals("                                                         Oracle corporatio"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.14.3                                                                                          ", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.hi#!#4444#hi#!10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "US                                 US                                 US                                 US        10.14.3", 513, 13);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("sophie");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("sun.lwawt.macosx.LWCToolkit", (java.lang.Object[]) strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!", strArray2, strArray5);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 51, 57);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 51");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sophie" + "'", str6.equals("sophie"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!" + "'", str7.equals("hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("170_80-15/t/ng0000cf4n1x2n2qc13v", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "170_80-15/t/ng0000cf4n1x2n2qc13v" + "'", str3.equals("170_80-15/t/ng0000cf4n1x2n2qc13v"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 35, 0.0f, (float) '4');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaJavaaHotSpot(TM)a64-BitaServeraVMaaaaaaaaa", "ot(tm) 6a-bit server vm");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("                         en                                                                                                     ", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14....", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14...." + "'", str3.equals("UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14...."));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("   /   ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("RS/SOPHIE!/USERS/SOPHIE4444/USERS/SOPHIEHI/USERS/SOPHIE!", 348, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444RS/SOPHIE!/USERS/SOPHIE4444/USERS/SOPHIEHI/USERS/SOPHIE!" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444RS/SOPHIE!/USERS/SOPHIE4444/USERS/SOPHIEHI/USERS/SOPHIE!"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        double[] doubleArray4 = new double[] { 1.0d, 10.0f, 35, 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("1.7                                ", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("OT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                             hi!", 100, 138);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Virtual Machine Specification", 0, "MACHINE4 4SPECIFICATION4##################4JAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4S4/4SJAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4JAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4HJAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4JAVA4 4VIRTUAL");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("hi#4444#!#Hi", 310, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/VAR/FOLDERS/_V/6V597ZMNa_V31CQ2N2X1NaFC0000GN/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 216, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("                US                 ");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("4Users4sophie4Documents4defects4j4tmp4run_randoopipl_88h3_h56!2268!3                                                                                                                                                     ", strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concatWith("http://j4O", (java.lang.Object[]) strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concatWith("MACHINE4 4SPECIFICATION4##################4JAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4S4/4SJAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4JAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4HJAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4JAVA4 4VIRTUAL", (java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "US" + "'", str5.equals("US"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "US" + "'", str7.equals("US"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "US" + "'", str8.equals("US"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("oitaroproc elcaro                                                                                                                                                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java44444444444444444444444444444444444444444444444", "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java44444444444444444444444444444444444444444444444" + "'", str2.equals("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java44444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("Orcle Corportio", "MACHINE4 4SPECIFICATION4##################4JAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4S4/4SJAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4JAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4HJAVA4 4VIRTUAL4 4MACHINE4 4SPECIFICATION4##################4JAVA4 4VIRTUAL");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                                    Oracle corporatio");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhOraclehcorporatio", "Hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################", 9);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/!sd oids", 138, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "...0226803");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Virtual Machine Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Users/sophie24.80-b1124.80-b112", "enaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(":10.14.3:124.80-B11", "/4sers/sophie/Library/Java/Extensio              1.7.0_80                                  brary/Java/Extensions:/usr/lib/java", 520);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("170_80-15/t/ng0000cf4n1x2n2qc13v", "UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "     ot(tm) 6a-bit server vm1.01");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 27, 64);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1" + "'", str1.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7./1.7.0", 64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64 + "'", int2 == 64);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", 6);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "J(M) SE Rutime Environment" + "'", str4.equals("J(M) SE Rutime Environment"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.cprinterjobHJAVA VIRTUAL MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################J");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                      Oracle corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                      oRACLE CORPORATIO" + "'", str1.equals("                                      oRACLE CORPORATIO"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((-1), (int) (short) 1, 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 1362, 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("....14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14....", 17, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "....14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14...." + "'", str3.equals("....14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14...."));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!4444hi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!hihi/Users/sophie!/Users/sophie/Users/sophiehi/Users/sophie!!", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("JAVA HOTSPOT(TM) 6 -BIT SERVER VM                US                                 US                                 US                                 US        10.14.3", "/VAR/FOLDERS/_V/6V597ZMNa_V31CQ2N2X1NaFC0000GN/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("4Users4sophie4Documents4defects4j4tmp4run_randoopipl_88h3_h56!2268!3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4Users4sophie4Documents4defects4j4tmp4run_randoopipl_88h3_h56!2268!3" + "'", str1.equals("4Users4sophie4Documents4defects4j4tmp4run_randoopipl_88h3_h56!2268!3"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("oitaroprocelcaro", "tioacle corpora###################################################################################Or");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t", "UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14....");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("51.0", "hi#!##hi#", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("1.7                                ", "java hotspot(tm) 64-bit server vm", 57);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaJavaaHotSpot(TM)a64-BitaServeraVMaaaaaaaaa", "ot(tm) 6a-bit server vm");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JHSpTM4BSVM" + "'", str3.equals("JHSpTM4BSVM"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi!4444hi!", 137, "1.7.0_8...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!4444hi!1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8" + "'", str3.equals("hi!4444hi!1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                      Oracle corporatio", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaiooraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(" OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OS X" + "'", str1.equals("OS X"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80", "io");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1201 + "'", int2 == 1201);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 0, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("               :", 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/U...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/U..." + "'", str1.equals("/U..."));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "orcle Corportion", "/4sers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/4ystem/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java Virtual Machine Specification", "hi/Users/sophie!/Users/sophiehhhh/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Virtual Machine Specification##################", 74, "mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification##################mixed mode            " + "'", str3.equals("Java Virtual Machine Specification##################mixed mode            "));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "orcle Corportion", "oitaroproc elcaro");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        double[] doubleArray3 = new double[] { 0, 'a', 8L };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 97.0d + "'", double4 == 97.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Oracle Corporation", 1364);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  Oracle Corporation" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  Oracle Corporation"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################4444/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################/UsJava Virtual Machine Specification##################Java Virtual Machine Specification##################s/sJava Virtual Machine Specification##################Java Virtual Machine Specification##################hJava Virtual Machine Specification##################Java Virtual Machine Specification##################!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################", "hJavaVirtualMachine/Users/sophie#######/UsJavaVirtu                                                                                       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hJavaVirtualMachine/Users/sophie#######/UsJavaVirtu                                                                                       " + "'", str2.equals("hJavaVirtualMachine/Users/sophie#######/UsJavaVirtu                                                                                       "));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("noitaroproCelcarOaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproCelcarOaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("noitaroproCelcarOaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(18);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 100, (byte) -1, (byte) -1, (byte) 0, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("444444444444444/4444444444444444", (int) (short) 100, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "####################################################JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java", ".3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java" + "'", str2.equals("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-b15hi!hi!hi!OracleCorporationhi!1.7.0_80", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaiooraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java Platform API Specif");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specif" + "'", str1.equals("Java Platform API Specif"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        char[] charArray6 = new char[] { 'a', '4', ' ', 'a', '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "OT(TM) 64-BIT SERVER VM", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444RS/SOPHIE!/USERS/SOPHIE4444/USERS/SOPHIEHI/USERS/SOPHIE!", 1215, 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("     ", 170);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi/users/sophie!/users/sophie4444/users/sophiehi/users/sophie!" + "'", str1.equals("hi/users/sophie!/users/sophie4444/users/sophiehi/users/sophie!"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sophiesopjava HotSpot(TM) 64-Bit Server VMsophiesoph", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("ot(tm) 6a-bit server vm", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("JAVA HOTSPOT(TM) 6 -BIT SERVER VM                US                                 US                                 US                                 US        10.14.3", "hi/Users/sophie!/Users/sophiehhhh/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(2L, 32L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 310, (float) 348, (float) 138);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 138.0f + "'", float3 == 138.0f);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!     HI!", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("http://java.oracle.com/", "SUN.LWAWT.MACOSX.cpRINTERjOB", 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        double[] doubleArray4 = new double[] { 1.0d, 10.0f, 35, 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java", "                                           noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java" + "'", str2.equals("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("O", ' ');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vm", 170, 350);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 170");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", 57);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("http :// java . oracle . com /", "noitacificepS enihcaM lautriV avaJ", 1366);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("hi!hi!", (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("oitaroproc elcarO", "       :", "JavaOracle corporatioOracle corporatioVirtualOracle corporatioOracle corporatioMachineOracle corporatioOracle corporatioSpecification##################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oitaroproc elcarO" + "'", str3.equals("oitaroproc elcarO"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) " Hi#!#4444#hi#! ", (java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 97L, (float) 216L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "...hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("I170_80-15OT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VMHI!4444HI!JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 18L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hjava" + "'", str2.equals("hjava"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("jAVA vIRTUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA vIRTUAL mACHINE sPECIFICATION" + "'", str1.equals("jAVA vIRTUAL mACHINE sPECIFICATION"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("...L MACHINE SPECIFICATION##################/USJAVA VIRTUAL MACHINE SPECIFICATION##################J", "I", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 0, "HI/uER/OPHIE!/uER/OPHIE/uER/OPHIEHI/uER/OPHIE!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                    " + "'", str3.equals("                                                    "));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "                                                    ", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "sophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesophsophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesophsophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesophsophiesopj v  HotSpot(TM) 64-Bit Servsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesophsophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesophsophiesopj v  HotSpot(TM) 64-Bit Server VMsophiesophsophiesopj v  HotSpot(TM) 64-Bit Serv");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "oitaroprocelcaro");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihpos" + "'", str1.equals("eihpos"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("...hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh...", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vmhi!4444hi!java hotspot(tm) 64-bit server vm", "ot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("x3 os x4 os x os x os x osHI!4444HI!x3 os x4 os x os x os x os", "/4sers/sophie/Library/Java/Extensio444444444444444/4444444444444444brary/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("aaaaaaaaaaaaaaaaaa", "Oracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatio", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ac OS ", 216, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ac OS aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("ac OS aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                                                                                                   3.41.01");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "Java/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseHot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseSpot/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse(/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseTM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse)/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse64/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse-/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseBit/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseServer/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorseVM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/xed mode", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!4444hi!", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("X3 OS X4 OS X OS X OS X OSX3 OS X4 OS X OS X OS X OSX3 OS X4 OS X OS X OS X OSX3 OS X4 OS X OS X OS X OS4X3 OS X4 OS X OS X OS X OS3", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java", "Java Platform API Specification", 97);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                  444444444444444/4444444444444444                                  ", (java.lang.CharSequence) "...0226803");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                      oRACLE CORPORATIO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE CORPORATIO" + "'", str1.equals("oRACLE CORPORATIO"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("x3 os x4 os x os x os x os", "441.7.0_80-b15hi!hi!hi!Oraclesun.lwawt.macosx.LWCToolkitCorporationhi!1.7.0_80444444444444/4444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x3 os x4 os x os x os x os" + "'", str2.equals("x3 os x4 os x os x os x os"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("               :                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "               :                                                                                 " + "'", str1.equals("               :                                                                                 "));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!hi!", "/!sd oids                                                                                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("hi!", 6, 53);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("#################", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444" + "'", str3.equals("44444444444444444"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/uSERS/SOPHIEHI/uSERS/SOPHIE!4HI/uSERS/SOPHIE!/uSERS/SOPHIE", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("ot(tm) 6a-bit server vm", "                                                                                                                                                                                                                                                                                                     /Library/Java/JavaVirtualMachines/jdk1.7.0_jAVA vIRTUAL mACHINE sPECIFICATION##################0.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("10.14.3", "", "/uSERS/SOPHIEHI/uSERS/SOPHIE!4HI/uSERS/SOPHIE!/uSERS/SOPHIE");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("h...", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h..." + "'", str2.equals("h..."));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!hi444444444444444/4444444444444444!444444444444444/44444444444444444444444444444444444/4444444444444444hi444444444444444/4444444444444444!hi!hi!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("UserssopeDocumentsdefectsjtmprun_randoop.pl_8813_156022680", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UserssopeDocumentsdefectsjtmprun_randoop.pl_8813_156022680" + "'", str2.equals("UserssopeDocumentsdefectsjtmprun_randoop.pl_8813_156022680"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!4444hi!");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny("10.14.3", strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!hi!", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UTF-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:UTF-:10.14.3:10.14.3:10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                         Oracle corporatio");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t", 100);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444444444444444444/444444444444444", 90);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90 + "'", int2 == 90);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("....14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:10.14.3:utf-ux3 os x4 os x os x os x os.14.3:10.14.3:10.14....");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_156022680");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("hi!#######################################################################################################################################", 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "64" + "'", str1.equals("64"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucod/eihpos/sresu/" + "'", str1.equals("086220651_3188_lp.poodnar_nur/pmt/j4stcefed/stnemucod/eihpos/sresu/"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("JAVA HOTSPOT(TM) 6 -BIT SERVER VM", (long) 310);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 310L + "'", long2 == 310L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("hi/users/sophie!/users/sophie4444/users/sophiehi/users/sophie!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("hjava", "ava Virtual Machine Specification#################", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("hi444444444444444/444444...", "                                           noitaroproCelcarO                                           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################", "http :// java . oracle . com /", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        java.lang.String[] strArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H", strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("oRACLE cORPORATIO");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"oRACLE cORPORATIO\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 48 + "'", int1 == 48);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) -1, 138, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("10.14.3                                                                                                                                   ", "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                  brary/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3                                                                                                                                   " + "'", str2.equals("10.14.3                                                                                                                                   "));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x3 os x4 os x os x os x osHI!4444HI!x3 os x4 os x os x os x os");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        double[] doubleArray1 = new double[] { 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation Oracle CorporationOracle CorporationOracle CorporationOracle Corporation", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("SUN.LWAWT.MACOSX.cpRINTERjOB", "/libr", 65);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/", '4');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("1.7#", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", "####################################################JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("", "/4sers/sophie/Library/Java/Extensio                                  444444444444444/4444444444444444                                                    Oracle corporatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("SUN.LWAWT.MACOSX.cpRINTERjOB                                    ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("4444444444444444444444444444444444/", "oracle Corporation", 513);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java Platform API Specification", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("java HotSpot(TM) 64-Bit Server VM", "                 ", 217);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "ava Virtual Machine Specification##################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!" + "'", charSequence2.equals("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("                                     http://java.oracle.com/                                     ", " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        int[] intArray2 = new int[] { ' ', (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("iooHI!ioo");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification#################" + "'", str1.equals("Hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################!/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################4444/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################/usjava virtual machine specification##################java virtual machine specification##################s/sjava virtual machine specification##################java virtual machine specification##################hjava virtual machine specification##################java virtual machine specification#################"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("ac OS ", "hi!4444hi!1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8...1.7.0_8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ac OS " + "'", str2.equals("ac OS "));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", (int) (short) -1, 1366);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!" + "'", str3.equals("!"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        java.lang.String[] strArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8813_1560226803/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("####################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"####################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("                                           noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                           ", "hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 28, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.0d + "'", double3 == 28.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 1364);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                                                                                                                                                                                                                                                                      ", "                         en                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(14.0f, (float) 1364, (float) 217L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 14.0f + "'", float3 == 14.0f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob", '#');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("UTF-8", "Oracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatioOracle corporatio", "JAVA HOTSPOT(TM) 6 -BIT SERVER VM");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("170_80-15", "mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!", 520, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!" + "'", str3.equals("hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!hi/Users/sophie!/Users/sophie4444/Users/sophiehi/Users/sophie!"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhOraclehcorporatio", "JAVA PLATFORM API SPECIF", 348);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1.7#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("                                                                                                                                                                                                                                                                                                                      /moc.elcaro.avaj//:ptth                                                                                                                                                                                                                                                                                                                      /moc.elcaro.avaj//:ptth                                                                                                                                                                                                                                                                                                                      /moc.elcaro.avaj//:ptth                                                                                                                                                                                                                                                                                                                      ", "racl# c#r##rat##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "44444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("JAVA HOTSPOT(TM) 6 -BIT SERVER VM                US                                 US                                 US                                 US        10.14.3", (int) '#');
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/Users/sophie", (int) (short) -1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.Class<?> wildcardClass6 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "24.80-b11", (int) '#');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/Users/sophie", (int) (short) -1);
        int int12 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("hi!4444hi!", strArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny("O", strArray11);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80", strArray5, strArray11);
        int int15 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("sophiesopj v  HotSpot(TM) 64-Bi", strArray11);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80" + "'", str14.equals("1.7.0_80-b15hi!hi!hi!Oracle Corporationhi!1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 51, (long) 62, (long) 217);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 217L + "'", long3 == 217L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("J(M) SE Rutime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J(M) SE Rutime Environment" + "'", str1.equals("J(M) SE Rutime Environment"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("e");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                           noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                           ", "Hi#!#4444#hi#!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                           noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                           " + "'", str2.equals("                                           noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                                                                      noitaroproCelcarO                                           "));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("oracle Corporation", "", "/Users/sophie24.80-b1124.80-b112");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracle Corporation" + "'", str3.equals("oracle Corporation"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("hihi/Users/soph/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/Users/sophie!!", 8, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "r" + "'", str3.equals("r"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        char[] charArray10 = new char[] { '#', '#', '#' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "O", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "roaroproc elcaoit", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny("dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", charArray10);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajh##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajs/s##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajsu/##################noitacificeps enihcam lautriv avajh##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajh##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajs/s##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajsu/4444##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajh##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajs/s##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajsu/!##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajh##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajs/s##################noitacificeps enihcam lautriv avaj##################noitacificeps enihcam lautriv avajsu/##################noitacificeps enihcam lautriv avajH", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }
}

