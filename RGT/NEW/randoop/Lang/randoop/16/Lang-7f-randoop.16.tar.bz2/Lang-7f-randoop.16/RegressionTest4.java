import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", '4');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!:", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "!:" + "'", str5.equals("!:"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("class [Ljava.lang.String;class [Ljava.lang.String;", (int) (short) 10, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str3.equals("class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                   ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "ihpos", 142);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "-1.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("             10.14.3              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:              10.14.3               is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("44#4a4#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44#4a4#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "#", (java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7orm API Specification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("mixed mod", "8.04-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mod" + "'", str2.equals("mixed mod"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "1.21.71.1");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!", "", 12);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ICEPSIPAMROFTALPAVAJ", "100#1ihpos");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "100a1a10a-1a1a1", (java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("VA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [d");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "va.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D" + "'", str1.equals("va.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", "####US####                                                                                          ", (int) '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str4.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("al Machine Specification", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "al Machine Specification" + "'", str2.equals("al Machine Specification"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("fication", "va.lang.string;class [ljava.lang.string;class [ljava.lang.string;class [d");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "va.lang.string;class [ljava.lang.string;class [ljava.lang.string;class [d" + "'", str2.equals("va.lang.string;class [ljava.lang.string;class [ljava.lang.string;class [d"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        double[] doubleArray3 = new double[] { (byte) 10, 26.0f, (byte) 1 };
        double[] doubleArray7 = new double[] { (byte) 10, 26.0f, (byte) 1 };
        double[] doubleArray11 = new double[] { (byte) 10, 26.0f, (byte) 1 };
        double[] doubleArray15 = new double[] { (byte) 10, 26.0f, (byte) 1 };
        double[] doubleArray19 = new double[] { (byte) 10, 26.0f, (byte) 1 };
        double[] doubleArray23 = new double[] { (byte) 10, 26.0f, (byte) 1 };
        double[][] doubleArray24 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19, doubleArray23 };
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("sun.lwawt.macosx.LWCToolkit", "14-", "mixed mod");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                                                                                                                                                                                                aa#a#a4a#", "4a#aaa#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                aa#a#a4a#" + "'", str2.equals("                                                                                                                                                                                                                aa#a#a4a#"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444" + "'", str2.equals("4444444444"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray2, '#', 1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1 -1" + "'", str7.equals("1 -1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1#-1" + "'", str9.equals("1#-1"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 100, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("31.0#9.0#12.0#10.0#35.0", "10 0 1 -1 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "31.0#9.0#12.0#10.0#35.0" + "'", str2.equals("31.0#9.0#12.0#10.0#35.0"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1http://java.oracle.com/", (int) 'a', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.0#21.0#-1.0#0.0", (double) 9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.0d + "'", double2 == 9.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288", "10 0 1 -1 -1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("####US####                                                                                          ", "Oracle Corporation");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "aa#a#a4a#");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a#####4##", (int) (byte) 1);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.split("-1.0 100.0", '4');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray17, ' ');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray14, strArray17);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10a0a1a-1a-1", strArray9, strArray14);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEach("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", strArray5, strArray14);
        int int23 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray14);
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.stripAll(strArray14, "##4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#");
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEach("51.", strArray1, strArray25);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-1.0 100.0" + "'", str19.equals("-1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10a0a1a-1a-1" + "'", str21.equals("10a0a1a-1a-1"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie" + "'", str22.equals("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "51." + "'", str26.equals("51."));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "al Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "mac os x", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("0.9", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "", "aa#a#a4a#");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("####US####      ####US####      ", "#######################A#####4#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####US####      ####US####      " + "'", str2.equals("####US####      ####US####      "));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D", (java.lang.CharSequence) "-1a1a0a10a0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "sophie", 10);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray5);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Mixed mode", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 0, (byte) 1, (byte) -1, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 8, (int) (short) 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 0, (int) (short) 1);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 0, 2);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "10#-1#100#0#-1#-1");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 10#-1#100#0#-1#-1");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10a0a1a-1a-1" + "'", str7.equals("10a0a1a-1a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10 0" + "'", str19.equals("10 0"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0" + "'", str1.equals("0"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixedmode" + "'", str1.equals("mixedmode"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 21.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.0 21.0 -1.0 0.0", (java.lang.CharSequence) "", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-" + "'", str1.equals("2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.0#21.0#-1.0#0.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "0.001#0                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "mixedmode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "al Machine Specification", (java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.21.71.1", 217);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                1.21.71.1" + "'", str2.equals("                                                                                                                                                                                                                1.21.71.1"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1a-1a100a-1a100a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "001a001a1-a001a1-a1" + "'", str1.equals("001a001a1-a001a1-a1"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("10.1#.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.1#.3" + "'", str1.equals("10.1#.3"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("#4#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#4#" + "'", str1.equals("#4#"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("             10.14.3              ", 21, "1#-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "             10.14.3              " + "'", str3.equals("             10.14.3              "));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) -1, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "0a100a10");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 0a100a10");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10#-1#100#0#-1#-1" + "'", str9.equals("10#-1#100#0#-1#-1"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("             10.14.3              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("100414104-141410", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100#1#10#-1#1#10", "ihpos", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("ORACLE CORPORATION-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2", "0#100.0                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE CORPORATION-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2" + "'", str2.equals("ORACLE CORPORATION-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "44444444444444444444444a#aaa", (java.lang.CharSequence) "1#-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.7.0_80", "354104-14-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ", 10, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          " + "'", str3.equals("####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          "));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Mixed mode", charSequence1, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("SUN.AWT.cgRAPHICSeNVIRONMENT", "1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str2.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-1" + "'", str1.equals("2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-1"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("http://java.oracle.com/", "h1a-11a-1", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "34.0 100.0 0.0 10.0 52.0", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "34.0 100.0 0.0 10.0 52.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        float[] floatArray2 = new float[] { 21, 34 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', (int) (short) 10, 9);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 21.0f + "'", float3 == 21.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "21.0#34.0" + "'", str9.equals("21.0#34.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 34.0f + "'", float10 == 34.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "21.0 34.0" + "'", str12.equals("21.0 34.0"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sUN.LWAWT.MACOSX.cpRINTERjOB", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "#4##");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                                 ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("####US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US###44444444444444444444444a#aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US###44444444444444444444444a#aaa" + "'", str1.equals("####US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US###44444444444444444444444a#aaa"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat(" aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4# ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("100.0a10.0a10.0a1.0", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1040414-14-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        float[] floatArray5 = new float[] { 34.0f, (byte) 100, 0, 10, '4' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ', 4, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "34.0 100.0 0.0 10.0 52.0" + "'", str7.equals("34.0 100.0 0.0 10.0 52.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "34.0 100.0 0.0 10.0 52.0" + "'", str12.equals("34.0 100.0 0.0 10.0 52.0"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "PLATFORM API SPECIFICATION", (java.lang.CharSequence) "-1.0100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "44444444444444444444444a#aaa", (java.lang.CharSequence) "####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "44444444444444444444444a#aaa" + "'", charSequence2.equals("44444444444444444444444a#aaa"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "_x7x8_88", (java.lang.CharSequence) "1a-1a100a-1a100a100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("http://java.oracle.com/                                                                             ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [", (java.lang.CharSequence) "10 0", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa", (long) 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophi" + "'", str1.equals("sophi"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 6, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10a0a1a-1a-1", '#');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sophi4", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0.001 0.1-", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-" + "'", str2.equals("-"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 'a', 35L, (long) 30);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 30L + "'", long3 == 30L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("mac os x", "AAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mac os x" + "'", str2.equals("mac os x"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                100#1ihpos", "-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                100#1ihpos" + "'", str2.equals("                100#1ihpos"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "001a001a1-a001a1-a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("10Java(TM) SE Runtime Environment10                                                                 ", 21, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " Environment10                     " + "'", str3.equals(" Environment10                     "));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("51.0", 1, 142);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0" + "'", str3.equals("1.0"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1http://java.oracle.com/", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("10 0 1 -1 -1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sU" + "'", str1.equals("sU"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 34, "sophi4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophi4sophi4sophisophi4sophi4sophi" + "'", str3.equals("sophi4sophi4sophisophi4sophi4sophi"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("####US####                                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####US####" + "'", str1.equals("####US####"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10a0a1a-1a-1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "m1.3", (java.lang.CharSequence) "10J...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        long[] longArray4 = new long[] { '#', (byte) 10, (short) -1, (-1L) };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        double[] doubleArray4 = new double[] { 1, 21, (-1.0f), 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 21.0d + "'", double5 == 21.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.0d + "'", double6 == 21.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(177, 4, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 177 + "'", int3 == 177);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("AAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("#", "0", (int) (short) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "J1.0 21.0v1.0 21.0(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "#" + "'", str5.equals("#"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4# is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr", "####US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US###44444444444444444444444a#aaa", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "4a#aaa", (java.lang.CharSequence) "0a100a10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("####US####                                                                                          ", "Oracle Corporation");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "aa#a#a4a#");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a#####4##", (int) (byte) 1);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.split("-1.0 100.0", '4');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, ' ');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray12, strArray15);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10a0a1a-1a-1", strArray7, strArray12);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", strArray3, strArray12);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray12);
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "##4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#");
        int int24 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray12);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-1.0 100.0" + "'", str17.equals("-1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10a0a1a-1a-1" + "'", str19.equals("10a0a1a-1a-1"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie" + "'", str20.equals("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaa", (int) (byte) 100, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444aaaaaa" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444aaaaaa"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "####US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US###44444444444444444444444a#aaa", 35, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("m1.3", "##################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "m1.3" + "'", str2.equals("m1.3"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0#100#10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0#100#10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str2.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray10 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny(charSequence4, charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "en", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "21.7", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0.0 0.1- 0.12 0.1", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "a#####4##" + "'", str12.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1a-1", "0.0 0.1- 0.12 0.1", "                                                                                                 14-");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "aaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("354104-14-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "354104-14-1" + "'", str1.equals("354104-14-1"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("OracleCorporationi!34.0100.00.010.052.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"OracleCorporationi!34.0100.00.010.052.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("racle.com/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("21.0A34.010A0A1A-1A-1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("                      Java", "0a100a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      Java" + "'", str2.equals("                      Java"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "mac os x", (java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "sophi4", (java.lang.CharSequence) "#4#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10Java(TM) SE Runtime Environment10", (java.lang.CharSequence) "al Machine Specification", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("0", "34.0 100.0 0.0 10.0 52.0", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "ihpos", (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("al Machine Specification", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "al Machine" + "'", str2.equals("al Machine"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4", (java.lang.CharSequence) "mac os x");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("14-1", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "14-1 " + "'", str2.equals("14-1 "));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [", "100#1ihpos_x7x8_88", 9, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [" + "'", str4.equals("100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class ["));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "100 1 10 -1 1 10EN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("a # # 4 #", 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a # # 4 #" + "'", str3.equals("a # # 4 #"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Sophie", "1040414-14-1", "#######################a#####4##");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Sophie" + "'", str3.equals("Sophie"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.awt.CGraphicsEnvironment", 18, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str3.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("OracleCorporationi!34.0100.00.010.052.0", "14-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCorporationi!34.0100.00.010.052.0" + "'", str2.equals("OracleCorporationi!34.0100.00.010.052.0"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "al Machine");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("racle.com", "sophie    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "racle.com" + "'", str2.equals("racle.com"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "sophi4", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sophi4" + "'", charSequence2.equals("sophi4"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 30, 0L, 31L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 31L + "'", long3 == 31L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "354104-14-1", (java.lang.CharSequence) "1#-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Virtual Machine Specification", (java.lang.CharSequence) "100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "                    -1.0 100.0", 41);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sophie    ", "100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [", 16);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    " + "'", str3.equals("sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    "));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) ' ', 12, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444aaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie    ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "-1.0100.0");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("al Machine", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("UTF-8", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("100 1 10 -1 1 10", (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "soph", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100.0 10.0 10.0 1.0", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("11", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1 -1" + "'", str7.equals("1 -1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "14-1" + "'", str9.equals("14-1"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sunEN.ENlwawtEN.ENmacosxEN.ENLWCTENoolkit", "1041004-14-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "##################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "                     0#100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#", (java.lang.CharSequence) "http://java.oracle.com/                                                                             ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("RACLE.COM/", "aaaaaaaa", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("aaaaaaaaaaaaaaaaaaaaaaaaaaa", "", "100#1ihpos");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("24.80-b11", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sU", "11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("4a#aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4a#aaa" + "'", str1.equals("4a#aaa"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "\n", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-1", "-11041004-14-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-1" + "'", str2.equals("2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-1"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-1", "21.7");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10J...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "100.0#10.0#10.0#1.0", (java.lang.CharSequence) " Environment10                     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                                                                                                                                                                                1.21.71.1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51227_1560278288" + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51227_1560278288"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("10", "Sophie", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        long[] longArray4 = new long[] { '#', (byte) 10, (short) -1, (-1L) };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 10, 2);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 0, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("4", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 4 + "'", short2 == (short) 4);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3, (double) 0, (double) 8);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob", "100#1#10#-1#1#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("100#1#10#-1#1#10", "AAAAAAAAAAAAAAAAAAAAAAAAAAA", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#1#10#-1#1#10" + "'", str3.equals("100#1#10#-1#1#10"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "21.7", "/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr", 26);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "100#1#10#-1#1#10");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("001a001a1-a001a1-a1", 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "NOITACIFICEPSIPAMROFTALPAVAJ", 9, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.61.11.41.1", "h1a-11a-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        char[] charArray5 = new char[] { '4', '#', 'a', '#' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray5);
        java.lang.Class<?> wildcardClass7 = charArray5.getClass();
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("100#1IHPOS");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "1a-1", 8, (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-1", "1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-" + "'", str2.equals("-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaa", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("##4#", "100414104-141410", (int) 'a', 142);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "##4#100414104-141410" + "'", str4.equals("##4#100414104-141410"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1040414-14-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1040414-14-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 143 + "'", int1 == 143);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("-1a2a2", "100a1ihpos", 41);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2" + "'", str3.equals("-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 28, (float) ' ', (float) 35);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 28.0f + "'", float3 == 28.0f);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Sophie", 143, 21);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("noitaroproC elcarO", "100 1 10 -1 1 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproC elcarO" + "'", str2.equals("noitaroproC elcarO"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S", (java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S" + "'", charSequence2.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("100 1 10 -1 1 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 1 10 -1 1 10" + "'", str1.equals("100 1 10 -1 1 10"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        double[] doubleArray4 = new double[] { 1, 21, (-1.0f), 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 21.0d + "'", double5 == 21.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.0d + "'", double6 == 21.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0 21.0 -1.0 0.0" + "'", str8.equals("1.0 21.0 -1.0 0.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.0#21.0#-1.0#0.0" + "'", str10.equals("1.0#21.0#-1.0#0.0"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 179 + "'", int1 == 179);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("SUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENT", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENT" + "'", str3.equals("SUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("OracleCorporationi!34.0100.00.010.052.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCorporationi!34.0100.00.010.052.0" + "'", str1.equals("OracleCorporationi!34.0100.00.010.052.0"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                100#1ihpos", (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("US", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("21.0A34.010A0A1A-1A-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"21.0A34.010A0A1A-1A-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        double[] doubleArray4 = new double[] { 1, 21, (-1.0f), 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 21.0d + "'", double5 == 21.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.0d + "'", double6 == 21.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0a21.0a-1.0a0.0" + "'", str8.equals("1.0a21.0a-1.0a0.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("racle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "racle.com/" + "'", str1.equals("racle.com/"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#", 26);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 12, (float) 5);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 12.0f + "'", float3 == 12.0f);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1041004-14-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1041004-14-1" + "'", str1.equals("1041004-14-1"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        short[] shortArray6 = new short[] { (short) 100, (short) 1, (byte) 10, (short) -1, (short) 1, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#1#10#-1#1#10" + "'", str10.equals("100#1#10#-1#1#10"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100414104-141410" + "'", str13.equals("100414104-141410"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '#');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "100#1IHPOS", 11, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/L brary/Java/JavaV rtualMac n /jdk1.7.0_80.jdk/C nt nt /H m /jr", "http://java.oracle.com/", 11);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10 0 1 -1 -1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10 0 1 -1 -1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "1.0", (java.lang.CharSequence) "0.001 0.1-");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1.0" + "'", charSequence2.equals("1.0"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("sophie    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("10#-1#100#0#-1#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#-1#100#0#-1#-1" + "'", str1.equals("10#-1#100#0#-1#-1"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "21.0#34.0", (java.lang.CharSequence) "a # # 4 #");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Sophie", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/L  # # 4 #br ry/J v /J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Sophie" + "'", str4.equals("Sophie"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.21.71.1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("14-1 ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "14-1 " + "'", str2.equals("14-1 "));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.CPrinterJob", 143);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                         sun.lwawt.macosx.CPrinterJob                                                          " + "'", str2.equals("                                                         sun.lwawt.macosx.CPrinterJob                                                          "));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "-", charSequence1, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "10J", (java.lang.CharSequence) "100.0a10.0a10.0a1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("100a1ihpos");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.7.0_80", "#", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa" + "'", charSequence2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(17, (int) (byte) 10, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) ".0 100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, '#', 21, 6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                    -1.0 100.0");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("####US####                                                                                          ", "Oracle Corporation");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "sophie    ");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("MAC OS X", strArray2, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 9 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("UTF-8", "", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a/Extensions:/usr/lib/java:." + "'", str2.equals("a/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10143L, (double) 21.0f, (double) 1.1f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.100000023841858d + "'", double3 == 1.100000023841858d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("0#100#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#100#10" + "'", str1.equals("0#100#10"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [" + "'", str1.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class ["));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("Sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "PLATFORM API SPECIFICATION", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "100.0#10.0#10.0#1.0", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 50 + "'", int1 == 50);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "h1a-11a-1", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("10 0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 0" + "'", str1.equals("10 0"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                     http://java.oracle.com/                                     ", 142, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "######################                                     http://java.oracle.com/                                     #######################" + "'", str3.equals("######################                                     http://java.oracle.com/                                     #######################"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-1", "sunEN.ENlwawtEN.ENmacosxEN.ENLWCTENoolkit", "SUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-1" + "'", str3.equals("-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-1"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("0#100#10");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "#4##", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        long[] longArray3 = new long[] { 10L, 31L, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10a31a1" + "'", str6.equals("10a31a1"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("100414104-141410");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '#', (int) (short) 4, 11);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Mac OS X", "0.001#0                     ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.1       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1      " + "'", str1.equals("1.1      "));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1.0 100.0", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "51.");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1.0 100.0" + "'", str4.equals("-1.0 100.0"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100#1#10#-1#1#10", (java.lang.CharSequence) "Java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sUN.LWAWT.MACOSX.cpRINTERjOB", "mixed mod", 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str3.equals("sUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', 1, 0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.0 10.0 10.0 1.0", "EN", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("100 1 10 -1 1 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 1 10 -1 1 10" + "'", str1.equals("100 1 10 -1 1 10"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10Java(TM) SE Runtime Environment10", "35a10a-1a-1", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "-", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1ihpos_x7x8_88#100", 5, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("44#4a4#", "a/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44#4a4#" + "'", str2.equals("44#4a4#"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("en");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie    ");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("a#####4##", strArray2, strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sophie", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "a#####4##" + "'", str6.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        java.lang.String str6 = javaVersion4.toString();
        boolean boolean7 = javaVersion0.atLeast(javaVersion4);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        java.lang.String str9 = javaVersion4.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.9" + "'", str6.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.9" + "'", str9.equals("0.9"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sophi", "Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophi" + "'", str2.equals("sophi"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("racle.com", (long) 12);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "sophie", 10);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "354104-14-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("RACLE.COM/", 0, ":");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RACLE.COM/" + "'", str3.equals("RACLE.COM/"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 35L, (float) ' ');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "100a1ihpos");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                                                                                    ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "-1.04100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 4, (long) 27, (long) 31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 31L + "'", long3 == 31L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        short[] shortArray6 = new short[] { (short) 100, (short) 1, (byte) 10, (short) -1, (short) 1, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100414104-141410" + "'", str11.equals("100414104-141410"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100414104-141410" + "'", str13.equals("100414104-141410"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("AAAAAAAAAAAAAAAAAAAAAAAAAAA", "1.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("14-1", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "14-1" + "'", str2.equals("14-1"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("##################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##################################" + "'", str1.equals("##################################"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) -1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        long[] longArray4 = new long[] { '#', (byte) 10, (short) -1, (-1L) };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "35#10#-1#-1" + "'", str8.equals("35#10#-1#-1"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("0#100#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "01#001#0" + "'", str1.equals("01#001#0"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Mixed mode", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "c os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("100a1ihpos", 50, "sophi4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph" + "'", str3.equals("100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "\n", (java.lang.CharSequence) "Oracle Corporationi!34.0 100.0 0.0 10.0 52.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("-1a2a2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a2a2" + "'", str1.equals("-1a2a2"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("-1.0100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0100.0" + "'", str1.equals("-1.0100.0"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("-1.0 100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0 100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) " Environment10                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("44444444444444444444444a#aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa#a44444444444444444444444" + "'", str1.equals("aa#a44444444444444444444444"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        double[] doubleArray2 = new double[] { 8L, (-1) };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "8.04-1.0" + "'", str7.equals("8.04-1.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("a # # 4 #aaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("####US####      ####US####      ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####US####      ####US####      " + "'", str2.equals("####US####      ####US####      "));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 30L, (float) 100L, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Oracle Corporation", (-1), 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 31, 0.0d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.0d + "'", double3 == 31.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("100a1ihpos", 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a1ihpos" + "'", str3.equals("100a1ihpos"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("10a0a1a-1a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10a0a1a-1a-1" + "'", str1.equals("10a0a1a-1a-1"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 179);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                   " + "'", str2.equals("                                                                                                                                                                                   "));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444aaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444aaaaaa" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444aaaaaa"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10 0 1 -1 -1", "##4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 0 1 -1 -1" + "'", str2.equals("10 0 1 -1 -1"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("ICEPSIPAMROFTALPAVAJ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ICEPSIPAMROFTALPAVAJ" + "'", str2.equals("ICEPSIPAMROFTALPAVAJ"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("#######################a#####4##", 32, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#######################a#####4##" + "'", str3.equals("#######################a#####4##"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100a1ihpos");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.1", "sophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("4a#aaa#", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#", "2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-", "-");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("JAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATION", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        double[] doubleArray4 = new double[] { 1, 21, (-1.0f), 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 21.0d + "'", double5 == 21.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.0d + "'", double6 == 21.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0a21.0a-1.0a0.0" + "'", str8.equals("1.0a21.0a-1.0a0.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.0#21.0#-1.0#0.0" + "'", str10.equals("1.0#21.0#-1.0#0.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 21.0d + "'", double12 == 21.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1http://java.oracle.com/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1http://java.oracle.com/" + "'", str2.equals("1http://java.oracle.com/"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1 -1" + "'", str1.equals("1 -1"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "al Machine", (java.lang.CharSequence) "             10.14.3              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4a#aaa", "1a-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "14-1", (int) (short) -1, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        double[] doubleArray4 = new double[] { 1, 21, (-1.0f), 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 142, 0);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 21.0d + "'", double5 == 21.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.0d + "'", double6 == 21.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 21.0d + "'", double7 == 21.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ', (int) 'a', (int) (byte) 0);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("4444444444", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.1       ", 0, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "21.0a34.010a0a1a-1a-1", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("100.0 10.0 10.0 1.0", "PLATFORM API SPECIFICATIO", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.010.010.01.0" + "'", str3.equals("100.010.010.01.0"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr", 32, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "                                                                                                 14-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("21.0a34.010a0a1a-1a-1", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr", (java.lang.CharSequence) "/L  # # 4 #br ry/J v /J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "0.001 0.1-", (java.lang.CharSequence) "354104-14-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) " aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4# ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("100a1ihpos");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a1ihpos" + "'", str1.equals("100a1ihpos"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0.9", 217, "0.001#0                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.90.001#0                     0.001#0                     0.001#0                     0.001#0                     0.001#0                     0.001#0                     0.001#0                     0.001#0           " + "'", str3.equals("0.90.001#0                     0.001#0                     0.001#0                     0.001#0                     0.001#0                     0.001#0                     0.001#0                     0.001#0           "));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun.awt.CGraphicsEnvironment", "ORACLE CORPORATION-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2", (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        char[] charArray8 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", charArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444aaaaaa", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a#####4##" + "'", str10.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "aa#a#a4a#" + "'", str14.equals("aa#a#a4a#"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "a # # 4 #" + "'", str16.equals("a # # 4 #"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("100.010.010.01.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.010.010.01.0" + "'", str1.equals("100.010.010.01.0"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "14-1 ", (java.lang.CharSequence) "21.0 34.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sophie    ", (java.lang.CharSequence) "####US####      ####US####      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0" + "'", str1.equals("0"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("####US####                                                                                          ", "Oracle Corporation");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "aa#a#a4a#");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a#####4##", (int) (byte) 1);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.split("-1.0 100.0", '4');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, ' ');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray12, strArray15);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10a0a1a-1a-1", strArray7, strArray12);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", strArray3, strArray12);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.stripAll(strArray12);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-1.0 100.0" + "'", str17.equals("-1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10a0a1a-1a-1" + "'", str19.equals("10a0a1a-1a-1"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie" + "'", str20.equals("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie"));
        org.junit.Assert.assertNotNull(strArray21);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        char[] charArray8 = new char[] { '4', '#', 'a', '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.0", charArray8);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', 35, 8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1a-1" + "'", str6.equals("1a-1"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment", 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', (int) ' ', 5);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "1.0 21.0");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "J1.0 21.0v1.0 21.0(TM) SE Runtime Environment" + "'", str4.equals("J1.0 21.0v1.0 21.0(TM) SE Runtime Environment"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "J#v#(TM) SE Runtime Environment" + "'", str6.equals("J#v#(TM) SE Runtime Environment"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/L  # # 4 #br ry/J v /J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr", "1041004-14-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/L  # # 4 #br ry/J v /J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr" + "'", str2.equals("/L  # # 4 #br ry/J v /J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a-1" + "'", str1.equals("1a-1"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-1", (java.lang.CharSequence) "                                                                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "##################################", (java.lang.CharSequence) "100a1a10a-1a1a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("4a#aaa", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4a#aaa                      " + "'", str2.equals("4a#aaa                      "));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "\n", "10Java(TM) SE Runtime Environment10");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "1.0 21.0");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("0a100a10", "");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray6, strArray9);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '#', 28, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 28");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("hi!", "http://java.oracle.com/", (int) (short) 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!http://java.oracle.com/hi!http://java.oracle.com/hi!http://java.oracle.com/hi!" + "'", str3.equals("hi!http://java.oracle.com/hi!http://java.oracle.com/hi!http://java.oracle.com/hi!"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                                                                 14-", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "0a100a10");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        short[] shortArray6 = new short[] { (short) 100, (short) 1, (byte) 10, (short) -1, (short) 1, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4', 0, 177);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "-1.04100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("noitaroproC elcarO", "", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("0", "EN");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "##4#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "21.0a34.010a0a1a-1a-1", (java.lang.CharSequence) "Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0.0f, 35.0d, 35.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("EN", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("100a1ihpos", " aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4# ", "aa#a#a4a#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a1ihpos" + "'", str3.equals("100a1ihpos"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a#####4##", (int) (byte) 1);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("-1.0 100.0", '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray5, strArray8);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "Java");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("a#####4##", strArray8, strArray15);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, ".0 100.0");
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0 100.0" + "'", str10.equals("-1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "a#####4##" + "'", str16.equals("a#####4##"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strArray19);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10Java(TM) SE Runtime Environment10                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("ORACLE CORPORATION-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("34.0 100.0 0.0 10.0 52.0", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "34.0 100.0 0.0 10.0 52.0" + "'", str2.equals("34.0 100.0 0.0 10.0 52.0"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a-1" + "'", str7.equals("1a-1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 1, (byte) 0, (byte) 10, (byte) 0 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "100 1 10 -1 1 10");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 100 1 10 -1 1 10");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "10a31a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("-", "a # # 4 #");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-" + "'", str2.equals("-"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("#######################A#####4#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#######################A#####4#" + "'", str1.equals("#######################A#####4#"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1#-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("SUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENT", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("sUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str1.equals("sUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sun.awt.CGraphicsEnvironment", 16, 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("-1.04100.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                    -1.0 100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "J#v#(TM) SE Runtime Environment", (java.lang.CharSequence) "-1a2a2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("0", "", 8, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("J#v#(TM) SE Runtime Environment", 3, "10Java(TM) SE Runtime Environment10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J#v#(TM) SE Runtime Environment" + "'", str3.equals("J#v#(TM) SE Runtime Environment"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "ORACLE CORPORATION", (java.lang.CharSequence) " Environment10                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION", (java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("2a2a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2a2a-1" + "'", str1.equals("2a2a-1"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("class [Ljava.lang.String;class [Ljava.lang.String;", 8, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str3.equals("class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("0.53#0.01#0.21#0.9#0.13", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.53#0.01#0.21#0.9#0.13" + "'", str2.equals("0.53#0.01#0.21#0.9#0.13"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("354104-14-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "354104-14-1" + "'", str1.equals("354104-14-1"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ", (java.lang.CharSequence) "0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104", 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("class [Ljava.lang.String;class [Ljava.lang.String;", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str2.equals("class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("##4#100414104-141410", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##4#100414104-141410" + "'", str2.equals("##4#100414104-141410"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(8L, (long) 'a', (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100a1a10a-1a1a10", (java.lang.CharSequence) "2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1ihpos_x7x8_88#100", "10a31a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1ihpos_x7x8_88#100" + "'", str2.equals("1ihpos_x7x8_88#100"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "44#4a4#", (java.lang.CharSequence) "1http://java.oracle.com/", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', 8, 4);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sunEN.ENlwawtEN.ENmacosxEN.ENLWCTENoolkit", 0, "0#100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sunEN.ENlwawtEN.ENmacosxEN.ENLWCTENoolkit" + "'", str3.equals("sunEN.ENlwawtEN.ENmacosxEN.ENLWCTENoolkit"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.0#21.0#-1.0#0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("001a001a1-a001a1-a1", (int) (short) 4, 118);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "001a1-a001a1-a1" + "'", str3.equals("001a1-a001a1-a1"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 1.1f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.1f + "'", float2 == 1.1f);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                    " + "'", str1.equals("                                                                                                    "));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("SU");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#", (java.lang.CharSequence) "                                                                                                                                                                                                                1.21.71.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                                                                                    ", "44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(".0 100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".0 100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sunEN.ENlwawtEN.ENmacosxEN.ENLWCTENoolkit", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sunEN.ENlwawtEN.ENmacosxEN.ENLWCTENoolkit" + "'", str2.equals("sunEN.ENlwawtEN.ENmacosxEN.ENLWCTENoolkit"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########################" + "'", str2.equals("##########################"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/                                                                             ", "1.4");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        long[] longArray4 = new long[] { '#', (byte) 10, (short) -1, (-1L) };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 8, (int) (byte) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35a10a-1a-1" + "'", str11.equals("35a10a-1a-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "354104-14-1" + "'", str13.equals("354104-14-1"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7", "0#100.0");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        char[] charArray7 = new char[] { '4', '#', 'a', '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporationi!", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "a#####4##", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("100.0 10.0 10.0 1.0", "-1a1a0a10a0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0 10.0 10.0 1.0" + "'", str2.equals("100.0 10.0 10.0 1.0"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("NOITACIFICEPSIPAMROFTALPAVAJ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOITACIFICEPSIPAMROFTALPAVAJ" + "'", str2.equals("NOITACIFICEPSIPAMROFTALPAVAJ"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("100a1a10a-1a1a10", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a1a10a-1a1a10" + "'", str2.equals("100a1a10a-1a1a10"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "SU", 30);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU" + "'", str3.equals("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("10", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("100.010.010.01.0", "aaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.010.010.01.0" + "'", str2.equals("100.010.010.01.0"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.0#21.0#-1.0#0.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#21.0#-1.0#0.0" + "'", str2.equals("1.0#21.0#-1.0#0.0"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("21.0a34.0", "hi!");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "mixedmode", 118, (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("-1.0#100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0#100.0" + "'", str1.equals("-1.0#100.0"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) '4', (float) 32L, (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("10 0 1 -1 -1", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51227_1560278288");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51227_1560278288" + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51227_1560278288"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("a4#4#444#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "             10.14.3              ", (java.lang.CharSequence) "MAC OS X", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100414104-141410", "h1a-11a-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4a#aaa#", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4a#aaa#" + "'", str3.equals("4a#aaa#"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "c os x", charSequence1, 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10", "aa#a#a4a#", "1.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sUN.LWAWT.MACOSX.cpRINTERjOB", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str2.equals("sUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa", "a # # 4 #aaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 108 + "'", int1 == 108);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 10, (short) 4);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 9L, (float) 26, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "ICEPSIPAMROFTALPAVAJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "0.001#0                     ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 0.001#0                     ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        long[] longArray4 = new long[] { '#', (byte) 10, (short) -1, (-1L) };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 8, (int) (byte) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 0, (int) (short) -1);
        long long16 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35a10a-1a-1" + "'", str11.equals("35a10a-1a-1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "21.0a34.0", (java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        char[] charArray9 = new char[] { '4', '#', 'a', '#' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1a2a2", charArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "44#4a4#" + "'", str15.equals("44#4a4#"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        double[] doubleArray5 = new double[] { 31, 9.0f, 12, (byte) 10, 35L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31.0#9.0#12.0#10.0#35.0" + "'", str7.equals("31.0#9.0#12.0#10.0#35.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31.0#9.0#12.0#10.0#35.0" + "'", str9.equals("31.0#9.0#12.0#10.0#35.0"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.1#.3", (java.lang.CharSequence) "21.0A34.010A0A1A-1A-1", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("001a1-a001a1-a1", "                                                                                                                                                                                                                aa#a#a4a#", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("sUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str1.equals("sUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-" + "'", str3.equals("-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 8L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "al Machine", (java.lang.CharSequence) "10143");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a # # 4 #aaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }
}

