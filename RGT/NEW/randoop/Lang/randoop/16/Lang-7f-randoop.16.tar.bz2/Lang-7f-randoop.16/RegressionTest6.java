import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test001");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test002");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("AAAAAA", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test003");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sophi", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test004");
        double[] doubleArray4 = new double[] { 1, 21, (-1.0f), 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 142, 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', 11, (int) (short) -1);
        double double16 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 21.0d + "'", double5 == 21.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.0d + "'", double6 == 21.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 21.0d + "'", double7 == 21.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("a4#4#444#", (int) (short) 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a4#4#444#" + "'", str3.equals("a4#4#444#"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test006");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("100.0a10.0a10.0a1.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test007");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100.0 10.0 10.0 1.0", 50, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("en", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test009");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test010");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", (java.lang.CharSequence) "100.0 10.0 10.0 1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test011");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "100a1a10a-1a1a10", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("         0a100a10          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a100a10" + "'", str1.equals("0a100a10"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test013");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test014");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("100414104-141410");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test015");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "oracle corporationi!", (java.lang.CharSequence) "4a#aaa                      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("http://java.oracle.com/                                                                             ", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "htt" + "'", str2.equals("htt"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test017");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "JAVAPLATFORMAPISPECIFICATION", (java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test018");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie    ");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 21 + "'", int5 == 21);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test019");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                                                                                 14-", "NOITACIFICEPSIPAMROFTALPAVAJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 14-" + "'", str2.equals("                                                                                                 14-"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test021");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray7 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.0 21.0 -1.0 0.0", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "a#####4##" + "'", str9.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "aa#a#a4a#" + "'", str12.equals("aa#a#a4a#"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test022");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(" aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4# ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4# " + "'", str1.equals(" aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4# "));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test023");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sophi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test024");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test025");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("####US####");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "#", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "####US####" + "'", str5.equals("####US####"));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test026");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Mac OS X");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test027");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("100.010.010.01.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#", "Oracle Corporationi!34.0 100.0 0.0 10.0 52.0", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test029");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test030");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "#######################A#####4#", "-1a2a2100a1ihpos-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("354104-14-1", "PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "354104-14-1" + "'", str2.equals("354104-14-1"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1040414-14-1", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "14-1" + "'", str2.equals("14-1"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test033");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("SUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test034");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("hi!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("100.0 10.0 10.0 1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0 10.0 10.0 1.0" + "'", str1.equals("100.0 10.0 10.0 1.0"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test036");
        double[] doubleArray4 = new double[] { 1, 21, (-1.0f), 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 217, 21);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 21.0d + "'", double5 == 21.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.0d + "'", double6 == 21.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test037");
        long[] longArray4 = new long[] { '#', (byte) 10, (short) -1, (-1L) };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 32, (int) (byte) 0);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 0, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "354104-14-1" + "'", str9.equals("354104-14-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test038");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("ihpos/Library/Java/JavaVirtualMachi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ihpos/Library/Java/JavaVirtualMachi" + "'", str1.equals("ihpos/Library/Java/JavaVirtualMachi"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("ihpos/Library/Java/JavaVirtualMachi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ihpos/Library/Java/JavaVirtualMachi" + "'", str1.equals("ihpos/Library/Java/JavaVirtualMachi"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test040");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test041");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("SUN.AWT.cgRAPHICSeNVIRONMENTSUN.");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test042");
        short[] shortArray1 = new short[] { (short) 0 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test043");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                   ", (java.lang.CharSequence) "14-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test044");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "14-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test045");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray8 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "a/Extensions:/usr/lib/java:.", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a#####4##" + "'", str10.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "a4#4#444#" + "'", str14.equals("a4#4#444#"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("!", "                      Jav", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!" + "'", str3.equals("!"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [" + "'", str1.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class ["));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2" + "'", str2.equals("a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test049");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test050");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "", (java.lang.CharSequence) "1a-1a100a-1a100a100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test051");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("444444444444fication444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("mixedmode", "10 0 1 -1 -1001a1-a001a1-a1001a1-a001a1-a1001a1-a001a1-a1001a1-a001a1-a1001a1-a001a1-a1001a1-a001a1-", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test053");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("10 0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test054");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 0.0f, (float) 32);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test055");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.7orm API Specification", (java.lang.CharSequence) "4###a##");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test056");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                      Java", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test057");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "", 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 12, "sophie    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test059");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "####US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US###44444444444444444444444a#aaa", (java.lang.CharSequence) "####US####                                                                                          ", 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("-14242");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-14242" + "'", str1.equals("-14242"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test061");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Oracle Corporationi!", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444442a2a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporationi!" + "'", str2.equals("Oracle Corporationi!"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test063");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7orm API Specification", (java.lang.CharSequence) "                100#1ihpos");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22 + "'", int2 == 22);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 118);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                      " + "'", str2.equals("                                                                                                                      "));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test065");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test066");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#4#4#444#", "#4#");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "100414104-141410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test068");
        short[] shortArray6 = new short[] { (short) 100, (short) 1, (byte) 10, (short) -1, (short) 1, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short20 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100414104-141410" + "'", str11.equals("100414104-141410"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100 1 10 -1 1 10" + "'", str13.equals("100 1 10 -1 1 10"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 100 + "'", short15 == (short) 100);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100#1#10#-1#1#10" + "'", str17.equals("100#1#10#-1#1#10"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100 1 10 -1 1 10" + "'", str19.equals("100 1 10 -1 1 10"));
        org.junit.Assert.assertTrue("'" + short20 + "' != '" + (short) 100 + "'", short20 == (short) 100);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test069");
        char[] charArray7 = new char[] { '4', '#', 'a', '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporationi!", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1a1a0a10a0", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test070");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "ORACLE CORPORATIONI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test071");
        char[] charArray8 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "##4#", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a#####4##" + "'", str10.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test072");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!http://java.oracle.com/hi!http://java.oracle.com/hi!http://java.oracle.com/hi!", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test073");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test074");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                    -1.0 100.0", "100#1#10#-1#1#10");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test076");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test077");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 0.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test078");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-14242", "8.04-1.0", 132);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test079");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("##################################", "14-1 ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("0.001 0.1-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.001 0.1-" + "'", str1.equals("0.001 0.1-"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("####US####", 28, "-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1a2a2100a1ihpos-1####US####" + "'", str3.equals("-1a2a2100a1ihpos-1####US####"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test082");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.0 0.1- 0.12 0.1", "", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0 0.1- 0.12 0.1" + "'", str3.equals("0.0 0.1- 0.12 0.1"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test084");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("2a2a-1", "a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2", 50);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test085");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Oracle Corporationi!", (java.lang.CharSequence) "ihpos/Library/Java/JavaVirtualMachi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test086");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("4a#aaa                      ", "racle.com/", "mixed mode");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test087");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0#100.0", (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test088");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "en", (java.lang.CharSequence) "-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test089");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.21.71.1", (java.lang.CharSequence) "                                     http://java.oracle.com/                                     ", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test090");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "sophie", 10);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("", "sophie", 10);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray6, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray11);
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray11);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test092");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("mixed mod", "100a1a10a-1a1a10", "10Java(TM) SE Runtime Environment10                                                                 ", 22);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mixed mod" + "'", str4.equals("mixed mod"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test093");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0 100 10", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 100 10" + "'", str3.equals("0 100 10"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test094");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1#-1#100#-1#100#100", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1#-1#100#-1#100#100" + "'", str3.equals("1#-1#100#-1#100#100"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test096");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', 12, 0);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', 28, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 28");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test097");
        short[] shortArray6 = new short[] { (short) 100, (short) 1, (byte) 10, (short) -1, (short) 1, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100414104-141410" + "'", str10.equals("100414104-141410"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test099");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("soph");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test100");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1a2a2100a1ihpos-", "100#1#10#-1#1#10");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test101");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("21.0A34.010A0A1A-1A-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.6", "                     0#100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test103");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " 100.0 0.0 10.0 52.0", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test104");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "hi!http://java.oracle.com/hi!http://java.oracle.com/hi!http://java.oracle.com/hi!", 3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test105");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test106");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("####US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US###44444444444444444444444a#aaa", "                                                                                                    ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("NOITACIFICEPSIPAMROFTALPAVAJ", 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test108");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-", 11, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-" + "'", str3.equals("-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test109");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "100#1ihpos");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test110");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0a100a10", "");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0a100a10" + "'", str4.equals("0a100a10"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test111");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1.0100.0", (java.lang.CharSequence) "aaaaaa21.7aaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test112");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(" aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", (int) (byte) -1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals(" aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test113");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Sophiesophi4sophi4sophi4sophi4sophi");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test114");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "100.0#10.0#10.0#1.0");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "-1a2a2");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-1", 22, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 22");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test115");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test116");
        char[] charArray7 = new char[] { '4', '#', 'a', '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Virtual Machine Specification", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mac os x", charArray7);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4a#aaa#" + "'", str11.equals("4a#aaa#"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4a#aaa#" + "'", str14.equals("4a#aaa#"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test117");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.0#21.0#-1.0#0.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test118");
        float[] floatArray5 = new float[] { 34.0f, (byte) 100, 0, 10, '4' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "34.0 100.0 0.0 10.0 52.0" + "'", str7.equals("34.0 100.0 0.0 10.0 52.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34.0a100.0a0.0a10.0a52.0" + "'", str11.equals("34.0a100.0a0.0a10.0a52.0"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test119");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.4", (java.lang.CharSequence) "1#-1#100#-1#100#100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test120");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test121");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("354104-14-1", 179, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test122");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4a#aaa", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test123");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "#################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test124");
        char[] charArray11 = new char[] { '4', '#', 'a', '#' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.0", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "a # # 4 #", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test125");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test126");
        float[] floatArray2 = new float[] { (-1.0f), (byte) 100 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', (int) 'a', 21);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4', (int) (byte) 10, 5);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1.0 100.0" + "'", str4.equals("-1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("                                   ", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test128");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test129");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test130");
        double[] doubleArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("mixedmode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mixedmode" + "'", str1.equals("Mixedmode"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test132");
        float[] floatArray2 = new float[] { (-1.0f), (byte) 100 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', (int) 'a', 21);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1.0 100.0" + "'", str4.equals("-1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0a100.0" + "'", str10.equals("-1.0a100.0"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOB", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str2.equals("sUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test135");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "4a#aaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test136");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test137");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray8 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "en", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', 217, 118);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a#####4##" + "'", str10.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "a # # 4 #" + "'", str19.equals("a # # 4 #"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test138");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaa...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test139");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("va.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("35#10#-1#-1", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35#10#-1#-1" + "'", str2.equals("35#10#-1#-1"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test141");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.61.11.41.1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test142");
        short[] shortArray1 = new short[] { (short) 0 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 30, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 30");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr" + "'", str1.equals("/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("2a2a-1", "RACLE.COM/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2a2a-1" + "'", str2.equals("2a2a-1"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test145");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sunEN.ENlwawtEN.ENmacosxEN.ENLWCTENoolkit", "class [Ljava.lang.String;class [Ljava.lang.String;", 3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + " u EN.ENlwawtEN.ENmacosxEN.ENLWCTENoolkit" + "'", str5.equals(" u EN.ENlwawtEN.ENmacosxEN.ENLWCTENoolkit"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test146");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', 12, 3);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1 -1" + "'", str5.equals("1 -1"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1#-1" + "'", str7.equals("1#-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test147");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java HotSpot(TM) 64-Bit Server VM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test148");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1#-1#100#-1#100#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test149");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10 0", 66, "0a100a10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a100a100a100a100a100a100a100a100a100a100a100a100a100a100a100a10 0" + "'", str3.equals("0a100a100a100a100a100a100a100a100a100a100a100a100a100a100a100a10 0"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1a-1a100a-1a100a100", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a-1a100a-1a100a100" + "'", str2.equals("1a-1a100a-1a100a100"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test151");
        short[] shortArray4 = new short[] { (byte) 10, (short) 100, (short) -1, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1041004-14-1" + "'", str8.equals("1041004-14-1"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test152");
        short[] shortArray6 = new short[] { (short) 100, (short) 1, (byte) 10, (short) -1, (short) 1, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.Class<?> wildcardClass8 = shortArray6.getClass();
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100414104-141410" + "'", str11.equals("100414104-141410"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test153");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(42.0d, (double) 12.0f, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 42.0d + "'", double3 == 42.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test154");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 9L, (double) 28.0f, (double) 5);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.0d + "'", double3 == 28.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test155");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("a4#4#444#", "10J", 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#" + "'", str3.equals("a4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test156");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test158");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.61.11.41.1", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("al Machine", "-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test160");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "sophie", 10);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) 'a', 21);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "sU");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("sU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sU" + "'", str1.equals("sU"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaa", "/L brary/Java/JavaV rtualMac n /jdk1.7.0_80.jdk/C nt nt /H m /jr");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("44444444444444444444444a#aaa", "PLATFORM API SPECIFICATIO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444a#aaa" + "'", str2.equals("44444444444444444444444a#aaa"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test164");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100a1a10a-1a1a1", "         0a100a10          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test165");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "J#v#(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Environment10                     ", (-1), (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Environment10                     " + "'", str3.equals("Environment10                     "));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Java(TM) SE Runtime Environment", " Environment10                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Ru" + "'", str2.equals("Java(TM) SE Ru"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test168");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java(TM) SE Runtime Environment", "ICEPSIPAMROFTALPAVAJ", "4");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test169");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("noitaroproc elcaroVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [dVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAV");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproc elcaroVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [dVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAV" + "'", str1.equals("noitaroproc elcaroVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [dVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAV"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test170");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test171");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(":", "100.0#10.0#10.0#1.0100.0#10.0SU");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":" + "'", str4.equals(":"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test172");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("ments/defects4j/tmp/run_randoop.pl_51227_1560278288");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test173");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "\n", "10Java(TM) SE Runtime Environment10");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "1.0 21.0");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "aaaaaa");
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test174");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "0.53#0.01#0.21#0.9#0.13", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("SU", "a # # 4 #");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SU" + "'", str2.equals("SU"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test176");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 17, 1.1f, (float) 97);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test177");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-1a1a0a10a0", (int) (byte) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a1a0a10a0" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a1a0a10a0"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test178");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                                                                                                                   ", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                   " + "'", str3.equals("                                                                                                                                                                                   "));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test179");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sophiSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONME", (java.lang.CharSequence) "Java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test180");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.0", "aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test181");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "va.lang.string;class [ljava.lang.string;class [ljava.lang.string;class [d", (java.lang.CharSequence) "#####10a31a1######");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test182");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaa", (java.lang.CharSequence) "0#100#10", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test183");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("a # # 4 #aaaaaaaaaaaaaaaaaaaaaaaaaa", (float) 108);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 108.0f + "'", float2 == 108.0f);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test184");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "0.001#0                     ", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test185");
        char[] charArray9 = new char[] { '4', '#', 'a', '#' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1a2a2", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#######################a#####4#", charArray9);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, '#', 50, 21);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test186");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "h0a100a10", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test187");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test188");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) -1, (long) 9, 27L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 27L + "'", long3 == 27L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test189");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("-1.0#100.0", "04100410", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0#100.0" + "'", str3.equals("-1.0#100.0"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test191");
        java.lang.CharSequence charSequence6 = null;
        char[] charArray12 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray12, '#');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny(charSequence6, charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "en", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "a#####4##", charArray12);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray12, 'a');
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Platform API Specification", charArray12);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaa", charArray12);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "44444444444444444444444a#aaa", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "a#####4##" + "'", str14.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "aa#a#a4a#" + "'", str20.equals("aa#a#a4a#"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                   ", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                   " + "'", str3.equals("                                   "));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test193");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1http://java.oracle.com/", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test194");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("##4#100414104-141410", "51.0", "ICEPSIPAMROFTALPAVAJ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##4#100414104-141410" + "'", str3.equals("##4#100414104-141410"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test195");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("SU");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test196");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test197");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("24.80-b11", ":", "-1a2a2100a1ihpos-");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test198");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.0a21.0a-1.0a0.0", (java.lang.CharSequence) "J1.0 21.0v1.0 21.0(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test199");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("21.0A34.010A0A1A-1A-1", "-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-", 97);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "21.0A34.010A0A1A-1A-1" + "'", str4.equals("21.0A34.010A0A1A-1A-1"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test200");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("oracle corporationi!", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("100.010.010.01.0", "a/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.010.010.01.0" + "'", str2.equals("100.010.010.01.0"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test202");
        double[] doubleArray4 = new double[] { 1, 21, (-1.0f), 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 142, 0);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 21.0d + "'", double5 == 21.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.0d + "'", double6 == 21.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 21.0d + "'", double7 == 21.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 21.0d + "'", double12 == 21.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 21.0d + "'", double13 == 21.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test203");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("racle.com/", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test204");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("21.0#34.0", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test205");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("44444444444444444444444a#aa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1040414-14-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1040414-14-1" + "'", str1.equals("1040414-14-1"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test207");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("444444444444fication444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444444444444fication444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/L  # # 4 #br ry/J v /J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/L  # # 4 #br ry/J v /J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr" + "'", str1.equals("/L  # # 4 #br ry/J v /J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test209");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 100 10" + "'", str9.equals("0 100 10"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0 100 10" + "'", str11.equals("0 100 10"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0 100 10" + "'", str13.equals("0 100 10"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test210");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "100.0a10.0a10.0a1.0", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("                                     http://java.oracle.com/                                     ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a1a0a10a0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                     http://java.oracle.com/                                     " + "'", str2.equals("                                     http://java.oracle.com/                                     "));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aa#a#a4a#", "04100410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa#a#a4a#" + "'", str2.equals("aa#a#a4a#"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test213");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str4 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.3" + "'", str4.equals("1.3"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test214");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("soph");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hpos" + "'", str1.equals("hpos"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test215");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test216");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "aaaaaa21.7aaaaaa", 34, 34);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaa21.7aaaaaa" + "'", str4.equals("aaaaaa21.7aaaaaa"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test217");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie", charSequence1, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test218");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ", 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test219");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".0 100.0", "SU", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test220");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "001a001a1-a001a1-a1", (java.lang.CharSequence) "34.0a6.0a3.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1http://java.oracle.com/", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1http://java.oracle.com/" + "'", str2.equals("1http://java.oracle.com/"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("100#1#10#-1#1#10", "0.001#0                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test223");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, '#', (int) (byte) 100, (int) (byte) -1);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1 -1" + "'", str5.equals("1 -1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test224");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("ments/defects4j/tmp/run_randoop.pl_51227_1560278288");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ments/defects4j/tmp/run_randoop.pl_51227_1560278288\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test225");
        float[] floatArray3 = new float[] { 34, 6, 3 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', 3, 142);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 34.0f + "'", float4 == 34.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#-1" + "'", str1.equals("1#-1"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Mixed mode", 11, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " Mixed mode" + "'", str3.equals(" Mixed mode"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr", "                                                                                                                                                                                                                1.21.71.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr" + "'", str2.equals("/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test230");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4444444444", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.0a21.0a-1.0a0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0a21.0a-1.0a0.0" + "'", str1.equals("1.0a21.0a-1.0a0.0"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test232");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
        java.lang.String str7 = javaVersion4.toString();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        java.lang.String str10 = javaVersion8.toString();
        boolean boolean11 = javaVersion4.atLeast(javaVersion8);
        boolean boolean12 = javaVersion2.atLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.9" + "'", str10.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test233");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 4);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 4 + "'", short2 == (short) 4);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test234");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.61.11.41.1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test235");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test236");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4", "", "100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph#100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph#100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph4100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph" + "'", str3.equals("100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph#100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph#100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph4100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie" + "'", str2.equals("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.21.71.1", " Environment10                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.21.71.1" + "'", str2.equals("1.21.71.1"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test239");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test240");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("21.7", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("ihpos", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ihpos" + "'", str2.equals("ihpos"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test242");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '#', (-1), 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test243");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("a4#4#444#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a4#4#444#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test244");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "10a31a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "0a100a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test246");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaa", "10J...", "                     0#100.0", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaa" + "'", str4.equals("aaaaaaaaaa"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test247");
        double[] doubleArray2 = new double[] { 8L, (-1) };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "8.04-1.0" + "'", str7.equals("8.04-1.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "8.04-1.0" + "'", str9.equals("8.04-1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 8.0d + "'", double10 == 8.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test248");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("100.0#10.0#10.0#1.0", "####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0#10.0#10.0#1.0" + "'", str2.equals("100.0#10.0#10.0#1.0"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("35a10a-1a-1", "                      Jav", "2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-1");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("0 100 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 100 10" + "'", str1.equals("0 100 10"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("44#4a4#", "34.0 100.0 0.0 10.0 52.0sun");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#4a4#" + "'", str2.equals("#4a4#"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2", "aaaaaa21.7aaaaaa", "-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0" + "'", str3.equals("-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test254");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "2a2a-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-", "/", "0.001 0.1-");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test256");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("##4#", (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test257");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 30, 6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 27, 21);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test258");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "10 0 1 -1 -1", 0, 34);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10 0 1 -1 -1" + "'", str4.equals("10 0 1 -1 -1"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 11, 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test260");
        short[] shortArray6 = new short[] { (short) 100, (short) 1, (byte) 10, (short) -1, (short) 1, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4', 12, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#1#10#-1#1#10" + "'", str10.equals("100#1#10#-1#1#10"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test261");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Hi!", (java.lang.CharSequence) "4###a##");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test262");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "0 100 10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test263");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "44444444444444444444444a#aaa", (java.lang.CharSequence) "mixed mod");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("http://java.oracle.com/                                                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test265");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 0, "mac os x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test266");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) ' ', 0L, (long) 18);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test268");
        float[] floatArray2 = new float[] { (-1.0f), (byte) 100 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1.0 100.0" + "'", str4.equals("-1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1.0#100.0" + "'", str6.equals("-1.0#100.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test269");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test270");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("a/Extensions:/usr/lib/java:.", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a/Extensions:/usr/lib/java:." + "'", str3.equals("a/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test271");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a-1" + "'", str7.equals("1a-1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test272");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "11#1#111#1#1#1", (java.lang.CharSequence) ".0 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("100#1ihpos_x7x8_88", "-1.04100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#1ihpos_x7x8_88" + "'", str2.equals("100#1ihpos_x7x8_88"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test274");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("-1.0100.0", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51227_1560278288", "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test275");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "100a1ihpos", 34);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("100.0#10.0#10.0#1.0", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0" + "'", str2.equals("100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S", "14-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S" + "'", str2.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test278");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "10 0 1 -1 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test279");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test280");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "####US####                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("##################################", "ICEPSIPAMROFTALPAVAJ", 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##################################" + "'", str3.equals("##################################"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOB", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str2.equals("sUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test283");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#4a4#", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("####US####                                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####US####                                                                                         " + "'", str1.equals("####US####                                                                                         "));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test285");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, '#', 21, 6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test286");
        long[] longArray3 = new long[] { 10L, 31L, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10 31 1" + "'", str7.equals("10 31 1"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test287");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "14-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test288");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test289");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#####10a31a1######", (java.lang.CharSequence) "0a100a100a100a100a100a100a100a100a100a100a100a100a100a100a100a10 0", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("     ihpos", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test291");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0.001 0.1-", (int) (short) 4, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test292");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaa", "sophi");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test293");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "1.1");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test294");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("sophiSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONME");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophiSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONME\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test295");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 0, 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test296");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE CORPORATION" + "'", str1.equals("oRACLE CORPORATION"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test298");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("h0a100a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1.1      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1      " + "'", str1.equals("1.1      "));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test300");
        short[] shortArray6 = new short[] { (short) 100, (short) 1, (byte) 10, (short) -1, (short) 1, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short18 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short19 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100414104-141410" + "'", str11.equals("100414104-141410"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100 1 10 -1 1 10" + "'", str13.equals("100 1 10 -1 1 10"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 100 + "'", short15 == (short) 100);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100414104-141410" + "'", str17.equals("100414104-141410"));
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) -1 + "'", short18 == (short) -1);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) -1 + "'", short19 == (short) -1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test301");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str5 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.1" + "'", str5.equals("1.1"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test302");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("va.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D", "-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "va.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D" + "'", str2.equals("va.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java(TM) SE Runtime Environment", 28, "1http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test305");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2", (int) (short) 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test306");
        java.lang.reflect.Type[] typeArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(typeArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test307");
        double[] doubleArray4 = new double[] { 1, 21, (-1.0f), 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 21.0d + "'", double5 == 21.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.0d + "'", double6 == 21.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 21.0d + "'", double7 == 21.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0 21.0 -1.0 0.0" + "'", str9.equals("1.0 21.0 -1.0 0.0"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test308");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.1      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test309");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1 -1" + "'", str5.equals("1 -1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a-1" + "'", str9.equals("1a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1a-1" + "'", str11.equals("1a-1"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("-1.04100.0", "sophie    ", "                                                                                                                                                                                                                aa#a#a4a#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.04100.0" + "'", str3.equals("-1.04100.0"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("10.1#.3", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test314");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test315");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("fication");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                      Jav", "sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      Jav" + "'", str2.equals("                      Jav"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test317");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test318");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("a/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test319");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test320");
        long[] longArray4 = new long[] { '#', (byte) 10, (short) -1, (-1L) };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 32, (int) (byte) 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 11, 6);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "354104-14-1" + "'", str9.equals("354104-14-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test321");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                     0#100.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("AAAAAAAAAAAAAAAAAAAAAAAAAAA", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test323");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("####US####                                                                                          ", "Oracle Corporation");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "aa#a#a4a#");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a#####4##", (int) (byte) 1);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.split("-1.0 100.0", '4');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray16, ' ');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray13, strArray16);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10a0a1a-1a-1", strArray8, strArray13);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", strArray4, strArray13);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "1.21.71.1");
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Sophiesophi4sophi4sophi4sophi4sophi", strArray13, strArray24);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-1.0 100.0" + "'", str18.equals("-1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10a0a1a-1a-1" + "'", str20.equals("10a0a1a-1a-1"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie" + "'", str21.equals("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie"));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Sophiesophi4sophi4sophi4sophi4sophi" + "'", str25.equals("Sophiesophi4sophi4sophi4sophi4sophi"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 132);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                    " + "'", str2.equals("                                                                                                                                    "));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test325");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                 14-", "-1.04100.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test326");
        float[] floatArray5 = new float[] { 34.0f, (byte) 100, 0, 10, '4' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ', 21, 132);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 21");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "34.0 100.0 0.0 10.0 52.0" + "'", str7.equals("34.0 100.0 0.0 10.0 52.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test327");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.1      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test328");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4444444444", "35#10#-1#-1", " aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4# ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444" + "'", str3.equals("4444444444"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test329");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "-b15", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test330");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "14-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test331");
        double[] doubleArray5 = new double[] { 31, 9.0f, 12, (byte) 10, 35L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31.0#9.0#12.0#10.0#35.0" + "'", str7.equals("31.0#9.0#12.0#10.0#35.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.0d + "'", double9 == 9.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("             10.14.3              ", 66, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                             10.14.3              " + "'", str3.equals("                                             10.14.3              "));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test334");
        char[] charArray11 = new char[] { '4', '#', 'a', '#' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1a2a2", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#######################a#####4#", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "####US####                                                                                          ", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ments/defects4j/tmp/run_randoop.pl_51227_1560278288", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 13 + "'", int18 == 13);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test335");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64", "1http://java.oracle.com/", 132);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("100#1IHPOS", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#1IHPOS" + "'", str3.equals("100#1IHPOS"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test337");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("al Machine", "0.9", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("0", "1.7.0_80-b15", 108);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b150" + "'", str3.equals("01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b150"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test339");
        long[] longArray4 = new long[] { '#', (byte) 10, (short) -1, (-1L) };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 9, (int) (short) 1);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("ihpos/Library/Java/JavaVirtualMachi", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i" + "'", str2.equals("i"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test341");
        long[] longArray4 = new long[] { '#', (byte) 10, (short) -1, (-1L) };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 8, (int) (byte) 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 32, (int) (byte) 0);
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 100, (int) (short) -1);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test342");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                                      ", 177);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test343");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1041004-14-1", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test344");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4", "-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test345");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("44#4a4#", (-1), "10#-1#100#0#-1#-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44#4a4#" + "'", str3.equals("44#4a4#"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test346");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("_X7X8_88_X7X8_88_X7X8_88_X7X-14242");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test347");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "####US####                                                                                          ", (java.lang.CharSequence) "21.0a34.010a0a1a-1a-1", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test348");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ".0 ", "1#-1#100#-1#100#100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test349");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(97L, (long) (short) 100, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("PLATFORM API SPECIFICATION", "0a100a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PLATFORM API SPECIFICATION" + "'", str2.equals("PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.7.0_80", "11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaa"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test353");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr", "0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104", 17, (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr" + "'", str4.equals("0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test354");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test355");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                                                                                                                                                1.21.71.1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test356");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(97, 118, 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 118 + "'", int3 == 118);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test358");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "0 100 10", 0);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "!");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "SU", (java.lang.CharSequence[]) strArray6);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "al Machine Specification", 1, (int) (short) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "sUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(" Mixed mode", 179);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Mixed mode" + "'", str2.equals(" Mixed mode"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test361");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#", (java.lang.CharSequence) "100 1 10 -1 1 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test362");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("10#-1#100#0#-1#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#-1#100#0#-1#-1" + "'", str1.equals("10#-1#100#0#-1#-1"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test363");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("####US####                                                                                          ", 66, "                                     http://java.oracle.com/                                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####US####                                                                                          " + "'", str3.equals("####US####                                                                                          "));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test365");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                                                                    ", (long) 143);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 143L + "'", long2 == 143L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test366");
        char[] charArray5 = new char[] { '#', 'a', 'a', ' ' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10J", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                                                                                      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("##4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#" + "'", str1.equals("##4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("21.0A34.010A0A1A-1A-1", "10 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 0" + "'", str2.equals("10 0"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("mimi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mimi" + "'", str1.equals("mimi"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test371");
        char[] charArray8 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray8);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ', (int) (short) 100, 9);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "h0a100a10", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a#####4##" + "'", str10.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("##################################", ".0 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##################################" + "'", str2.equals("##################################"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test373");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "ICEPSIPAMROFTALPAVAJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(" 100.0 0.0 10.0 52.0", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 100.0 0.0 10.0 52.0" + "'", str3.equals(" 100.0 0.0 10.0 52.0"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test375");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(21L, 12L, (long) 13);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test376");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("14-1 ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test377");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1.0 21.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test378");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0, (double) 66, (double) 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test379");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "01#001#0", 179, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("10.1#.3", "Java Platform API Specification", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51227_1560278288");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.1#.3" + "'", str3.equals("10.1#.3"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test381");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "ihpos", (java.lang.CharSequence) "34.0 100.0 0.0 10.0 52.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test382");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1 -1" + "'", str5.equals("1 -1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1a-1" + "'", str8.equals("1a-1"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test383");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.0", (java.lang.CharSequence) "mixedmode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("44444444444444444444444a#aa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444a#aa" + "'", str2.equals("44444444444444444444444a#aa"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test385");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", "10 31 1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test386");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "##4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test387");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "a001");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test388");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("JAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"JAVA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sun.lwawt.macosx.LWCToolkit", 217, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test390");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#######################A#####4#", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("10Java(TM) SE Runtime Environment10", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10Java(TM) SE Runtime Environment10" + "'", str2.equals("10Java(TM) SE Runtime Environment10"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test392");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!http://java.oracle.com/hi!http://java.oracle.com/hi!http://java.oracle.com/hi!", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test393");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "0a100a100a100a100a100a100a100a100a100a100a100a100a100a100a100a10 0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test394");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1", (java.lang.CharSequence) "35a10a-1a-11.1       1.1       1.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test395");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 26, 11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1041004-14-1", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1041004-14-1" + "'", str2.equals("1041004-14-1"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("100 1 10 -1 1 10", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 1 10 -1 1 10" + "'", str2.equals("100 1 10 -1 1 10"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test398");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test399");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "10.1#.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test400");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("mixedmode", 179);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 179 + "'", int2 == 179);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("J", (-1), "4a#aaa                      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J" + "'", str3.equals("J"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a1a0a10a0", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaa" + "'", str2.equals("aaaaaaaa"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10J", "VA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [d", "\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test404");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                                                      ", 16, 271);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test405");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Mac OS Xawt.CGraphicsEnvironment", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test406");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", 8, 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Oracle Corporationi!34.0 100.0 0.0 10.0 52.0", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Orcle Corportioni!34.0 100.0 0.0 10.0 52.0" + "'", str2.equals("Orcle Corportioni!34.0 100.0 0.0 10.0 52.0"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test408");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("mac os x", "", "100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph#100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph#100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph4100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph");
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                    " + "'", str1.equals("                                                                                                                                    "));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test410");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("-1.0#100.0", "             10.14.3              ", 27);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr#" + "'", str5.equals("-0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr#"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test411");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("####US####", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test412");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 10143L, (float) 143L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10143.0f + "'", float3 == 10143.0f);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test413");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "####US####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test414");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("35a10a-1a-11.1       1.1       1.1", 118);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 118 + "'", int2 == 118);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.0 21.0 -1.0 0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 21.0 -1.0 0.0" + "'", str1.equals("1.0 21.0 -1.0 0.0"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast(" aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "sophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test418");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test419");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0.90.001#0                     0.001#0                     0.001#0                     0.001#0                     0.001#0                     0.001#0                     0.001#0                     0.001#0           ", (java.lang.CharSequence) "35#10#-1#-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test421");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "35a10a-1a-1", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a1a0a10a0", "oracle corporationi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("noitaroproc elcaro", "a4#4#444#");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test424");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "0#100.0                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test425");
        double[] doubleArray4 = new double[] { 1, 21, (-1.0f), 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 118, (int) '4');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 21.0d + "'", double5 == 21.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.0d + "'", double6 == 21.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0a21.0a-1.0a0.0" + "'", str8.equals("1.0a21.0a-1.0a0.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 21.0d + "'", double9 == 21.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test426");
        char[] charArray8 = new char[] { '4', '#', 'a', '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1a2a2", charArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        java.lang.Class<?> wildcardClass15 = charArray8.getClass();
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "44#4a4#" + "'", str14.equals("44#4a4#"));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test427");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test428");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test429");
        double[] doubleArray4 = new double[] { 1, 21, (-1.0f), 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 142, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 21.0d + "'", double5 == 21.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.0d + "'", double6 == 21.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 21.0d + "'", double7 == 21.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.0 21.0 -1.0 0.0" + "'", str13.equals("1.0 21.0 -1.0 0.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 21.0d + "'", double14 == 21.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test430");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("RACLE.COM/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RACLE.COM/" + "'", str1.equals("RACLE.COM/"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test431");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test432");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test433");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) ".0 100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test434");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "al Machine Specification");
        java.lang.Class<?> wildcardClass6 = strArray3.getClass();
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a#####4##", (int) (byte) 1);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("-1.0 100.0", '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, ' ');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray11, strArray14);
        java.lang.Class<?> wildcardClass18 = strArray14.getClass();
        java.lang.String[] strArray22 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie    ");
        int int23 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray22);
        java.lang.Class<?> wildcardClass24 = strArray22.getClass();
        java.lang.String[] strArray29 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a#####4##", (int) (byte) 1);
        java.lang.String[] strArray32 = org.apache.commons.lang3.StringUtils.split("-1.0 100.0", '4');
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray32, ' ');
        java.lang.String str35 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray29, strArray32);
        java.lang.Class<?> wildcardClass36 = strArray32.getClass();
        short[] shortArray43 = new short[] { (short) 100, (short) 1, (byte) 10, (short) -1, (short) 1, (short) 10 };
        short short44 = org.apache.commons.lang3.math.NumberUtils.max(shortArray43);
        java.lang.Class<?> wildcardClass45 = shortArray43.getClass();
        java.lang.Class[] classArray47 = new java.lang.Class[5];
        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray48 = (java.lang.Class<?>[]) classArray47;
        wildcardClassArray48[0] = wildcardClass6;
        wildcardClassArray48[1] = wildcardClass18;
        wildcardClassArray48[2] = wildcardClass24;
        wildcardClassArray48[3] = wildcardClass36;
        wildcardClassArray48[4] = wildcardClass45;
        java.lang.String str59 = org.apache.commons.lang3.StringUtils.join(wildcardClassArray48);
        java.lang.String str60 = org.apache.commons.lang3.StringUtils.join((java.lang.reflect.GenericDeclaration[]) wildcardClassArray48);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1.0 100.0" + "'", str16.equals("-1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 21 + "'", int23 == 21);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "-1.0 100.0" + "'", str34.equals("-1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(shortArray43);
        org.junit.Assert.assertTrue("'" + short44 + "' != '" + (short) 100 + "'", short44 == (short) 100);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(classArray47);
        org.junit.Assert.assertNotNull(wildcardClassArray48);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S" + "'", str59.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S" + "'", str60.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaa...", 31, "i");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "iiiiiiiiiiaaaaaaa...iiiiiiiiiii" + "'", str3.equals("iiiiiiiiiiaaaaaaa...iiiiiiiiiii"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test436");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "001a001a1-a001a1-a1", (java.lang.CharSequence) ".0 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test437");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("8.04-1.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44#4a4..." + "'", str2.equals("44#4a4..."));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("c os x", "0#100#10");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test440");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "_X7X8_88_X7X8_88_X7X8_88_X7X-14242", "##4#100414104-141410");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test441");
        short[] shortArray6 = new short[] { (short) 100, (short) 1, (byte) 10, (short) -1, (short) 1, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#1#10#-1#1#10" + "'", str10.equals("100#1#10#-1#1#10"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test442");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test443");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "0 100 10", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "va.lang.string;class [ljava.lang.string;class [ljava.lang.string;class [d");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str5.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test444");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 4, (short) (byte) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2", "100a1a10a-1a1a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2" + "'", str2.equals("-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "/L  # # 4 #br ry/J v /J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", " aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test448");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "100.0a10.0a10.0a1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test449");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray11 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray11, '#');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny(charSequence5, charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "en", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ICEPSIPAMROFTALPAVAJ", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-b15", charArray11);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_80", charArray11);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray11, '#');
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "a#####4##" + "'", str13.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "a#####4##" + "'", str21.equals("a#####4##"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test450");
        short[] shortArray6 = new short[] { (short) 100, (short) 1, (byte) 10, (short) -1, (short) 1, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100414104-141410" + "'", str11.equals("100414104-141410"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str1.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test452");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ', (int) (short) 100, 8);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test453");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a1a0a10a0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a1a0a10a0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0#100#10" + "'", str9.equals("0#100#10"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test454");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1.04100.0", "EN", (-1));
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test455");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                      Java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                      Java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test456");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                                                    ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test457");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Hi!", 5, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test458");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                         ", "", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                         " + "'", str3.equals("                                         "));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test459");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("a # # 4 #", 27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27 + "'", int2 == 27);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test460");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "14-1", "4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test461");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "-14242");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test462");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr#", (double) 3.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test463");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Sophiesophi4sophi4sophi4sophi4sophi");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test464");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.3", 26);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("0a100a10", "hi!http://java.oracle.com/hi!http://java.oracle.com/hi!http://java.oracle.com/hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a100a10" + "'", str2.equals("0a100a10"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test466");
        double[] doubleArray4 = new double[] { 100, 10L, 10.0d, 1L };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', 10, (int) (byte) -1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100.0#10.0#10.0#1.0" + "'", str6.equals("100.0#10.0#10.0#1.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("racle.com", (int) (short) 10, "1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1racle.com" + "'", str3.equals("1racle.com"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test468");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "#################");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test469");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test470");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "Mixed mode", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test471");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 22, (double) 0, 9.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 22.0d + "'", double3 == 22.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test472");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "100414104-141410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                     http://java.oracle.com/                                     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                     http://java.oracle.com/                                     " + "'", str1.equals("                                     http://java.oracle.com/                                     "));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test474");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "VA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [d", (java.lang.CharSequence) "Hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73 + "'", int2 == 73);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test475");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("-1.0 100.0", '4');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sophie    ", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("0a100a10", "");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("#######################a#####4##", strArray6, strArray10);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "", 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aa#a#a4a#", strArray6, strArray15);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44#4a4#", (java.lang.CharSequence[]) strArray15);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "#######################a#####4##" + "'", str11.equals("#######################a#####4##"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "aa#a#a4a#" + "'", str16.equals("aa#a#a4a#"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test476");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "-14242", (java.lang.CharSequence) "4a#aaa");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "-14242" + "'", charSequence2.equals("-14242"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("          ", "                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test478");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("#4a4#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#4a4#" + "'", str1.equals("#4a4#"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test479");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("10 0 1 -1 -1", (short) 4);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 4 + "'", short2 == (short) 4);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test480");
        float[] floatArray2 = new float[] { 21, 34 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 21.0f + "'", float3 == 21.0f);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "21.0a34.0" + "'", str5.equals("21.0a34.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 34.0f + "'", float6 == 34.0f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test481");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("100.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test482");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "##4#-1.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test483");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("######################                                     http://java.oracle.com/                                     #######################", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test484");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "21.0a34.010a0a1a-1a-1", (java.lang.CharSequence) "100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU", "http://java.oracle.com/", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU" + "'", str3.equals("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test486");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-1", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("!", "100 1 10 -1 1 10EN", "                          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!" + "'", str3.equals("!"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-", 3, "Mac OS Xawt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-" + "'", str3.equals("2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test489");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.0 21.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test490");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.0 21.0", "#######################a#####4#");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("-1.0 100.0", strArray2, strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1.0 100.0" + "'", str6.equals("-1.0 100.0"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test492");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "##4#", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test493");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("4444444444");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.444444444E9d + "'", double1.equals(4.444444444E9d));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test494");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("-1.0 100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0 100.0" + "'", str1.equals("-1.0 100.0"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test495");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("hpos");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test496");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("#####10a31a1######");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#####10a31a1######" + "'", str1.equals("#####10a31a1######"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.1       ", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1       " + "'", str3.equals("1.1       "));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU", "PLATFORM API SPECIFICATIO");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test499");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 0, (byte) 1, (byte) -1, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 8, (int) (short) 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 0, (int) (short) 1);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 28, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 28");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10a0a1a-1a-1" + "'", str7.equals("10a0a1a-1a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test500");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophie", "");
        org.junit.Assert.assertNotNull(strArray2);
    }
}

