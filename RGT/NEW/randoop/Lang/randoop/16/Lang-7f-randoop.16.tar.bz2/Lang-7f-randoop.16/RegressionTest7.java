import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10 31 1", 41, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444410 31 144444444444444444" + "'", str3.equals("4444444444444444410 31 144444444444444444"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "_X7X8_88_X7X8_88_X7X8_88_X7X-14242");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1#-1", "####US####                                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#-1" + "'", str2.equals("1#-1"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        float[] floatArray2 = new float[] { (-1.0f), (byte) 100 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1.0 100.0" + "'", str4.equals("-1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1.0#100.0" + "'", str6.equals("-1.0#100.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        long[] longArray4 = new long[] { '#', (byte) 10, (short) -1, (-1L) };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 8, (int) (byte) 1);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 35L + "'", long11 == 35L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                      Java", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        short[] shortArray1 = new short[] { (short) 0 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ');
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Oracle Corporation", "                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "racle.com", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 21, (int) (short) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "14-", 16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "J#v#(TM) SE Runtime Environment", (java.lang.CharSequence) "sU");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.io.File[][] fileArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(fileArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("mac os x", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mac..." + "'", str2.equals("mac..."));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("ORACLE CORPORATIONI!", (double) 179.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 179.0d + "'", double2 == 179.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-", "Orcle Corportioni!34.0 100.0 0.0 10.0 52.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-", "/L  # # 4 #br ry/J v /J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-" + "'", str2.equals("-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("sophi", "Mac OS Xawt.CGraphicsEnvironment", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51227_1560278288");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophi" + "'", str3.equals("sophi"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("34.0 100.0 0.0 10.0 52.0sun", "04100410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "34.0 100.0 0.0 10.0 52.0sun" + "'", str2.equals("34.0 100.0 0.0 10.0 52.0sun"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("rs/soph", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rs/soph" + "'", str2.equals("rs/soph"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("44444444444444444444444a#aa", (double) 16);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.0d + "'", double2 == 16.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                  1.0 21.0 -1.0 0.0", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##################1.0#21.0#-1.0#0.0" + "'", str3.equals("##################1.0#21.0#-1.0#0.0"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', 8, 4);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 11, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0 100 10" + "'", str15.equals("0 100 10"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center(" aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals(" aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOB", 2, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str3.equals("sUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("noitaroproc elcaroVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [dVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAV", 143, "ihpos/Library/Java/JavaVirtualMachi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "inoitaroproc elcaroVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [dVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAV" + "'", str3.equals("inoitaroproc elcaroVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [dVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAV"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aa#a44444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aa#a44444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 0, (byte) 1, (byte) -1, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "10 0 1 -1 -1");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 10 0 1 -1 -1");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10a0a1a-1a-1" + "'", str7.equals("10a0a1a-1a-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Oracle Corporationi!34.0 100.0 0.0 10.0 52.0", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                100#1ihpos");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#1ihpos" + "'", str1.equals("100#1ihpos"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 100 10" + "'", str9.equals("0 100 10"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0a100a10" + "'", str13.equals("0a100a10"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "#4##");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", " aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4# ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                  1.0 21.0 -1.0 0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("ICEPSIPAMROFTALPAVAJ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) ' ', (double) (byte) 10, (double) 12L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("oRACLE CORPORATION", (int) (short) 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE CORPORATION" + "'", str2.equals("oRACLE CORPORATION"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        long[] longArray4 = new long[] { '#', (byte) 10, (short) -1, (-1L) };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 32, (int) (byte) 0);
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.Class<?> wildcardClass15 = longArray4.getClass();
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "354104-14-1" + "'", str9.equals("354104-14-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        char[] charArray11 = new char[] { '4', '#', 'a', '#' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1a2a2", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#######################a#####4#", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.CORACLE CORPORATIONI!", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-1.0#0.0-110a100a-1a-11.0#21.0#-", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("0", "0#100.0                         ", "ORACLE CORPORATION");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "ihpos", "100414104-141410");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Virtual Machine Specification", (java.lang.CharSequence) "sunEN.ENlwawtEN.ENmacosxEN.ENLWCTENoolkit", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 100, (int) (byte) 10);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 271, (float) 4, (float) 12L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("J", 9, "21.0#34.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "21.0J21.0" + "'", str3.equals("21.0J21.0"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [", (-1), 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        float[] floatArray5 = new float[] { 34.0f, (byte) 100, 0, 10, '4' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "34.0 100.0 0.0 10.0 52.0" + "'", str7.equals("34.0 100.0 0.0 10.0 52.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34.0 100.0 0.0 10.0 52.0" + "'", str11.equals("34.0 100.0 0.0 10.0 52.0"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "34.0#100.0#0.0#10.0#52.0" + "'", str14.equals("34.0#100.0#0.0#10.0#52.0"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "##4#", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "001a1-a001a1-a1", (java.lang.CharSequence) "21.0a34.010a0a1a-1a-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "2a2a-1", charSequence1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT", "Sophiesophi4sophi4sophi4sophi4sophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str2.equals("SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 0, (byte) 1, (byte) -1, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 8, (int) (short) 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 0, (int) (short) 1);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 0, 2);
        byte byte20 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10a0a1a-1a-1" + "'", str7.equals("10a0a1a-1a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10 0" + "'", str19.equals("10 0"));
        org.junit.Assert.assertTrue("'" + byte20 + "' != '" + (byte) 10 + "'", byte20 == (byte) 10);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1 -1" + "'", str5.equals("1 -1"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "14-1" + "'", str7.equals("14-1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a-1" + "'", str9.equals("1a-1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) " aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4# ", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        char[] charArray12 = new char[] { '4', '#', 'a', '#' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1a2a2", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#######################a#####4#", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100.0#10.0#10.0#1.0", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/L brary/Java/JavaV rtualMac n /jdk1.7.0_80.jdk/C nt nt /H m /jr", charArray12);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray12, '#');
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "21.0a34.010a0a1a-1a-1", charArray12);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(charArray12, '#');
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "4###a##" + "'", str21.equals("4###a##"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "4###a##" + "'", str24.equals("4###a##"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.CORACLE CORPORATIONI!", "0#100.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        double[] doubleArray2 = new double[] { 8L, (-1) };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "8.0 -1.0" + "'", str6.equals("8.0 -1.0"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("noitaroproc elcaroVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [dVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAV", " aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproc elcaroVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [dVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAV" + "'", str2.equals("noitaroproc elcaroVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [dVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAV"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("0#100#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#100#10" + "'", str1.equals("0#100#10"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "oracle corporationi!", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(28, (int) (short) -1, 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("0a100a10", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("14-1 ", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "14-1 " + "'", str3.equals("14-1 "));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("va.lang.string;class [ljava.lang.string;class [ljava.lang.string;class [d", (long) 21);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21L + "'", long2 == 21L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "Mixed mode");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie    ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "mac...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        char[] charArray9 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####US####", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-1.0 100.0", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray9);
        java.lang.Class<?> wildcardClass16 = charArray9.getClass();
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "a#####4##" + "'", str11.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 18 + "'", int15 == 18);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S", charSequence1, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1#-1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("34.0 100.0 0.0 10.0 52.0sun", 10, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Orcle Corportioni!34.0 100.0 0.0 10.0 52.0", (float) 31L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 31.0f + "'", float2 == 31.0f);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                    -1.0 100.0");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.substringsBetween("", "\n", "10Java(TM) SE Runtime Environment10");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "1.0 21.0");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1a-1", strArray3, strArray9);
        java.lang.String[] strArray13 = null;
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("sophie    ", strArray9, strArray13);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1a-1" + "'", str12.equals("1a-1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "sophie    " + "'", str14.equals("sophie    "));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.0#21.0#-1.0#0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        char[] charArray8 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####US####", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "rs/soph", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a#####4##" + "'", str10.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "PLATFORM API SPECIFICATIO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("a # # 4 #aaaaaaaaaaaaaaaaaaaaaaaaaa", "Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a # # 4 #aaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("a # # 4 #aaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("hi!", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("#4##", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "Orcle Corportioni!34.0 100.0 0.0 10.0 52.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39 + "'", int2 == 39);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-1.04100.0", 39, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#############################-1.04100.0" + "'", str3.equals("#############################-1.04100.0"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0000-0ihpos-0-0-0", 97, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "ICEPSIPAMROFTALPAVAJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-1a2a2100a1ihpos-1####US####", (java.lang.CharSequence) "100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [", 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("-1a2a2100a1ihpos-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a2a2100a1ihpos-" + "'", str1.equals("-1a2a2100a1ihpos-"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        java.lang.String str6 = javaVersion4.toString();
        boolean boolean7 = javaVersion0.atLeast(javaVersion4);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion9 = null;
        try {
            boolean boolean10 = javaVersion4.atLeast(javaVersion9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.9" + "'", str6.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "####US####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.1      ", "a4#4#444#");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1      " + "'", str3.equals("1.1      "));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "4###a##", (java.lang.CharSequence) "!:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("fication", 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        long[] longArray4 = new long[] { '#', (byte) 10, (short) -1, (-1L) };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 32, (int) (byte) 0);
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long15 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "354104-14-1" + "'", str9.equals("354104-14-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "0.001#0                     ", (java.lang.CharSequence) "J");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "0.001#0                     " + "'", charSequence2.equals("0.001#0                     "));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "100a1a10a-1a1a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "100#1ihpos");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 100, (int) (byte) 10);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0 100 10" + "'", str11.equals("0 100 10"));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0#100#10" + "'", str16.equals("0#100#10"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("####US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US###44444444444444444444444a#aaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("-1.0 100.0", "8.04-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.1", charArray9);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', 179, (int) '4');
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100a1ihpos", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "a#####4##" + "'", str11.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        short[] shortArray6 = new short[] { (short) 100, (short) 1, (byte) 10, (short) -1, (short) 1, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short18 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100414104-141410" + "'", str11.equals("100414104-141410"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100 1 10 -1 1 10" + "'", str13.equals("100 1 10 -1 1 10"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 100 + "'", short15 == (short) 100);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100414104-141410" + "'", str17.equals("100414104-141410"));
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) -1 + "'", short18 == (short) -1);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100a1a10a-1a1a10" + "'", str20.equals("100a1a10a-1a1a10"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "##4#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "34.0a100.0a0.0a10.0a52.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("##################################", (double) 50);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 50.0d + "'", double2 == 50.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("fication", "!:", 50);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        java.lang.Class<?> wildcardClass8 = intArray2.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1 -1" + "'", str5.equals("1 -1"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "14-1" + "'", str7.equals("14-1"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 -1" + "'", str10.equals("1 -1"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "ihpos/Library/Java/JavaVirtualMachi", (java.lang.CharSequence) "1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                              " + "'", str2.equals("                              "));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/j", "100.010.010.01.0", 108);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("_X7X8_88_X7X8_88_X7X8_88_X7X-14242", "oRACLE CORPORATION", "rs/soph");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "_X7X8_88_X7X8_88_X7X8_88_X7X-14242" + "'", str3.equals("_X7X8_88_X7X8_88_X7X8_88_X7X-14242"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        char[] charArray11 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray11, '#');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####US####", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-1.0 100.0", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http://java.oracle.com/", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray11);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray11, 'a');
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "#############################-1.04100.0", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "a#####4##" + "'", str13.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "aa#a#a4a#" + "'", str20.equals("aa#a#a4a#"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 3L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray10 = new char[] { '4', '#', 'a', '#' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.0", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray10);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a', 30, 2);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ', 177, 0);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                             10.14.3              ", (java.lang.CharSequence) "#######################A#####4#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.3\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) (short) 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    " + "'", str2.equals("    "));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 8L, (long) 21);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("inoitaroproc elcaroVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [dVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAV", (int) (short) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "inoitaroproc elcaroVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [dVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAV" + "'", str3.equals("inoitaroproc elcaroVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [dVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAV"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "-1a2a2", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sophiSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONME", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONME" + "'", str2.equals("sophiSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONME"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie    ");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sophie", (java.lang.CharSequence[]) strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "aa#a#a4a#");
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie    ");
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray18);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray18);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sophie", (java.lang.CharSequence[]) strArray18);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1a-1", (java.lang.CharSequence[]) strArray18);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEach("sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    ", strArray6, strArray18);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 21 + "'", int7 == 21);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr" + "'", str11.equals("/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 21 + "'", int19 == 21);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    " + "'", str23.equals("sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    "));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        long[] longArray4 = new long[] { '#', (byte) 10, (short) -1, (-1L) };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 8, (int) (byte) 1);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "35#10#-1#-1" + "'", str12.equals("35#10#-1#-1"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.substringsBetween("", "\n", "10Java(TM) SE Runtime Environment10");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "1.0 21.0");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("0a100a10", "");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray7, strArray10);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "34.0 100.0 0.0 10.0 52.0sun");
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "#4##", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOB", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("-1.0 100.0", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "aaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("-1a2a2100a1ihpos-", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos-" + "'", str2.equals("-1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos-"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 32, (double) (byte) 1, (double) 18);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("RACLE.COM/", "al Machine Specification", (int) '#');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Mac OS Xawt.CGraphicsEnvironment", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                  Mac OS Xawt.CGraphicsEnvironment                                  " + "'", str2.equals("                                  Mac OS Xawt.CGraphicsEnvironment                                  "));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("#", "                  1.0 21.0 -1.0 0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "en", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "a#####4##", charArray9);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', (int) (byte) 10, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "a#####4##" + "'", str11.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("21.7", "AAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAA" + "'", str2.equals("AAAAAA"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (java.lang.CharSequence) "                                         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, '#', 21, 6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "PLATFORM API SPECIFICATIO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("100 1 10 -1 1 10EN", "class [ljava.lang.string;class [ljava.lang.string;class [ljava.lang.string;class [ljava.lang.string;class [d", "1.0a21.0a-1.0a0.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100 1 10 -1 1 10EN" + "'", str3.equals("100 1 10 -1 1 10EN"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/Users/sophie");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("...", "100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "..." + "'", str2.equals("..."));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 132, (float) 12L, (float) 4L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("sun.awt.CGraphicsEnvironment", "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "100 1 10 -1 1 10EN", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("noitaroproc elcaro");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"noitaroproc elcaro\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("21.7", 108, "a/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a/Extensions:/usr/lib/java:.a/Extensions:/usr/lib/java:.a/Extensions:/usr/lib/java:.a/Extensions:/usr/li21.7" + "'", str3.equals("a/Extensions:/usr/lib/java:.a/Extensions:/usr/lib/java:.a/Extensions:/usr/lib/java:.a/Extensions:/usr/li21.7"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 0, (byte) 1, (byte) -1, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10a0a1a-1a-1" + "'", str7.equals("10a0a1a-1a-1"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1#-1#100#-1#100#100", "44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#", "0a100a100a100a100a100a100a100a100a100a100a100a100a100a100a100a10 0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1#-1#100#-1#100#100" + "'", str3.equals("1#-1#100#-1#100#100"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', 8, 4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0 100 10" + "'", str13.equals("0 100 10"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("-1a2a2100a1ihpos-", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("JAVAPLATFORMAPISPECIFICATION", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVAPLATFORMAPISPECIFICATION" + "'", str3.equals("JAVAPLATFORMAPISPECIFICATION"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("21.0a34.0", "hi!");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "EN");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "10", (java.lang.CharSequence) "NOITACIFICEPSIPAMROFTALPAVAJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("...", "0 100 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        char[] charArray8 = new char[] { '4', '#', 'a', '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Virtual Machine Specification", charArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sophi4", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4a#aaa#" + "'", str12.equals("4a#aaa#"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("...", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                                                                                                                                                                aa#a#a4a#", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                          aa#a#a4a#" + "'", str2.equals("                          aa#a#a4a#"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("         0a100a10          ", "                                             10.14.3              ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "         0a100a10          " + "'", str4.equals("         0a100a10          "));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.String str6 = javaVersion1.toString();
        java.lang.String str7 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ":", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("001a001a1-a001a1-a1", 4, "                                                                                                                      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "001a001a1-a001a1-a1" + "'", str3.equals("001a001a1-a001a1-a1"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaa", "35a10a-1a-11.1       1.1       1.1", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("i", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "i" + "'", str3.equals("i"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "10a0a1a-1a-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1041004-14-1", "sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    ", "", 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1041004-14-1" + "'", str4.equals("1041004-14-1"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "10Java(TM) SE Runtime Environment10", (java.lang.CharSequence) "                                             10.14.3              ", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "ORACLE CORPORATIONI!", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "ORACLE CORPORATIONI!" + "'", charSequence2.equals("ORACLE CORPORATIONI!"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1040414-14-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D" + "'", str2.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a1a0a10a0", (java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;", 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaa21.7aaaaaa", "0.53#0.01#0.21#0.9#0.13");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0#100.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("J#v#(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"J#v#(TM) SE Runtime Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.0 21.0 -1.0 0.0", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "oRACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.0#21.0#-1.0#0.0", "100.0#10.0#10.0#1.0100.0#10.0SU", (int) (short) 4, (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100.0#10.0#10.0#1.0100.0#10.0SU21.0#-1.0#0.0" + "'", str4.equals("100.0#10.0#10.0#1.0100.0#10.0SU21.0#-1.0#0.0"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100 1 10 -1 1 10", '#');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0.001#0                     ", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        double[] doubleArray3 = new double[] { 0L, 4.444444444E9d, 1.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.444444444E9d + "'", double4 == 4.444444444E9d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.0 21.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java HotSpot(TM) 64-Bit Server VM", "             10.14.3              ", "Sophiesophi4sophi4sophi4sophi4sophi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) " aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("SUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENT", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENT" + "'", str3.equals("SUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "100 1 10 -1 1 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("mixed mod", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mod" + "'", str2.equals("mixed mod"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "noitaroproc elcaro", (java.lang.CharSequence) "100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("noitaroproC elcarO");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"noitaroproC elcarO\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sophiSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONME", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONME" + "'", str2.equals("sophiSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONME"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        double[] doubleArray4 = new double[] { 1, 21, (-1.0f), 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 21.0d + "'", double5 == 21.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.0d + "'", double6 == 21.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0 21.0 -1.0 0.0" + "'", str8.equals("1.0 21.0 -1.0 0.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.0 21.0 -1.0 0.0" + "'", str10.equals("1.0 21.0 -1.0 0.0"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "####US####                                                                                         ", charSequence1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("EN", "racle.com/", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("10 0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 0" + "'", str1.equals("10 0"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("34.0a6.0a3.0", "354104-14-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "34.0a6.0a3.0" + "'", str2.equals("34.0a6.0a3.0"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray8 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "34.0 100.0 0.0 10.0 52.0sun", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a#####4##" + "'", str10.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("100 1 10 -1 1 10EN", "1 -1", "/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100 1 10 -1 1 10EN" + "'", str3.equals("100 1 10 -1 1 10EN"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("44#4a4...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44#4A4..." + "'", str1.equals("44#4A4..."));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;", (java.lang.CharSequence) "Mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("mac os x");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mac os x\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1#-1#100#-1#100#100");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("iiiiiiiiiiaaaaaaa...iiiiiiiiiii");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "iiiiiiiiiii...aaaaaaaiiiiiiiiii" + "'", str1.equals("iiiiiiiiiii...aaaaaaaiiiiiiiiii"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("2a2a-1", "/");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("10J...", 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("0.001 0.1-", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.001 0.1-" + "'", str7.equals("0.001 0.1-"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1", 142, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "#4##");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 0, (byte) 1, (byte) -1, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 8, (int) (short) 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 0, (int) (short) 1);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 0, 2);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ');
        byte byte22 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10a0a1a-1a-1" + "'", str7.equals("10a0a1a-1a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10 0" + "'", str19.equals("10 0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10 0 1 -1 -1" + "'", str21.equals("10 0 1 -1 -1"));
        org.junit.Assert.assertTrue("'" + byte22 + "' != '" + (byte) -1 + "'", byte22 == (byte) -1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("hi!", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "46_68x" + "'", str1.equals("46_68x"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1041004-14-1", "1ihpos_x7x8_88#100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("http://java.oracle.com/                                                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HTTP://JAVA.ORACLE.COM/                                                                             " + "'", str1.equals("HTTP://JAVA.ORACLE.COM/                                                                             "));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("-14242");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("14-");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(4, 28, 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Hi!");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean6 = javaVersion0.atLeast(javaVersion5);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                          ", (java.lang.CharSequence) "100a1a10a-1a1a10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie    ");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sophie", (java.lang.CharSequence[]) strArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '#', 31, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 21 + "'", int6 == 21);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "/Laaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aabrary/Java/JavaVaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aartualMacaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aanaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa/jdk1.7.0_80.jdk/Caaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aantaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aantaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa/Haaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aamaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa/jr" + "'", str14.equals("/Laaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aabrary/Java/JavaVaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aartualMacaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aanaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa/jdk1.7.0_80.jdk/Caaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aantaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aantaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa/Haaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aamaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa/jr"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "ments/defects4j/tmp/run_randoop.pl_51227_1560278288", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.0 21.0", 217);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0 21.0" + "'", str2.equals("1.0 21.0"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("0.53#0.01#0.21#0.9#0.13", 0, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.53#0.01#0." + "'", str3.equals("0.53#0.01#0."));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        char[] charArray7 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "##4#", charArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        java.lang.Class<?> wildcardClass14 = charArray7.getClass();
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "a#####4##" + "'", str9.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "aa#a#a4a#" + "'", str13.equals("aa#a#a4a#"));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "a#####4##" + "'", str16.equals("a#####4##"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        float[] floatArray2 = new float[] { 21, 34 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', (int) (short) 10, 9);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', 217, (int) ' ');
        float float17 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 21.0f + "'", float3 == 21.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "21.0a34.0" + "'", str9.equals("21.0a34.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 34.0f + "'", float10 == 34.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "21.0#34.0" + "'", str12.equals("21.0#34.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 21.0f + "'", float17 == 21.0f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("a4#4#444#", "OracleCorporationi!34.0100.00.010.052.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a4#4#444#" + "'", str2.equals("a4#4#444#"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.0a21.0a-1.0a0.0", "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT", "rs/soph");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0a21.0a-1.0a0.0" + "'", str3.equals("1.0a21.0a-1.0a0.0"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("ihpos");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ihpos" + "'", str1.equals("ihpos"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.1      ", "a4#4#444#");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a1a0a10a0");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, ' ');
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("100.010.010.01.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 100, (int) (byte) 10);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "\n");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: \n");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0 100 10" + "'", str11.equals("0 100 10"));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.1       ", "hi!http://java.oracle.com/hi!http://java.oracle.com/hi!http://java.oracle.com/hi!", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3.0f, 10.0d, 52.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sophi", "", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "21.7");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Java(TM) SE Ru", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "100#1ihpos");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "J", (java.lang.CharSequence) "2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10a31a1", "001a1-a001a1-a1", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444442a2a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444442a2a-1" + "'", str1.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444442a2a-1"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        float[] floatArray2 = new float[] { 21, 34 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', (int) (short) 10, 9);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        java.lang.Class<?> wildcardClass12 = floatArray2.getClass();
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 21.0f + "'", float3 == 21.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "21.0a34.0" + "'", str9.equals("21.0a34.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "21.0#34.0" + "'", str11.equals("21.0#34.0"));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 21.0f + "'", float13 == 21.0f);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("4###a##", (double) 5.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("4444444444444444410 31 144444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444410 31 144444444444444444" + "'", str1.equals("4444444444444444410 31 144444444444444444"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr", 5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJo" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-", "sun.lwawt.macosx.CPrinterJob", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-" + "'", str3.equals("-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 50);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 50.0f + "'", float2 == 50.0f);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(39, 0, 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39 + "'", int3 == 39);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 100, (int) (byte) 10);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: SUN.AWT.cgRAPHICSeNVIRONMENTSUN.");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0 100 10" + "'", str11.equals("0 100 10"));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("100#1ihpos", "Oracle Corporationi!", "!:", (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100#1ihpos" + "'", str4.equals("100#1ihpos"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1a-1", (java.lang.CharSequence) "sunEN.ENlwawtEN.ENmacosxEN.ENLWCTENoolkit", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("0a100a100a100a100a100a100a100a100a100a100a100a100a100a100a100a10 0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a100a100a100a100a100a100a100a100a100a100a100a100a100a100a100a10 0" + "'", str2.equals("0a100a100a100a100a100a100a100a100a100a100a100a100a100a100a100a10 0"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaa", (int) (byte) 0, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaa" + "'", str3.equals("aaaaaaaa"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "\n", "10Java(TM) SE Runtime Environment10");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "1.0 21.0");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "aa#a#a4a#");
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a#####4##", (int) (byte) 1);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.split("-1.0 100.0", '4');
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray20, ' ');
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray17, strArray20);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10a0a1a-1a-1", strArray12, strArray17);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, ' ');
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("RACLE.COM/", strArray6, strArray12);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-1.0 100.0" + "'", str22.equals("-1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10a0a1a-1a-1" + "'", str24.equals("10a0a1a-1a-1"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str26.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RACLE.COM/" + "'", str27.equals("RACLE.COM/"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("AAAAAAAAAAAAAAAAAAAAAAAAAAA", (int) ' ', "-1.0100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1AAAAAAAAAAAAAAAAAAAAAAAAAAA-1." + "'", str3.equals("-1AAAAAAAAAAAAAAAAAAAAAAAAAAA-1."));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.CharSequence[] charSequenceArray5 = new java.lang.CharSequence[] { "/", "US", "Java", "aa#a#a4a#" };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", charSequenceArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray5, '#', (int) (short) -1, 217);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charSequenceArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        char[] charArray7 = new char[] { '4', '#', 'a', '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Virtual Machine Specification", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#######################A#####4#", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4a#aaa#" + "'", str11.equals("4a#aaa#"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("4###a##", (int) (short) -1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4###a##" + "'", str3.equals("4###a##"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph", "##4#-1.0 100.0", "1.4");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("SU", "aaaaaaa...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SU" + "'", str2.equals("SU"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.0a21.0a-1.0a0.0", 31, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        java.lang.String str6 = javaVersion4.toString();
        boolean boolean7 = javaVersion0.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean11 = javaVersion9.atLeast(javaVersion10);
        boolean boolean12 = javaVersion8.atLeast(javaVersion9);
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        java.lang.String str14 = javaVersion9.toString();
        boolean boolean15 = javaVersion4.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean18 = javaVersion16.atLeast(javaVersion17);
        java.lang.String str19 = javaVersion17.toString();
        boolean boolean20 = javaVersion4.atLeast(javaVersion17);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.9" + "'", str6.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.4" + "'", str14.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1.7" + "'", str19.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("4444444444444444410 31 144444444444444444", "SUN.AWT.cgRAPHICSeNVIRONMENT", (int) (byte) 10, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4444444444SUN.AWT.cgRAPHICSeNVIRONMENT444444410 31 144444444444444444" + "'", str4.equals("4444444444SUN.AWT.cgRAPHICSeNVIRONMENT444444410 31 144444444444444444"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "##################1.0#21.0#-1.0#0.0", 177);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("RACLE.COM/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "rACLE.COM/" + "'", str1.equals("rACLE.COM/"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aa#a#a4a#");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        short[] shortArray6 = new short[] { (short) 100, (short) 1, (byte) 10, (short) -1, (short) 1, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100414104-141410" + "'", str11.equals("100414104-141410"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100#1#10#-1#1#10" + "'", str15.equals("100#1#10#-1#1#10"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "racle.com/", (java.lang.CharSequence) "                                                                                                                      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 4, (short) (byte) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray11 = new char[] { '4', '#', 'a', '#' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.0", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray11);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray11, 'a', 30, 2);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-1", "-1.0a100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "41004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14" + "'", str2.equals("41004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("NOITACIFICEPSIPAMROFTALPAVAJ", 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                                                                                      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("UTF-8", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray12 = new char[] { '4', '#', 'a', '#' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.0", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone(charSequence2, charArray12);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100.0 10.0 10.0 1.0", charArray12);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "14-", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("44#4a4...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44#4a4...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 12, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############" + "'", str3.equals("############"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("0#100.0", "class [ljava.lang.string;class [ljava.lang.string;class [ljava.lang.string;class [ljava.lang.string;class [d", "JAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0#100.0" + "'", str3.equals("0#100.0"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "oracle corporationi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.String str5 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7" + "'", str5.equals("1.7"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", '4');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) " ", (java.lang.CharSequence[]) strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.1.3" + "'", str5.equals("10.1.3"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 41);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 34, (long) '4', (long) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("##4#100414104-141410");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "a # # 4 #aaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd(" Environment10                     ", "8.04-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Environment10                     " + "'", str2.equals(" Environment10                     "));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 4, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 4 + "'", short3 == (short) 4);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("ihpos/Library/Java/JavaVirtualMachi");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51227_1560278288", (java.lang.CharSequence) "1a-1a100a-1a100a100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("J#v#(TM) SE Runtime Environment", "#4##", "Java(TM) SE Ru");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JJvJ(TM) SE Runtime Environment" + "'", str3.equals("JJvJ(TM) SE Runtime Environment"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 118, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                      " + "'", str3.equals("                                                                                                                      "));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "100.0#10.0#10.0#1.0100.0#10.0SU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java", "sophi4", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("44#4a4#", "1http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44#4a4#" + "'", str2.equals("44#4a4#"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        char[] charArray8 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", charArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "al Machine Specification", charArray8);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a#####4##" + "'", str10.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "aa#a#a4a#" + "'", str14.equals("aa#a#a4a#"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "a # # 4 #" + "'", str16.equals("a # # 4 #"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "a # # 4 #" + "'", str19.equals("a # # 4 #"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Virtual Machine Specification", "", 10);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJo", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJo" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "4a#aaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.0", "44#4a4#", "0.0 0.1- 0.12 0.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0" + "'", str3.equals("1.0"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                      Java", (java.lang.CharSequence) " aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4# ", 179);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a1a0a10a0", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444442a2a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444442a2a-1" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444442a2a-1"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("NOITACIFICEPSIPAMROFTALPAVAJ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOITACIFICEPSIPAMROFTALPAVAJ" + "'", str2.equals("NOITACIFICEPSIPAMROFTALPAVAJ"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase(".0 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".0 " + "'", str1.equals(".0 "));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b150");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 5, 5.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("#################", "1#-1#100#-1#100#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################" + "'", str2.equals("#################"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("####US####      ####US####      ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.21.71.1", 41, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################1.21.71.1################" + "'", str3.equals("################1.21.71.1################"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "mixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("mixed mode", 13, 22);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                     0#100.0", "-0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     0#100.0" + "'", str2.equals("                     0#100.0"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("mixed mode", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("51.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"51.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 100, (int) (byte) 10);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', 16, 271);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 16");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "04100410" + "'", str11.equals("04100410"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("rs/soph", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rs/soph                           " + "'", str2.equals("rs/soph                           "));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str2.equals("SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("0#100#10", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#10" + "'", str2.equals("0#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#10"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        char[] charArray10 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####US####", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-1.0 100.0", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "al Machine Specification", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "#################", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "a#####4##" + "'", str12.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "aaaaaaaaaaaaaaaaaaaaaaaaaaa", 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100a1a10a-1a1a1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 179L, (double) 132, 21.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 179.0d + "'", double3 == 179.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("100a1a10a-1a1a10", "10#-1#100#0#-1#-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("a4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#10Ja4#4#444#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a4#4#4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mixedmode", "sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    100#1ihpos_x7x8_88ava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [sophie    ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("0#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#10", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                    -1.0 100.0", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("-1a2a2", "RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.CORACLE CORPORATIONI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a2a2" + "'", str2.equals("-1a2a2"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104", (java.lang.CharSequence) "4a#aaa                      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "21.0J21.0", (java.lang.CharSequence) "rs/soph                           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aa#a#a4a#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aa#a#a4a#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJo", (java.lang.CharSequence) "1.1      ", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.61.11.41.1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.61.11.41.1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "ihpos", 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph", 39, "1.61.11.41.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph" + "'", str3.equals("100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        float[] floatArray2 = new float[] { 21, 34 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', (int) (short) 10, 9);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', (int) '4', 9);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 21.0f + "'", float3 == 21.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 21.0f + "'", float8 == 21.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 21.0f + "'", float9 == 21.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 34.0f + "'", float14 == 34.0f);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("al Machine Specification", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "al Machine Specification" + "'", str2.equals("al Machine Specification"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("100a1a10a-1a1a1", "100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph#100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph#100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph4100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph", "1ihpos_x7x8_88#100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a1a10a-1a1a1" + "'", str3.equals("100a1a10a-1a1a1"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "44#4A4...", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444aaaaaa", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                                      ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("racle.com/", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "racle.com/" + "'", str2.equals("racle.com/"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENT", (java.lang.CharSequence) "44#4a4#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("aaaaaa4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hpos");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "100a1a10a-1a1a10", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4###a##", 17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        float[] floatArray3 = new float[] { 100, 21, (byte) 10 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', 0, 143);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 10.0f + "'", float4 == 10.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("354104-14-1", "-1AAAAAAAAAAAAAAAAAAAAAAAAAAA-1.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("4444444444444444410 31 144444444444444444", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle Corporation", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (short) -1);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.CPrinterJob", "Oracle Corporationi!");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a # # 4 #");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray9, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                             10.14.3              ", strArray4, strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "                                             10.14.3              " + "'", str13.equals("                                             10.14.3              "));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("35a10a-1a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "35A10A-1A-1" + "'", str1.equals("35A10A-1A-1"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.0 21.0 -1.0 0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 21.0 -1.0 0.0" + "'", str1.equals("1.0 21.0 -1.0 0.0"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("####US####                                                                                         ", 0, 41);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####US####                               " + "'", str3.equals("####US####                               "));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10 0", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10 0" + "'", str3.equals("10 0"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-1.0 100.0", "mixed mod");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("mixedmode");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "21.0 34.0", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "8.04-1.0", (java.lang.CharSequence) "aaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.4", "##4#");
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "100.0#10.0#10.0#1.0100.0#10.0SU", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.1", (java.lang.CharSequence) "10J");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("racle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Racle.com/" + "'", str1.equals("Racle.com/"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####" + "'", str1.equals("####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Mixedmode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mixedmode" + "'", str1.equals("Mixedmode"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aa#a#a4a#", (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        short[] shortArray6 = new short[] { (short) 100, (short) 1, (byte) 10, (short) -1, (short) 1, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4', 217, 27);
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) -1 + "'", short15 == (short) -1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("         0a100a10          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"         0a100a10          \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0#100#10" + "'", str9.equals("0#100#10"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1#-1", (double) 1.1f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.100000023841858d + "'", double2 == 1.100000023841858d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos--1a2a2100a1ihpos-", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean5 = javaVersion2.atLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "sophie", 10);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "0 100 10");
        java.lang.Class<?> wildcardClass9 = strArray3.getClass();
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 11, 142);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("0a100a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a100a1" + "'", str1.equals("0a100a1"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("100414104-141410", "4###a##");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100414104-141410" + "'", str2.equals("100414104-141410"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aa#a#a4a#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa#a#a4a#" + "'", str1.equals("aa#a#a4a#"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "a # # 4 #aaaaaaaaaaaaaaaaaaaaaaaaaa", "21.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.61.11.41.1", "1.7.0_80-b15", "4444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.61.11.41.1" + "'", str3.equals("1.61.11.41.1"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Laaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aabrary/Java/JavaVaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aartualMacaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aanaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa/jdk1.7.0_80.jdk/Caaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aantaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aantaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa/Haaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aamaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa/jr", "ORACLE CORPORATIONI!", " u EN.ENlwawtEN.ENmacosxEN.ENLWCTENoolkit", (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Laaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aabrary/Java/JavaVaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aartualMacaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aanaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa/jdk1.7.0_80.jdk/Caaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aantaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aantaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa/Haaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aamaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa/jr" + "'", str4.equals("/Laaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aabrary/Java/JavaVaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aartualMacaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aanaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa/jdk1.7.0_80.jdk/Caaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aantaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aantaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa/Haaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aamaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa/jr"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        float[] floatArray2 = new float[] { 21, 34 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', (int) (short) 10, 9);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 6, 2);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 21.0f + "'", float3 == 21.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "21.0#34.0" + "'", str9.equals("21.0#34.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 34.0f + "'", float10 == 34.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "21.0434.0" + "'", str16.equals("21.0434.0"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("SUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENT", 42);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGR..." + "'", str2.equals("SUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGR..."));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                    -1.0 100.0");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.substringsBetween("", "\n", "10Java(TM) SE Runtime Environment10");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "1.0 21.0");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1a-1", strArray3, strArray9);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4 # a #", "ORACLE CORPORATION-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2", 177);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray3, strArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 9 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1a-1" + "'", str12.equals("1a-1"));
        org.junit.Assert.assertNotNull(strArray16);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        short[] shortArray6 = new short[] { (short) 100, (short) 1, (byte) 10, (short) -1, (short) 1, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short16 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100414104-141410" + "'", str11.equals("100414104-141410"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100 1 10 -1 1 10" + "'", str13.equals("100 1 10 -1 1 10"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 100 + "'", short15 == (short) 100);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) -1 + "'", short16 == (short) -1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("     ihpos", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "J", (java.lang.CharSequence) "14-1");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "J" + "'", charSequence2.equals("J"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        int[] intArray3 = new int[] { (short) -1, 2, 2 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ', 3, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1a2a2" + "'", str6.equals("-1a2a2"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-14242" + "'", str9.equals("-14242"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("hi!http://java.oracle.com/hi!http://java.oracle.com/hi!http://java.oracle.com/hi!", "rACLE.COM/", 73, 27);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!http://java.oracle.com/hrACLE.COM/.com/hi!" + "'", str4.equals("hi!http://java.oracle.com/hrACLE.COM/.com/hi!"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("2a2a-1", "SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1 -1", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.CORACLE CORPORATIONI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                100#1ihpos");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                100#1ihpos\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "100.0#10.0#10.0#1.0100.0#10.0SU21.0#-1.0#0.0", (java.lang.CharSequence) "##################1.0#21.0#-1.0#0.0", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("-1.04100.0", "Oracle Corporationi!34.0 100.0 0.0 10.0 52.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-" + "'", str2.equals("-"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "0 100 10", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean7 = javaVersion4.atLeast(javaVersion6);
        boolean boolean8 = javaVersion2.atLeast(javaVersion4);
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hpos", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "#####10a31a1######");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ihpos", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "en", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "US", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "a#####4##" + "'", str11.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "Sophie", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Sophie" + "'", charSequence2.equals("Sophie"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2100a1ihpos-1a2a2", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "a/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray11 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray11, '#');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####US####", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-1.0 100.0", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http://java.oracle.com/", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray11);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "a#####4##" + "'", str13.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        char[] charArray9 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", charArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10143", charArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "a#####4##" + "'", str11.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "aa#a#a4a#" + "'", str15.equals("aa#a#a4a#"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "_X7X8_88_X7X8_88_X7X8_88_X7X-14242", (java.lang.CharSequence) "                                                                                                 14-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie    ");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "noitaroproC elcarO");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 21 + "'", int4 == 21);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51227_1560278288");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51227_1560278288 is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("\n", "ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 0, (byte) 1, (byte) -1, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 8, (int) (short) 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 0, (int) (short) 1);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 0, 2);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 8, (-1));
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10a0a1a-1a-1" + "'", str7.equals("10a0a1a-1a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10 0" + "'", str19.equals("10 0"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1http://java.oracle.com/", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1.0a100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0a100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("0#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#100#10", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#100#100#100" + "'", str2.equals("0#100#100#100"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                          aa#a#a4a#", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                          aa#a#a4a#" + "'", str2.equals("                          aa#a#a4a#"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "Java");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "http://java.oracle.com/                                                                             ", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("21.0A34.010A0A1A-1A-1", "-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-", 97);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("AAAAAAAAAAAAAAAAAAAAAAAAAAA", strArray6, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str11.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(4, 50, 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 50 + "'", int3 == 50);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "#######################a#####4#", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1a1a0a10a0", "", 3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1 -1", (java.lang.CharSequence) "EN", 177);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0" + "'", str1.equals("100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0100.0#10.0#10.0#1.0"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Mixed mode", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "######################                                     http://java.oracle.com/                                     #######################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "-1.04100.0", (java.lang.CharSequence) "1ihpos_x7x8_88#100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sU", "", 17);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sUsUsUsUsUsUsUsUsUsUsUsUsUsUsUsUsU" + "'", str3.equals("sUsUsUsUsUsUsUsUsUsUsUsUsUsUsUsUsU"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "VA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [d");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1.0#100.0", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4sopha100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph#100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph#100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph4100a1ihpossophi4sophi4sophi4sophi4sophi4sophi4soph", "JJvJ(TM) SE Runtime Environment", "####US####                               ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("SUN.AWT.cgRAPHICSeNVIRONMENT", "                  1.0 21.0 -1.0 0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str2.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(" Mixed mode", (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.0#21.0#-1.0#0.0", 34, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                    -1.0 100.0", (java.lang.CharSequence) "51.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sophie", "21.0a34.010a0a1a-1a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, '#', 21, 6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1#-1" + "'", str9.equals("1#-1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 100, (int) (byte) 10);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0 100 10" + "'", str11.equals("0 100 10"));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0#100#10" + "'", str14.equals("0#100#10"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.61.11.41.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.61.11.41.1" + "'", str1.equals("1.61.11.41.1"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                  Mac OS Xawt.CGraphicsEnvironment                                  ", " u EN.ENlwawtEN.ENmacosxEN.ENLWCTENoolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b150", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b150" + "'", str2.equals("01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b150"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("en", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "0.001#0                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1a-1", (java.lang.CharSequence) "sUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOBmixed modsUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "SUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGR...");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sophi", "a#####4##");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophi" + "'", str2.equals("sophi"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("####US####                               ", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("4###a##");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        char[] charArray9 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "##4#", charArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "noitaroproc elcaroVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [dVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAV", charArray9);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "a#####4##" + "'", str11.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "aa#a#a4a#" + "'", str15.equals("aa#a#a4a#"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4a#aaa#", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        long[] longArray4 = new long[] { '#', (byte) 10, (short) -1, (-1L) };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 10, 2);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 32, 0);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "JAVAPLATFORMAPISPECIFICATION", 142);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str5.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "100#1ihpos_x7x8_88");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("NOITACIFICEPSIPAMROFTALPAVAJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOITACIFICEPSIPAMROFTALPAVAJ" + "'", str1.equals("NOITACIFICEPSIPAMROFTALPAVAJ"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("ORACLE CORPORATION");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100#1#10#-1#1#10", (java.lang.CharSequence) "1.1       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("####US####                                                                                          ", "Oracle Corporation");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "aa#a#a4a#");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a#####4##", (int) (byte) 1);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.split("-1.0 100.0", '4');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray16, ' ');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray13, strArray16);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10a0a1a-1a-1", strArray8, strArray13);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", strArray4, strArray13);
        int int22 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                                                                 14-", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-1.0 100.0" + "'", str18.equals("-1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10a0a1a-1a-1" + "'", str20.equals("10a0a1a-1a-1"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie" + "'", str21.equals("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 179);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################################################################################################################################################################" + "'", str2.equals("###################################################################################################################################################################################"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "#######################a#####4#", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        java.lang.String str6 = javaVersion4.toString();
        boolean boolean7 = javaVersion0.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        boolean boolean10 = javaVersion0.atLeast(javaVersion8);
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean14 = javaVersion12.atLeast(javaVersion13);
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean16 = javaVersion13.atLeast(javaVersion15);
        boolean boolean17 = javaVersion8.atLeast(javaVersion15);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.9" + "'", str6.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '#', 217, 42);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '#', 73, 1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("-1.0 100.0", '4');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.0 21.0", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1a-1");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("100.0#10.0#10.0#1.0100.0#10.0SU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0#10.0#10.0#1.0100.0#10.0SU" + "'", str1.equals("100.0#10.0#10.0#1.0100.0#10.0SU"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        char[] charArray8 = new char[] { '4', '#', 'a', '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1.0100.0", "aaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10Java(TM) SE Runtime Environment10", "RACLE.COM/", 12);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "######################                                     http://java.oracle.com/                                     #######################", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100 1 10 -1 1 10", '#');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0.001#0                     ", (java.lang.CharSequence[]) strArray10);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("100#1IHPOS", strArray5, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 5 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 118 + "'", int6 == 118);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("###################################################################################################################################################################################", (int) (short) 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################################################################################################################################################################" + "'", str3.equals("###################################################################################################################################################################################"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1.0#100.0", (java.lang.CharSequence) "0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        double[] doubleArray2 = new double[] { 8L, (-1) };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4', 217, 32);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "8.04-1.0" + "'", str7.equals("8.04-1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.0d + "'", double12 == 8.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "8.04-1.0" + "'", str14.equals("8.04-1.0"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "21.0a34.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("51.0");
        java.math.BigDecimal bigDecimal3 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("51.0");
        java.math.BigDecimal bigDecimal5 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("51.0");
        java.math.BigDecimal[] bigDecimalArray6 = new java.math.BigDecimal[] { bigDecimal1, bigDecimal3, bigDecimal5 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray6);
        org.junit.Assert.assertNotNull(bigDecimal1);
        org.junit.Assert.assertNotNull(bigDecimal3);
        org.junit.Assert.assertNotNull(bigDecimal5);
        org.junit.Assert.assertNotNull(bigDecimalArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "51.051.051.0" + "'", str7.equals("51.051.051.0"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("J#v#(TM) SE Runtime Environment", "Mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J#v#(TM) SE Runtime Environment" + "'", str2.equals("J#v#(TM) SE Runtime Environment"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Oracle Corporation", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie    ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444442a2a-1", (double) 28);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 28.0d + "'", double2 == 28.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sophie    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "51.", 108);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Environment10                     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Environment10                     " + "'", str1.equals("Environment10                     "));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("aa#a44444444444444444444444", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444a#" + "'", str2.equals("44444444444444444444444a#"));
    }
}

