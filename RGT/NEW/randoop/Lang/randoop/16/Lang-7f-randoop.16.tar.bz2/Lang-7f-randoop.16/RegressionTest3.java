import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Oracle Corporationi!34.0 100.0 0.0 10.0 52.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporationi!34.0 100.0 0.0 10.0 52.0" + "'", str2.equals("Oracle Corporationi!34.0 100.0 0.0 10.0 52.0"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 0, 6);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "noitaroproC elcarO", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("#4##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#4#" + "'", str1.equals("#4#"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("#4##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##4#" + "'", str1.equals("##4#"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("31.0#9.0#12.0#10.0#35.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.53#0.01#0.21#0.9#0.13" + "'", str1.equals("0.53#0.01#0.21#0.9#0.13"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:", "51.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:" + "'", str2.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "0a100a10", (java.lang.CharSequence) "h0a100a10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#-1" + "'", str1.equals("1#-1"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((-1L), (long) 8, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("24.80-b11", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("-1a2a2", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2a2a-1" + "'", str2.equals("2a2a-1"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str5 = javaVersion3.toString();
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.3" + "'", str5.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("4a#aaa#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4a#aaa#" + "'", str1.equals("4a#aaa#"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "racle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr", "                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "                      Java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie    ");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        java.lang.String[] strArray7 = null;
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie    ");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("a#####4##", strArray7, strArray10);
        java.lang.Class<?> wildcardClass12 = strArray10.getClass();
        java.lang.String[] strArray14 = null;
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie    ");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("a#####4##", strArray14, strArray17);
        java.lang.Class<?> wildcardClass19 = strArray17.getClass();
        java.lang.String[] strArray21 = null;
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie    ");
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("a#####4##", strArray21, strArray24);
        java.lang.Class<?> wildcardClass26 = strArray24.getClass();
        double[] doubleArray31 = new double[] { 100, 10L, 10.0d, 1L };
        java.lang.String str33 = org.apache.commons.lang3.StringUtils.join(doubleArray31, '#');
        java.lang.Class<?> wildcardClass34 = doubleArray31.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray35 = new java.lang.reflect.GenericDeclaration[] { wildcardClass5, wildcardClass12, wildcardClass19, wildcardClass26, wildcardClass34 };
        java.lang.String str36 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray35);
        java.lang.String str37 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray35);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 21 + "'", int4 == 21);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "a#####4##" + "'", str11.equals("a#####4##"));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "a#####4##" + "'", str18.equals("a#####4##"));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "a#####4##" + "'", str25.equals("a#####4##"));
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100.0#10.0#10.0#1.0" + "'", str33.equals("100.0#10.0#10.0#1.0"));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(genericDeclarationArray35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D" + "'", str36.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D" + "'", str37.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#######################A#####4#", (java.lang.CharSequence) "31.0#9.0#12.0#10.0#35.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("SU", "UTF-8", "#4#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SU" + "'", str3.equals("SU"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("100#1#10#-1#1#10", "_x7x8_88", "100a1a10a-1a1a1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#1#10#-1#1#10" + "'", str3.equals("100#1#10#-1#1#10"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "21.0a34.0", 30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "US", (int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("http://java.oracle.com/", "ihpos/Library/Java/JavaVirtualMachi", " ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("####US####");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("racle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "racle.com" + "'", str1.equals("racle.com"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "51.0", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.COM/RACLE.CORACLE CORPORATIONI!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("         0a100a10          ", "100414104-141410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         0a100a10          " + "'", str2.equals("         0a100a10          "));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sophie    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophie    \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1a-1");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("", "sophie", 10);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4', (int) 'a', 21);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray2, strArray6);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/L brary/Java/JavaV rtualMac n /jdk1.7.0_80.jdk/C nt nt /H m /jr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/L brary/Java/JavaV rtualMac n /jdk1.7.0_80.jdk/C nt nt /H m /jr" + "'", str1.equals("/L brary/Java/JavaV rtualMac n /jdk1.7.0_80.jdk/C nt nt /H m /jr"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0.9");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9d + "'", double1 == 0.9d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("24.80-b11");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#######################a#####4##", 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("h0a100a10", "0.0 0.1- 0.12 0.1", "Java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "h0a100a10" + "'", str3.equals("h0a100a10"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "\n", "10Java(TM) SE Runtime Environment10");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 26, (long) 12, (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(28, 35, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-1.04100.0", "10a0a1a-1a-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("UTF-8");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("##4#", (int) ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("####US####                                                                                          ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          " + "'", str2.equals("####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          "));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(" 100.0 0.0 10.0 52.0", "!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 100.0 0.0 10.0 52.0" + "'", str2.equals(" 100.0 0.0 10.0 52.0"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENT", (java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "#######################a#####4##", (java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "100#1ihpos", (java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "21.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("PLATFORM API SPECIFICATION", "sUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PLATFORM API SPECIFICATION" + "'", str2.equals("PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0a100a10", (int) 'a', "-11041004-14-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104" + "'", str3.equals("0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("100#1ihpos", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                100#1ihpos" + "'", str2.equals("                100#1ihpos"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1041004-14-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1041004-14-1" + "'", str1.equals("1041004-14-1"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0a100a10", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a100a10" + "'", str2.equals("0a100a10"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("US", "class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.7orm API Specification", "en", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7orm API Specification" + "'", str3.equals("1.7orm API Specification"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("c os x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "c os x" + "'", str1.equals("c os x"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aa#a#a4a#", (java.lang.CharSequence) "sUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("34.0 100.0 0.0 10.0 52.0", "21.7", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("10 0", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 0" + "'", str2.equals("10 0"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("#######################a#####4#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#######################a#####4#" + "'", str1.equals("#######################a#####4#"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("-1.0#100.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("a # # 4 #aaaaaaaaaaaaaaaaaaaaaaaaaa", "####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a # # 4 #aaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("a # # 4 #aaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!" + "'", str1.equals("!"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Oracle Corporationi!34.0 100.0 0.0 10.0 52.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCorporationi!34.0100.00.010.052.0" + "'", str1.equals("OracleCorporationi!34.0100.00.010.052.0"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "-1.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("_x7x8_88", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "_x7x8_88" + "'", str2.equals("_x7x8_88"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "100.0a10.0a10.0a1.0", (java.lang.CharSequence) "sunEN.ENlwawtEN.ENmacosxEN.ENLWCTENoolkit", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "100 1 10 -1 1 10EN", (java.lang.CharSequence) "sophie    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        float[] floatArray3 = new float[] { 100, 21, (byte) 10 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 10.0f + "'", float4 == 10.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "-1.0 100.0", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        short[] shortArray6 = new short[] { (short) 100, (short) 1, (byte) 10, (short) -1, (short) 1, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4', 3, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100414104-141410" + "'", str11.equals("100414104-141410"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100 1 10 -1 1 10" + "'", str13.equals("100 1 10 -1 1 10"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "2a2a-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) -1, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', 10, 10);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10#-1#100#0#-1#-1" + "'", str9.equals("10#-1#100#0#-1#-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(".0 100.0", (-1), "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".0 100.0" + "'", str3.equals(".0 100.0"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 5, 32.0f, (float) '4');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Oracle Corporationi!", (java.lang.CharSequence) "             10.14.3              ", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.7.0_80", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("racle.com/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) ".0 100.0", (java.lang.CharSequence) "0.0 0.1- 0.12 0.1", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0.9", (java.lang.CharSequence) "10 0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "100a1a10a-1a1a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a1a10a-1a1a10" + "'", str2.equals("100a1a10a-1a1a10"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("100 1 10 -1 1 10EN", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("34.0 100.0 0.0 10.0 52.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "34.0 100.0 0.0 10.0 52.0" + "'", str1.equals("34.0 100.0 0.0 10.0 52.0"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 4, "mixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mimi" + "'", str3.equals("mimi"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("mac os x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac os x" + "'", str1.equals("mac os x"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        java.lang.CharSequence charSequence0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.length(charSequence0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("class [Ljava.lang.String;class [Ljava.lang.String;", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Java Virtual Machine Specification", charSequence1, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (byte) 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("21.0a34.010a0a1a-1a-1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaa" + "'", str2.equals("aaaaaaaa"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.21.71.1", "UTF-8");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "10143", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "##################################", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                                     http://java.oracle.com/                                     ", (java.lang.CharSequence) "racle.com", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "JAVAPLATFORMAPISPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.1       ", (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.1f + "'", float2 == 1.1f);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 100, (int) (byte) 10);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        double[] doubleArray4 = new double[] { 100, 10L, 10.0d, 1L };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', 2, 0);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 1, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100.0#10.0#10.0#1.0" + "'", str6.equals("100.0#10.0#10.0#1.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "10Java(TM) SE Runtime Environment10                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("UTF-8", "http://java.oracle.com/                                                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "a4#4#444#", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 177 + "'", int2 == 177);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(":", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("SUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENT", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, charSequence1, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10143", "mac os x");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("!", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        double[] doubleArray4 = new double[] { 100, 10L, 10.0d, 1L };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', 2, 0);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.Class<?> wildcardClass12 = doubleArray4.getClass();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100.0#10.0#10.0#1.0" + "'", str6.equals("100.0#10.0#10.0#1.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("100#1ihpos", "_x7x8_88", 30, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100#1ihpos_x7x8_88" + "'", str4.equals("100#1ihpos_x7x8_88"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("##################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob", 16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "100.0#10.0#10.0#1.0100.0#10.0SU");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 100.0#10.0#10.0#1.0100.0#10.0SU");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("\n", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "va.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D", (java.lang.CharSequence) "10Java(TM) SE Runtime Environment10                                                                 ", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("####US####      ####US####      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "OracleCorporationi!34.0100.00.010.052.0", (java.lang.CharSequence) "100 1 10 -1 1 10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aa#a#a4a#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aa#a#a4a#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-1", "ORACLE CORPORATION-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie    ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "1.0#21.0#-1.0#0.0", 217);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 27 + "'", int3 == 27);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("mac os x");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("sophie    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "         0a100a10          ", charSequence1, 142);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("100a1ihpos", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a1ihpos" + "'", str2.equals("100a1ihpos"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [" + "'", str1.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class ["));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr", 100, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr" + "'", str3.equals("/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("35a10a-1a-1", "####US####                                                                                          ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("va.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [d" + "'", str1.equals("VA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [d"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4', 0, (int) 'a');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "#4#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("EN", "aaaaaa", 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "EN" + "'", str3.equals("EN"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "PLATFORM API SPECIFICATION", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mod" + "'", str1.equals("mixed mod"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("10a0a1a-1a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10a0a1a-1a-1" + "'", str1.equals("10a0a1a-1a-1"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("#4##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#4##" + "'", str1.equals("#4##"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                   ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mixed mode" + "'", str1.equals("Mixed mode"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 10, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "10Java(TM) SE Runtime Environment10", (java.lang.CharSequence) "-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-11.0#21.0#-1.0#0.0-11041004-14-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4', (int) '#', (int) ' ');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "##4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test168");
//        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getJavaHome();
//        java.io.File[] fileArray1 = new java.io.File[] { file0 };
//        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(fileArray1);
//        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) fileArray1, "Java Virtual Machine Specification");
//        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) fileArray1, '#', 177, 4);
//        org.junit.Assert.assertNotNull(file0);
//        org.junit.Assert.assertNotNull(fileArray1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str4.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("en", (double) 2.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "100.0#10.0#10.0#1.0100.0#10.0SU", (java.lang.CharSequence) "1http://java.oracle.com/", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        char[] charArray7 = new char[] { ' ', '4', '4', '4', ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.14.3", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sUN.LWAWT.MACOSX.cpRINTERjOB", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "ihpos");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.0a21.0a-1.0a0.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a21.0a-1.0a0.0" + "'", str2.equals("1.0a21.0a-1.0a0.0"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "100414104-141410");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("10 0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10 0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("35a10a-1a-1", "####US####                                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35a10a-1a-1" + "'", str2.equals("35a10a-1a-1"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sophie    ", (java.lang.CharSequence) "racle.com");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("100#1IHPOS");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sophie", "Oracle Corporation");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str5.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("100414104-141410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100414104-141410" + "'", str1.equals("100414104-141410"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.1", (java.lang.CharSequence) "1 -1", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("OracleCorporationi!34.0100.00.010.052.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sun.awt.CGraphicsEnvironment", "Mac OS X", 4, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mac OS Xawt.CGraphicsEnvironment" + "'", str4.equals("Mac OS Xawt.CGraphicsEnvironment"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "21.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("-1.0#100.0", 3, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0#100.0" + "'", str3.equals("0#100.0"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 1, (long) '#', (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie    ");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sophie", (java.lang.CharSequence[]) strArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1a-1", (java.lang.CharSequence[]) strArray8);
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "NOITACIFICEPSIPAMROFTALPAVAJ", (java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.split("Oracle Corporationi!", "!", (int) '4');
        int int19 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sUN.LWAWT.MACOSX.cpRINTERjOB", (java.lang.CharSequence[]) strArray18);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray8, strArray18);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 21 + "'", int9 == 21);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "ICEPSIPAMROFTALPAVAJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("VA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [d");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "va.lang.string;class [ljava.lang.string;class [ljava.lang.string;class [d" + "'", str1.equals("va.lang.string;class [ljava.lang.string;class [ljava.lang.string;class [d"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "####US####      ####US####      ", (java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("0.0 0.1- 0.12 0.1", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("21.0a34.010a0a1a-1a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "21.0A34.010A0A1A-1A-1" + "'", str1.equals("21.0A34.010A0A1A-1A-1"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 9, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S" + "'", str2.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1a-1", "", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1a-1" + "'", str3.equals("1a-1"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51227_1560278288", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENTSUN.AWT.CGRAPHICSENVIRONMENT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "####US####", (java.lang.CharSequence) "21.0a34.010a0a1a-1a-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104", 34, "####US####");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104" + "'", str3.equals("0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.7orm API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7orm API Specification" + "'", str1.equals("1.7orm API Specification"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("NOITACIFICEPSIPAMROFTALPAVAJ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) -1, (double) 9.0f, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 100, (int) (byte) 10);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', (int) (byte) -1, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean8 = javaVersion6.atLeast(javaVersion7);
        boolean boolean9 = javaVersion5.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean12 = javaVersion10.atLeast(javaVersion11);
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean14 = javaVersion11.atLeast(javaVersion13);
        boolean boolean15 = javaVersion5.atLeast(javaVersion11);
        boolean boolean16 = javaVersion3.atLeast(javaVersion11);
        org.apache.commons.lang3.JavaVersion javaVersion17 = null;
        try {
            boolean boolean18 = javaVersion3.atLeast(javaVersion17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "35a10a-1a-1", 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "sunEN.ENlwawtEN.ENmacosxEN.ENLWCTENoolkit", (java.lang.CharSequence) "-1a1a0a10a0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("100#1IHPOS", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#1IHPOS" + "'", str2.equals("100#1IHPOS"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "                  1.0 21.0 -1.0 0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("44#4a4#", "mixed mode", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44#4a4#" + "'", str3.equals("44#4a4#"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("14-", "/Users/sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("0#100.0", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     0#100.0" + "'", str2.equals("                     0#100.0"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaa", (java.lang.CharSequence) "mac os x", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 100 10" + "'", str9.equals("0 100 10"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0a100a10" + "'", str11.equals("0a100a10"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S" + "'", str2.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("va.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "va.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D" + "'", str2.equals("va.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproc elcaro" + "'", str1.equals("noitaroproc elcaro"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporationi!", ":", (int) ' ');
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 1, 0, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("-14242", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-14242" + "'", str2.equals("-14242"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("mac os x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS X" + "'", str1.equals("MAC OS X"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        org.apache.commons.lang3.JavaVersion javaVersion0 = null;
        try {
            boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("         0a100a10          ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 177, (double) 9L, 1.4d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4d + "'", double3 == 1.4d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10 0 1 -1 -1", "10143");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/L  # # 4 #br ry/J v /J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr", (int) (short) -1, "10a0a1a-1a-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/L  # # 4 #br ry/J v /J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr" + "'", str3.equals("/L  # # 4 #br ry/J v /J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Hi!", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("JAVAPLATFORMAPISPECIFICATION", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVAPLATFORMAPISPECIFICATION" + "'", str2.equals("JAVAPLATFORMAPISPECIFICATION"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "####US####      ####US####      ", (java.lang.CharSequence) "ORACLE CORPORATIONI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "10 0 1 -1 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44#4a4#", (java.lang.CharSequence) "0#100#10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(6, 177, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 177 + "'", int3 == 177);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("Sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        char[] charArray10 = new char[] { '4', '#', 'a', '#' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.0", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/                                                                             ", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "MAC OS X", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "noitaroproC elcarO", (int) ' ', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("100#1IHPOS");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100#1IHPOS\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          " + "'", str2.equals("####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          "));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        double[] doubleArray4 = new double[] { 1, 21, (-1.0f), 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 217, 21);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 21.0d + "'", double5 == 21.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.0d + "'", double6 == 21.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("#4##", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#4##" + "'", str2.equals("#4##"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                                                                                 ", (java.lang.CharSequence) "14-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#4#", 0, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("#", (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "11", (java.lang.CharSequence) "100.0#10.0#10.0#1.0100.0#10.0SU");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("VA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [d", 21, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [d" + "'", str3.equals("VA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS [d"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("10Java(TM) SE Runtime Environment10                                                                 ", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10J" + "'", str2.equals("10J"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("-1.0#100.0", "1http://java.oracle.com/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "#######################a#####4#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.1       ", (int) (byte) 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1       " + "'", str3.equals("1.1       "));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "#######################a#####4#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("100#1#10#-1#1#10", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("al Machine Specification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("24.80-b11", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100414104-141410");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("51.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51." + "'", str1.equals("51."));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1041004-14-1", 18, 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("####US####                                                                                          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"####US####\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        double[] doubleArray2 = new double[] { 5, (short) 0 };
        double[] doubleArray5 = new double[] { 5, (short) 0 };
        double[] doubleArray8 = new double[] { 5, (short) 0 };
        double[] doubleArray11 = new double[] { 5, (short) 0 };
        double[][] doubleArray12 = new double[][] { doubleArray2, doubleArray5, doubleArray8, doubleArray11 };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("a#####4##", "21.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4a#aaa", 28, "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444a#aaa" + "'", str3.equals("44444444444444444444444a#aaa"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Virtual Machine Specification", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "fication" + "'", str2.equals("fication"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "#######################a#####4#", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "#######################a#####4#" + "'", charSequence2.equals("#######################a#####4#"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.CPrinterJob", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "Mac OS X");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("10Java(TM) SE Runtime Environment10", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10Java(TM) SE Runtime Environment10" + "'", str2.equals("10Java(TM) SE Runtime Environment10"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("10143");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10143L + "'", long1 == 10143L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/L brary/Java/JavaV rtualMac n /jdk1.7.0_80.jdk/C nt nt /H m /jr", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.0 21.0", (java.lang.CharSequence) "100a1a10a-1a1a10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a-1" + "'", str1.equals("1a-1"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.CPrinterJob", "354104-14-1", "EN");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.4", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("mixed mode", "1.3", (int) 'a', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "m1.3" + "'", str4.equals("m1.3"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/L  # # 4 #br ry/J v /J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr", "aa#a#a4a#", "Virtual Machine Specification");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("4a#aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4a#aaa" + "'", str1.equals("4a#aaa"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("SU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sU" + "'", str1.equals("sU"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("44444444444444444444444a#aaa", 217, "####US####");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US###44444444444444444444444a#aaa" + "'", str3.equals("####US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US###44444444444444444444444a#aaa"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("_x7x8_88");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104", (java.lang.CharSequence) "Oracle Corporationi!34.0 100.0 0.0 10.0 52.0", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "##################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("2a2a-1", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-1" + "'", str2.equals("2a2a-12a2a-12a2a-12a2a-12a2a-12a2a-1"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "-1.0#100.0", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100#1ihpos", 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.7.0_80");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sUN.LWAWT.MACOSX.cpRINTERjOB", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str2.equals("sUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("44#4a4#", "                      Java", 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#" + "'", str3.equals("44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, '#', 16, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "Oracle Corporation");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("PLATFORM API SPECIFICATIO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PLATFORM API SPECIFICATIO" + "'", str1.equals("PLATFORM API SPECIFICATIO"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ", "ihpos");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          " + "'", str2.equals("####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          "));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("-1.0 100.0", '4');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "51.");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "0.9", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0 100.0" + "'", str5.equals("-1.0 100.0"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0 100.0" + "'", str8.equals("-1.0 100.0"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 2, 0);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 100 10" + "'", str9.equals("0 100 10"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0a100a10" + "'", str12.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("0a100a10", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("class [Ljava.lang.String;class [Ljava.lang.String;", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str2.equals("class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray8 = new char[] { 'a', '#', '#', '4', '#' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                 ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a#####4##" + "'", str10.equals("a#####4##"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("21.0a34.010a0a1a-1a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "21.0a34.010a0a1a-1a-1" + "'", str1.equals("21.0a34.010a0a1a-1a-1"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#" + "'", str3.equals("#"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "J", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("US", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1.0 100.0", '4');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("100.0a10.0a10.0a1.0", "", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0a10.0a10.0a1.0" + "'", str3.equals("100.0a10.0a10.0a1.0"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("44444444444444444444444a#aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444a#aa" + "'", str1.equals("44444444444444444444444a#aa"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("#######################a#####4#");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                     http://java.oracle.com/                                     ", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("100#1ihpos", "!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("mixed mod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mod" + "'", str1.equals("mixed mod"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "Mixed mode", (int) (short) 0, 28);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mixed mode" + "'", str4.equals("Mixed mode"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("\n", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/jr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/j" + "'", str1.equals("/Laa#a#a4a#brary/Java/JavaVaa#a#a4a#rtualMacaa#a#a4a#naa#a#a4a#/jdk1.7.0_80.jdk/Caa#a#a4a#ntaa#a#a4a#ntaa#a#a4a#/Haa#a#a4a#maa#a#a4a#/j"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10 0", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "100 1 10 -1 1 10EN");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("noitaroproC elcarO", "0a100a10-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-11041004-14-1-1104", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitaroproC elcarO" + "'", str3.equals("noitaroproC elcarO"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "         0a100a10          ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaa", (int) '4', 177);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                     http://java.oracle.com/                                     ", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41 + "'", int2 == 41);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION", (java.lang.CharSequence) "2a2a-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("##################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("14-", (float) 26);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 26.0f + "'", float2 == 26.0f);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.3", (int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "100 1 10 -1 1 10EN", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                     0#100.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     0#100.0" + "'", str2.equals("                     0#100.0"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "a # # 4 #");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = null;
        try {
            boolean boolean4 = javaVersion1.atLeast(javaVersion3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        short[] shortArray1 = new short[] { (short) 0 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ');
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [", (int) (short) -1, "8.04-1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [" + "'", str3.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class ["));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a#####4##", (int) (byte) 1);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("-1.0 100.0", '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray4, strArray7);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1.0 100.0" + "'", str9.equals("-1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "44444444444444444444444a#aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray9 = new char[] { '4', '#', 'a', '#' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1a2a2", charArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "44#4a4#" + "'", str15.equals("44#4a4#"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "0", (java.lang.CharSequence) "####US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US###44444444444444444444444a#aaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Java", "http://java.oracle.com/                                                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java" + "'", str2.equals("Java"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "va.lang.string;class [ljava.lang.string;class [ljava.lang.string;class [d", charSequence1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("al Machine Specification", (double) 18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.0d + "'", double2 == 18.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 0, 0.0d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("354104-14-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "354104-14-1" + "'", str1.equals("354104-14-1"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("##4#");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D" + "'", str2.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#" + "'", str2.equals("44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1.0f, 10.0d, (double) 26.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 26.0d + "'", double3 == 26.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("10J", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10J" + "'", str2.equals("10J"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("10J");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "             10.14.3              ", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("####US####                                                                                          ", "Oracle Corporation");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "sophie    ");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "SUN.AWT.cgRAPHICSeNVIRONMENT", 0, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "OracleCorporationi!34.0100.00.010.052.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "100.0a10.0a10.0a1.0", (java.lang.CharSequence) "-1a1a0a10a0", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("##################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##################################" + "'", str1.equals("##################################"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("fication", "1#-1", 26);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 0);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "al Machine Specification");
        java.lang.Class<?> wildcardClass7 = strArray4.getClass();
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "noitaroproC elcarO", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.0#21.0#-1.0#0.0", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("sUN.LWAWT.MACOSX.cpRINTERjOB");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"s\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("sophi4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophi4" + "'", str1.equals("sophi4"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("##4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#", "10a0a1a-1a-1", "1a-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#" + "'", str3.equals("##4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1 -1" + "'", str5.equals("1 -1"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1#-1" + "'", str7.equals("1#-1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                                                                                 ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa", "h0a100a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aa"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mod", ".0 100.0", 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("h0a100a10", "1041004-14-1", "-1a1a0a10a0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "h1a-11a-1" + "'", str3.equals("h1a-11a-1"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaa", "44444444444444444444444a#aa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                  1.0 21.0 -1.0 0.0", "44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#                      Java44#4a4#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  1.0 21.0 -1.0 0.0" + "'", str2.equals("                  1.0 21.0 -1.0 0.0"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("0.001 0.1-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".001 0.1-\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100.0a10.0a10.0a1.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "SU");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", '4');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) " ", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("SUN.AWT.cgRAPHICSeNVIRONMENT", "1.21.71.1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("a4#4#444#");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "#4##", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("100#1#10#-1#1#10", "0a100a10", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Mac OS X", 5, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "Oracle Corporationi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 30, 6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("21.0a34.0", "21.0A34.010A0A1A-1A-1", "ORACLE CORPORATIONI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "21.0a34.0" + "'", str3.equals("21.0a34.0"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4#", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4# " + "'", str2.equals(" aaaaaaaaaaaaaaaaaaaaaaaaaaaa##4# "));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44444444444444444444444a#aaa", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sun.lwawt.macosx.CPrinterJob", (int) ' ', 142);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 0, (byte) 1, (byte) -1, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 8, (int) (short) 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 0, (int) (short) 1);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 0, 2);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ');
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10a0a1a-1a-1" + "'", str7.equals("10a0a1a-1a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10 0" + "'", str19.equals("10 0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10 0 1 -1 -1" + "'", str21.equals("10 0 1 -1 -1"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1040414-14-1" + "'", str23.equals("1040414-14-1"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "", (java.lang.CharSequence) "noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ####US####                                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("J", "ORACLE CORPORATION-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2a2-1a2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("04100410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("-1.0 100.0", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0100.0" + "'", str2.equals("-1.0100.0"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0#100.0", 32, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0#100.0                         " + "'", str3.equals("0#100.0                         "));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("0.9", "100a1a10a-1a1a10", "racle.com");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("hi!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/", "-1a1a0a10a0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                                                 ", "                100#1ihpos", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("-1.0 100.0", "", "va.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0 100.0" + "'", str3.equals("-1.0 100.0"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("####US####      ####US####      ", "sun.awt.CGraphicsEnvironment", "                                                                                                                                                                                                                aa#a#a4a#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####US####      ####US####      " + "'", str3.equals("####US####      ####US####      "));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 1, (byte) 0, (byte) 10, (byte) 0 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "10 0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 10 0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                    -1.0 100.0", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("J", "Oracle Corporation", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sophi4", "mimi");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("-1a2a2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("####US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US###44444444444444444444444a#aaa", "100 1 10 -1 1 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US###44444444444444444444444a#aaa" + "'", str2.equals("####US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US###44444444444444444444444a#aaa"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("         0a100a10          ", "10143");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         0a100a10          " + "'", str2.equals("         0a100a10          "));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "44444444444444444444444a#aa", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "a # # 4 #", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("0.53#0.01#0.21#0.9#0.13", "Oracle Corporationi!", "#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.53#0.01#0.21#0.9#0.13" + "'", str3.equals("0.53#0.01#0.21#0.9#0.13"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("JAVAPLATFORMAPISPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"J\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("44444444444444444444444a#aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444a#aaa" + "'", str1.equals("44444444444444444444444a#aaa"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("mixed mod");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mixed mod\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("h0a100a10", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h0a100a10" + "'", str2.equals("h0a100a10"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "racle.com/", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "10a0a1a-1a-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                     0#100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.001#0                     " + "'", str1.equals("0.001#0                     "));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "10", (java.lang.CharSequence) "0.001 0.1-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("_x7x8_88");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "_X7X8_88" + "'", str1.equals("_X7X8_88"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("             10.14.3              ", (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4a#aaa", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "_X7X8_88", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "sU");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#4#", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "mixed mod", (java.lang.CharSequence) "1.0 21.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Java Virtual Machine Specification");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0a100a10" + "'", str5.equals("0a100a10"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                  1.0 21.0 -1.0 0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                  1.0 21.0 -1.0 0.0" + "'", str1.equals("                  1.0 21.0 -1.0 0.0"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.0#21.0#-1.0#0.0", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [S", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0#21.0#-1.0#0.0" + "'", str3.equals("1.0#21.0#-1.0#0.0"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 8L, (double) (short) -1, (double) 34);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 34.0d + "'", double3 == 34.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        float[] floatArray2 = new float[] { (-1.0f), (byte) 100 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4', (int) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1.0 100.0" + "'", str4.equals("-1.0 100.0"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "-1.04100.0", "a # # 4 #aaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 1, 1.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', 10, 27);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1 -1" + "'", str7.equals("1 -1"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr" + "'", str2.equals("/J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("##4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#a#####4####4#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#" + "'", str1.equals("##4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("##4#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"##4#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "h0a100a10", (java.lang.CharSequence) "EN");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray2 = null;
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceEach("                                   ", strArray1, strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                   " + "'", str3.equals("                                   "));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, " 100.0 0.0 10.0 52.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("100 1 10 -1 1 10EN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, (int) (short) 10, 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10 0", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:" + "'", str3.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "####US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US########US###44444444444444444444444a#aaa", (java.lang.CharSequence) "####US####      ####US####      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) -1, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "10J");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 10J");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("J1.0 21.0v1.0 21.0(TM) SE Runtime Environment", 177, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, charSequence1, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 'a', 35L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaa..." + "'", str2.equals("aaaaaaa..."));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("24.80-b11", "mixed mode", "c os x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun.lwawt.macosx.CPrinterJob", "/", 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", "Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "10143", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        double[] doubleArray4 = new double[] { 1, 21, (-1.0f), 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', (int) (short) 0, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 21.0d + "'", double5 == 21.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.0d + "'", double6 == 21.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "racle.com/", (java.lang.CharSequence) "/J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaa", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("OracleCorporationi!34.0100.00.010.052.0", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCorporationi!34.0100.00.010.052.0" + "'", str2.equals("OracleCorporationi!34.0100.00.010.052.0"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("100.0#10.0#10.0#1.0", (int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44#4a4#", (int) (short) 10, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "##4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#A#####4####4#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str3.equals("SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("100#1ihpos_x7x8_88", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1ihpos_x7x8_88#100" + "'", str2.equals("1ihpos_x7x8_88#100"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "-1.04100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "21.0a34.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(" 100.0 0.0 10.0 52.0", (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("11", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [", "0.0 0.1- 0.12 0.1", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [" + "'", str3.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class ["));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/L brary/Java/JavaV rtualMac n /jdk1.7.0_80.jdk/C nt nt /H m /jr", (java.lang.CharSequence) " 100.0 0.0 10.0 52.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("#######################a#####4##", "                100#1ihpos", "/L  # # 4 #br ry/J v /J v V  # # 4 #rtu lM c  # # 4 #n  # # 4 #/jdk1.7.0_80.jdk/C  # # 4 #nt  # # 4 #nt  # # 4 #/H  # # 4 #m  # # 4 #/jr");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#######################a#####4##" + "'", str3.equals("#######################a#####4##"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("14-", "sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob/sun.lwawt.macosx.CPrinterJob", "sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "14-" + "'", str3.equals("14-"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#4#", (int) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.1#.3" + "'", str4.equals("10.1#.3"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.0 21.0 -1.0 0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 21.0 -1.0 0.0" + "'", str1.equals("1.0 21.0 -1.0 0.0"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        double[] doubleArray2 = new double[] { 8L, (-1) };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', 31, (int) (short) 10);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "8.04-1.0" + "'", str7.equals("8.04-1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }
}

