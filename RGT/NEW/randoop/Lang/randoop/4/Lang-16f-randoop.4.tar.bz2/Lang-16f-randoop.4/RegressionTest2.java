import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!", 64, 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "oracle corporation", 0, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("hi", 0, 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi" + "'", str3.equals("hi"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.71.71.71.71.71.71.71.71");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.71.71.71.71.71.71.71.71\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("jAVA pLATFORM api sPECIFICATION", "###############################################################Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str2.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.7.0_80-b15", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", "t");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.14.3", "/Users/sophie/Documents/defectsaj/tmp/runarandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("oracle corporation", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         oracle corporation                                         " + "'", str2.equals("                                         oracle corporation                                         "));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!", 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "SUN.LWWT.MCOSX.cpRINTERjOB", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "en", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "", 0);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) '#', 64);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("  ", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", 25);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  " + "'", str3.equals("  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  "));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("s                         sun.lwawt.macosx.LWCToolkit", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s                         sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("s                         sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                         sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("hi1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi1." + "'", str1.equals("Hi1."));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("SUN.LW WT.M COSX.cpRINTERjOB", "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LW WT.M COSX.cpRINTERjOB" + "'", str2.equals("SUN.LW WT.M COSX.cpRINTERjOB"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophi1.", "/USERS/SOPHIEUTF-8sun.lwawt.maco");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophi1." + "'", str2.equals("/Users/sophi1."));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREx86_6x86_6x86_6x86_6x86_6x86_6x86");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-b15", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-b15" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-b15"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!", "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", (int) (byte) 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", "hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!", 2);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 35 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hi1.", (java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 306 + "'", int2 == 306);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 12, 0L, (long) 306);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.7.0_80-b15", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".7.0_80-b15" + "'", str2.equals(".7.0_80-b15"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        double[] doubleArray1 = new double[] { 1.0d };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.apache.commons.lang3.JavaVersion javaVersion0 = null;
        try {
            boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"  \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Platform API Specification", charSequence1, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "44en", (int) (short) 10, (int) (short) 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/users/sophi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) " 0.9  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str1.equals("SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                         sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "Java(TM) SE Runtime Environment", 141);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 44 + "'", int3 == 44);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        java.lang.String[] strArray3 = null;
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", "", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkit", strArray3, strArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence[]) strArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "44en", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkit" + "'", str10.equals("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophi1.7");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "a", (java.lang.CharSequence) "hi!", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("s                         sun.lwawt.macosx.LWCToolkit", 7, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "s                         sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("s                         sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.4", (java.lang.CharSequence) "...hie/Library...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7", 306, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############################################################################################################################################################################################################################################################################################################1.7" + "'", str3.equals("###############################################################################################################################################################################################################################################################################################################1.7"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                         sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "", 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/USERS/SOPHIE", "/USERS/SOPHIE");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray5, strArray10);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "/", (int) (short) 100);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray5, strArray15);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "1.2");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray18, "Mac OS X", (int) ' ', 1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "x86_64" + "'", str11.equals("x86_64"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str16.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str2.equals("sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (byte) 10, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (int) (byte) 0, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 216 + "'", int2 == 216);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "x86_6#", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" ", ' ');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence1, (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("", "", 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, "");
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/USERS/SOPHIE", "/USERS/SOPHIE");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray11, strArray16);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "/", (int) (short) 100);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray11, strArray21);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.stripAll(strArray21, "1.2");
        try {
            java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("Java(TM) SE Runtime Environmen", strArray4, strArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "x86_64" + "'", str17.equals("x86_64"));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str22.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertNotNull(strArray24);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophi1.", (long) 17);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 17L + "'", long2 == 17L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(".7.0_80-b15", 0, "1.71.71.71.71.71.71.71.71");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".7.0_80-b15" + "'", str3.equals(".7.0_80-b15"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151", (java.lang.CharSequence) "                         sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151", (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("SUN.LWWT.MCOSX.cpRINTERjOB");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SUN.LWWT.MCOSX.cpRINTERjOB\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "###############################################################################################################################################################################################################################################################################################################1.7", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/users/sophi", 44);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                /users/sophi                " + "'", str2.equals("                /users/sophi                "));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "sun.lwawt.macosx.CPrinterJo4                 sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("\n", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 7, (long) 'a', (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "x86_64", (int) 'a');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 7, 64);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Documents/defectsaj/tmp/runarandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar" + "'", str5.equals("/Users/sophie/Documents/defectsaj/tmp/runarandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070", 10, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: !IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT", '#');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophi", "/USERS/SOPHIE", (int) 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        java.lang.Class<?> wildcardClass6 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "s" + "'", str4.equals("s"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("...aTaoolkit", "hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("US");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "###############################################################################################################################################################################################################################################################################################################1.7", " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "  ", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie" + "'", str1.equals("/users/sophie"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 17, 141);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("hi1.", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi1." + "'", str2.equals("hi1."));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                            1.7.0_80-b15                                            ", (int) (byte) 100, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                            1.7.0_80-b15                                            " + "'", str3.equals("                                            1.7.0_80-b15                                            "));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.2", "       ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "                                             ...Toolkit                                             ", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "0.9", 25);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.9" + "'", str3.equals("0.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.9"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7", 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151", 7, "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151" + "'", str3.equals("71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("4                 ", "                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("mixed mode", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("hi!", "s");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s" + "'", str2.equals("s"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str2.equals("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                         oracle corporation                                         ", "44EN");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         oracle corporation                                         " + "'", str2.equals("                                         oracle corporation                                         "));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 1, (double) 17);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 17, "                                             ...Toolkit                                             ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                 " + "'", str3.equals("                 "));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java#Platform#API#Specification", 73, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444Java#Platform#API#Specification" + "'", str3.equals("444444444444444444444444444444444444444444Java#Platform#API#Specification"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference(" ", "sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str2.equals("sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/users/sophie", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie" + "'", str2.equals("/users/sophie"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("S", "                /users/sophi                ", 11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "S" + "'", str3.equals("S"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-b15", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0.9", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java HotSpot(TM) 64-Bit Server VM", "                /users/sophi                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("...hie/Library...", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...hie/Library..." + "'", str2.equals("...hie/Library..."));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("a", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...Toolkit", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", charArray9);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray9);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                 ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("0.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.9", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.9" + "'", str2.equals("0.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.9"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Users/sophi", "/USERS/SOPHIE", (int) 'a');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie", 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "s" + "'", str5.equals("s"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 306, 64);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("aaaaaaaaaaaaaaaaaaaaaaaaS");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 23 + "'", int1 == 23);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "", 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/USERS/SOPHIE", "/USERS/SOPHIE");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray4, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "sun.lwawt.macosx.CPrinterJob");
        int int14 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray9);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH", 23, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 23");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "x86_64" + "'", str10.equals("x86_64"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA PLATFORM API SPECIFICATION" + "'", str1.equals("JAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("hi1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi1." + "'", str1.equals("hi1."));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("SUN.LW WT.M COSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LW WT.M COSX.cpRINTERjOB" + "'", str1.equals("SUN.LW WT.M COSX.cpRINTERjOB"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("44en", "51.0", 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44en" + "'", str3.equals("44en"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference(".7.0_80-b15", "SUN.LWWT.MCOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWWT.MCOSX.cpRINTERjOB" + "'", str2.equals("SUN.LWWT.MCOSX.cpRINTERjOB"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("       ", "Java Virtual Machine Specification", 141);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       " + "'", str3.equals("       "));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("s", "4                 ");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "hi");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("SJava#Platform#API#Specification", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "SJava#Platform#API#Specification" + "'", str7.equals("SJava#Platform#API#Specification"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "t");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "44en", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT", "/Users/sophie/Documents/defectsaj/tmp/runarandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str2.equals("SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.71.71.71.71.71.71.71.71", 11, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.71.71.71.71.71.71.71.71" + "'", str3.equals("1.71.71.71.71.71.71.71.71"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", "                                             ...Toolkit                                             ", (int) (short) 10);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.2", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (java.lang.CharSequence) " 0.9  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 64, 0L, 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 184 + "'", int1 == 184);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaS");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  " + "'", str2.equals("  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("  ", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  " + "'", str2.equals("  "));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "SUN.LWWT.MCOSX.cpRINTERjOB", (java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("51.0");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "/USERS/SOPHIE", "", 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) ".7.0_80-b15", (java.lang.CharSequence) "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(216, (int) (short) 0, 141);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 216 + "'", int3 == 216);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151", (java.lang.CharSequence) "                                         oracle corporation                                         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) " 0.9  ", (java.lang.CharSequence) "4                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0.0f, (double) 5, (double) (-1));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                  ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("t");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"t\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "J v  Virtu l M chine Specific tion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Platform API Specification", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("SJava#Platform#API#Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: SJava#Platform#API#Specification is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.CharSequence charSequence3 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" ", ' ');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence3, (java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("51.0", strArray2, strArray6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "51.0" + "'", str8.equals("51.0"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkit", "s");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects#j/tmp/run#randoop.pl#9#37#15#0209070/target/classes:/Users/sophie/Documents/defects#j/framework/lib/test#generation/generation/randoop-current.jar", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str1.equals("SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U", (java.lang.CharSequence) ":", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-b15", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151" + "'", str3.equals("71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.9", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151", "/users/sophi");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "...Toolkit", "  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophi", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophi" + "'", str2.equals("/Users/sophi"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.CPrinterJob", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defectsaj/tmp/runarandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar", 141, 141);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...narandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar" + "'", str3.equals("...narandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.1" + "'", str1.equals("7.1"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.2", (java.lang.CharSequence) "                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) -1, 17.0d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-b15", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "mixed mode");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification", ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("444444444444444444444444444444444444444444Java#Platform#API#Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 444444444444444444444444444444444444444444Java#Platform#API#Specification is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("###############################################################################################################################################################################################################################################################################################################1.7", 45, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...##############################################..." + "'", str3.equals("...##############################################..."));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("JAVA PLATFORM API SPECIFICATION", "44en", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double[] doubleArray1 = new double[] { 1.0d };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151", "t");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151" + "'", str2.equals("71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Java(TM) SE Runtime Environmen");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM) SE Runtime Environmen\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("...aTaoolkit", 45, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                 ...aTaoolkit" + "'", str3.equals("                                 ...aTaoolkit"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort(":");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                  ", "/Users/sophie/Documents/defectsaj/tmp/runarandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  " + "'", str2.equals("                  "));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U" + "'", str1.equals("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("sun.lwawt.macosx.LWCToolkit", "x86_6#", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070", (java.lang.CharSequence) "44en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "en");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', (int) (short) 1, 0);
        java.lang.String[] strArray8 = null;
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("http://java.oracle.com/", strArray3, strArray8);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "/Users/sophi1.");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "http://java.oracle.com/" + "'", str9.equals("http://java.oracle.com/"));
        org.junit.Assert.assertNull(strArray11);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("x86_6#", "sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_6#" + "'", str3.equals("x86_6#"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) " 0.9  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre#################", "J v  Virtu l M chine Specific tion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str1.equals("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "###############################################################Java Virtual Machine Specification", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "44EN", (java.lang.CharSequence) "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkit", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", (java.lang.CharSequence) "en", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", "J v  Virtu l M chine Specific tion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                 ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAV" + "'", str1.equals("SIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAV"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("s                         sun.lwawt.macosx.LWCToolkit", "\n", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                 ...aTaoolkit", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                 ...aTaoolkit" + "'", str3.equals("                                 ...aTaoolkit"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "  ", (java.lang.CharSequence) "/USERS/SOPHIE", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sophie" + "'", str1.equals("Sophie"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 10L, (float) 17L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "sun.lw wt.m cosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Users/sophi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (java.lang.CharSequence) "hi1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "oracle corporation", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaS", "sun.lw wt.m cosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("...Toolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...Toolkit" + "'", str1.equals("...Toolkit"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("x86_6#", "44en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_6#" + "'", str2.equals("x86_6#"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.2", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "  ", (java.lang.CharSequence) "SOPHIE", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "J v  Virtu l M chine Specific tion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/SOPHIE" + "'", str4.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "", 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/USERS/SOPHIE", "/USERS/SOPHIE");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray5, strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "sun.lwawt.macosx.CPrinterJob");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray14);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence[]) strArray14);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "x86_64" + "'", str11.equals("x86_64"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Sophie", (java.lang.CharSequence) "444444444444444444444444444444444444444444Java#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                  " + "'", str1.equals("                  "));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                /users/sophi                ", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                /users/sophi                " + "'", str3.equals("                /users/sophi                "));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("51.0", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0" + "'", str3.equals("51.0"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "...##############################################...", (java.lang.CharSequence) "/USERS/SOPHIEUTF-8sun.lwawt.maco", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("4", 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                 ...aTaoolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '4', 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24.80-b11", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("0.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.9" + "'", str1.equals("0.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.9"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 12, 0.0d, (double) 18);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("x86_64", 73);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64" + "'", str2.equals("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (java.lang.CharSequence) "/", 141);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...narandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                 ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("###############################################################Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###############################################################Java Virtual Machine Specification" + "'", str1.equals("###############################################################Java Virtual Machine Specification"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("SOPHIE", "1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/", "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(".7.0_80-b15", "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".7.0_80-b15" + "'", str2.equals(".7.0_80-b15"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                         oracle corporation                                         ", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         oracle corporation                                         " + "'", str2.equals("                                         oracle corporation                                         "));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("US", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "/users/sophi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH" + "'", str1.equals("!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo4                 sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", 0, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sions:/Library/Java/JavaVirtualMach" + "'", str3.equals("sions:/Library/Java/JavaVirtualMach"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/USERS/SOPHIEUTF-8sun.lwawt.maco");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE" + "'", str1.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("SUN.LWWT.MCOSX.cpRINTERjOB");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...Toolkit", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", charArray9);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "s", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie", 9, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "phie" + "'", str3.equals("phie"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("", "", 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/USERS/SOPHIE", "/USERS/SOPHIE");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray6, strArray11);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "/", (int) (short) 100);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray6, strArray16);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray16);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "x86_64" + "'", str12.equals("x86_64"));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str17.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = null;
        try {
            boolean boolean2 = javaVersion0.atLeast(javaVersion1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment" + "'", charSequence2.equals("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("oracle corporation", "s", 6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "mixed mode");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "");
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                         sun.lwawt.macosx.LWCToolkit", "/Users/sophie/Documents/defects#j/tmp/run#randoop.pl#9#37#15#0209070/target/classes:/Users/sophie/Documents/defects#j/framework/lib/test#generation/generation/randoop-current.jar");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", strArray9, strArray16);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("...hie/Library...", strArray5, strArray9);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  ");
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", 'a');
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray23, 'a');
        try {
            java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEach("  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  ", strArray9, strArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str17.equals("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "...hie/Library..." + "'", str18.equals("...hie/Library..."));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str25.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREx86_6x86_6x86_6x86_6x86_6x86_6x86");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                 ", (java.lang.CharSequence) "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "/Users/sophie/Documents/defects#j/tmp/run#randoop.pl#9#37#15#0209070/target/classes:/Users/sophie/Documents/defects#j/framework/lib/test#generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.LW WT.M COSX.cpRINTERjOB", (java.lang.CharSequence) "                /users/sophi                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Java Virtual Machine Specification", "0.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.9", "sun.lw wt.m cosx.CPrinterJob", 7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Virtual Machine Specification" + "'", str4.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java Platform API Specification", "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "###############################################################################################################################################################################################################################################################################################################1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("JAVA PLATFORM API SPECIFICATION", "sun.lwawt.macosx.LWCToolkit", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(" ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        char[] charArray7 = new char[] { 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...Toolkit", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.4", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 18 + "'", int13 == 18);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("0.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.9", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/users/sophi", "/users/sophie", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sophi" + "'", str3.equals("/users/sophi"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "SJava#Platform#API#Specification", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("...##############################################...", (int) '4', 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("SIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAV", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-b15", "t");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaS", 11, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaS" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaS"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "7.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("44EN", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong(".7.0_80-b15");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.lw wt.m cosx.CPrinterJob", (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users/sophi1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("SUN.LW WT.M COSX.cpRINTERjOB", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWaWT.MaCOSX.cpRINTERjOB" + "'", str3.equals("SUN.LWaWT.MaCOSX.cpRINTERjOB"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 12, (long) (byte) 1, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "J v  Virtu l M chine Specific tion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("s                         sun.lwawt.macosx.LWCToolkit", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "macosx.LWCToolkit" + "'", str2.equals("macosx.LWCToolkit"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  ", "71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "http://java.oracle.com/", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.8");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", "sun.lw wt.m cosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "", 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/USERS/SOPHIE", "/USERS/SOPHIE");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray5, strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "sun.lwawt.macosx.CPrinterJob");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray14);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification", ' ');
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("SUN.LWWT.MCOSX.cpRINTERjOB", strArray14, strArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "x86_64" + "'", str11.equals("x86_64"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(strArray18);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/USERS/SOPHIEUTF-8sun.lwawt.maco", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("44EN", "/", 4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 0, 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 45, (double) 50, (double) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 50.0d + "'", double3 == 50.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", 'a');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 3, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                                    ", "################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre#################");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "s                         sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-b15" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-b15"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("x86_64", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) " 0.9  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                 ...aTaoolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("macosx.LWCToolkit", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "S");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 1, (double) (-1.0f), 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT", (java.lang.CharSequence) "Java#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!" + "'", str1.equals("hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkit", "SUN.LWaWT.MaCOSX.cpRINTERjOB");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("en", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "hi1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("\n", "en", "...##############################################...", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\n" + "'", str4.equals("\n"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 171 + "'", int2 == 171);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", (java.lang.CharSequence) "                                            1.7.0_80-b15                                            ", 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("S", (int) (byte) 1, "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "S" + "'", str3.equals("S"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "###############################################################################################################################################################################################################################################################################################################1.7", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/USERS/SOPHIE", "/USERS/SOPHIE");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "SUN.LWWT.MCOSX.cpRINTERjOB", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("SJava#Platform#API#Specification", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SJava#Platform#API#Specification" + "'", str2.equals("SJava#Platform#API#Specification"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"  \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("...##############################################...");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((-1L), (long) 184, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 184L + "'", long3 == 184L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/users/sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ihpos/sresu/" + "'", str1.equals("ihpos/sresu/"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects#j/tmp/run#randoop.pl#9#37#15#0209070/target/classes:/Users/sophie/Documents/defects#j/framework/lib/test#generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Users/sophie/Documents/defectsaj/tmp/runarandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("t");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("t");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "T" + "'", str1.equals("T"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "SJava#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                            1.7.0_80-b15                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("S", "h", "s");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "S" + "'", str3.equals("S"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!", "/Users/sophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!" + "'", str2.equals("HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 1, 4, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\n\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("7.1", "x86_6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("###############################################################################################################################################################################################################################################################################################################1.7", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###############################################################################################################################################################################################################################################################################################################1.7" + "'", str2.equals("###############################################################################################################################################################################################################################################################################################################1.7"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("s                         sun.lwawt.macosx.LWCToolkit", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", (int) (byte) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str3.equals("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "                                         oracle corporation                                         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                 ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                /users/sophi                ", "                /users/sophi                ", 0);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                              " + "'", str2.equals("                              "));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "                 ", (java.lang.CharSequence) " 0.9  ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + " 0.9  " + "'", charSequence2.equals(" 0.9  "));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.lang.CharSequence charSequence2 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/USERS/SOPHIE", "sun.lwawt.macosx.CPrinterJob", 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence2, (java.lang.CharSequence[]) strArray7);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("44EN", "/", 4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("1.7", strArray7, strArray12);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defectsaj/tmp/runarandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar", "sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence[]) strArray17);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT", strArray7, strArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 157");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.7" + "'", str13.equals("1.7"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "", 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/USERS/SOPHIE", "/USERS/SOPHIE");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray5, strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "sun.lwawt.macosx.CPrinterJob");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray14);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray14);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "x86_64" + "'", str11.equals("x86_64"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "t");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", 0, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", 97);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                /users/sophi                ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                /users/sophi                " + "'", str2.equals("                /users/sophi                "));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "  ", (java.lang.CharSequence) "  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("SOPHIE", "", "1.8");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.4", "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/users/sophi", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("4", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "/Users/sophi1.7", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                /users/sophi                ", "                /users/sophi                ", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + " " + "'", str5.equals(" "));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U", 31, 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Java#Platform#API#Specification", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification" + "'", str2.equals("Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.4", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("hi1.", "/Users/sophie/Documents/defectsaj/tmp/runarandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi1." + "'", str2.equals("hi1."));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("J v  Virtu l M chine Specific tion");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "                                             ...Toolkit                                             ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("       ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1658 + "'", int1 == 1658);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "uTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str1.equals("uTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                         oracle corporation                                         ", "aaaaaaaaaaaaaaaaaaaaaaaaS", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         " + "'", str3.equals("                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         "));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophi1.7", "/Users/sophie", "1.71.71.71.71.71.71.71.71");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophi1.7" + "'", str3.equals("/Users/sophi1.7"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "", "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "UTF-8", charSequence1, 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "JAVA PLATFORM API SPECIFICATION", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophi1.7", 171);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophi1.7" + "'", str2.equals("/Users/sophi1.7"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ", (java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          " + "'", str2.equals("               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          "));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "...narandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 10, (byte) 10, (byte) 10, (byte) -1, (byte) 1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 10 + "'", byte10 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 10 + "'", byte11 == (byte) 10);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n" + "'", str1.equals("\n"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.8", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 97, (double) 184, (double) 6L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.0d + "'", double3 == 6.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", (java.lang.CharSequence) "/USERS/SOPHIEUTF-8sun.lwawt.maco", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "...narandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar", "1.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("S");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"S\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) ' ', (int) (short) 1, 171);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 171 + "'", int3 == 171);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("hi1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi1." + "'", str1.equals("hi1."));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "44EN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.2", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("...aTaoolkit", 45);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...aTaoolkit" + "'", str2.equals("...aTaoolkit"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U", 1658, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!" + "'", str2.equals("8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("444444444444444444444444444444444444444444Java#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(" ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "                         sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.7", 31, "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8hi!UTF-8h1.7UTF-8hi!UTF-8h" + "'", str3.equals("UTF-8hi!UTF-8h1.7UTF-8hi!UTF-8h"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("x86_6#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_6#" + "'", str1.equals("x86_6#"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        float[] floatArray2 = new float[] { 31, 32.0f };
        float[] floatArray5 = new float[] { 31, 32.0f };
        float[] floatArray8 = new float[] { 31, 32.0f };
        float[] floatArray11 = new float[] { 31, 32.0f };
        float[] floatArray14 = new float[] { 31, 32.0f };
        float[][] floatArray15 = new float[][] { floatArray2, floatArray5, floatArray8, floatArray11, floatArray14 };
        float[] floatArray18 = new float[] { 31, 32.0f };
        float[] floatArray21 = new float[] { 31, 32.0f };
        float[] floatArray24 = new float[] { 31, 32.0f };
        float[] floatArray27 = new float[] { 31, 32.0f };
        float[] floatArray30 = new float[] { 31, 32.0f };
        float[][] floatArray31 = new float[][] { floatArray18, floatArray21, floatArray24, floatArray27, floatArray30 };
        float[] floatArray34 = new float[] { 31, 32.0f };
        float[] floatArray37 = new float[] { 31, 32.0f };
        float[] floatArray40 = new float[] { 31, 32.0f };
        float[] floatArray43 = new float[] { 31, 32.0f };
        float[] floatArray46 = new float[] { 31, 32.0f };
        float[][] floatArray47 = new float[][] { floatArray34, floatArray37, floatArray40, floatArray43, floatArray46 };
        float[] floatArray50 = new float[] { 31, 32.0f };
        float[] floatArray53 = new float[] { 31, 32.0f };
        float[] floatArray56 = new float[] { 31, 32.0f };
        float[] floatArray59 = new float[] { 31, 32.0f };
        float[] floatArray62 = new float[] { 31, 32.0f };
        float[][] floatArray63 = new float[][] { floatArray50, floatArray53, floatArray56, floatArray59, floatArray62 };
        float[] floatArray66 = new float[] { 31, 32.0f };
        float[] floatArray69 = new float[] { 31, 32.0f };
        float[] floatArray72 = new float[] { 31, 32.0f };
        float[] floatArray75 = new float[] { 31, 32.0f };
        float[] floatArray78 = new float[] { 31, 32.0f };
        float[][] floatArray79 = new float[][] { floatArray66, floatArray69, floatArray72, floatArray75, floatArray78 };
        float[] floatArray82 = new float[] { 31, 32.0f };
        float[] floatArray85 = new float[] { 31, 32.0f };
        float[] floatArray88 = new float[] { 31, 32.0f };
        float[] floatArray91 = new float[] { 31, 32.0f };
        float[] floatArray94 = new float[] { 31, 32.0f };
        float[][] floatArray95 = new float[][] { floatArray82, floatArray85, floatArray88, floatArray91, floatArray94 };
        float[][][] floatArray96 = new float[][][] { floatArray15, floatArray31, floatArray47, floatArray63, floatArray79, floatArray95 };
        java.lang.String str97 = org.apache.commons.lang3.StringUtils.join(floatArray96);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(floatArray69);
        org.junit.Assert.assertNotNull(floatArray72);
        org.junit.Assert.assertNotNull(floatArray75);
        org.junit.Assert.assertNotNull(floatArray78);
        org.junit.Assert.assertNotNull(floatArray79);
        org.junit.Assert.assertNotNull(floatArray82);
        org.junit.Assert.assertNotNull(floatArray85);
        org.junit.Assert.assertNotNull(floatArray88);
        org.junit.Assert.assertNotNull(floatArray91);
        org.junit.Assert.assertNotNull(floatArray94);
        org.junit.Assert.assertNotNull(floatArray95);
        org.junit.Assert.assertNotNull(floatArray96);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!", "...aTaoolkit", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("J v  Virtu l M chine Specific tion", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J v  Virtu l M chine Specific tion" + "'", str2.equals("J v  Virtu l M chine Specific tion"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("oracle corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporation" + "'", str1.equals("oracle corporation"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 1658);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str2.equals("##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "x86_6", (java.lang.CharSequence) "/USERS/SOPHIE", 1658);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "N.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment" + "'", str1.equals("N.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "x86_6", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("4                 ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("444444444444444444444444444444444444444444Java#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444Java#Platform#API#Specification" + "'", str1.equals("444444444444444444444444444444444444444444Java#Platform#API#Specification"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "en", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("...narandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar", 73);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ts/defectsaj/framework/lib/testageneration/generation/randoop-current.jar" + "'", str2.equals("ts/defectsaj/framework/lib/testageneration/generation/randoop-current.jar"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", (java.lang.CharSequence) "                  ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", charSequence2.equals("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("24.80-b11", "1.8", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence) "SUN.LWaWT.MaCOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "...Toolkit", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.1", (java.lang.CharSequence) "/users/sophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "SIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAV");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("ihpos/sresu/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "aaaaaaaaaaaaaaaaaaaaaaaaS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                 ...aTaoolkit", 31, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  ...aTaoolk" + "'", str3.equals("  ...aTaoolk"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }
}

