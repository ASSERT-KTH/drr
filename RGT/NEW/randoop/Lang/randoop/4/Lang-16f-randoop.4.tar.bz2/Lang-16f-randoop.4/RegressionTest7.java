import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151", (java.lang.CharSequence) "en", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        double[] doubleArray1 = new double[] { 1.0d };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi1.", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("aaaaaaaaaaaaaaaaaaaaaaaaS", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S" + "'", str2.equals("S"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("2.1###############", (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "                                             #T#                                             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 306);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 306.0f + "'", float2 == 306.0f);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "7.1  /LIBRARY/JAVA/JAVAVIRTUALMACHI...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1616121618", "ts/defectsaj/framework/lib/testageneration/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1616121618" + "'", str2.equals("1616121618"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 217, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "-Bit Server VM4Java HotSpot(TM) 6", (java.lang.CharSequence) "                                                                         hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophi1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHI1." + "'", str1.equals("/uSERS/SOPHI1."));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.7.0_80-B15", "icationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specificatio", "       44444444444444444       ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java(TM) SE Runtime Environmen", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime E..." + "'", str2.equals("Java(TM) SE Runtime E..."));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String[] strArray7 = new java.lang.String[] { "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", "SUN.LW WT.M COSX.cpRINTERjOB", "SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT", "sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", "sun.awt.CGraphicsEnvironment" };
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment");
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironment", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINECorporationCorporationCorporationCorporat", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo4sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 56 + "'", int1 == 56);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!u4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "terJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          a                         /v", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!", 3, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!" + "'", str3.equals("HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixed mode");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sions:/Library/Java/JavaVirtualMach", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sions:/Library/Java/JavaVirtualMach" + "'", str2.equals("sions:/Library/Java/JavaVirtualMach"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("PHIE", "/USERS/SOPHI1.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("terJob", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "erJob" + "'", str2.equals("erJob"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("RS/SOPHIEUTF-8sun.lwawt.maco");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6", 1610, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence) "TNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUs", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("ava Virtual Machine Specification", "                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava Virtual Machine Specification" + "'", str2.equals("ava Virtual Machine Specification"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Mac OS X", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left(":", 46);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151", (java.lang.CharSequence) "icationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specificatio", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            " + "'", str2.equals("            "));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  ", 43);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("N.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnv", "sun.lwawt.macosx.LWCToolkit", 17);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "N.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnv" + "'", str3.equals("N.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnv"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "en", (java.lang.CharSequence) "44444444444444444444444sophie44444444444444444444444", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "C[ ssalcnoisreVavaJ.3gnal.snommoc.ehcapa.gro ssalc");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "J", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("0.9", 305);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9                                                                                                                                                                                                                                                                                                              " + "'", str2.equals("0.9                                                                                                                                                                                                                                                                                                              "));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/", (java.lang.CharSequence) "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_6444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 305);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/USERS/SOPHIE", "sun.lwawt.macosx.CPrinterJob", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java(TM) SE Runtime Env");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", strArray5, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 13");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("SUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOB/Users/sophie", 48);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOB/Users/sophie" + "'", str2.equals("SUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOB/Users/sophie"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "edom dexim", (java.lang.CharSequence) "SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444utf-8HI!utf-8HI!utf-8HI!utf-8HI!utf-8HI!utf-8HI!utf-8HI!utf-8HI!utf-8HI!utf-8HI!utf-8HI!utf-8HI!u4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8", (int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "8-FTUaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "/Users/so                                             ...Toolkit                                             /Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Ho", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("j/tmp/run#randoop.pl#9#37#15#0209070/target/classes:/Users/sophie/Documents/defects#j/framework/lib/test#generation/generation/randoop-current.jar", "  ", "US");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Ja", 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("...aTaoolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...aTaoolkit" + "'", str1.equals("...aTaoolkit"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ihpos/sresu/", (int) (byte) 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ihpos/sresu/" + "'", str3.equals("ihpos/sresu/"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("       44444444444444444       ", "   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("noitacificepS#IPA#mroftalP#avaJS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepS#IPA#mroftalP#avaJS" + "'", str1.equals("noitacificepS#IPA#mroftalP#avaJS"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("7.1  /LIBRARY/JAVA/JAVAVIRTUALMACHI...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.1  /LIBRARY/JAVA/JAVAVIRTUALMACHI..." + "'", str1.equals("7.1  /LIBRARY/JAVA/JAVAVIRTUALMACHI..."));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("24.80-b11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("ts/defectsaj/framework/lib/testageneration/generation/randoop-current.jar", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "N.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnv", "...##############################################...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "S/SOPHIEUTF-8sun.lwawt.maco", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        char[] charArray4 = new char[] { 'a' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " ", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophi1.", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Phie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("E");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(306, 97, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("x86_64x86_avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("###############################################################################################################################################################################################################################################################################################################1.7", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT", (java.lang.CharSequence) "/Users/sophie/Documents/defects#j/tmp/run#randoop.pl#9#37#15#0209070/target/classes:/Users/sophie/Documents/defects#j/framework/lib/test#generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("  ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/" + "'", str1.equals("ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray2 = null;
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT", strArray1, strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str3.equals("SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "SENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENV");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "sun.lw wt.m cosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sun.lwawt.macosx.cprinterjo4sun.lwawt.macosx.cprinterjob", "71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.cprinterjo4sun.lwawt.macosx.cprinterjob" + "'", str2.equals("sun.lwawt.macosx.cprinterjo4sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        short[] shortArray5 = new short[] { (byte) 1, (short) -1, (byte) 0, (short) 1, (short) 1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 1 + "'", short6 == (short) 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus                 4oJretnirPC.xsocam.twawl.nus", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("uTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str1.equals("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        int[] intArray1 = new int[] { 10 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.Class<?> wildcardClass5 = intArray1.getClass();
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("a/Users/sophie/Lib");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "  ", "   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("0.9                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ", "SUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOB/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Corporation", (double) 305);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 305.0d + "'", double2 == 305.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("444444444444444444444444444444444444444444Java#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepS#IPA#mroftalP#avaJ444444444444444444444444444444444444444444" + "'", str1.equals("noitacificepS#IPA#mroftalP#avaJ444444444444444444444444444444444444444444"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/so                                             ...Toolkit                                             /Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "m" + "'", str2.equals("m"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java Platform API Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophi1.7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophi1.7\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 24, 11L, (long) 17);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 11L + "'", long3 == 11L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sions:/Library/Java/JavaVirtualMach", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                 ", 307);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/users/sophie", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREx86_6x86_6x86_6x86_6x86_6x86_6x86");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        char[] charArray8 = new char[] { 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...Toolkit", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                    ", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) ' ', (long) 45, (long) 12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/" + "'", str1.equals("avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        int[] intArray3 = new int[] { '4', 44, 30 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 30 + "'", int5 == 30);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...Library/Java/JavaVirtu...", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Llllllllllllllll/.../.phllllllllllllllll");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Llllllllllllllll/.../.phlllllllllllllll" + "'", str1.equals("Llllllllllllllll/.../.phlllllllllllllll"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", " ", "/Users/so                                             ...Toolkit                                             /Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "...hie/Library...", (java.lang.CharSequence) "ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-b15" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-b15"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("SUN.LWAWT.MACOSX.LWCTOOLKIT", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444SU");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str2.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 712);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "t", (java.lang.CharSequence) "sCorporation", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...Library/Java/JavaVirtu...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "SENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENV");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("      ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("//Users", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("N.awt.CGrapmixed modeN.awt.CGrap");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "N.AWT.CGRAPMIXED MODEN.AWT.CGRAP" + "'", str1.equals("N.AWT.CGRAPMIXED MODEN.AWT.CGRAP"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("SUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOB", "/Users/so                                             ...Toolkit                                             /Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOB" + "'", str2.equals("SUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOB"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("tiklooaTa...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "  ...aTaoolk");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "  ...aTaoolk" + "'", charSequence2.equals("  ...aTaoolk"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64", "SJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#Specification", 5, 31);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "x86_6SJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#Specification86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64" + "'", str4.equals("x86_6SJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#Specification86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification" + "'", str2.equals("Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment" + "'", str1.equals("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "bojretnirpc.xsocam.twawl.nus", (java.lang.CharSequence) "               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                         ", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("icationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "icationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification" + "'", str2.equals("icationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("x86_64x86_avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64", ".71.71.71.71.71");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("oracle corporation", "acle corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle corporation" + "'", str2.equals("oracle corporation"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophi1.7", (java.lang.CharSequence) "x86_6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ja" + "'", str1.equals("Ja"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("RS/SOPHIEUTF-8sun.lwawt.maco", 1658);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RS/SOPHIEUTF-8sun.lwawt.maco" + "'", str2.equals("RS/SOPHIEUTF-8sun.lwawt.maco"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.61.61.21.61.8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("oracleUTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitcorporation", (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sions:/Library/Java/JavaVirtualMach");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sions:/Library/Java/JavaVirtualMach" + "'", str1.equals("sions:/Library/Java/JavaVirtualMach"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("  ", "sun.lwawt.macosx.CPrinterJo4                 sun.lwawt.macosx.CPrinterJob", 0);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!", 141L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 141L + "'", long2 == 141L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophi1.7", (int) (short) 100, "          44en          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophi1.7          44en                    44en                    44en                    44e" + "'", str3.equals("/Users/sophi1.7          44en                    44en                    44en                    44e"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophi1.7          44en                    44en                    44en                    44e", "/Users/sophie#######################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophi1.7          44en                    44en                    44en                    44e" + "'", str2.equals("/Users/sophi1.7          44en                    44en                    44en                    44e"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Ja", "hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.CharSequence charSequence2 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification", (java.lang.CharSequence[]) strArray4);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "s                         sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/USERS/SOPHIE" + "'", str9.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/", (-1), "erJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/" + "'", str3.equals("ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Java Platform API Specification", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("  ...aTaoolk");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) ":Ddfjd937150209070g::Ddfjfbggdj", (java.lang.CharSequence) "          44en          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "tiklooaTa...                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (float) 712);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 712.0f + "'", float2 == 712.0f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 171, 0.0f, (float) 972);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 972.0f + "'", float3 == 972.0f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                         sun.lwawt.macosx.cprinterjo4sun.lwawt.macosx.cprinterjob", (java.lang.CharSequence) "J v  Virtu l M chine Specific tion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                         hi");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "llllllllllllllll/.../.phllllllllllllllll");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                              ", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(" ", 45);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREx86_6x86_6x86_6x86_6x86_6x86_6x86", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("       44444444444444444       ", "SUN.LWaWT.MaCOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 97L, (float) 32L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                                                                                                                                                                                                                    ", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                    " + "'", str2.equals("                                                                                                                                                                                                                                                    "));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("JAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATION");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444utf-8HI!utf-8HI!utf-8HI!utf-8HI!utf-8HI!utf-8HI!utf-8HI!utf-8HI!utf-8HI!utf-8HI!utf-8HI!utf-8HI!u4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                             ", (java.lang.CharSequence) "  ...aTaoolk");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "SUN.LWaWT.MaCOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        double[] doubleArray4 = new double[] { 52.0f, 17L, 0.0f, 45 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 52.0d + "'", double6 == 52.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 307, (long) 23, 52L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 307L + "'", long3 == 307L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "                                             ...Toolkit                                             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "mac os x", (java.lang.CharSequence) "hi1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("            ", 25, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAV" + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAV"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sCorporation", "hi1.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "24.80-b11", 3, 46);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java HotSpot(TM) 64-Bit Server VM", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest7.test184");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        java.lang.Class<?> wildcardClass2 = javaVersion0.getClass();
//        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment");
//        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
//        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", "1.2");
//        java.lang.Class<?> wildcardClass9 = strArray8.getClass();
//        java.lang.reflect.Type[] typeArray10 = new java.lang.reflect.Type[] { wildcardClass2, wildcardClass5, wildcardClass9 };
//        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
//        java.lang.Class<?> wildcardClass13 = javaVersion11.getClass();
//        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment");
//        java.lang.Class<?> wildcardClass16 = strArray15.getClass();
//        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.split("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", "1.2");
//        java.lang.Class<?> wildcardClass20 = strArray19.getClass();
//        java.lang.reflect.Type[] typeArray21 = new java.lang.reflect.Type[] { wildcardClass13, wildcardClass16, wildcardClass20 };
//        org.apache.commons.lang3.JavaVersion javaVersion22 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean23 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion22);
//        java.lang.Class<?> wildcardClass24 = javaVersion22.getClass();
//        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment");
//        java.lang.Class<?> wildcardClass27 = strArray26.getClass();
//        java.lang.String[] strArray30 = org.apache.commons.lang3.StringUtils.split("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", "1.2");
//        java.lang.Class<?> wildcardClass31 = strArray30.getClass();
//        java.lang.reflect.Type[] typeArray32 = new java.lang.reflect.Type[] { wildcardClass24, wildcardClass27, wildcardClass31 };
//        org.apache.commons.lang3.JavaVersion javaVersion33 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean34 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion33);
//        java.lang.Class<?> wildcardClass35 = javaVersion33.getClass();
//        java.lang.String[] strArray37 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment");
//        java.lang.Class<?> wildcardClass38 = strArray37.getClass();
//        java.lang.String[] strArray41 = org.apache.commons.lang3.StringUtils.split("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", "1.2");
//        java.lang.Class<?> wildcardClass42 = strArray41.getClass();
//        java.lang.reflect.Type[] typeArray43 = new java.lang.reflect.Type[] { wildcardClass35, wildcardClass38, wildcardClass42 };
//        org.apache.commons.lang3.JavaVersion javaVersion44 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean45 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion44);
//        java.lang.Class<?> wildcardClass46 = javaVersion44.getClass();
//        java.lang.String[] strArray48 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment");
//        java.lang.Class<?> wildcardClass49 = strArray48.getClass();
//        java.lang.String[] strArray52 = org.apache.commons.lang3.StringUtils.split("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", "1.2");
//        java.lang.Class<?> wildcardClass53 = strArray52.getClass();
//        java.lang.reflect.Type[] typeArray54 = new java.lang.reflect.Type[] { wildcardClass46, wildcardClass49, wildcardClass53 };
//        java.lang.reflect.Type[][] typeArray55 = new java.lang.reflect.Type[][] { typeArray10, typeArray21, typeArray32, typeArray43, typeArray54 };
//        java.lang.String str56 = org.apache.commons.lang3.StringUtils.join(typeArray55);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(strArray4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(strArray8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(typeArray10);
//        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(strArray15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(strArray19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(typeArray21);
//        org.junit.Assert.assertTrue("'" + javaVersion22 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion22.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(strArray26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(strArray30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(typeArray32);
//        org.junit.Assert.assertTrue("'" + javaVersion33 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion33.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(strArray37);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(strArray41);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(typeArray43);
//        org.junit.Assert.assertTrue("'" + javaVersion44 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion44.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(strArray48);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(strArray52);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(typeArray54);
//        org.junit.Assert.assertNotNull(typeArray55);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "aaaaaaa1.7.0_80aaaaaaaa", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("oracleUTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitcorporation");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray10 = new char[] { 'a' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...Toolkit", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.4", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71", charArray10);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SJava#Platform#API#Specification", charArray10);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lw wt.m cosx.CPrinterJob", charArray10);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification" + "'", str1.equals("java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                  ", (java.lang.CharSequence) "///////");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                              0.9", (java.lang.CharSequence) "                         sun.lwawt.macosx.LWCToolkit", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.61.61.21.61.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                         SUN.LWAWT.MACOSX.LWCTOOLKIT", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification", (java.lang.CharSequence) "                                                                                                                    ...aTaoolkit                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("tiklooaTa...", "                                             #T#                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tiklooaTa..." + "'", str2.equals("tiklooaTa..."));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATION", (java.lang.CharSequence) "4                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("444444444444444444444444444444444444444444Java#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444Java#Platform#API#Specification" + "'", str1.equals("444444444444444444444444444444444444444444Java#Platform#API#Specification"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Java Virtual Machine Specification", "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_6444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (double) 73L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 73.0d + "'", double2 == 73.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "SUN.LWaWT.MaCOSX.cpRINTERjOB", "71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7ihpos/sresu/71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("N.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", "N.AWT.CGRAPMIXED MODEN.AWT.CGRAP");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "N.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment" + "'", str2.equals("N.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        float[] floatArray6 = new float[] { (-1), 0.0f, 100, (short) -1, (short) 1, 10.0f };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + (-1.0f) + "'", float11 == (-1.0f));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.CharSequence charSequence7 = null;
        char[] charArray13 = new char[] { 'a' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...Toolkit", charArray13);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray13);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray13);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny(charSequence7, charArray13);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray13);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "...aTaoolkit", charArray13);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", charArray13);
        int int23 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151", charArray13);
        boolean boolean24 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "J", charArray13);
        boolean boolean25 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specification", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolki", 0, (int) (short) -1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                             #T#                                             ", "bojretnirpc.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                             #T#                                             " + "'", str2.equals("                                             #T#                                             "));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", 43, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str3.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("///////", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "...     ...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 11 + "'", int1 == 11);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/users/sophie", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie" + "'", str2.equals("/users/sophie"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Corporation", 307);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                    Corporation                                                                                                                                                    " + "'", str2.equals("                                                                                                                                                    Corporation                                                                                                                                                    "));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        char[] charArray5 = new char[] { 'a' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...Toolkit", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-Bit Server VM4Java HotSpot(TM) 6", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophi", "1.7.0_80", 12);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "sun.lwawt.macosx.CPrinterJob", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                         oracle corporation                                         ", "/USERS/SOPHI1.", "sun.lwawt.macosx.CPrinterJo4sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                         oracle corporation                                         " + "'", str3.equals("                                         oracle corporation                                         "));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAV");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 10, (byte) 10, (byte) 10, (byte) -1, (byte) 1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 10 + "'", byte10 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/USERS/SOPHIE", "tionasCorpor");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE" + "'", str2.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAV", (java.lang.CharSequence) "/Users/sophi1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "VM", (java.lang.CharSequence) "                                                    ", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                             #t#                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                             #t#                                             " + "'", str1.equals("                                             #t#                                             "));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("hi1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi1." + "'", str1.equals("hi1."));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("jAVA pLATFORM api sPECIFICATION", "1.71.71.71.71.71.71.71.71                                                                                                                                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str2.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.6", (java.lang.CharSequence) "   SOPHIE   ", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 5, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     " + "'", str3.equals("     "));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification1.7.0_80-B15Java Platform API Specification", (java.lang.CharSequence) "                                             #T#                                             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray5 = new char[] { '4' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "...hie/Library...", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "0.9                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.lw wt.m cosx.CPrinterJob", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("aphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", "/Users");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment" + "'", str2.equals("aphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-b15", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                             ", 171, "4444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                             4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("                             4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("...               ...Toolkit               ...");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) " 0.9  ", "...ONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("SUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOB/Users/sophie", "Java#Platform#API#Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("17.17.17.17.17.17.17.17.1", 216, 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) ' ', 48, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("###############################################################Java Virtual Machine Specification", (int) 'a', 30);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...rtual Machine Specification" + "'", str3.equals("...rtual Machine Specification"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("####################################################################################VM#####################################################################################", "SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################################################VM#####################################################################################" + "'", str3.equals("####################################################################################VM#####################################################################################"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("hi", "1.71.71.71.71.71.71.71.71", "SUN.LWAWT.MACOSX.LWCTOOLKIT");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.6", 217, 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("icationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "icationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification" + "'", str2.equals("icationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                  ", 0, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("0.9", "phie", "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          a                         /v");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 712, 0.0d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 712.0d + "'", double3 == 712.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("0.9                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.9f + "'", float1.equals(0.9f));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi", "oracle corporation");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-b15", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.9                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ", 244, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("terJob", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "sun.lwawt.macosx.CPrinterJo4sun.lwawt.macosx.CPrinterJob");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", "hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!", 2);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("ihpos/sresu/", "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("x86_6", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "x86_6" + "'", str8.equals("x86_6"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("a/Users/sophie/Lib", "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", 141);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("sCorporation");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(".71.71.71.71.71", "1.71.71.71.71.71.71.71.71");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".71.71.71.71.71" + "'", str2.equals(".71.71.71.71.71"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("J v  Virtu l M chine Specific tion");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "                             4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "SUN.LWWT.MCOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("E");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E" + "'", str1.equals("E"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 4, (float) 100, (float) 45);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/so                                             ...Toolkit                                             /Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Ho");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (java.lang.CharSequence) "tionasCorpor", 244);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("j/tmp/run#randoop.pl#9#37#15#0209070/target/classes:/Users/sophie/Documents/defects#j/framework/lib/test#generation/generation/randoop-current.jar", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j/tmp/run#randoop.pl#..." + "'", str2.equals("j/tmp/run#randoop.pl#..."));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("4                 ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.0f + "'", float1.equals(4.0f));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "en");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("x86_64", "SUN.LW WT.M COSX.cpRINTERjOB");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT", strArray4, strArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44EN", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "x86_64" + "'", str8.equals("x86_64"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str9.equals("sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("\n");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "/", (int) (short) 100);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "\n");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("VM", "tiklooaTa...                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tiklooaTa...                                 " + "'", str2.equals("tiklooaTa...                                 "));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "######");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("JAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATION", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("tiklooaTa...                                 ", "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 100, (float) 52L, (float) 2L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("sions:/Library/Java/JavaVirtualMach");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sions:/Library/Java/JavaVirtualMach" + "'", str1.equals("sions:/Library/Java/JavaVirtualMach"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "SUN.LW WT.M COSX.cpRINTERjOB", (java.lang.CharSequence) "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("mixed#mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed#mode" + "'", str1.equals("mixed#mode"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "44444444444444444444444sophie44444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINECorporationCorporationCorporationCorporat");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("tiklooTCWL.xsocam.twawl.nus!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!iheihpos/sresU/!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ihtiklooTCWL.xsocam.twawl.nus!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU" + "'", str2.equals("ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "oracle corporation", "a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 64.0f, 0.0d, (double) 245);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 245.0d + "'", double3 == 245.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophi1.", "44444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophi1." + "'", str2.equals("/Users/sophi1."));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "icationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray10 = new char[] { 'a' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...Toolkit", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone(charSequence4, charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", charArray10);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "...aTaoolkit", charArray10);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!", charArray10);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre#################", (java.lang.CharSequence) "tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 213 + "'", int2 == 213);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("oracle corporation", "s", 6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "mixed mode");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "");
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                         sun.lwawt.macosx.LWCToolkit", "/Users/sophie/Documents/defects#j/tmp/run#randoop.pl#9#37#15#0209070/target/classes:/Users/sophie/Documents/defects#j/framework/lib/test#generation/generation/randoop-current.jar");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", strArray9, strArray16);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("...hie/Library...", strArray5, strArray9);
        java.lang.String[] strArray22 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", "                                             ...Toolkit                                             ", (int) (short) 10);
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.stripAll(strArray22);
        try {
            java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEach("1.5", strArray5, strArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str17.equals("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "...hie/Library..." + "'", str18.equals("...hie/Library..."));
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(strArray23);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Phie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Phie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("x86_6#", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        int[] intArray1 = new int[] { 10 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        double[] doubleArray2 = new double[] { 972, 141 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 972.0d + "'", double3 == 972.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("mixed#mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed#mode" + "'", str1.equals("mixed#mode"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("...Toolkit", "                                                                                                                                        UTF-8", (int) (byte) 10);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                                                                                                        UTF-8", (java.lang.CharSequence[]) strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (java.lang.CharSequence[]) strArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(10.0d, (double) (byte) -1, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("  /LIBRARY/JAVA/JAVAVIRTUALMACHI...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"  /LIBRARY/JAVA/JAVAVIRTUALMACHI...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 73, (long) 50, 244L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 244L + "'", long3 == 244L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Users/sophi1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophi1.7" + "'", str1.equals("/Users/sophi1.7"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 64);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                " + "'", str2.equals("                                                                "));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 141);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#############################################################################################################################################" + "'", str2.equals("#############################################################################################################################################"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) ":Ddfjd937150209070g::Ddfjfbggdj");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                         ", "Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                         " + "'", str2.equals("                         "));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsE", (int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str1.equals("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                                                    ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("SUN.LWaWT.MaCOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWaWT.MaCOSX.cpRINTERjOB" + "'", str1.equals("SUN.LWaWT.MaCOSX.cpRINTERjOB"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "US44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "     ", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("US44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.awt.CGraphicsEnvironment", (long) 17);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 17L + "'", long2 == 17L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "...##############################################...", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "SIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAV");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironment", " ");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, ' ', 35, (int) (short) 1);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", 100);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U", strArray8, strArray16);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray16);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", (java.lang.CharSequence[]) strArray18);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray18);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U" + "'", str17.equals("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 46, (double) (byte) -1, (double) 17.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7ihpos/sresu/71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.", (java.lang.CharSequence) "                                                                                                                                        UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi", (int) (short) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi" + "'", str3.equals("hi"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java(TM) SE Runtime Environment", (double) 244L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 244.0d + "'", double2 == 244.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str4 = javaVersion3.toString();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        boolean boolean9 = javaVersion5.atLeast(javaVersion7);
        java.lang.String str10 = javaVersion5.toString();
        boolean boolean11 = javaVersion3.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        boolean boolean15 = javaVersion3.atLeast(javaVersion12);
        boolean boolean16 = javaVersion0.atLeast(javaVersion12);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.9" + "'", str4.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.1" + "'", str10.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                             4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.61.61.21.61.8");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.5", "a");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 48, (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-Bit Server VM4Java HotSpot(TM) 6", (java.lang.CharSequence) "mixed#mode", 56);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ", 712);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("          44en          ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0.9                                                                                                                                                                                                                                                                                                              ", 35, "S");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9                                                                                                                                                                                                                                                                                                              " + "'", str3.equals("0.9                                                                                                                                                                                                                                                                                                              "));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("J v  Virtu l M chine Specific tion", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("SJava#Platform#API#Specification", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SJava#Platform#API#Specification" + "'", str2.equals("SJava#Platform#API#Specification"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                oracle corporation                     ###############################################################Java Virtual Machine Specification", "SJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(4L, 0L, (long) 216);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 216L + "'", long3 == 216L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "...     ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Phie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(1.0f, 217.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("phie7.1", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("44en", "hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44en" + "'", str2.equals("44en"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("HI!", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444SU");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("terJob", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", 50, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str3.equals("71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("oracle corporation", "s", 6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "mixed mode");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                         sun.lwawt.macosx.LWCToolkit", "/Users/sophie/Documents/defects#j/tmp/run#randoop.pl#9#37#15#0209070/target/classes:/Users/sophie/Documents/defects#j/framework/lib/test#generation/generation/randoop-current.jar");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", strArray8, strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("...hie/Library...", strArray4, strArray8);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ");
        int int20 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str16.equals("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "...hie/Library..." + "'", str17.equals("...hie/Library..."));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "oracle corporation" + "'", str19.equals("oracle corporation"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) '#', 1L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        char[] charArray8 = new char[] { 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...Toolkit", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                    ", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOB", charSequence1, 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("x86_64x86_avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64", ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", 56);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo4                 sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "PHIE", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo4sun.lwawt.macosx.CPrinterJob", 307);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("macosx.LWCToolkit", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "macosx.LWCToolkit" + "'", str2.equals("macosx.LWCToolkit"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "                         sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "va");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                             ...Toolkit                                             ", "x86_6", 24);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          x86_6         " + "'", str3.equals("          x86_6         "));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", "       44444444444444444       ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd(":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals(":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH", "...     ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4                 ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("   ", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "                                            1.7.0_80-b15                                            ", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) ' ', (double) 0L, 35.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "TNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUs");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                                                                                                                                    Corporation                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                         ", 171);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                 " + "'", str2.equals("               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                 "));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                /users/sophi                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("en", 30, "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironmenten" + "'", str3.equals("sun.awt.CGraphicsEnvironmenten"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8" + "'", str1.equals("!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "aaaaaaa1.7.0_80aaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                              ", (java.lang.CharSequence) "US44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "  ", (java.lang.CharSequence) "                                                oracle corporation                     ###############################################################Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "                                             ...Toolkit                                           ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        float[] floatArray4 = new float[] { 245, 18, 52.0f, 141 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 245.0f + "'", float5 == 245.0f);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Java Platform API Specification");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, " ");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", "                                             ...Toolkit                                             ", (int) (short) 10);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("##", strArray4, strArray10);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "icationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specificatio", (java.lang.CharSequence[]) strArray12);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "##" + "'", str11.equals("##"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("...aTaoolkit", "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                                                                                                                                                                                                                                                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                oracle corporation                     ###############################################################Java Virtual Machine Specification", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                oracle corporation                     ###############################################################Java Virtual Machine Specification" + "'", str2.equals("                                                oracle corporation                     ###############################################################Java Virtual Machine Specification"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 15, " ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               " + "'", str3.equals("               "));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "PI SPECIFICATIONJAVA PLAT", (java.lang.CharSequence) "avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 52, (float) 244, (float) 25);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 244.0f + "'", float3 == 244.0f);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 216, 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 216 + "'", int3 == 216);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION", (java.lang.CharSequence) "/Users/sophie/Documents/defects#j/tmp/run#randoop.pl#9#37#15#0209070/target/classes:/Users/sophie/Documents/defects#j/framework/lib/test#generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151", 245);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151" + "'", str2.equals("1.71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Java(TM) SE Runtime Env", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU" + "'", str1.equals("Ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("                                             ...Toolkit                                             ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (byte) -1);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                         sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "acle corporation", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 45 + "'", int6 == 45);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070", "######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("tiklooTCWL.xsocam.twawl.nus!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!iheihpos/sresU/!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ihtiklooTCWL.xsocam.twawl.nus!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"tiklooTCWL.xsocam.twawl.nus!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!iheihpos/sresU/!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ihtiklooTCWL.xsocam.twawl.nus!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU!ih8-FTU\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.4", "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_6444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("noitacificepS#IPA#mroftalP#avaJ444444444444444444444444444444444444444444", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepSIPAmroftalPavaJ444444444444444444444444444444444444444444" + "'", str2.equals("noitacificepSIPAmroftalPavaJ444444444444444444444444444444444444444444"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("###############1.2", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray5 = null;
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray5, strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("jAVA pLATFORM api sPECIFICATION", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str9.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("x86_6SJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#Specification86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_6SJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#Specification86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64" + "'", str2.equals("x86_6SJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#Specification86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "t");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151", "/uSERS/SOPHI1.", "                                                                         ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 216, (long) 44, (long) 45);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 44L + "'", long3 == 44L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...Toolkit", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray9);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "44444444444444444444444    44444444444444444444444", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(217.0f, (float) 46, (float) 141L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 46.0f + "'", float3 == 46.0f);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java(TM) SE Runtime Env", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "J");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Env" + "'", str3.equals("Java(TM) SE Runtime Env"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          " + "'", str2.equals("               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          "));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        short[] shortArray5 = new short[] { (byte) 1, (short) -1, (byte) 0, (short) 1, (short) 1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.Class<?> wildcardClass12 = shortArray5.getClass();
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 1 + "'", short6 == (short) 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 1 + "'", short11 == (short) 1);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 31, (float) 100, (float) 31);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 31.0f + "'", float3 == 31.0f);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                             ...Toolkit                                           ", "aphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", "                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                             ...Toolkit                                           " + "'", str3.equals("                                             ...Toolkit                                           "));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("icationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specificatio", "j/tmp/run#randoop.pl#...", 46);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.1", "sun.lwawt.macosx.CPrinterJo4sun.lwawt.macosx.CPrinterJob");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!u4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.awt.CGraphicsEnvironmenten", "sun.awt.cgraphicsenvironment", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aaaaaaa1.7.0_80aaaaaaaa", (java.lang.CharSequence) "s");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                                                                                                                                    Corporation                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...rtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                                                                                                                                                                                                    ", (int) (short) -1, 43);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                        ..." + "'", str3.equals("                                        ..."));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "SJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#Specification", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("JAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATION" + "'", str1.equals("JAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, charSequence1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsE", 73.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 73.0d + "'", double2 == 73.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 244);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/USERS/SOPHI1.", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHI1./USERS/SOPHI1./USERS/SOPHI1./USERS/SOPHI1." + "'", str2.equals("/USERS/SOPHI1./USERS/SOPHI1./USERS/SOPHI1./USERS/SOPHI1."));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "Java(TM) SE Runtime Environmen", 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("TNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUs");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070", 2, 45);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("N.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment" + "'", str1.equals("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                         ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                             4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "SOPHIE", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("444444444444444444444444444444444444444444Java#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", '#');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "", 0);
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                  ", (java.lang.CharSequence[]) strArray5);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification", "                  ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification" + "'", str3.equals("Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsE", "!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8-ftu!ih8", "1.7.0_80-b15");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#######################", 44, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "PHIE", charSequence1, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "edom dexi", (java.lang.CharSequence) "n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                             ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                ", 30, "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                " + "'", str3.equals("                                                oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                "));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                                         hi");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 75 + "'", int1 == 75);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "", 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/USERS/SOPHIE", "/USERS/SOPHIE");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray5, strArray10);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "/", (int) (short) 100);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray5, strArray15);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "1.2");
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray18, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray18);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "x86_64" + "'", str11.equals("x86_64"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str16.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUsers/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str20.equals("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarUsers/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("...Toolkit", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...Toolkit" + "'", str2.equals("...Toolkit"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str1.equals("71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "US44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "S", 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "          x86_6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("SUN.LWAWT.MACOSX.LWCTOOLKIT", "J", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.7.0_80-b15", "                                                                         hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("en", (int) (byte) 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                    oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                          ", (java.lang.CharSequence) "ava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a" + "'", str1.equals("a"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("T", "      ", (int) (short) -1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "noitacificepS#IPA#mroftalP#avaJS", 0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("phie7.1", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "phie7.1" + "'", str2.equals("phie7.1"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", (java.lang.CharSequence) "/USERS/SOPHIEUTF-8sun.lwawt.maco");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophi1.7", (java.lang.CharSequence) "SUN.LW WT.M COSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "a/Users/sophie/Lib");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                                                                                                                                                                                                                                                                                                  ", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "           " + "'", str2.equals("           "));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                             ...Toolkit                                             ", "", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.cprinterjo4sun.lwawt.macosx.cprinterjob", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.cprinterjo4sun.lwawt.macosx.cprinterjob" + "'", str2.equals("sun.lwawt.macosx.cprinterjo4sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center(":1.8", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":1.8" + "'", str2.equals(":1.8"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("   SOPHIE   ", ":Ddfjd937150209070g::Ddfjfbggdj");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "###############################################################################################################################################################################################################################################################################################################1.7", "!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...Toolkit", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", charArray9);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "...aTaoolkit", charArray9);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "UTF-8hi!UTF-8h1.7UTF-8hi!UTF-8h");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("x86_6#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: x86_6# is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("tionasCorpor", "-Bit Server VM4Java HotSpot(TM) 6", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Sophie", "sions:/Library/Java/JavaVirtualMach", 217);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("TNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUs", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) ":Ddfjd937150209070g::Ddfjfbggdj");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        double[] doubleArray1 = new double[] { 1.0d };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_6444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_6444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_6444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) ":Ddfjd937150209070g::Ddfjfbggdj", (java.lang.CharSequence) "44444444444444444444444    44444444444444444444444", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt", charSequence1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("7.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Hi1.", 216);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                    Hi1." + "'", str2.equals("                                                                                                                                                                                                                    Hi1."));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "J", (java.lang.CharSequence) "ihpos/sresu/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaa1.7.0_80aaaaaaaa", 52, "SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJOBSaaaaaaa1.7.0_80aaaaaaaa" + "'", str3.equals("SUN.LWAWT.MACOSX.CPRINTERJOBSaaaaaaa1.7.0_80aaaaaaaa"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                         oracle corporation                                         ", "mac os x");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}

