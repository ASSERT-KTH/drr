import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                         oracle corporation                                         ", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         oracle corporation                                         " + "'", str2.equals("                                         oracle corporation                                         "));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("J v  Virtu l M chine Specific tion", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophi", (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 0L, (long) 64);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        java.lang.Object[] objArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(objArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "bojretnirpc.xsocam.twawl.nus", "...hie/Library...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64", "SOPHIE");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                            1.7.0_80-b15                                            ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.8", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREx86_6x86_6x86_6x86_6x86_6x86_6x86");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("...aTaoolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...aTaoolkit" + "'", str1.equals("...aTaoolkit"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase(":", "0.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "###############################################################Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("24.80-b11", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "44444444444444444444444    44444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 7, (long) 17, (long) 23);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Corporation", 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "Java(TM) SE Runtime Environmen");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment" + "'", charSequence2.equals("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                    ", (float) 11);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 11.0f + "'", float2 == 11.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.7.0_80-b15", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, charSequence1, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("###############1.2");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###############1.2\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINE" + "'", str2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINE"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defectsaj/tmp/runarandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar", "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkit", ":");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":Ddfjd937150209070g::Ddfjfbggdj" + "'", str3.equals(":Ddfjd937150209070g::Ddfjfbggdj"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", 17, "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str3.equals("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "SENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENV", (java.lang.CharSequence) "/Users/so                                             ...Toolkit                                             /Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.71.71.71.71.71.71.71.71", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.71.71.71.71.71.71.71.71" + "'", str4.equals("1.71.71.71.71.71.71.71.71"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("SJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("44444444444444444444444sophie44444444444444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironmenthi!sun.awt.cgraphicsenvironment", "0.9", "sCorporation");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/", "N.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "uTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 245 + "'", int1 == 245);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "a", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str1.equals("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "44444444444444444444444sophie44444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("VM", 171, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################################################VM#####################################################################################" + "'", str3.equals("####################################################################################VM#####################################################################################"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("jAVA pLATFORM api sPECIFICATION", "1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str2.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                                                                                                                        UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                        UTF-8" + "'", str1.equals("                                                                                                                                        UTF-8"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        char[] charArray7 = new char[] { 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...Toolkit", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                    ", charArray7);
        java.lang.Class<?> wildcardClass13 = charArray7.getClass();
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                /users/sophi                ", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/Users/sophi1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophi1.7" + "'", str1.equals("/Users/sophi1.7"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "8-FTUaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("US", 184, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("US44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("JAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATION", "UTF-8hi!UTF-8h1.7UTF-8hi!UTF-8h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATION" + "'", str2.equals("JAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "oracle corporation", "sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "tiklooaTa...                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH", "Corporation", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                         oracle corporation                                         ", (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "edom dexim" + "'", str1.equals("edom dexim"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("US44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"US44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("J v  Virtu l M chine Specific tion", "x86_6");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaS", (java.lang.CharSequence) "Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification", 306);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "8-FTUaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.cgraphicsenvironment", "                                                oracle corporation                     ###############################################################Java Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 100, 216);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("jAVA pLATFORM api sPECIFICATION", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "...aTaoolkit", (java.lang.CharSequence) "                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH", "hi");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH" + "'", str4.equals("!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U", "1.1");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("SJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                                oracle corporation                     ###############################################################Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophi1.7", "x86_6#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophi1.7" + "'", str2.equals("/Users/sophi1.7"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151", (java.lang.CharSequence) "/", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "phie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "icationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification" + "'", str2.equals("icationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (-1L), (float) 245, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 245.0f + "'", float3 == 245.0f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("44EN");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(" ", "N.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnv", (int) '#');
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "llllllllllllllll/.../.phllllllllllllllll", (java.lang.CharSequence) "####################################################################################VM#####################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "E");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie", (int) (byte) 10, "                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("VM", "1.7.0_80-b15", "US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VM" + "'", str3.equals("VM"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("llllllllllllllll/.../.phllllllllllllllll", "TNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUs");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "llllllllllllllll/.../.phllllllllllllllll" + "'", str2.equals("llllllllllllllll/.../.phllllllllllllllll"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("SOPHIE", 245);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SOPHIE" + "'", str2.equals("SOPHIE"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray11 = new char[] { 'a' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...Toolkit", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny(charSequence5, charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray11);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "...aTaoolkit", charArray11);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", charArray11);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.awt.cgraphicsenvironment", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 6, 0.0f, (float) 306);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/USERS/SOPHIE");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("###############################################################Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###############################################################Java Virtual Machine Specification" + "'", str1.equals("###############################################################Java Virtual Machine Specification"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"s\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("JAVA PLATFORM API SPECIFICATION", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "44en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 0, 1658);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1658 + "'", int3 == 1658);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", 44, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          " + "'", str1.equals("                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          "));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "SUN.LW WT.M COSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.2", 'a');
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("...aTaoolkit", strArray3, strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "...aTaoolkit" + "'", str5.equals("...aTaoolkit"));
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest4.test103");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        java.lang.Class<?> wildcardClass2 = javaVersion0.getClass();
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "N.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", 184, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444" + "'", str2.equals("44444444444444444"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 245, 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 45, 25);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom" + "'", str2.equals("Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "7.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.awt.cgraphicsenvironment", (java.lang.CharSequence) "                                 ...aTaoolkit", 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("t", 216);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt" + "'", str2.equals("tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "TNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUs", (java.lang.CharSequence) "  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  ", 141);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("boJretnirPC.xsocam.twawl.nus                 4oJretnirPC.xsocam.twawl.nus", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "boJretnirPC.xsocam.twawl.nus                 4oJretnirPC.xsocam.twawl.nus" + "'", str2.equals("boJretnirPC.xsocam.twawl.nus                 4oJretnirPC.xsocam.twawl.nus"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATIONJAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("N.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnv", "/LIBRARY/JAVA/JAVAVIRTUALMACHINE", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ts/defectsaj/framework/lib/testageneration/generation/randoop-current.jar", "/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "E", (java.lang.CharSequence) "a/Users/sophie/Lib");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java Platform API Specification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Oracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation", "...aTaoolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation" + "'", str2.equals("Oracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("44444444444444444444444    44444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lwawt.macosx.CPrinterJo4                 sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                         oracle corporation                                         ", "sions:/Library/Java/JavaVirtualMach", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) '4', (double) 7, (double) 0.9f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8999999761581421d + "'", double3 == 0.8999999761581421d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "VM", (java.lang.CharSequence) "http://java.oracle.com/", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Corporation", "  ...aTaoolk");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  ...aTaoolk" + "'", str2.equals("  ...aTaoolk"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(28, 9, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.CPrinterJob\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Documents/defects#j/tmp/run#randoop.pl#9#37#15#0209070/target/classes:/Users/sophie/Documents/defects#j/framework/lib/test#generation/generation/randoop-current.jar", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j/tmp/run#randoop.pl#9#37#15#0209070/target/classes:/Users/sophie/Documents/defects#j/framework/lib/test#generation/generation/randoop-current.jar" + "'", str2.equals("j/tmp/run#randoop.pl#9#37#15#0209070/target/classes:/Users/sophie/Documents/defects#j/framework/lib/test#generation/generation/randoop-current.jar"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("uTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"uTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                            1.7.0_80-b15                                            ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.71.71.71.71.71.71.71.71", 184, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.71.71.71.71.71.71.71.71                                                                                                                                                               " + "'", str3.equals("1.71.71.71.71.71.71.71.71                                                                                                                                                               "));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", 50, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "va" + "'", str3.equals("va"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.71.71.71.71.71.71.71.71", 245);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", "SJava#Platform#API#Specification");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "phie");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str4.equals("sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "s                         sun.lwawt.macosx.LWCToolkit", 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", charSequence2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                         sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        java.lang.String[] strArray7 = new java.lang.String[] { "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", "SUN.LW WT.M COSX.cpRINTERjOB", "SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT", "sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", "sun.awt.CGraphicsEnvironment" };
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification", 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', (int) (byte) 100, (int) (byte) 10);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Java Platform API Specification");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("S", strArray8, strArray11);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "S" + "'", str12.equals("S"));
        org.junit.Assert.assertNotNull(strArray13);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("sun.awt.CGraphicsEnvironment", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64", 44, 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "icationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification", 141);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.2", 'a');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolki", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkit", "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", "               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment" + "'", str2.equals("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("SJava#Platform#API#Specification", "ts/defectsaj/framework/lib/testageneration/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SJava#Platform#API#Specification" + "'", str2.equals("SJava#Platform#API#Specification"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "...hie/Library...", (java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 184L, (float) 184, 10.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 184.0f + "'", float3 == 184.0f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("va", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "va" + "'", str2.equals("va"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 217 + "'", int1 == 217);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tnemnorivnescihpargc.twa.nus" + "'", str1.equals("tnemnorivnescihpargc.twa.nus"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("s                         sun.lwawt.macosx.LWCToolkit", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "44444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.9", (java.lang.CharSequence) "Oracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", "                                             ...Toolkit                                             ", (int) (short) 10);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 100, 0);
        java.lang.Class<?> wildcardClass8 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "Corporation", "                                            1.7.0_80-b15                                            ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sun.awt.cgraphicsenvironment", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.cgraphicsenvironment" + "'", str2.equals("sun.awt.cgraphicsenvironment"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!", 216, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("h", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h" + "'", str2.equals("h"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("51.0", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 1658, (long) (short) 0, (long) 46);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1658L + "'", long3 == 1658L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sions:/Library/Java/JavaVirtualMach", 1658);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sions:/Library/Java/JavaVirtualMach" + "'", str2.equals("sions:/Library/Java/JavaVirtualMach"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween(".7.0_80-b15", "HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!", "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (java.lang.CharSequence) "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "...hie/Library...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Mac OS X", 217, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMac OS X" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMac OS X"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("VM", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VM" + "'", str2.equals("VM"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("       ", "                         sun.lwawt.macosx.LWCToolkit", "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "///////" + "'", str3.equals("///////"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 171);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "SOPHIE", "1.71.71.71.71.71.71.71.71", 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str4.equals("UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt", (java.lang.CharSequence) "edom dexim");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                             #T#                                             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "hi");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 46, (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("44EN", "71.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44EN" + "'", str2.equals("44EN"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("ihpos/sresu/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("SUN.LWaWT.MaCOSX.cpRINTERjOB", "               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWaWT.MaCOSX.cpRINTERjOB" + "'", str2.equals("SUN.LWaWT.MaCOSX.cpRINTERjOB"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREx86_6x86_6x86_6x86_6x86_6x86_6x86");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREx86_6x86_6x86_6x86_6x86_6x86_6x86" + "'", str3.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREx86_6x86_6x86_6x86_6x86_6x86_6x86"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("10.14.3", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Oracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Oracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lw wt.m cosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/USERS/SOPHIEUTF-8sun.lwawt.maco");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                /users/sophi                ", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                /users/sophi                " + "'", str2.equals("                /users/sophi                "));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "          ", (java.lang.CharSequence) "################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre#################", 45);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("a/Users/sophie/Lib", "1.1", "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a/Users/sophie/Lib" + "'", str3.equals("a/Users/sophie/Lib"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("/Users/sophi", "/USERS/SOPHIE", (int) 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.Class<?> wildcardClass7 = strArray5.getClass();
        java.lang.Class<?> wildcardClass8 = strArray5.getClass();
        short[] shortArray14 = new short[] { (byte) 1, (short) -1, (byte) 0, (short) 1, (short) 1 };
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray14);
        short short16 = org.apache.commons.lang3.math.NumberUtils.max(shortArray14);
        short short17 = org.apache.commons.lang3.math.NumberUtils.max(shortArray14);
        short short18 = org.apache.commons.lang3.math.NumberUtils.max(shortArray14);
        java.lang.Class<?> wildcardClass19 = shortArray14.getClass();
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment");
        java.lang.Class<?> wildcardClass22 = strArray21.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray23 = new java.lang.reflect.GenericDeclaration[] { wildcardClass1, wildcardClass8, wildcardClass19, wildcardClass22 };
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray23);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "s" + "'", str6.equals("s"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 1 + "'", short15 == (short) 1);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 1 + "'", short16 == (short) 1);
        org.junit.Assert.assertTrue("'" + short17 + "' != '" + (short) 1 + "'", short17 == (short) 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 1 + "'", short18 == (short) 1);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(genericDeclarationArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Sclass [Ljava.lang.String;" + "'", str24.equals("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Sclass [Ljava.lang.String;"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 46);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "t");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 244 + "'", int2 == 244);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(":", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJOB" + "'", str1.equals("SUN.LWAWT.MACOSX.CPRINTERJOB"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defectsaj/tmp/runarandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo4sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) '4', (long) 'a', (long) 73);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.9", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo4                 sun.lwawt.macosx.CPrinterJob", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/" + "'", str2.equals("avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", '#');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Mac OS X");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "4", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(17.0f, (float) 97, 30.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 17.0f + "'", float3 == 17.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("j/tmp/run#randoop.pl#9#37#15#0209070/target/classes:/Users/sophie/Documents/defects#j/framework/lib/test#generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                             #T#                                             ", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("tnemnorivnescihpargc.twa.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tnemnorivnescihpargc.twa.nus" + "'", str1.equals("tnemnorivnescihpargc.twa.nus"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("10.14.3", "bojretnirpc.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "US44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7", (double) 50);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7d + "'", double2 == 1.7d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "SUN.LW WT.M COSX.cpRINTERjOB", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.lwawt.macosx.CPrinterJo4                 sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mixed#mode", "0.9", 11);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "tiklooaTa...                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "###############1.2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Documents/defectsaj/tmp/runarandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defectsaj/tmp/runarandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defectsaj/tmp/runarandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                                                oracle corporation                     ###############################################################Java Virtual Machine Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                oracle corporation                     ###############################################################Java Virtual Machine Specification" + "'", str2.equals("                                                oracle corporation                     ###############################################################Java Virtual Machine Specification"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 6, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "######" + "'", str3.equals("######"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("  ...aTaoolk", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Java HotSpot(TM) 64-Bit Server VM", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophi", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "US", 216, (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophi" + "'", str3.equals("/Users/sophi"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("      ", "N.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnv");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      " + "'", str2.equals("      "));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "llllllllllllllll/.../.phllllllllllllllll", (java.lang.CharSequence) "/Users/sophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) (byte) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.71.71.71.71.71.71.71.71                                                                                                                                                               ", "                                                                                              0.9", "1.7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.71.71.71.71.71.71.71.71                                                                                                                                                               " + "'", str3.equals("1.71.71.71.71.71.71.71.71                                                                                                                                                               "));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("24.80-b11", "      ", "                /users/sophi                ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo4                 sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "/Users/sophie", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        long[] longArray3 = new long[] { 0L, (short) 100, (-1L) };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (-1), (long) 44, (long) 23);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("a", (int) (short) 0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Sclass [Ljava.lang.String;", "44444444444444444444444    44444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Sclass [Ljava.lang.String;" + "'", str2.equals("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Sclass [Ljava.lang.String;"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("SOPHIE", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 73);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str1.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.awt.CGraphicsEnvironment", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "s");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "x86_64" + "'", str5.equals("x86_64"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                  ", (java.lang.CharSequence) "######");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Users/sophi1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 1658, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                                                              0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/users/sophi", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sophi" + "'", str3.equals("/users/sophi"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Oracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "                              ", 171);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                 ", "/Users/sophie/Documents/defects#j/tmp/run#randoop.pl#9#37#15#0209070/target/classes:/Users/sophie/Documents/defects#j/framework/lib/test#generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 10, (float) 97, 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("tnemnorivnescihpargc.twa.nus", "                         sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tnemnorivnescihpargc.twa.nus" + "'", str2.equals("tnemnorivnescihpargc.twa.nus"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "x86_6", (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!", (java.lang.CharSequence) "/Users/sophie/Documents/defects#j/tmp/run#randoop.pl#9#37#15#0209070/target/classes:/Users/sophie/Documents/defects#j/framework/lib/test#generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x86_64", (int) (short) -1, 44);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defectsaj/tmp/runarandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar", (java.lang.CharSequence) "hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!utf-8hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        int[] intArray1 = new int[] { 10 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(31, 216, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("SENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENV", "Corporation", (int) (byte) 100);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", 64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("mixed mode", 25, 245);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("8-FTU", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(":Ddfjd937150209070g::Ddfjfbggdj", "1.8", (int) (short) 1, 73);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":1.8" + "'", str4.equals(":1.8"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence) "s", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Hi1.", "mixed#mode", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification", "/LIBRARY/JAVA/JAVAVIRTUALMACHINE", "n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("          ", "x86_6", 45, 64);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "          x86_6" + "'", str4.equals("          x86_6"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("hi!", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("phie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PHIE" + "'", str1.equals("PHIE"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Oracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation/USERS/SOPHIEOracle Corporation", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        char[] charArray8 = new char[] { 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...Toolkit", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/USERS/SOPHIE", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environmen", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.2", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...##############################################...", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.5", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("TNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUs", "44444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUs" + "'", str2.equals("TNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUs"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str1.equals("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "####################################################################################VM#####################################################################################", 44);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str4 = javaVersion0.toString();
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str6 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.2" + "'", str4.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.2" + "'", str6.equals("1.2"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "N.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnv", 17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification", "SUN.LWAWT.MACOSX.CPRINTERJOB", 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification" + "'", str3.equals("Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophi1.7", 171, "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophi1.7" + "'", str3.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophi1.7"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("###############################################################################################################################################################################################################################################################################################################1.7", "                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###############################################################################################################################################################################################################################################################################################################1.7" + "'", str2.equals("###############################################################################################################################################################################################################################################################################################################1.7"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.4", 46, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "  /LIBRARY/JAVA/JAVAVIRTUALMACHI...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/USERS/SOPHI1.", (java.lang.CharSequence) "Sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("class org.apache.commons.lang3.JavaVersionclass [C");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass [C" + "'", str1.equals("class org.apache.commons.lang3.JavaVersionclass [C"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("oracle corporation", "s", 6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "mixed mode");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                         sun.lwawt.macosx.LWCToolkit", "/Users/sophie/Documents/defects#j/tmp/run#randoop.pl#9#37#15#0209070/target/classes:/Users/sophie/Documents/defects#j/framework/lib/test#generation/generation/randoop-current.jar");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", strArray8, strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("...hie/Library...", strArray4, strArray8);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  ");
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "          x86_6");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str16.equals("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "...hie/Library..." + "'", str17.equals("...hie/Library..."));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("x86_6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_6" + "'", str1.equals("X86_6"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("###############################################################Java Virtual Machine Specification", "class org.apache.commons.lang3.JavaVersionclass [C");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###############################################################Java Virtual Machine Specification" + "'", str2.equals("###############################################################Java Virtual Machine Specification"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 9, 10L, (long) 7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("444444444444444444444444444444444444444444Java#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 'a', (long) 244, (long) '#');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 244L + "'", long3 == 244L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 31, 0.0d, (double) 23);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("VM", "SJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#Specification");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie" + "'", str1.equals("/users/sophie"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("ihpos/sresu/", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ihpos/sresu/" + "'", str2.equals("ihpos/sresu/"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "44EN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("X86_6", "/Users/sophi1.7");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("class org.apache.commons.lang3.JavaVersionclass [C");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C[ ssalcnoisreVavaJ.3gnal.snommoc.ehcapa.gro ssalc" + "'", str1.equals("C[ ssalcnoisreVavaJ.3gnal.snommoc.ehcapa.gro ssalc"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(44, 0, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a" + "'", str1.equals("a"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                 ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "///////", "Java#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "          x86_6", (java.lang.CharSequence) "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("44444444444444444444444sophie44444444444444444444444", "T", 217, (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "T" + "'", str4.equals("T"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/USERS/SOPHI1.", (java.lang.CharSequence) "Java Platform API Specification", 1658);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString(" ", "                                             #T#                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("44EN", "/", 4);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "44EN" + "'", str4.equals("44EN"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("      ", "1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      " + "'", str2.equals("      "));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "SJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#Specification", (java.lang.CharSequence) "llllllllllllllll/.../.phllllllllllllllll", 244);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         " + "'", str2.equals("                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         "));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJo4sun.lwawt.macosx.CPrinterJob");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 10, "uTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java(TM) SE Runtime Environment", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                 ...aTaoolkit");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMac OS X", 11, 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/USERS/SOPHI1.", "uTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHI1." + "'", str2.equals("/USERS/SOPHI1."));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        char[] charArray8 = new char[] { 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...Toolkit", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                    ", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("SJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#Specification", "icationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#Specification" + "'", str2.equals("SJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#Specification"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre#################", "oracle corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "####################################################################################VM#####################################################################################", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) 'a', 44, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("SJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#SpecificationSJava#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "7.1", (java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "7.1" + "'", charSequence2.equals("7.1"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt", "", 171);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt" + "'", str3.equals("tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 306, (float) 28, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 28.0f + "'", float3 == 28.0f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) (byte) 10, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", "", (-1), 73);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment" + "'", str4.equals("aphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  " + "'", str1.equals("  "));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0.9", "       ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "UTF-8hi!UTF-8h1.7UTF-8hi!UTF-8h");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "44444444444444444444444    44444444444444444444444", (java.lang.CharSequence) " 0.9  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48 + "'", int2 == 48);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!", 217, "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!" + "'", str3.equals("HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!UTF-8HI!"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("###############################################################Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###############################################################Java Virtual Machine Specification" + "'", str1.equals("###############################################################Java Virtual Machine Specification"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                                                              0.9");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("x86_6", "                                             ...Toolkit                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_6" + "'", str2.equals("x86_6"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.8");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt", "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64", 44);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt" + "'", str3.equals("tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "...##############################################...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", "       ", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("n.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", "                                            1.7.0_80-b15                                            ", (-1));
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "", 31, 10);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("SUN.LWaWT.MaCOSX.cpRINTERjOB", "SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWaWT.MaCOSX.cpRINTERjOB" + "'", str2.equals("SUN.LWaWT.MaCOSX.cpRINTERjOB"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("###############1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###############1.2" + "'", str1.equals("###############1.2"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", (java.lang.CharSequence) "  ...aTaoolk");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "US44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sCorporation" + "'", str1.equals("sCorporation"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE  ", "J v  Virtu l M chine Specific tion");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specificatio" + "'", str1.equals("Java Platform API Specificatio"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "aphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "8-FTU", (java.lang.CharSequence) " 0.9  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                                                              0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("8-FTUaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8-FTUaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("8-FTUaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("...aTaoolkit", 244);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                    ...aTaoolkit                                                                                                                    " + "'", str2.equals("                                                                                                                    ...aTaoolkit                                                                                                                    "));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.71.71.71.71.71.71.71.71");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "17.17.17.17.17.17.17.17.1" + "'", str1.equals("17.17.17.17.17.17.17.17.1"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("PHIE");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.9", (java.lang.CharSequence) "Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationSUN.LWAWT.MACOSX.CPRINTERJOBJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str2.equals("71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("hi1.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINE", (java.lang.CharSequence) "                         sun.lwawt.macosx.LWCToolkit", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/USERS/SOPHI1.", (java.lang.CharSequence) "Java#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#SpecificationJava#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "SIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAV");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("N.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnv", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre#################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre#################" + "'", str1.equals("################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre#################"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolkithi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!/Users/sophiehi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!sun.lwawt.macosx.LWCToolki", (java.lang.CharSequence) "          ", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(":", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("  ", "UTF-8hi!UTF-8h1.7UTF-8hi!UTF-8h", "Java HotSpot(TM) 64-Bit Server VM", 9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "  " + "'", str4.equals("  "));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.1", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.7.0_80", 23, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaa1.7.0_80aaaaaaaa" + "'", str3.equals("aaaaaaa1.7.0_80aaaaaaaa"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "      ", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        int[] intArray1 = new int[] { 10 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("4                 ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        double[] doubleArray1 = new double[] { 1.0d };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(23, 97, 48);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 4, (long) (short) 100, 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444444444444444Java#Platform#API#Specification", (java.lang.CharSequence) "...narandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "VM", (int) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("uTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "/users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "uTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str2.equals("uTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitJava(TM) SE Runtime EnvironmentUsersJava(TM) SE Runtime Environmentsophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("SJava#Platform#API#Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepS#IPA#mroftalP#avaJS" + "'", str1.equals("noitacificepS#IPA#mroftalP#avaJS"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Java(TM) SE Runtime Environmen");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 64, 73.0f, (float) 5);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 73.0f + "'", float3 == 73.0f);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophi1.7", (java.lang.CharSequence) "Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "h", (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "...narandoop.pla9a37a15a0209070/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/testageneration/generation/randoop-current.jar", 17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) " 0.9  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaS", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" ", ' ');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "          ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "N.awt.CGrapmixed modeN.awt.CGrap", (java.lang.CharSequence) "/Users/sophi1.7");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "N.awt.CGrapmixed modeN.awt.CGrap" + "'", charSequence2.equals("N.awt.CGrapmixed modeN.awt.CGrap"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("s");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                                                                                    ...aTaoolkit                                                                                                                    ", "noitacificepS#IPA#mroftalP#avaJS", 48);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "T");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "a", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users" + "'", str2.equals("/Users"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ", 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          " + "'", str3.equals("               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          "));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle Corporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("SENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENV", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "S");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sun.lwawt.macosx.CPrinterJo4sun.lwawt.macosx.CPrinterJob", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "///////", (java.lang.CharSequence) "tnemnorivnescihpargc.twa.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION", (java.lang.CharSequence) "SUN.LWWT.MCOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.1", "71.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", ":1.8", 171);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.1" + "'", str4.equals("1.1"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("4", (double) 17L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray7 = new char[] { 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...Toolkit", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "SENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENV", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U" + "'", str2.equals("UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!UTF-8hi!U"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophi1.7", (java.lang.CharSequence) "  ...aTaoolk", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "t", (java.lang.CharSequence) "!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH8-FTU!IH");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        short[] shortArray5 = new short[] { (byte) 1, (short) -1, (byte) 0, (short) 1, (short) 1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.Class<?> wildcardClass10 = shortArray5.getClass();
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 1 + "'", short6 == (short) 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 1 + "'", short8 == (short) 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 1 + "'", short11 == (short) 1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 'a', (float) 2, 64.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(6L, 0L, (long) 12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/USERS/SOPHIE", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...Toolkit", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", charArray9);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8sun.lwawt.macosx.LWCToolkitUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray9);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                /users/sophi                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophi" + "'", str1.equals("/users/sophi"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "               /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ", (java.lang.CharSequence) "17.17.17.17.17.17.17.17.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("SUN.LW WT.M COSX.cpRINTERjOB");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 18, 50.0d, (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT", "Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str2.equals("sUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENTHI!SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation                                                                                         oracle corporation", (java.lang.CharSequence) "TNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUS!IHTNEMNORIVNESCIHPARGC.TWA.NUs");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("ihpos/sresu/", "aaaaaaaaaaaaaaaaaaaaaaaaS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ihpos/sresu/" + "'", str2.equals("ihpos/sresu/"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/USERS/SOPHIEUTF-8sun.lwawt.maco", "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RS/SOPHIEUTF-8sun.lwawt.maco" + "'", str2.equals("RS/SOPHIEUTF-8sun.lwawt.maco"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("          x86_6", "44444444444444444", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "/users/sophi");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                             #T#                                             ", (java.lang.CharSequence) "SUN.LWWT.MCOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun.lwawt.macosx.CPrinterJo4sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.cprinterjo4sun.lwawt.macosx.cprinterjob" + "'", str1.equals("sun.lwawt.macosx.cprinterjo4sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("a/Users/sophie/Lib", (double) 6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         " + "'", str2.equals("                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         aaaaaaaaaaaaaaaaaaaaaaaaS                                         oracle corporation                                         "));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("h", 6, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("###############################################################Java Virtual Machine Specification", "US", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str2.equals("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94378_1560209070/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', 17, 245);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 17");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str1.equals("##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 10, (long) 2, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironmenthi!sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(":", (int) (byte) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals(":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Mac OS X", "X86_6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lw wt.m cosx.CPrinterJob", (java.lang.CharSequence) "macosx.LWCToolkit", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/USERS/SOPHI1.", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHI1." + "'", str2.equals("/USERS/SOPHI1."));
    }
}

