import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray7 = strBuilder1.toCharArray(0, (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.deleteFirst("StrTokenizer[not tokenized yet]");
        char[] charArray16 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray16, strMatcher17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray16);
        boolean boolean20 = strTokenizer19.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer19.getQuoteMatcher();
        int int23 = strBuilder9.lastIndexOf(strMatcher21, (-1));
        int int24 = strBuilder9.length();
        boolean boolean25 = strBuilder9.isEmpty();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        java.lang.String[] strArray10 = strTokenizer9.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer9.setQuoteMatcher(strMatcher11);
        java.lang.Class<?> wildcardClass13 = strTokenizer9.getClass();
        java.lang.String str14 = strTokenizer9.nextToken();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder16.appendNewLine();
        char[] charArray26 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray26);
        org.apache.commons.lang.text.StrMatcher strMatcher30 = strTokenizer29.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder19.deleteFirst(strMatcher30);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder31.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int36 = strBuilder35.capacity();
        int int37 = strBuilder35.size();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder35.deleteAll("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer43.setIgnoreEmptyTokens(true);
        java.lang.String[] strArray46 = strTokenizer45.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer45.getTrimmerMatcher();
        boolean boolean48 = strBuilder39.contains(strMatcher47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer9.setTrimmerMatcher(strMatcher47);
        int int50 = strTokenizer49.size();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#  a a" + "'", str14.equals("#  a a"));
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strMatcher30);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 35 + "'", int36 == 35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 11 + "'", int37 == 11);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray6, "hi!");
        boolean boolean11 = strTokenizer10.hasNext();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        int int14 = strTokenizer13.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher16 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoredMatcher(strMatcher16);
        char[] charArray24 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher25 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer(charArray24, strMatcher25);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray24);
        org.apache.commons.lang.text.StrMatcher strMatcher28 = strTokenizer27.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer15.setQuoteMatcher(strMatcher28);
        int int30 = strBuilder1.indexOf(strMatcher28);
        int int31 = strBuilder1.capacity();
        char[] charArray32 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder1.clear();
        java.lang.String str34 = strBuilder1.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder1.append("\naaaaaaaa10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strMatcher28);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 35 + "'", int31 == 35);
        org.junit.Assert.assertNotNull(charArray32);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(strBuilder36);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher9, strMatcher10);
        char[] charArray18 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray18, strMatcher19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray18);
        org.apache.commons.lang.text.StrMatcher strMatcher22 = strTokenizer21.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer11.setTrimmerMatcher(strMatcher22);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer11.setIgnoredChar(' ');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strMatcher22);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer25);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        boolean boolean16 = strBuilder4.contains('#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strBuilder4.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.deleteFirst("hi!");
        boolean boolean22 = strBuilder19.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder19.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder19.append((float) (byte) 1);
        char[] charArray27 = strBuilder19.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray27, ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer32.setQuoteChar('#');
        org.apache.commons.lang.text.StrMatcher strMatcher35 = strTokenizer32.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer17.setQuoteMatcher(strMatcher35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer17.reset("");
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strMatcher35);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strTokenizer38);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("", 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = strTokenizer2.setDelimiterChar('#');
        java.lang.String str5 = strTokenizer4.toString();
        try {
            strTokenizer4.remove();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: remove() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(strTokenizer4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "StrTokenizer[not tokenized yet]" + "'", str5.equals("StrTokenizer[not tokenized yet]"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        boolean boolean16 = strBuilder4.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder4.appendFixedWidthPadRight(0, (int) (byte) 0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.deleteFirst("hi!");
        boolean boolean25 = strBuilder22.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder22.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder22.appendPadding(0, '4');
        java.lang.String str31 = strBuilder22.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder33.appendNewLine();
        char[] charArray43 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray43, strMatcher44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray43);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer46.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder36.deleteFirst(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder48.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder48.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder56.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.appendNewLine();
        char[] charArray66 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher67 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer(charArray66, strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray66);
        org.apache.commons.lang.text.StrMatcher strMatcher70 = strTokenizer69.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder59.deleteFirst(strMatcher70);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder71.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int76 = strBuilder75.capacity();
        boolean boolean77 = strBuilder54.equals(strBuilder75);
        boolean boolean78 = strBuilder22.equalsIgnoreCase(strBuilder75);
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder22.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder80.deleteAll("");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder20.appendFixedWidthPadLeft((java.lang.Object) "", (-1), 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder86 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder20.append(strBuilder86, (int) (byte) 10, (int) (short) 10);
        java.lang.String str90 = strBuilder20.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder92 = strBuilder20.append((double) (-1.0f));
        org.apache.commons.lang.text.StrBuilder strBuilder93 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder94 = strBuilder92.append(strBuilder93);
        try {
            char[] charArray97 = strBuilder94.toCharArray((-1), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strMatcher70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 35 + "'", int76 == 35);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNull(str90);
        org.junit.Assert.assertNotNull(strBuilder92);
        org.junit.Assert.assertNotNull(strBuilder94);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        java.io.Writer writer5 = strBuilder1.asWriter();
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.ensureCapacity((int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.setNewLineText("hi!");
        boolean boolean10 = strBuilder7.isEmpty();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(writer5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        char[] charArray9 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray9);
        boolean boolean11 = strTokenizer10.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder13.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer22.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder16.appendWithSeparators((java.util.Iterator) strTokenizer22, "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer30.setIgnoreEmptyTokens(true);
        java.lang.String[] strArray33 = strTokenizer32.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer32.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer22.setIgnoredMatcher(strMatcher34);
        org.apache.commons.lang.text.StrMatcher strMatcher36 = strTokenizer22.getIgnoredMatcher();
        org.apache.commons.lang.text.StrMatcher strMatcher37 = strTokenizer22.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer10.setTrimmerMatcher(strMatcher37);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strMatcher36);
        org.junit.Assert.assertNotNull(strMatcher37);
        org.junit.Assert.assertNotNull(strTokenizer38);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("\naaaaaaaa10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        int int3 = strBuilder0.lastIndexOf('4', (int) (byte) -1);
        char[] charArray10 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder19.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder17.appendFixedWidthPadLeft((java.lang.Object) strBuilder22, (int) (byte) 10, 'a');
        char[] charArray29 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray29, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder22.append(charArray29);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder35.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.appendNewLine();
        char[] charArray45 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer(charArray45, strMatcher46);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray45);
        org.apache.commons.lang.text.StrMatcher strMatcher49 = strTokenizer48.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder38.deleteFirst(strMatcher49);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder22.replaceAll(strMatcher49, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher49);
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder0.replaceAll(strMatcher49, "");
        char[] charArray56 = strBuilder0.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder57 = new org.apache.commons.lang.text.StrBuilder();
        int int60 = strBuilder57.lastIndexOf('4', (int) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder63 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder63.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder63.appendNewLine();
        char[] charArray73 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher74 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = new org.apache.commons.lang.text.StrTokenizer(charArray73, strMatcher74);
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray73);
        org.apache.commons.lang.text.StrMatcher strMatcher77 = strTokenizer76.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder78 = strBuilder66.deleteFirst(strMatcher77);
        int int80 = strBuilder78.lastIndexOf(' ');
        java.util.Collection collection81 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder83 = strBuilder78.appendWithSeparators(collection81, "#  a a");
        char[] charArray84 = strBuilder78.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder57.insert((int) (short) 0, charArray84);
        char[] charArray86 = strBuilder0.getChars(charArray84);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strMatcher49);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(charArray56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(charArray73);
        org.junit.Assert.assertNotNull(strTokenizer76);
        org.junit.Assert.assertNotNull(strMatcher77);
        org.junit.Assert.assertNotNull(strBuilder78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertNotNull(strBuilder83);
        org.junit.Assert.assertNotNull(charArray84);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(charArray86);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder16.appendFixedWidthPadRight((java.lang.Object) strMatcher32, 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.appendPadding((int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder35.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder35.replaceAll("\n", "StrTokenizer[#  a a]");
        boolean boolean44 = strBuilder35.endsWith("aaa4444444100");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder0.appendFixedWidthPadRight(8, (int) (byte) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.deleteFirst("hi!");
        boolean boolean9 = strBuilder6.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder6.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder6.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder6.delete(0, 0);
        boolean boolean18 = strBuilder6.contains('a');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder6.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder20.append('3');
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer("", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer25.setQuoteChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder29.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder29.appendNewLine();
        char[] charArray39 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher40 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer(charArray39, strMatcher40);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray39);
        org.apache.commons.lang.text.StrMatcher strMatcher43 = strTokenizer42.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder32.deleteFirst(strMatcher43);
        int int46 = strBuilder32.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder32.appendPadding((int) (byte) 100, ' ');
        char[] charArray56 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher57 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer(charArray56, strMatcher57);
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray56);
        boolean boolean60 = strTokenizer59.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher61 = strTokenizer59.getQuoteMatcher();
        int int62 = strBuilder49.lastIndexOf(strMatcher61);
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = strTokenizer25.setDelimiterMatcher(strMatcher61);
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder20.replace(strMatcher61, "hi!", (int) (short) 1, 99, (-1));
        int int70 = strBuilder4.indexOf(strMatcher61, (int) (byte) 1);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(charArray39);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strMatcher43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(charArray56);
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(strMatcher61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer63);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher9, strMatcher10);
        char[] charArray16 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray16);
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer11.reset(charArray16);
        char[] charArray25 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher26 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer(charArray25, strMatcher26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray25);
        boolean boolean29 = strTokenizer28.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher30 = strTokenizer28.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer18.setTrimmerMatcher(strMatcher30);
        java.lang.String str32 = strTokenizer31.previousToken();
        java.lang.Object obj33 = strTokenizer31.clone();
        java.lang.String str34 = strTokenizer31.previousToken();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(strMatcher30);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.delete(0, 0);
        boolean boolean13 = strBuilder1.contains('a');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.appendNewLine();
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder20.deleteFirst(strMatcher31);
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder32.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder32.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder40 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder40.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder40.appendNewLine();
        char[] charArray50 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher51 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer(charArray50, strMatcher51);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray50);
        org.apache.commons.lang.text.StrMatcher strMatcher54 = strTokenizer53.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder43.deleteFirst(strMatcher54);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder55.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int60 = strBuilder59.capacity();
        boolean boolean61 = strBuilder38.equals(strBuilder59);
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder38.deleteFirst("StrTokenizer[not tokenized yet]");
        boolean boolean65 = strBuilder38.endsWith("");
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder38.replaceAll("01.001.0hi!", "a");
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder15.appendFixedWidthPadRight((java.lang.Object) strBuilder68, 99, ' ');
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder71.replace((int) (byte) 100, (int) '4', "01.0");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(charArray50);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strMatcher54);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 35 + "'", int60 == 35);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder71);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        char[] charArray15 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray15, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder8.append(charArray15);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder21.appendNewLine();
        char[] charArray31 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher32 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer(charArray31, strMatcher32);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray31);
        org.apache.commons.lang.text.StrMatcher strMatcher35 = strTokenizer34.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder24.deleteFirst(strMatcher35);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder8.replaceAll(strMatcher35, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder38.replaceFirst("\n5aaaaaaaaa4444444100", "01.0");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strMatcher35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder41);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        boolean boolean16 = strBuilder4.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder4.appendFixedWidthPadRight(0, (int) (byte) 0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.deleteFirst("hi!");
        boolean boolean25 = strBuilder22.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder22.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder22.appendPadding(0, '4');
        java.lang.String str31 = strBuilder22.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder33.appendNewLine();
        char[] charArray43 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray43, strMatcher44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray43);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer46.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder36.deleteFirst(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder48.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder48.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder56.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.appendNewLine();
        char[] charArray66 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher67 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer(charArray66, strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray66);
        org.apache.commons.lang.text.StrMatcher strMatcher70 = strTokenizer69.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder59.deleteFirst(strMatcher70);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder71.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int76 = strBuilder75.capacity();
        boolean boolean77 = strBuilder54.equals(strBuilder75);
        boolean boolean78 = strBuilder22.equalsIgnoreCase(strBuilder75);
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder22.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder80.deleteAll("");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder20.appendFixedWidthPadLeft((java.lang.Object) "", (-1), 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder86 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder20.append(strBuilder86, (int) (byte) 10, (int) (short) 10);
        try {
            java.lang.String str92 = strBuilder89.substring(5, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strMatcher70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 35 + "'", int76 == 35);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(strBuilder89);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[not tokenized yet]");
        char[] charArray8 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray8, strMatcher9);
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray8, "hi!");
        char[] charArray19 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer(charArray19, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray19);
        org.apache.commons.lang.text.StrMatcher strMatcher23 = strTokenizer22.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder25.appendNewLine();
        char[] charArray35 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher36 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray35, strMatcher36);
        int int38 = strTokenizer37.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer37.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher40 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer39.setIgnoredMatcher(strMatcher40);
        char[] charArray48 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer(charArray48, strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray48);
        org.apache.commons.lang.text.StrMatcher strMatcher52 = strTokenizer51.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer39.setQuoteMatcher(strMatcher52);
        int int54 = strBuilder25.indexOf(strMatcher52);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer(charArray8, strMatcher23, strMatcher52);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer1.setDelimiterMatcher(strMatcher23);
        int int57 = strTokenizer56.nextIndex();
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strMatcher23);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(charArray48);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strMatcher52);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = strTokenizer2.setQuoteChar('a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer6 = strTokenizer4.setIgnoredChar(' ');
        int int7 = strTokenizer6.previousIndex();
        org.junit.Assert.assertNotNull(strTokenizer4);
        org.junit.Assert.assertNotNull(strTokenizer6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        int int14 = strTokenizer13.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher16 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoredMatcher(strMatcher16);
        char[] charArray24 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher25 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer(charArray24, strMatcher25);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray24);
        org.apache.commons.lang.text.StrMatcher strMatcher28 = strTokenizer27.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer15.setQuoteMatcher(strMatcher28);
        int int30 = strBuilder1.indexOf(strMatcher28);
        int int31 = strBuilder1.capacity();
        char[] charArray32 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder1.clear();
        int int35 = strBuilder33.lastIndexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder33.deleteAll('3');
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder33.append("StrTokenizer[hi!]", (int) (byte) 1, 4);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strMatcher28);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 35 + "'", int31 == 35);
        org.junit.Assert.assertNotNull(charArray32);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder41);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        java.util.List list4 = strTokenizer3.getTokenList();
        org.apache.commons.lang.text.StrMatcher strMatcher5 = strTokenizer3.getTrimmerMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder7 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.appendNewLine();
        char[] charArray17 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher18 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer(charArray17, strMatcher18);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray17);
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer20.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder10.deleteFirst(strMatcher21);
        boolean boolean24 = strBuilder10.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder10.replaceAll('a', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder10.appendFixedWidthPadLeft((int) (short) 1, (int) (byte) 100, 'a');
        try {
            strTokenizer3.add((java.lang.Object) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: add() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(strMatcher5);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder31);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendPadding(0, '4');
        java.lang.String str10 = strBuilder1.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder1.deleteAll('#');
        java.io.Reader reader13 = strBuilder12.asReader();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(reader13);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        java.lang.String[] strArray10 = strTokenizer9.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer9.setQuoteMatcher(strMatcher11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer9.setIgnoredChar(' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer9.setDelimiterString("\n5aaaaaaaaa4444444100");
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strTokenizer16);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder4.insert((int) (short) -1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray6, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        char[] charArray20 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray20, strMatcher21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray20);
        org.apache.commons.lang.text.StrMatcher strMatcher24 = strTokenizer23.getQuoteMatcher();
        char[] charArray26 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray26, '#', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer23.reset(charArray26);
        char[] charArray37 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher38 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer(charArray37, strMatcher38);
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray37);
        org.apache.commons.lang.text.StrMatcher strMatcher41 = strTokenizer40.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer30.setQuoteMatcher(strMatcher41);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder44.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder44.appendNewLine();
        char[] charArray54 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher55 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer(charArray54, strMatcher55);
        int int57 = strTokenizer56.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer56.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher59 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer58.setIgnoredMatcher(strMatcher59);
        char[] charArray67 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher68 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer(charArray67, strMatcher68);
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray67);
        org.apache.commons.lang.text.StrMatcher strMatcher71 = strTokenizer70.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = strTokenizer58.setQuoteMatcher(strMatcher71);
        int int73 = strBuilder44.indexOf(strMatcher71);
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[not tokenized yet]", strMatcher41, strMatcher71);
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = strTokenizer12.setDelimiterMatcher(strMatcher71);
        org.apache.commons.lang.text.StrMatcher strMatcher76 = strTokenizer75.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = strTokenizer75.setIgnoredChar(' ');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strMatcher24);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strMatcher41);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(charArray67);
        org.junit.Assert.assertNotNull(strTokenizer70);
        org.junit.Assert.assertNotNull(strMatcher71);
        org.junit.Assert.assertNotNull(strTokenizer72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer75);
        org.junit.Assert.assertNotNull(strMatcher76);
        org.junit.Assert.assertNotNull(strTokenizer78);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        boolean boolean16 = strBuilder4.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder4.appendFixedWidthPadRight(0, (int) (byte) 0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.deleteFirst("hi!");
        boolean boolean25 = strBuilder22.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder22.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder22.appendPadding(0, '4');
        java.lang.String str31 = strBuilder22.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder33.appendNewLine();
        char[] charArray43 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray43, strMatcher44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray43);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer46.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder36.deleteFirst(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder48.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder48.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder56.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.appendNewLine();
        char[] charArray66 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher67 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer(charArray66, strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray66);
        org.apache.commons.lang.text.StrMatcher strMatcher70 = strTokenizer69.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder59.deleteFirst(strMatcher70);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder71.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int76 = strBuilder75.capacity();
        boolean boolean77 = strBuilder54.equals(strBuilder75);
        boolean boolean78 = strBuilder22.equalsIgnoreCase(strBuilder75);
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder22.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder80.deleteAll("");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder20.appendFixedWidthPadLeft((java.lang.Object) "", (-1), 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder86 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder20.append(strBuilder86, (int) (byte) 10, (int) (short) 10);
        java.lang.String str90 = strBuilder20.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder92 = strBuilder20.append((double) (-1.0f));
        org.apache.commons.lang.text.StrBuilder strBuilder94 = strBuilder92.ensureCapacity(0);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strMatcher70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 35 + "'", int76 == 35);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNull(str90);
        org.junit.Assert.assertNotNull(strBuilder92);
        org.junit.Assert.assertNotNull(strBuilder94);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        char char3 = strBuilder1.charAt((int) (short) 1);
        org.junit.Assert.assertTrue("'" + char3 + "' != '" + 'i' + "'", char3 == 'i');
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendPadding(0, '4');
        java.lang.String str10 = strBuilder1.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder12.appendNewLine();
        char[] charArray22 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray22, strMatcher23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray22);
        org.apache.commons.lang.text.StrMatcher strMatcher26 = strTokenizer25.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder15.deleteFirst(strMatcher26);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder27.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder27.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder35 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder35.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.appendNewLine();
        char[] charArray45 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer(charArray45, strMatcher46);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray45);
        org.apache.commons.lang.text.StrMatcher strMatcher49 = strTokenizer48.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder38.deleteFirst(strMatcher49);
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder50.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int55 = strBuilder54.capacity();
        boolean boolean56 = strBuilder33.equals(strBuilder54);
        boolean boolean57 = strBuilder1.equalsIgnoreCase(strBuilder54);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder1.setNullText("");
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder1.appendPadding(101, '4');
        java.lang.String str64 = strBuilder62.leftString(3);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strMatcher26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strMatcher49);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 35 + "'", int55 == 35);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "044" + "'", str64.equals("044"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("01.0", 'a');
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder16.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder22.appendPadding(0, '#');
        java.lang.String str26 = strBuilder25.toString();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "\naaaaaaaa10" + "'", str26.equals("\naaaaaaaa10"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.delete(0, 0);
        boolean boolean13 = strBuilder1.contains('a');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.append('3');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.deleteFirst("51");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder19);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.reverse();
        int int5 = strBuilder0.lastIndexOf("\n5aaaaaaaaa4444444100");
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.deleteFirst("hi!");
        boolean boolean13 = strBuilder10.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder10.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder10.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder19.appendNewLine();
        char[] charArray29 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray29, strMatcher30);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray29);
        org.apache.commons.lang.text.StrMatcher strMatcher33 = strTokenizer32.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder22.deleteFirst(strMatcher33);
        int int36 = strBuilder17.lastIndexOf(strMatcher33, 10);
        int int39 = strBuilder17.indexOf("hi!", 0);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder17.append(strBuilder41);
        java.lang.StringBuffer stringBuffer43 = strBuilder42.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder8.append(stringBuffer43);
        java.lang.String str46 = strBuilder8.rightString((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder8.insert(0, (long) 8);
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder49.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder50.appendFixedWidthPadRight((int) (short) 0, 82, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder50.appendPadding((int) '4', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder50.replace(1, (int) (byte) 10, "StrTokenizer[not tokenized yet]");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(stringBuffer43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "01.001.0hi!" + "'", str46.equals("01.001.0hi!"));
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertNotNull(strBuilder61);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.appendFixedWidthPadRight((int) '#', 100, ' ');
        char char10 = strBuilder8.charAt((int) '#');
        int int12 = strBuilder8.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder8.appendFixedWidthPadRight(1, 35, 'a');
        java.lang.String str18 = strBuilder16.rightString((int) (byte) 1);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + ' ' + "'", char10 == ' ');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 99 + "'", int12 == 99);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "a" + "'", str18.equals("a"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        char[] charArray15 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray15, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder8.append(charArray15);
        char[] charArray26 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher27);
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher29, strMatcher30);
        char[] charArray36 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer31.reset(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray36);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder8.appendWithSeparators((java.util.Iterator) strTokenizer39, "");
        java.lang.String str42 = strBuilder41.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder41.deleteAll("");
        java.lang.Object obj45 = null;
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder44.appendFixedWidthPadLeft(obj45, 35, '3');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "aa4 #" + "'", str42.equals("aa4 #"));
        org.junit.Assert.assertNotNull(strBuilder44);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder0.appendFixedWidthPadRight(8, (int) (byte) 100, 'a');
        java.lang.String str5 = strBuilder4.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder4.insert((int) 'a', true);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder11.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder11.appendNull();
        char[] charArray17 = strBuilder11.toCharArray(0, (int) '4');
        char[] charArray18 = strBuilder11.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer(charArray18);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder8.insert((int) (byte) 1, charArray18, (int) (short) 10, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: Invalid offset: 10");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray18);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.lang.text.StrTokenizer strTokenizer0 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance();
        int int1 = strTokenizer0.nextIndex();
        org.junit.Assert.assertNotNull(strTokenizer0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        boolean boolean16 = strBuilder4.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder4.appendFixedWidthPadRight(0, (int) (byte) 0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.deleteFirst("hi!");
        boolean boolean25 = strBuilder22.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder22.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder22.appendPadding(0, '4');
        java.lang.String str31 = strBuilder22.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder33.appendNewLine();
        char[] charArray43 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray43, strMatcher44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray43);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer46.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder36.deleteFirst(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder48.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder48.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder56.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.appendNewLine();
        char[] charArray66 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher67 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer(charArray66, strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray66);
        org.apache.commons.lang.text.StrMatcher strMatcher70 = strTokenizer69.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder59.deleteFirst(strMatcher70);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder71.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int76 = strBuilder75.capacity();
        boolean boolean77 = strBuilder54.equals(strBuilder75);
        boolean boolean78 = strBuilder22.equalsIgnoreCase(strBuilder75);
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder22.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder80.deleteAll("");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder20.appendFixedWidthPadLeft((java.lang.Object) "", (-1), 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder86 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder20.append(strBuilder86, (int) (byte) 10, (int) (short) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder90 = strBuilder89.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder91 = strBuilder89.trim();
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strMatcher70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 35 + "'", int76 == 35);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder90);
        org.junit.Assert.assertNotNull(strBuilder91);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.appendNewLine();
        char[] charArray20 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray20, strMatcher21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray20);
        org.apache.commons.lang.text.StrMatcher strMatcher24 = strTokenizer23.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder13.deleteFirst(strMatcher24);
        int int27 = strBuilder8.lastIndexOf(strMatcher24, 10);
        int int30 = strBuilder8.indexOf("hi!", 0);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder8.append(strBuilder32);
        char[] charArray35 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray35, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder40 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder40.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder40.appendNewLine();
        char[] charArray50 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher51 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer(charArray50, strMatcher51);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray50);
        org.apache.commons.lang.text.StrMatcher strMatcher54 = strTokenizer53.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder43.deleteFirst(strMatcher54);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer(charArray35, strMatcher54);
        org.apache.commons.lang.text.StrBuilder strBuilder58 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder58.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder58.appendNewLine();
        char[] charArray68 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher69 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer(charArray68, strMatcher69);
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray68);
        org.apache.commons.lang.text.StrMatcher strMatcher72 = strTokenizer71.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder61.deleteFirst(strMatcher72);
        int int75 = strBuilder73.lastIndexOf(' ');
        java.util.Collection collection76 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder78 = strBuilder73.appendWithSeparators(collection76, "#  a a");
        char[] charArray79 = strBuilder73.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = strTokenizer56.reset(charArray79);
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder33.append(charArray79);
        org.apache.commons.lang.text.StrBuilder strBuilder84 = strBuilder81.replaceAll(' ', '3');
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = strBuilder81.asTokenizer();
        java.lang.String str86 = strTokenizer85.toString();
        java.lang.Class<?> wildcardClass87 = strTokenizer85.getClass();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strMatcher24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(charArray50);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strMatcher54);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(charArray68);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertNotNull(strMatcher72);
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(strBuilder78);
        org.junit.Assert.assertNotNull(charArray79);
        org.junit.Assert.assertNotNull(strTokenizer80);
        org.junit.Assert.assertNotNull(strBuilder81);
        org.junit.Assert.assertNotNull(strBuilder84);
        org.junit.Assert.assertNotNull(strTokenizer85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "StrTokenizer[not tokenized yet]" + "'", str86.equals("StrTokenizer[not tokenized yet]"));
        org.junit.Assert.assertNotNull(wildcardClass87);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendPadding(0, '4');
        java.lang.String str10 = strBuilder1.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder1.deleteAll('#');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.insert(0, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.appendNewLine();
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder20.deleteFirst(strMatcher31);
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder32.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder32.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder40 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder40.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder40.appendNewLine();
        char[] charArray50 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher51 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer(charArray50, strMatcher51);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray50);
        org.apache.commons.lang.text.StrMatcher strMatcher54 = strTokenizer53.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder43.deleteFirst(strMatcher54);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder55.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int60 = strBuilder59.capacity();
        boolean boolean61 = strBuilder38.equals(strBuilder59);
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder38.deleteFirst("StrTokenizer[not tokenized yet]");
        java.lang.StringBuffer stringBuffer64 = strBuilder38.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder1.append(strBuilder38);
        java.lang.String str66 = strBuilder38.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder38.setNewLineText("\n");
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder38.append((-1L));
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(charArray50);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strMatcher54);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 35 + "'", int60 == 35);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertNotNull(stringBuffer64);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder70);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(' ');
        int int19 = strBuilder4.indexOf('4', 0);
        char[] charArray26 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray26);
        boolean boolean30 = strTokenizer29.hasPrevious();
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer29, "");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder34.deleteFirst("hi!");
        boolean boolean37 = strBuilder34.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder34.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder34.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder43.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder43.appendNewLine();
        char[] charArray53 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher54 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer(charArray53, strMatcher54);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray53);
        org.apache.commons.lang.text.StrMatcher strMatcher57 = strTokenizer56.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder46.deleteFirst(strMatcher57);
        int int60 = strBuilder41.lastIndexOf(strMatcher57, 10);
        int int63 = strBuilder41.indexOf("hi!", 0);
        org.apache.commons.lang.text.StrBuilder strBuilder65 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder41.append(strBuilder65);
        java.lang.StringBuffer stringBuffer67 = strBuilder66.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder4.append(stringBuffer67);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder4.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder69.delete(4, (int) '#');
        int int73 = strBuilder69.length();
        java.lang.String str74 = strBuilder69.getNewLineText();
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strMatcher57);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(stringBuffer67);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 4 + "'", int73 == 4);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "hi!" + "'", str74.equals("hi!"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("", 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = new org.apache.commons.lang.text.StrBuilder((int) (short) 100);
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher15 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher14, strMatcher15);
        char[] charArray21 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer16.reset(charArray21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray21, "");
        char[] charArray26 = strBuilder4.getChars(charArray21);
        char[] charArray33 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher34 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray33, strMatcher34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray33, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray33);
        char[] charArray45 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer(charArray45, strMatcher46);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray45);
        org.apache.commons.lang.text.StrMatcher strMatcher49 = strTokenizer48.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer(charArray33, strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = new org.apache.commons.lang.text.StrTokenizer(charArray21, strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer2.reset(charArray21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer2.setIgnoredChar('#');
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder59.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strTokenizer65.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder59.appendWithSeparators((java.util.Iterator) strTokenizer65, "");
        boolean boolean71 = strBuilder59.contains('#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = strBuilder59.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder74 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder74.deleteFirst("hi!");
        boolean boolean77 = strBuilder74.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder74.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder74.append((float) (byte) 1);
        char[] charArray82 = strBuilder74.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = new org.apache.commons.lang.text.StrTokenizer(charArray82, '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = new org.apache.commons.lang.text.StrTokenizer(charArray82, ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray82);
        org.apache.commons.lang.text.StrTokenizer strTokenizer89 = strTokenizer87.setQuoteChar('#');
        org.apache.commons.lang.text.StrMatcher strMatcher90 = strTokenizer87.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer91 = strTokenizer72.setQuoteMatcher(strMatcher90);
        org.apache.commons.lang.text.StrTokenizer strTokenizer92 = strTokenizer54.setTrimmerMatcher(strMatcher90);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strMatcher49);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(strTokenizer67);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(strTokenizer72);
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertNotNull(strBuilder81);
        org.junit.Assert.assertNotNull(charArray82);
        org.junit.Assert.assertNotNull(strTokenizer87);
        org.junit.Assert.assertNotNull(strTokenizer89);
        org.junit.Assert.assertNotNull(strMatcher90);
        org.junit.Assert.assertNotNull(strTokenizer91);
        org.junit.Assert.assertNotNull(strTokenizer92);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("StrTokenizer[hi!]");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder3.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer12.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder6.appendWithSeparators((java.util.Iterator) strTokenizer12, "");
        boolean boolean18 = strBuilder6.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder6.appendFixedWidthPadRight(0, (int) (byte) 0, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("", '4', '#');
        char[] charArray33 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher34 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray33, strMatcher34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray33);
        org.apache.commons.lang.text.StrMatcher strMatcher37 = strTokenizer36.getQuoteMatcher();
        char[] charArray39 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer(charArray39, '#', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer36.reset(charArray39);
        char[] charArray50 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher51 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer(charArray50, strMatcher51);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray50);
        org.apache.commons.lang.text.StrMatcher strMatcher54 = strTokenizer53.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer43.setQuoteMatcher(strMatcher54);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer26.setIgnoredMatcher(strMatcher54);
        int int57 = strBuilder22.lastIndexOf(strMatcher54);
        int int59 = strBuilder1.indexOf(strMatcher54, (int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder1.deleteFirst("01.001.0hi!");
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strMatcher37);
        org.junit.Assert.assertNotNull(charArray39);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(charArray50);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strMatcher54);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(strBuilder61);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder8.ensureCapacity((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.append("\naaaaaaaa101", (int) (short) 1, 4);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder21.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder24.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer30.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder24.appendWithSeparators((java.util.Iterator) strTokenizer30, "");
        boolean boolean36 = strBuilder24.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder24.appendFixedWidthPadRight(0, (int) (byte) 0, 'a');
        int int42 = strBuilder40.indexOf('#');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder44.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder44.appendNewLine();
        char[] charArray54 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher55 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer(charArray54, strMatcher55);
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray54);
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer57.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder47.deleteFirst(strMatcher58);
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder59.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int64 = strBuilder63.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder63.setNullText("");
        java.lang.StringBuffer stringBuffer67 = strBuilder66.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder40.append(stringBuffer67);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder15.append(stringBuffer67, (int) (byte) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: startIndex must be valid");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 35 + "'", int64 == 35);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(stringBuffer67);
        org.junit.Assert.assertNotNull(strBuilder68);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder2.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder2.appendNewLine();
        char[] charArray12 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher13 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = new org.apache.commons.lang.text.StrTokenizer(charArray12, strMatcher13);
        int int15 = strTokenizer14.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer14.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer16.setIgnoredMatcher(strMatcher17);
        char[] charArray25 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher26 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer(charArray25, strMatcher26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray25);
        org.apache.commons.lang.text.StrMatcher strMatcher29 = strTokenizer28.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer16.setQuoteMatcher(strMatcher29);
        int int31 = strBuilder2.indexOf(strMatcher29);
        char[] charArray38 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher39 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer(charArray38, strMatcher39);
        int int41 = strTokenizer40.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer40.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher43 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer42.setIgnoredMatcher(strMatcher43);
        char[] charArray51 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher52 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer(charArray51, strMatcher52);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray51);
        org.apache.commons.lang.text.StrMatcher strMatcher55 = strTokenizer54.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer42.setQuoteMatcher(strMatcher55);
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer("#  a a", strMatcher29, strMatcher55);
        java.lang.String str58 = strTokenizer57.nextToken();
        try {
            java.lang.Object obj59 = strTokenizer57.next();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strMatcher29);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(charArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(charArray51);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strMatcher55);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "#  a a" + "'", str58.equals("#  a a"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder18.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder22.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder20.appendFixedWidthPadLeft((java.lang.Object) strBuilder25, (int) (byte) 10, 'a');
        java.io.Reader reader31 = strBuilder25.asReader();
        boolean boolean32 = strBuilder16.equalsIgnoreCase(strBuilder25);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder16.setNewLineText("");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder34.ensureCapacity(35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strBuilder36.asTokenizer();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(reader31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strTokenizer37);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        char[] charArray15 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray15, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder8.append(charArray15);
        char[] charArray26 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher27);
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher29, strMatcher30);
        char[] charArray36 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer31.reset(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray36);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder8.appendWithSeparators((java.util.Iterator) strTokenizer39, "");
        java.lang.String str42 = strBuilder41.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder41.replaceAll('i', '4');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(strBuilder45);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder8.appendNewLine();
        char[] charArray18 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray18, strMatcher19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray18);
        org.apache.commons.lang.text.StrMatcher strMatcher22 = strTokenizer21.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder11.deleteFirst(strMatcher22);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder23.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray34 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray34);
        boolean boolean38 = strTokenizer37.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer37.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder23.appendFixedWidthPadRight((java.lang.Object) strMatcher39, 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder42.appendPadding((int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder42.appendNull();
        char char48 = strBuilder42.charAt(4);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder42.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) strBuilder49, (int) '#', '#');
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder49.setCharAt(99, '#');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 99");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strMatcher22);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(strMatcher39);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertTrue("'" + char48 + "' != '" + 'a' + "'", char48 == 'a');
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder52);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder8.ensureCapacity((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder15.insert(0, (int) (short) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder15.insert(0, (float) 8);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder21);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("\n");
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray6, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer10.setIgnoredChar(' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer14.setEmptyTokenAsNull(true);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strTokenizer16);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        java.lang.String[] strArray10 = strTokenizer9.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer9.setQuoteMatcher(strMatcher11);
        java.lang.Class<?> wildcardClass13 = strTokenizer9.getClass();
        java.lang.String str14 = strTokenizer9.nextToken();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder16.appendNewLine();
        char[] charArray26 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray26);
        org.apache.commons.lang.text.StrMatcher strMatcher30 = strTokenizer29.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder19.deleteFirst(strMatcher30);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder31.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int36 = strBuilder35.capacity();
        int int37 = strBuilder35.size();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder35.deleteAll("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer43.setIgnoreEmptyTokens(true);
        java.lang.String[] strArray46 = strTokenizer45.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer45.getTrimmerMatcher();
        boolean boolean48 = strBuilder39.contains(strMatcher47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer9.setTrimmerMatcher(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder51 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder51.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder51.appendNewLine();
        char[] charArray61 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher62 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer(charArray61, strMatcher62);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray61);
        org.apache.commons.lang.text.StrMatcher strMatcher65 = strTokenizer64.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder54.deleteFirst(strMatcher65);
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder66.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray77 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher78 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = new org.apache.commons.lang.text.StrTokenizer(charArray77, strMatcher78);
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray77);
        boolean boolean81 = strTokenizer80.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher82 = strTokenizer80.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder66.appendFixedWidthPadRight((java.lang.Object) strMatcher82, 0, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = strTokenizer9.setQuoteMatcher(strMatcher82);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#  a a" + "'", str14.equals("#  a a"));
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strMatcher30);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 35 + "'", int36 == 35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 11 + "'", int37 == 11);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(charArray61);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strMatcher65);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNotNull(charArray77);
        org.junit.Assert.assertNotNull(strTokenizer80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(strMatcher82);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(strTokenizer86);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(' ');
        int int19 = strBuilder4.indexOf('4', 0);
        char[] charArray26 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray26);
        boolean boolean30 = strTokenizer29.hasPrevious();
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer29, "");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder34.deleteFirst("hi!");
        boolean boolean37 = strBuilder34.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder34.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder34.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder43.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder43.appendNewLine();
        char[] charArray53 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher54 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer(charArray53, strMatcher54);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray53);
        org.apache.commons.lang.text.StrMatcher strMatcher57 = strTokenizer56.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder46.deleteFirst(strMatcher57);
        int int60 = strBuilder41.lastIndexOf(strMatcher57, 10);
        int int63 = strBuilder41.indexOf("hi!", 0);
        org.apache.commons.lang.text.StrBuilder strBuilder65 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder41.append(strBuilder65);
        java.lang.StringBuffer stringBuffer67 = strBuilder66.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder4.append(stringBuffer67);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder4.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder4.append((java.lang.Object) (-1.0d));
        boolean boolean73 = strBuilder71.endsWith("#  a a");
        char[] charArray74 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = new org.apache.commons.lang.text.StrTokenizer(charArray74, ' ', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder71.appendWithSeparators((java.util.Iterator) strTokenizer77, "0");
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strMatcher57);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(stringBuffer67);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(strBuilder79);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[hi!]", "aaaaaaaaa");
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("StrTokenizer[not tokenized yet]");
        int int3 = strBuilder1.lastIndexOf("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.appendFixedWidthPadRight((-1), (int) '4', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder7.appendNewLine();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder8);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        char[] charArray15 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray15, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder8.append(charArray15);
        char[] charArray26 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher27);
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher29, strMatcher30);
        char[] charArray36 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer31.reset(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray36);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder8.appendWithSeparators((java.util.Iterator) strTokenizer39, "");
        char[] charArray49 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher50 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = new org.apache.commons.lang.text.StrTokenizer(charArray49, strMatcher50);
        int int52 = strTokenizer51.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer51.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher54 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer53.setIgnoredMatcher(strMatcher54);
        char[] charArray62 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher63 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = new org.apache.commons.lang.text.StrTokenizer(charArray62, strMatcher63);
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray62);
        org.apache.commons.lang.text.StrMatcher strMatcher66 = strTokenizer65.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strTokenizer53.setQuoteMatcher(strMatcher66);
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = strTokenizer71.setIgnoreEmptyTokens(true);
        java.lang.String[] strArray74 = strTokenizer73.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher75 = strTokenizer73.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = strTokenizer67.setDelimiterMatcher(strMatcher75);
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = new org.apache.commons.lang.text.StrTokenizer("a", strMatcher75);
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder8.replaceAll(strMatcher75, "                                    ");
        int int82 = strBuilder8.lastIndexOf("044", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(charArray49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(charArray62);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertNotNull(strMatcher66);
        org.junit.Assert.assertNotNull(strTokenizer67);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertNotNull(strArray74);
        org.junit.Assert.assertNotNull(strMatcher75);
        org.junit.Assert.assertNotNull(strTokenizer76);
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder16.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder24.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder24.appendNewLine();
        char[] charArray34 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray34);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer37.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder27.deleteFirst(strMatcher38);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder39.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int44 = strBuilder43.capacity();
        boolean boolean45 = strBuilder22.equals(strBuilder43);
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder22.deleteFirst("StrTokenizer[not tokenized yet]");
        java.lang.StringBuffer stringBuffer48 = strBuilder22.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder22.insert(0, 0.0d);
        java.lang.String str52 = strBuilder22.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder22.setLength((int) '3');
        java.lang.String str55 = strBuilder22.getNullText();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strMatcher38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 35 + "'", int44 == 35);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(stringBuffer48);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNull(str55);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        char[] charArray7 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher8 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray7, strMatcher8);
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray7);
        org.apache.commons.lang.text.StrMatcher strMatcher11 = strTokenizer10.getQuoteMatcher();
        char[] charArray13 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer(charArray13, '#', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer10.reset(charArray13);
        char[] charArray24 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher25 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer(charArray24, strMatcher25);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray24);
        org.apache.commons.lang.text.StrMatcher strMatcher28 = strTokenizer27.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer17.setQuoteMatcher(strMatcher28);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder31.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.appendNewLine();
        char[] charArray41 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher42 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer(charArray41, strMatcher42);
        int int44 = strTokenizer43.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer43.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer45.setIgnoredMatcher(strMatcher46);
        char[] charArray54 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher55 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer(charArray54, strMatcher55);
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray54);
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer57.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = strTokenizer45.setQuoteMatcher(strMatcher58);
        int int60 = strBuilder31.indexOf(strMatcher58);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[not tokenized yet]", strMatcher28, strMatcher58);
        org.apache.commons.lang.text.StrMatcher strMatcher62 = strTokenizer61.getDelimiterMatcher();
        org.apache.commons.lang.text.StrMatcher strMatcher63 = strTokenizer61.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer61.reset("");
        java.lang.String str66 = strTokenizer61.previousToken();
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertNotNull(strMatcher11);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strMatcher28);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(strMatcher62);
        org.junit.Assert.assertNotNull(strMatcher63);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertNull(str66);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        char[] charArray15 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray15, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder8.append(charArray15);
        char[] charArray26 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher27);
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher29, strMatcher30);
        char[] charArray36 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer31.reset(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray36);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder8.appendWithSeparators((java.util.Iterator) strTokenizer39, "");
        java.lang.String str42 = strBuilder41.getNewLineText();
        java.io.Reader reader43 = strBuilder41.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder41.replaceFirst('3', '3');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(reader43);
        org.junit.Assert.assertNotNull(strBuilder46);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance("0");
        org.junit.Assert.assertNotNull(strTokenizer1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        org.apache.commons.lang.text.StrMatcher strMatcher10 = strTokenizer9.getQuoteMatcher();
        char[] charArray12 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray12, '#', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer9.reset(charArray12);
        java.lang.String str17 = strTokenizer16.nextToken();
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer16.setQuoteChar('3');
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[hi!]");
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setDelimiterChar('4');
        try {
            strTokenizer16.set((java.lang.Object) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: set() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strMatcher10);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "a" + "'", str17.equals("a"));
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strTokenizer23);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        java.lang.String[] strArray10 = strTokenizer9.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer9.setQuoteMatcher(strMatcher11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer12.reset("#  a a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer12.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer12.reset();
        int int18 = strTokenizer17.previousIndex();
        boolean boolean19 = strTokenizer17.hasNext();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        int int17 = strBuilder4.indexOf('#', (int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder4.insert((int) (byte) 0, false);
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder4.deleteAll('S');
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        java.io.Reader reader15 = strBuilder4.asReader();
        int int16 = strBuilder4.length();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder4.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder4.replaceAll("\naaaaaaaa10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "#  a a");
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(reader15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder21);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", '4', '#');
        char[] charArray10 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray10);
        org.apache.commons.lang.text.StrMatcher strMatcher14 = strTokenizer13.getQuoteMatcher();
        char[] charArray16 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer(charArray16, '#', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer13.reset(charArray16);
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer20.setQuoteMatcher(strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer3.setIgnoredMatcher(strMatcher31);
        boolean boolean34 = strTokenizer33.isIgnoreEmptyTokens();
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strMatcher14);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder14.replaceFirst('a', 'a');
        int int19 = strBuilder14.lastIndexOf('4');
        java.lang.String str20 = strBuilder14.getNullText();
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((java.lang.Object) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.insert(0, "");
        try {
            char[] charArray11 = strBuilder8.toCharArray(11, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        int int10 = strBuilder8.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder8.replaceFirst("#  a a", "hi!");
        int int16 = strBuilder13.lastIndexOf("01.0", (int) '3');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        int int18 = strBuilder16.lastIndexOf(' ');
        java.util.Collection collection19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder16.appendWithSeparators(collection19, "#  a a");
        int int23 = strBuilder21.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder25.appendNewLine();
        char[] charArray35 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher36 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray35, strMatcher36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray35);
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer38.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder28.deleteFirst(strMatcher39);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder40.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder40.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder46.appendPadding(0, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder46.append((float) '#');
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder46.append((int) '#');
        boolean boolean54 = strBuilder21.equals((java.lang.Object) strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strMatcher39);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder16.appendFixedWidthPadRight((java.lang.Object) strMatcher32, 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.appendPadding((int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder("StrTokenizer[hi!]");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder41.append('3');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder38.insert((int) (short) 100, (java.lang.Object) strBuilder41);
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder38.insert(3, 100);
        int int49 = strBuilder47.lastIndexOf("hi!");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 116 + "'", int49 == 116);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        int int18 = strBuilder4.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder4.appendFixedWidthPadRight(5, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder22.appendFixedWidthPadLeft((int) (byte) 100, (int) (short) 10, '4');
        java.lang.String str29 = strBuilder22.substring(8, (int) 'a');
        int int31 = strBuilder22.indexOf('#');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "aaa4444444100" + "'", str29.equals("aaa4444444100"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder2.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder2.appendNewLine();
        char[] charArray12 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher13 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = new org.apache.commons.lang.text.StrTokenizer(charArray12, strMatcher13);
        int int15 = strTokenizer14.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer14.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer16.setIgnoredMatcher(strMatcher17);
        char[] charArray25 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher26 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer(charArray25, strMatcher26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray25);
        org.apache.commons.lang.text.StrMatcher strMatcher29 = strTokenizer28.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer16.setQuoteMatcher(strMatcher29);
        int int31 = strBuilder2.indexOf(strMatcher29);
        char[] charArray38 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher39 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer(charArray38, strMatcher39);
        int int41 = strTokenizer40.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer40.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher43 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer42.setIgnoredMatcher(strMatcher43);
        char[] charArray51 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher52 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer(charArray51, strMatcher52);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray51);
        org.apache.commons.lang.text.StrMatcher strMatcher55 = strTokenizer54.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer42.setQuoteMatcher(strMatcher55);
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer("#  a a", strMatcher29, strMatcher55);
        java.lang.String str58 = strTokenizer57.nextToken();
        int int59 = strTokenizer57.previousIndex();
        java.lang.Object obj60 = strTokenizer57.previous();
        int int61 = strTokenizer57.nextIndex();
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strMatcher29);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(charArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(charArray51);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strMatcher55);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "#  a a" + "'", str58.equals("#  a a"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + obj60 + "' != '" + "#  a a" + "'", obj60.equals("#  a a"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder16.appendFixedWidthPadRight((java.lang.Object) strMatcher32, 0, '4');
        java.lang.String str37 = strBuilder35.rightString(0);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder38.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder40.setNullText("StrTokenizer[hi!]");
        boolean boolean43 = strBuilder35.equals((java.lang.Object) strBuilder40);
        org.apache.commons.lang.text.StrBuilder strBuilder45 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder45.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder49 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder49.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder52.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder47.appendFixedWidthPadLeft((java.lang.Object) strBuilder52, (int) (byte) 10, 'a');
        char[] charArray59 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = new org.apache.commons.lang.text.StrTokenizer(charArray59, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder52.append(charArray59);
        org.apache.commons.lang.text.StrMatcher strMatcher64 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder63.replace(strMatcher64, "", 1, 100, (int) 'a');
        java.io.Writer writer70 = strBuilder69.asWriter();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder40.append((java.lang.Object) strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(writer70);
        org.junit.Assert.assertNotNull(strBuilder71);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.reverse();
        char[] charArray10 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher11);
        org.apache.commons.lang.text.StrMatcher strMatcher13 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher13, strMatcher14);
        char[] charArray20 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer15.reset(charArray20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray20, '#', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder0.append(charArray20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer(charArray20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray20);
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strTokenizer28);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder0.appendFixedWidthPadRight(8, (int) (byte) 100, 'a');
        java.lang.String str5 = strBuilder4.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder4.insert((int) 'a', true);
        int int10 = strBuilder4.lastIndexOf(' ');
        boolean boolean12 = strBuilder4.contains("                                    ");
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.deleteFirst("hi!");
        boolean boolean13 = strBuilder10.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder10.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder10.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder19.appendNewLine();
        char[] charArray29 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray29, strMatcher30);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray29);
        org.apache.commons.lang.text.StrMatcher strMatcher33 = strTokenizer32.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder22.deleteFirst(strMatcher33);
        int int36 = strBuilder17.lastIndexOf(strMatcher33, 10);
        int int39 = strBuilder17.indexOf("hi!", 0);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder17.append(strBuilder41);
        java.lang.StringBuffer stringBuffer43 = strBuilder42.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder8.append(stringBuffer43);
        java.lang.String str46 = strBuilder8.rightString((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder8.insert(0, (long) 8);
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder49.trim();
        java.lang.String str51 = strBuilder50.getNullText();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(stringBuffer43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "01.001.0hi!" + "'", str46.equals("01.001.0hi!"));
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNull(str51);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        int int18 = strBuilder4.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder4.appendPadding((int) (byte) 100, ' ');
        char[] charArray28 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer(charArray28, strMatcher29);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray28);
        boolean boolean32 = strTokenizer31.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher33 = strTokenizer31.getQuoteMatcher();
        int int34 = strBuilder21.lastIndexOf(strMatcher33);
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder21.insert(5, 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder37.setCharAt(1, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder37.deleteAll("StrTokenizer[#  a a]");
        int int44 = strBuilder42.indexOf('a');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray6, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        int int13 = strTokenizer10.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer10.setIgnoredChar('a');
        java.lang.Object obj16 = strTokenizer10.next();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + "#   " + "'", obj16.equals("#   "));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        char[] charArray7 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher8 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray7, strMatcher8);
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray7, strMatcher10, strMatcher11);
        char[] charArray19 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer(charArray19, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray19);
        org.apache.commons.lang.text.StrMatcher strMatcher23 = strTokenizer22.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer12.setTrimmerMatcher(strMatcher23);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("aaaaaaaaa", strMatcher23, strMatcher25);
        org.apache.commons.lang.text.StrMatcher strMatcher27 = strTokenizer26.getIgnoredMatcher();
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strMatcher23);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher27);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        boolean boolean16 = strBuilder4.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder4.appendFixedWidthPadRight(0, (int) (byte) 0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.deleteFirst("hi!");
        boolean boolean25 = strBuilder22.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder22.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder22.appendPadding(0, '4');
        java.lang.String str31 = strBuilder22.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder33.appendNewLine();
        char[] charArray43 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray43, strMatcher44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray43);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer46.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder36.deleteFirst(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder48.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder48.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder56.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.appendNewLine();
        char[] charArray66 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher67 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer(charArray66, strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray66);
        org.apache.commons.lang.text.StrMatcher strMatcher70 = strTokenizer69.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder59.deleteFirst(strMatcher70);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder71.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int76 = strBuilder75.capacity();
        boolean boolean77 = strBuilder54.equals(strBuilder75);
        boolean boolean78 = strBuilder22.equalsIgnoreCase(strBuilder75);
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder22.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder80.deleteAll("");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder20.appendFixedWidthPadLeft((java.lang.Object) "", (-1), 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder87 = strBuilder85.append("01.001.0hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder87.deleteAll('3');
        org.apache.commons.lang.text.StrBuilder strBuilder91 = strBuilder87.append(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder93 = strBuilder87.deleteFirst("");
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strMatcher70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 35 + "'", int76 == 35);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(strBuilder87);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder91);
        org.junit.Assert.assertNotNull(strBuilder93);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        java.io.Reader reader15 = strBuilder4.asReader();
        int int16 = strBuilder4.length();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder4.append(true);
        int int20 = strBuilder18.lastIndexOf("a");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder22.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder25.appendWithSeparators((java.util.Iterator) strTokenizer31, "");
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.replaceFirst('a', 'a');
        boolean boolean39 = strBuilder18.equals((java.lang.Object) strBuilder38);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder38.delete(104, 116);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(reader15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray7 = strBuilder1.toCharArray(0, (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.deleteFirst("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.deleteFirst("StrTokenizer[#  a a]");
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder1.delete((int) '4', (int) 'i');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        char[] charArray9 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray9, '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray9, ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray9);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.deleteFirst("hi!");
        boolean boolean19 = strBuilder16.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder16.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder16.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder25.appendNewLine();
        char[] charArray35 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher36 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray35, strMatcher36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray35);
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer38.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder28.deleteFirst(strMatcher39);
        int int42 = strBuilder23.lastIndexOf(strMatcher39, 10);
        int int45 = strBuilder23.indexOf("hi!", 0);
        org.apache.commons.lang.text.StrBuilder strBuilder47 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder23.append(strBuilder47);
        char[] charArray56 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher57 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer(charArray56, strMatcher57);
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer(charArray56, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray56);
        char[] charArray68 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher69 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer(charArray68, strMatcher69);
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray68);
        org.apache.commons.lang.text.StrMatcher strMatcher72 = strTokenizer71.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = new org.apache.commons.lang.text.StrTokenizer(charArray56, strMatcher72);
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = new org.apache.commons.lang.text.StrTokenizer("#  a a", strMatcher72);
        int int76 = strBuilder47.indexOf(strMatcher72, (int) 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strTokenizer14.setIgnoredMatcher(strMatcher72);
        try {
            strTokenizer77.set((java.lang.Object) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: set() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strMatcher39);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(charArray56);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(charArray68);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertNotNull(strMatcher72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer77);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        boolean boolean16 = strBuilder4.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder4.appendFixedWidthPadRight(0, (int) (byte) 0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.deleteFirst("hi!");
        boolean boolean25 = strBuilder22.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder22.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder22.appendPadding(0, '4');
        java.lang.String str31 = strBuilder22.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder33.appendNewLine();
        char[] charArray43 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray43, strMatcher44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray43);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer46.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder36.deleteFirst(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder48.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder48.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder56.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.appendNewLine();
        char[] charArray66 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher67 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer(charArray66, strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray66);
        org.apache.commons.lang.text.StrMatcher strMatcher70 = strTokenizer69.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder59.deleteFirst(strMatcher70);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder71.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int76 = strBuilder75.capacity();
        boolean boolean77 = strBuilder54.equals(strBuilder75);
        boolean boolean78 = strBuilder22.equalsIgnoreCase(strBuilder75);
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder22.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder80.deleteAll("");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder20.appendFixedWidthPadLeft((java.lang.Object) "", (-1), 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder86 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder20.append(strBuilder86, (int) (byte) 10, (int) (short) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder90 = strBuilder89.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder92 = strBuilder89.append((long) (byte) -1);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strMatcher70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 35 + "'", int76 == 35);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder90);
        org.junit.Assert.assertNotNull(strBuilder92);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.deleteFirst("hi!");
        boolean boolean13 = strBuilder10.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder10.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder10.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder19.appendNewLine();
        char[] charArray29 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray29, strMatcher30);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray29);
        org.apache.commons.lang.text.StrMatcher strMatcher33 = strTokenizer32.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder22.deleteFirst(strMatcher33);
        int int36 = strBuilder17.lastIndexOf(strMatcher33, 10);
        int int39 = strBuilder17.indexOf("hi!", 0);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder17.append(strBuilder41);
        java.lang.StringBuffer stringBuffer43 = strBuilder42.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder8.append(stringBuffer43);
        org.apache.commons.lang.text.StrBuilder strBuilder46 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder46.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder46.appendNewLine();
        char[] charArray56 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher57 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer(charArray56, strMatcher57);
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray56);
        org.apache.commons.lang.text.StrMatcher strMatcher60 = strTokenizer59.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder49.deleteFirst(strMatcher60);
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder61.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder61.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder69 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder69.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder69.appendNewLine();
        char[] charArray79 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher80 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer81 = new org.apache.commons.lang.text.StrTokenizer(charArray79, strMatcher80);
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray79);
        org.apache.commons.lang.text.StrMatcher strMatcher83 = strTokenizer82.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder84 = strBuilder72.deleteFirst(strMatcher83);
        org.apache.commons.lang.text.StrBuilder strBuilder88 = strBuilder84.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int89 = strBuilder88.capacity();
        boolean boolean90 = strBuilder67.equals(strBuilder88);
        org.apache.commons.lang.text.StrBuilder strBuilder92 = strBuilder67.deleteFirst("StrTokenizer[not tokenized yet]");
        java.lang.StringBuffer stringBuffer93 = strBuilder67.toStringBuffer();
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder96 = strBuilder44.append(stringBuffer93, (int) (short) -1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: startIndex must be valid");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(stringBuffer43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(charArray56);
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertNotNull(strMatcher60);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder72);
        org.junit.Assert.assertNotNull(charArray79);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertNotNull(strMatcher83);
        org.junit.Assert.assertNotNull(strBuilder84);
        org.junit.Assert.assertNotNull(strBuilder88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 35 + "'", int89 == 35);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(strBuilder92);
        org.junit.Assert.assertNotNull(stringBuffer93);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.deleteFirst("hi!");
        boolean boolean18 = strBuilder15.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder15.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder15.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder24.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder24.appendNewLine();
        char[] charArray34 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray34);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer37.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder27.deleteFirst(strMatcher38);
        int int41 = strBuilder22.lastIndexOf(strMatcher38, 10);
        java.io.Reader reader42 = strBuilder22.asReader();
        java.lang.StringBuffer stringBuffer43 = strBuilder22.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder13.append(stringBuffer43);
        int int47 = strBuilder44.lastIndexOf("01.001.0hi!", (int) (short) -1);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strMatcher38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(reader42);
        org.junit.Assert.assertNotNull(stringBuffer43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        char[] charArray16 = new char[] { 'a' };
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder4.append(charArray16);
        java.util.Collection collection18 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder4.appendWithSeparators(collection18, "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer("", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer23, "StrTokenizer[hi!]");
        int int26 = strTokenizer23.previousIndex();
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray6, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        int int13 = strTokenizer10.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer10.setIgnoredChar('a');
        boolean boolean16 = strTokenizer15.hasNext();
        java.lang.String str17 = strTokenizer15.toString();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "StrTokenizer[#   ]" + "'", str17.equals("StrTokenizer[#   ]"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.delete(0, 0);
        boolean boolean13 = strBuilder1.contains('a');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.append('3');
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setQuoteChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder24.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder24.appendNewLine();
        char[] charArray34 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray34);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer37.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder27.deleteFirst(strMatcher38);
        int int41 = strBuilder27.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder27.appendPadding((int) (byte) 100, ' ');
        char[] charArray51 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher52 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer(charArray51, strMatcher52);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray51);
        boolean boolean55 = strTokenizer54.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher56 = strTokenizer54.getQuoteMatcher();
        int int57 = strBuilder44.lastIndexOf(strMatcher56);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer20.setDelimiterMatcher(strMatcher56);
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder15.replace(strMatcher56, "hi!", (int) (short) 1, 99, (-1));
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder63.insert(15, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 15");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strMatcher38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(charArray51);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(strMatcher56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strBuilder63);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        char[] charArray8 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray8, strMatcher9);
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray8, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray8);
        char[] charArray20 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray20, strMatcher21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray20);
        org.apache.commons.lang.text.StrMatcher strMatcher24 = strTokenizer23.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray8, strMatcher24);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[not tokenized yet]", strMatcher24);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer("#   ", strMatcher24);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strMatcher24);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher9, strMatcher10);
        char[] charArray18 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray18, strMatcher19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray18);
        org.apache.commons.lang.text.StrMatcher strMatcher22 = strTokenizer21.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer11.setTrimmerMatcher(strMatcher22);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder26.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder26.appendNewLine();
        char[] charArray36 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher37 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray36, strMatcher37);
        int int39 = strTokenizer38.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher41 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer40.setIgnoredMatcher(strMatcher41);
        char[] charArray49 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher50 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = new org.apache.commons.lang.text.StrTokenizer(charArray49, strMatcher50);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray49);
        org.apache.commons.lang.text.StrMatcher strMatcher53 = strTokenizer52.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer40.setQuoteMatcher(strMatcher53);
        int int55 = strBuilder26.indexOf(strMatcher53);
        char[] charArray62 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher63 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = new org.apache.commons.lang.text.StrTokenizer(charArray62, strMatcher63);
        int int65 = strTokenizer64.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer64.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher67 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = strTokenizer66.setIgnoredMatcher(strMatcher67);
        char[] charArray75 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher76 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = new org.apache.commons.lang.text.StrTokenizer(charArray75, strMatcher76);
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray75);
        org.apache.commons.lang.text.StrMatcher strMatcher79 = strTokenizer78.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = strTokenizer66.setQuoteMatcher(strMatcher79);
        org.apache.commons.lang.text.StrTokenizer strTokenizer81 = new org.apache.commons.lang.text.StrTokenizer("#  a a", strMatcher53, strMatcher79);
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = strTokenizer11.setDelimiterMatcher(strMatcher53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = strTokenizer82.setDelimiterChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher85 = strTokenizer82.getDelimiterMatcher();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strMatcher22);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(charArray49);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strMatcher53);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(charArray62);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(strTokenizer68);
        org.junit.Assert.assertNotNull(charArray75);
        org.junit.Assert.assertNotNull(strTokenizer78);
        org.junit.Assert.assertNotNull(strMatcher79);
        org.junit.Assert.assertNotNull(strTokenizer80);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertNotNull(strTokenizer84);
        org.junit.Assert.assertNotNull(strMatcher85);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.reverse();
        char[] charArray10 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher11);
        org.apache.commons.lang.text.StrMatcher strMatcher13 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher13, strMatcher14);
        char[] charArray20 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer15.reset(charArray20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray20, '#', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder0.append(charArray20);
        java.lang.String str29 = strBuilder0.substring((int) (byte) 0, 5);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder0.deleteFirst('3');
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "eurta" + "'", str29.equals("eurta"));
        org.junit.Assert.assertNotNull(strBuilder31);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        boolean boolean16 = strBuilder4.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder4.appendFixedWidthPadRight(0, (int) (byte) 0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.deleteFirst("hi!");
        boolean boolean25 = strBuilder22.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder22.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder22.appendPadding(0, '4');
        java.lang.String str31 = strBuilder22.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder33.appendNewLine();
        char[] charArray43 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray43, strMatcher44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray43);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer46.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder36.deleteFirst(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder48.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder48.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder56.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.appendNewLine();
        char[] charArray66 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher67 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer(charArray66, strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray66);
        org.apache.commons.lang.text.StrMatcher strMatcher70 = strTokenizer69.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder59.deleteFirst(strMatcher70);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder71.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int76 = strBuilder75.capacity();
        boolean boolean77 = strBuilder54.equals(strBuilder75);
        boolean boolean78 = strBuilder22.equalsIgnoreCase(strBuilder75);
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder22.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder80.deleteAll("");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder20.appendFixedWidthPadLeft((java.lang.Object) "", (-1), 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder87 = strBuilder85.append("01.001.0hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder87.deleteAll('3');
        org.apache.commons.lang.text.StrBuilder strBuilder92 = strBuilder87.insert((int) (short) 10, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder94 = strBuilder87.deleteAll("51");
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strMatcher70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 35 + "'", int76 == 35);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(strBuilder87);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder92);
        org.junit.Assert.assertNotNull(strBuilder94);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        char[] charArray7 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher8 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray7, strMatcher8);
        int int10 = strTokenizer9.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoredMatcher(strMatcher12);
        char[] charArray20 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray20, strMatcher21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray20);
        org.apache.commons.lang.text.StrMatcher strMatcher24 = strTokenizer23.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer11.setQuoteMatcher(strMatcher24);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(true);
        java.lang.String[] strArray32 = strTokenizer31.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher33 = strTokenizer31.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer25.setDelimiterMatcher(strMatcher33);
        char[] charArray41 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher42 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer(charArray41, strMatcher42);
        int int44 = strTokenizer43.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer43.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer45.setIgnoredMatcher(strMatcher46);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder49.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder49.appendNewLine();
        char[] charArray59 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher60 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer(charArray59, strMatcher60);
        int int62 = strTokenizer61.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = strTokenizer61.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher64 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer63.setIgnoredMatcher(strMatcher64);
        char[] charArray72 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher73 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = new org.apache.commons.lang.text.StrTokenizer(charArray72, strMatcher73);
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray72);
        org.apache.commons.lang.text.StrMatcher strMatcher76 = strTokenizer75.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strTokenizer63.setQuoteMatcher(strMatcher76);
        int int78 = strBuilder49.indexOf(strMatcher76);
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = strTokenizer47.setIgnoredMatcher(strMatcher76);
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[not tokenized yet]", strMatcher33, strMatcher76);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strMatcher24);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer63);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertNotNull(charArray72);
        org.junit.Assert.assertNotNull(strTokenizer75);
        org.junit.Assert.assertNotNull(strMatcher76);
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer79);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        char[] charArray15 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray15, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder8.append(charArray15);
        char[] charArray26 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher27);
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher29, strMatcher30);
        char[] charArray36 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer31.reset(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray36);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder8.appendWithSeparators((java.util.Iterator) strTokenizer39, "");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder8.append(strBuilder42, (int) (short) -1, (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder8.deleteAll('a');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder47);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        boolean boolean16 = strBuilder4.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder4.appendFixedWidthPadRight(0, (int) (byte) 0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.deleteFirst("hi!");
        boolean boolean25 = strBuilder22.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder22.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder22.appendPadding(0, '4');
        java.lang.String str31 = strBuilder22.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder33.appendNewLine();
        char[] charArray43 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray43, strMatcher44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray43);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer46.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder36.deleteFirst(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder48.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder48.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder56.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.appendNewLine();
        char[] charArray66 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher67 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer(charArray66, strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray66);
        org.apache.commons.lang.text.StrMatcher strMatcher70 = strTokenizer69.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder59.deleteFirst(strMatcher70);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder71.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int76 = strBuilder75.capacity();
        boolean boolean77 = strBuilder54.equals(strBuilder75);
        boolean boolean78 = strBuilder22.equalsIgnoreCase(strBuilder75);
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder22.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder80.deleteAll("");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder20.appendFixedWidthPadLeft((java.lang.Object) "", (-1), 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder87 = strBuilder85.append("01.001.0hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder87.deleteAll('3');
        org.apache.commons.lang.text.StrBuilder strBuilder92 = strBuilder87.insert((int) (short) 10, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder93 = strBuilder92.trim();
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strMatcher70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 35 + "'", int76 == 35);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(strBuilder87);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder92);
        org.junit.Assert.assertNotNull(strBuilder93);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance("StrTokenizer[not tokenized yet]");
        int int2 = strTokenizer1.size();
        char[] charArray9 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray9, strMatcher10);
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher13 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = new org.apache.commons.lang.text.StrTokenizer(charArray9, strMatcher12, strMatcher13);
        char[] charArray19 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer14.reset(charArray19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer1.reset(charArray19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer22.reset("StrTokenizer[hi!]");
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer24.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer24.setDelimiterChar('#');
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strTokenizer27);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        java.lang.String str7 = strBuilder6.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.deleteAll("");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder6.append((int) '3');
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        int int13 = strBuilder6.indexOf(strMatcher12);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        java.io.Reader reader14 = strBuilder8.asReader();
        java.lang.Object obj15 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder8.appendFixedWidthPadRight(obj15, 0, ' ');
        boolean boolean19 = strBuilder18.isEmpty();
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer("", '4', '#');
        char[] charArray30 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher31 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray30, strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray30);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer33.getQuoteMatcher();
        char[] charArray36 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer(charArray36, '#', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer33.reset(charArray36);
        char[] charArray47 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher48 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = new org.apache.commons.lang.text.StrTokenizer(charArray47, strMatcher48);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray47);
        org.apache.commons.lang.text.StrMatcher strMatcher51 = strTokenizer50.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer40.setQuoteMatcher(strMatcher51);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer23.setIgnoredMatcher(strMatcher51);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer23.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder57 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder57.deleteFirst("hi!");
        boolean boolean60 = strBuilder57.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder57.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder57.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder66 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder66.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder66.appendNewLine();
        char[] charArray76 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher77 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = new org.apache.commons.lang.text.StrTokenizer(charArray76, strMatcher77);
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray76);
        org.apache.commons.lang.text.StrMatcher strMatcher80 = strTokenizer79.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder69.deleteFirst(strMatcher80);
        int int83 = strBuilder64.lastIndexOf(strMatcher80, 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = strTokenizer23.setTrimmerMatcher(strMatcher80);
        int int85 = strBuilder18.indexOf(strMatcher80);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(reader14);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(charArray47);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strMatcher51);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(charArray76);
        org.junit.Assert.assertNotNull(strTokenizer79);
        org.junit.Assert.assertNotNull(strMatcher80);
        org.junit.Assert.assertNotNull(strBuilder81);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1) + "'", int85 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        boolean boolean18 = strBuilder4.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder4.replaceAll('a', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder23.deleteFirst("hi!");
        boolean boolean26 = strBuilder23.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder23.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder23.appendPadding(0, '4');
        java.lang.String str32 = strBuilder23.getNewLineText();
        int int35 = strBuilder23.indexOf(' ', 35);
        char[] charArray42 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher43 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray42, strMatcher43);
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray42);
        java.util.List list46 = strTokenizer45.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder23.appendWithSeparators((java.util.Collection) list46, "\naaaaaaaa101");
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder4.appendWithSeparators((java.util.Collection) list46, "aaaaaaaaa");
        java.lang.Object obj52 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder50.insert((int) (byte) 0, obj52);
        char[] charArray56 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = new org.apache.commons.lang.text.StrTokenizer(charArray56, '#', '4');
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder50.insert(35, charArray56, (int) '3', 101);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 35");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(charArray42);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(charArray56);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        int int9 = strTokenizer8.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer8.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoredMatcher(strMatcher11);
        char[] charArray19 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer(charArray19, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray19);
        org.apache.commons.lang.text.StrMatcher strMatcher23 = strTokenizer22.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer10.setQuoteMatcher(strMatcher23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer10.setIgnoredChar('#');
        java.lang.String str27 = strTokenizer26.previousToken();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strMatcher23);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        org.apache.commons.lang.text.StrMatcher strMatcher15 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder14.replaceFirst(strMatcher15, "\naaaa");
        java.lang.StringBuffer stringBuffer18 = strBuilder14.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder20.deleteFirst("hi!");
        boolean boolean23 = strBuilder20.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder20.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder20.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder29.deleteFirst("hi!");
        boolean boolean32 = strBuilder29.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder29.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder29.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder38.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder38.appendNewLine();
        char[] charArray48 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer(charArray48, strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray48);
        org.apache.commons.lang.text.StrMatcher strMatcher52 = strTokenizer51.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder41.deleteFirst(strMatcher52);
        int int55 = strBuilder36.lastIndexOf(strMatcher52, 10);
        int int58 = strBuilder36.indexOf("hi!", 0);
        org.apache.commons.lang.text.StrBuilder strBuilder60 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder36.append(strBuilder60);
        java.lang.StringBuffer stringBuffer62 = strBuilder61.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder27.append(stringBuffer62);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder14.append(stringBuffer62, (int) (short) 100, (int) 'i');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: startIndex must be valid");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(stringBuffer18);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(charArray48);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strMatcher52);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(stringBuffer62);
        org.junit.Assert.assertNotNull(strBuilder63);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        char[] charArray7 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher8 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray7, strMatcher8);
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray7);
        org.apache.commons.lang.text.StrMatcher strMatcher11 = strTokenizer10.getQuoteMatcher();
        char[] charArray13 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer(charArray13, '#', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer10.reset(charArray13);
        char[] charArray24 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher25 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer(charArray24, strMatcher25);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray24);
        org.apache.commons.lang.text.StrMatcher strMatcher28 = strTokenizer27.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer17.setQuoteMatcher(strMatcher28);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder31.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.appendNewLine();
        char[] charArray41 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher42 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer(charArray41, strMatcher42);
        int int44 = strTokenizer43.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer43.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer45.setIgnoredMatcher(strMatcher46);
        char[] charArray54 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher55 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer(charArray54, strMatcher55);
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray54);
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer57.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = strTokenizer45.setQuoteMatcher(strMatcher58);
        int int60 = strBuilder31.indexOf(strMatcher58);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[not tokenized yet]", strMatcher28, strMatcher58);
        org.apache.commons.lang.text.StrMatcher strMatcher62 = strTokenizer61.getDelimiterMatcher();
        org.apache.commons.lang.text.StrMatcher strMatcher63 = strTokenizer61.getIgnoredMatcher();
        java.lang.String str64 = strTokenizer61.previousToken();
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertNotNull(strMatcher11);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strMatcher28);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(strMatcher62);
        org.junit.Assert.assertNotNull(strMatcher63);
        org.junit.Assert.assertNull(str64);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        java.lang.String[] strArray10 = strTokenizer9.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer9.setQuoteMatcher(strMatcher11);
        java.lang.Class<?> wildcardClass13 = strTokenizer9.getClass();
        java.lang.String str14 = strTokenizer9.nextToken();
        int int15 = strTokenizer9.nextIndex();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#  a a" + "'", str14.equals("#  a a"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder16.appendFixedWidthPadRight((java.lang.Object) strMatcher32, 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.appendPadding((int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder35.appendNull();
        java.lang.String str40 = strBuilder35.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder35.deleteAll('i');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(strBuilder42);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder9.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder7.appendFixedWidthPadLeft((java.lang.Object) strBuilder12, (int) (byte) 10, 'a');
        boolean boolean18 = strBuilder1.equals(strBuilder12);
        java.lang.String str20 = strBuilder1.substring(0);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = strTokenizer1.reset("aaaaaa10");
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertNotNull(strTokenizer3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((int) (short) -1, (int) (short) 0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder26.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder29.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder24.appendFixedWidthPadLeft((java.lang.Object) strBuilder29, (int) (byte) 10, 'a');
        char[] charArray36 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer(charArray36, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder29.append(charArray36);
        org.apache.commons.lang.text.StrBuilder strBuilder42 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder42.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder42.appendNewLine();
        char[] charArray52 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher53 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer(charArray52, strMatcher53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray52);
        org.apache.commons.lang.text.StrMatcher strMatcher56 = strTokenizer55.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder45.deleteFirst(strMatcher56);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder29.replaceAll(strMatcher56, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder16.deleteFirst(strMatcher56);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(charArray52);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strMatcher56);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder60);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = strTokenizer2.setQuoteChar('a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer6 = strTokenizer4.setDelimiterChar('#');
        java.lang.String str7 = strTokenizer4.previousToken();
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strTokenizer4.setDelimiterChar('#');
        org.junit.Assert.assertNotNull(strTokenizer4);
        org.junit.Assert.assertNotNull(strTokenizer6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(strTokenizer9);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((java.lang.Object) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.insert(0, "");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder8.replaceFirst('a', 'a');
        char[] charArray18 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray18, strMatcher19);
        int int21 = strTokenizer20.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer22.setIgnoredMatcher(strMatcher23);
        char[] charArray31 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher32 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer(charArray31, strMatcher32);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray31);
        org.apache.commons.lang.text.StrMatcher strMatcher35 = strTokenizer34.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer22.setQuoteMatcher(strMatcher35);
        char[] charArray43 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray43, strMatcher44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer(charArray43, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray43);
        char[] charArray55 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher56 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer(charArray55, strMatcher56);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray55);
        org.apache.commons.lang.text.StrMatcher strMatcher59 = strTokenizer58.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer(charArray43, strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer22.setQuoteMatcher(strMatcher59);
        int int62 = strBuilder11.indexOf(strMatcher59);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strMatcher35);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(charArray55);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strMatcher59);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.appendNewLine();
        char[] charArray20 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray20, strMatcher21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray20);
        org.apache.commons.lang.text.StrMatcher strMatcher24 = strTokenizer23.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder13.deleteFirst(strMatcher24);
        int int27 = strBuilder8.lastIndexOf(strMatcher24, 10);
        int int30 = strBuilder8.indexOf("hi!", 0);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder8.append(strBuilder32);
        int int34 = strBuilder32.size();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strMatcher24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 3 + "'", int34 == 3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((int) (short) -1, (int) (short) 0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder16.replaceFirst('4', 'a');
        java.io.Writer writer24 = strBuilder23.asWriter();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(writer24);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("StrTokenizer[not tokenized yet]");
        java.lang.String str2 = strBuilder1.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.deleteAll("");
        java.lang.String str8 = strBuilder3.midString(116, (int) (short) 1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder16.appendFixedWidthPadRight((java.lang.Object) strMatcher32, 0, '4');
        char[] charArray36 = strBuilder16.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray36);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strTokenizer37);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder16.appendFixedWidthPadRight((java.lang.Object) strMatcher32, 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.appendPadding((int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder("StrTokenizer[hi!]");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder41.append('3');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder38.insert((int) (short) 100, (java.lang.Object) strBuilder41);
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder38.insert(3, 100);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder47.reverse();
        boolean boolean50 = strBuilder48.startsWith("\n5aaaaaaaaa4444444100");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        java.lang.String str16 = strBuilder13.midString((int) (short) 1, 11);
        java.lang.Class<?> wildcardClass17 = strBuilder13.getClass();
        int int20 = strBuilder13.indexOf('S', (int) (short) 100);
        int int21 = strBuilder13.length();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "aaaaaaaaa" + "'", str16.equals("aaaaaaaaa"));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        org.apache.commons.lang.text.StrMatcher strMatcher10 = strTokenizer9.getQuoteMatcher();
        char[] charArray12 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray12, '#', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer9.reset(charArray12);
        char[] charArray23 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher24 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray23, strMatcher24);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray23);
        org.apache.commons.lang.text.StrMatcher strMatcher27 = strTokenizer26.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer16.setQuoteMatcher(strMatcher27);
        boolean boolean29 = strTokenizer16.hasPrevious();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strMatcher10);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strMatcher27);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.appendFixedWidthPadRight((int) '#', 100, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder1.appendFixedWidthPadLeft((int) (byte) 1, 5, 'a');
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        char[] charArray15 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray15, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder8.append(charArray15);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder21.appendNewLine();
        char[] charArray31 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher32 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer(charArray31, strMatcher32);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray31);
        org.apache.commons.lang.text.StrMatcher strMatcher35 = strTokenizer34.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder24.deleteFirst(strMatcher35);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder8.replaceAll(strMatcher35, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder38.trim();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strMatcher35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder39);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder14.replaceFirst('a', 'a');
        int int19 = strBuilder14.lastIndexOf('4');
        try {
            char char21 = strBuilder14.charAt(11);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 11");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((double) 10.0f);
        boolean boolean10 = strBuilder8.endsWith("aaa4444444100");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        char[] charArray9 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray9, '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray9, ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = new org.apache.commons.lang.text.StrTokenizer(charArray9);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(charArray9);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(' ');
        char[] charArray23 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher24 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray23, strMatcher24);
        int int26 = strTokenizer25.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer25.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer27.setIgnoredMatcher(strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(false);
        java.lang.Object obj32 = strTokenizer31.clone();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder4.append((java.lang.Object) strTokenizer31);
        int int34 = strTokenizer31.previousIndex();
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder0.appendFixedWidthPadRight(8, (int) (byte) 100, 'a');
        java.lang.String str5 = strBuilder4.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder4.insert((int) 'a', true);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.deleteFirst("hi!");
        boolean boolean13 = strBuilder10.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder10.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder10.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder19.appendNewLine();
        char[] charArray29 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray29, strMatcher30);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray29);
        org.apache.commons.lang.text.StrMatcher strMatcher33 = strTokenizer32.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder22.deleteFirst(strMatcher33);
        int int36 = strBuilder17.lastIndexOf(strMatcher33, 10);
        int int39 = strBuilder17.indexOf("hi!", 0);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder17.append(strBuilder41);
        java.lang.StringBuffer stringBuffer43 = strBuilder42.toStringBuffer();
        int int45 = strBuilder42.lastIndexOf('a');
        boolean boolean46 = strBuilder8.equalsIgnoreCase(strBuilder42);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance("01.0");
        org.apache.commons.lang.text.StrMatcher strMatcher49 = strTokenizer48.getIgnoredMatcher();
        int int50 = strBuilder42.lastIndexOf(strMatcher49);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(stringBuffer43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strMatcher49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        int int18 = strBuilder16.lastIndexOf(' ');
        java.util.Collection collection19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder16.appendWithSeparators(collection19, "#  a a");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.append((long) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder21.append('4');
        char[] charArray32 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher33 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer(charArray32, strMatcher33);
        int int35 = strTokenizer34.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer34.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher37 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer36.setIgnoredMatcher(strMatcher37);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder40.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder40.appendNewLine();
        char[] charArray50 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher51 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer(charArray50, strMatcher51);
        int int53 = strTokenizer52.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer52.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher55 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer54.setIgnoredMatcher(strMatcher55);
        char[] charArray63 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher64 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = new org.apache.commons.lang.text.StrTokenizer(charArray63, strMatcher64);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray63);
        org.apache.commons.lang.text.StrMatcher strMatcher67 = strTokenizer66.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = strTokenizer54.setQuoteMatcher(strMatcher67);
        int int69 = strBuilder40.indexOf(strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = strTokenizer38.setIgnoredMatcher(strMatcher67);
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder21.deleteAll(strMatcher67);
        java.lang.String str72 = strBuilder71.toString();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(charArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(charArray50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(charArray63);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(strMatcher67);
        org.junit.Assert.assertNotNull(strTokenizer68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "\n524" + "'", str72.equals("\n524"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder16.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder24.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder24.appendNewLine();
        char[] charArray34 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray34);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer37.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder27.deleteFirst(strMatcher38);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder39.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int44 = strBuilder43.capacity();
        boolean boolean45 = strBuilder22.equals(strBuilder43);
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder22.deleteFirst("StrTokenizer[not tokenized yet]");
        char[] charArray54 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher55 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer(charArray54, strMatcher55);
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray54);
        boolean boolean58 = strTokenizer57.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher59 = strTokenizer57.getQuoteMatcher();
        int int60 = strBuilder47.lastIndexOf(strMatcher59);
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder47.setCharAt((int) (byte) 10, '3');
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder47.insert((int) (byte) 100, (int) 'S');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 100");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strMatcher38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 35 + "'", int44 == 35);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(strMatcher59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(strBuilder63);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher9, strMatcher10);
        char[] charArray16 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray16);
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer11.reset(charArray16);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray16, '3');
        boolean boolean21 = strTokenizer20.hasPrevious();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.appendNewLine();
        char[] charArray20 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray20, strMatcher21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray20);
        org.apache.commons.lang.text.StrMatcher strMatcher24 = strTokenizer23.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder13.deleteFirst(strMatcher24);
        int int27 = strBuilder8.lastIndexOf(strMatcher24, 10);
        java.io.Reader reader28 = strBuilder8.asReader();
        java.lang.StringBuffer stringBuffer29 = strBuilder8.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder8.insert(4, "a");
        char char34 = strBuilder32.charAt(0);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strMatcher24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(reader28);
        org.junit.Assert.assertNotNull(stringBuffer29);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertTrue("'" + char34 + "' != '" + '0' + "'", char34 == '0');
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder16.appendFixedWidthPadRight((java.lang.Object) strMatcher32, 0, '4');
        java.io.Writer writer36 = strBuilder16.asWriter();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(writer36);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray7 = strBuilder1.toCharArray(0, (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.deleteFirst("StrTokenizer[not tokenized yet]");
        char[] charArray16 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray16, strMatcher17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray16);
        boolean boolean20 = strTokenizer19.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer19.getQuoteMatcher();
        int int23 = strBuilder9.lastIndexOf(strMatcher21, (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder9.append((long) 5);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder25.replace((int) ' ', 0, "\naaaaaaaa10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(strBuilder25);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("aaaaaaaaaa", '0');
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("", "");
        boolean boolean3 = strTokenizer2.isIgnoreEmptyTokens();
        java.lang.String str4 = strTokenizer2.previousToken();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[not tokenized yet]");
        char[] charArray8 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray8, strMatcher9);
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray8, "hi!");
        char[] charArray19 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer(charArray19, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray19);
        org.apache.commons.lang.text.StrMatcher strMatcher23 = strTokenizer22.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder25.appendNewLine();
        char[] charArray35 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher36 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray35, strMatcher36);
        int int38 = strTokenizer37.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer37.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher40 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer39.setIgnoredMatcher(strMatcher40);
        char[] charArray48 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer(charArray48, strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray48);
        org.apache.commons.lang.text.StrMatcher strMatcher52 = strTokenizer51.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer39.setQuoteMatcher(strMatcher52);
        int int54 = strBuilder25.indexOf(strMatcher52);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer(charArray8, strMatcher23, strMatcher52);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer1.setDelimiterMatcher(strMatcher23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer1.setIgnoredChar('#');
        org.apache.commons.lang.text.StrMatcher strMatcher59 = strTokenizer1.getQuoteMatcher();
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strMatcher23);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(charArray48);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strMatcher52);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strMatcher59);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int21 = strBuilder20.capacity();
        int int22 = strBuilder20.size();
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder20.deleteAll("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder24.deleteAll(' ');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 35 + "'", int21 == 35);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 11 + "'", int22 == 11);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder26);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray7 = strBuilder1.toCharArray(0, (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.deleteFirst("StrTokenizer[not tokenized yet]");
        java.lang.String str10 = strBuilder9.getNullText();
        boolean boolean12 = strBuilder9.startsWith("StrTokenizer[not tokenized yet]");
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder9.insert((int) 'a', (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 97");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = new org.apache.commons.lang.text.StrTokenizer(charArray1, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.appendNewLine();
        char[] charArray16 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray16, strMatcher17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray16);
        org.apache.commons.lang.text.StrMatcher strMatcher20 = strTokenizer19.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder9.deleteFirst(strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray1, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer22.setIgnoredChar('a');
        boolean boolean25 = strTokenizer24.isIgnoreEmptyTokens();
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strMatcher20);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder16.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder24.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder24.appendNewLine();
        char[] charArray34 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray34);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer37.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder27.deleteFirst(strMatcher38);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder39.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int44 = strBuilder43.capacity();
        boolean boolean45 = strBuilder22.equals(strBuilder43);
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder22.deleteFirst("StrTokenizer[not tokenized yet]");
        java.lang.StringBuffer stringBuffer48 = strBuilder22.toStringBuffer();
        char[] charArray55 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher56 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer(charArray55, strMatcher56);
        int int58 = strTokenizer57.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = strTokenizer57.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher60 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer59.setIgnoredMatcher(strMatcher60);
        org.apache.commons.lang.text.StrBuilder strBuilder63 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder63.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder63.appendNewLine();
        char[] charArray73 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher74 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = new org.apache.commons.lang.text.StrTokenizer(charArray73, strMatcher74);
        int int76 = strTokenizer75.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strTokenizer75.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher78 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = strTokenizer77.setIgnoredMatcher(strMatcher78);
        char[] charArray86 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher87 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer88 = new org.apache.commons.lang.text.StrTokenizer(charArray86, strMatcher87);
        org.apache.commons.lang.text.StrTokenizer strTokenizer89 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray86);
        org.apache.commons.lang.text.StrMatcher strMatcher90 = strTokenizer89.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer91 = strTokenizer77.setQuoteMatcher(strMatcher90);
        int int92 = strBuilder63.indexOf(strMatcher90);
        org.apache.commons.lang.text.StrTokenizer strTokenizer93 = strTokenizer61.setIgnoredMatcher(strMatcher90);
        java.lang.String[] strArray94 = strTokenizer93.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder96 = strBuilder22.appendWithSeparators((java.lang.Object[]) strArray94, "\naaaaaaaa10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.apache.commons.lang.text.StrTokenizer strTokenizer97 = strBuilder96.asTokenizer();
        java.lang.String str98 = strTokenizer97.toString();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strMatcher38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 35 + "'", int44 == 35);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(stringBuffer48);
        org.junit.Assert.assertNotNull(charArray55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(charArray73);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertNotNull(strTokenizer79);
        org.junit.Assert.assertNotNull(charArray86);
        org.junit.Assert.assertNotNull(strTokenizer89);
        org.junit.Assert.assertNotNull(strMatcher90);
        org.junit.Assert.assertNotNull(strTokenizer91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + (-1) + "'", int92 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer93);
        org.junit.Assert.assertNotNull(strArray94);
        org.junit.Assert.assertNotNull(strBuilder96);
        org.junit.Assert.assertNotNull(strTokenizer97);
        org.junit.Assert.assertTrue("'" + str98 + "' != '" + "StrTokenizer[not tokenized yet]" + "'", str98.equals("StrTokenizer[not tokenized yet]"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(' ');
        int int19 = strBuilder4.indexOf('4', 0);
        char[] charArray26 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray26);
        boolean boolean30 = strTokenizer29.hasPrevious();
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer29, "");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder34.deleteFirst("hi!");
        boolean boolean37 = strBuilder34.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder34.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder34.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder43.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder43.appendNewLine();
        char[] charArray53 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher54 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer(charArray53, strMatcher54);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray53);
        org.apache.commons.lang.text.StrMatcher strMatcher57 = strTokenizer56.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder46.deleteFirst(strMatcher57);
        int int60 = strBuilder41.lastIndexOf(strMatcher57, 10);
        int int63 = strBuilder41.indexOf("hi!", 0);
        org.apache.commons.lang.text.StrBuilder strBuilder65 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder41.append(strBuilder65);
        java.lang.StringBuffer stringBuffer67 = strBuilder66.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder4.append(stringBuffer67);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder4.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder4.setCharAt((int) (byte) 0, 'i');
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strMatcher57);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(stringBuffer67);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder72);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        int int9 = strTokenizer8.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer8.reset();
        java.lang.String str11 = strTokenizer8.nextToken();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "#  a a" + "'", str11.equals("#  a a"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder3.appendNewLine();
        char[] charArray16 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder14.insert(5, charArray16);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder17.appendFixedWidthPadRight((int) (short) 10, 3, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder17.insert(0, (long) '3');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder24);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder16.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder24.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder24.appendNewLine();
        char[] charArray34 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray34);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer37.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder27.deleteFirst(strMatcher38);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder39.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int44 = strBuilder43.capacity();
        boolean boolean45 = strBuilder22.equals(strBuilder43);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder22.appendPadding(100, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder48.clear();
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder49.append("\naaaaaaaa101", (int) (byte) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: startIndex must be valid");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strMatcher38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 35 + "'", int44 == 35);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder49);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder16.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder24.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder24.appendNewLine();
        char[] charArray34 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray34);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer37.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder27.deleteFirst(strMatcher38);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder39.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int44 = strBuilder43.capacity();
        boolean boolean45 = strBuilder22.equals(strBuilder43);
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder22.deleteFirst("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder49 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder49.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder49.appendNewLine();
        char[] charArray59 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher60 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer(charArray59, strMatcher60);
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray59);
        org.apache.commons.lang.text.StrMatcher strMatcher63 = strTokenizer62.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder52.deleteFirst(strMatcher63);
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder64.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder64.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder72 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder72.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder72.appendNewLine();
        char[] charArray82 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher83 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = new org.apache.commons.lang.text.StrTokenizer(charArray82, strMatcher83);
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray82);
        org.apache.commons.lang.text.StrMatcher strMatcher86 = strTokenizer85.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder87 = strBuilder75.deleteFirst(strMatcher86);
        org.apache.commons.lang.text.StrBuilder strBuilder91 = strBuilder87.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int92 = strBuilder91.capacity();
        boolean boolean93 = strBuilder70.equals(strBuilder91);
        org.apache.commons.lang.text.StrBuilder strBuilder96 = strBuilder70.appendPadding(100, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder97 = strBuilder96.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder98 = strBuilder47.append((java.lang.Object) strBuilder96);
        org.apache.commons.lang.text.StrBuilder strBuilder99 = strBuilder98.appendNull();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strMatcher38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 35 + "'", int44 == 35);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(strMatcher63);
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNotNull(strBuilder74);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertNotNull(charArray82);
        org.junit.Assert.assertNotNull(strTokenizer85);
        org.junit.Assert.assertNotNull(strMatcher86);
        org.junit.Assert.assertNotNull(strBuilder87);
        org.junit.Assert.assertNotNull(strBuilder91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 35 + "'", int92 == 35);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertNotNull(strBuilder96);
        org.junit.Assert.assertNotNull(strBuilder97);
        org.junit.Assert.assertNotNull(strBuilder98);
        org.junit.Assert.assertNotNull(strBuilder99);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        int int18 = strBuilder16.lastIndexOf(' ');
        java.util.Collection collection19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder16.appendWithSeparators(collection19, "#  a a");
        char[] charArray22 = strBuilder16.toCharArray();
        char[] charArray29 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray29, strMatcher30);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray29);
        boolean boolean33 = strTokenizer32.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer32.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray22, strMatcher34);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(strMatcher34);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder4.minimizeCapacity();
        char[] charArray7 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray7, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder12.appendNewLine();
        char[] charArray22 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray22, strMatcher23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray22);
        org.apache.commons.lang.text.StrMatcher strMatcher26 = strTokenizer25.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder15.deleteFirst(strMatcher26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray7, strMatcher26);
        int int29 = strBuilder5.lastIndexOf(strMatcher26);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strMatcher26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((java.lang.Object) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder3.append((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder7.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.append(5);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.setLength((int) (short) 10);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder12);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", '4', '#');
        char[] charArray10 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray10);
        org.apache.commons.lang.text.StrMatcher strMatcher14 = strTokenizer13.getQuoteMatcher();
        char[] charArray16 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer(charArray16, '#', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer13.reset(charArray16);
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer20.setQuoteMatcher(strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer3.setIgnoredMatcher(strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer3.setIgnoredChar('a');
        java.util.List list36 = strTokenizer3.getTokenList();
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strMatcher14);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(list36);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder4.appendPadding((int) (short) 100, 'a');
        int int20 = strBuilder19.size();
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder19.appendWithSeparators((java.util.Iterator) strTokenizer30, "044");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 101 + "'", int20 == 101);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strBuilder33);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[#   ]", 'a', 'a');
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.appendFixedWidthPadRight((int) '#', 100, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.replaceFirst("\naaaaaaaa10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "\naaaa");
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        java.lang.String str7 = strBuilder6.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.deleteAll("");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder6.deleteFirst('#');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder11.minimizeCapacity();
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder12);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        int int7 = strBuilder4.length();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("", 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder4.append((java.lang.Object) strTokenizer10);
        java.lang.String str12 = strTokenizer10.getContent();
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder16.appendFixedWidthPadRight((java.lang.Object) strMatcher32, 0, '4');
        java.lang.String str37 = strBuilder35.rightString(0);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder38.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder40.setNullText("StrTokenizer[hi!]");
        boolean boolean43 = strBuilder35.equals((java.lang.Object) strBuilder40);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder40.minimizeCapacity();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(strBuilder44);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", '4', '#');
        char[] charArray10 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray10);
        org.apache.commons.lang.text.StrMatcher strMatcher14 = strTokenizer13.getQuoteMatcher();
        char[] charArray16 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer(charArray16, '#', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer13.reset(charArray16);
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer20.setQuoteMatcher(strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer3.setIgnoredMatcher(strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer3.setIgnoredChar('a');
        char[] charArray36 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer3.reset(charArray36);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer37.getTrimmerMatcher();
        try {
            java.lang.Object obj39 = strTokenizer37.next();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strMatcher14);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strMatcher38);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        java.lang.String str16 = strBuilder13.midString((int) (short) 1, 11);
        java.lang.Class<?> wildcardClass17 = strBuilder13.getClass();
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder13.deleteCharAt(10);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 10");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "aaaaaaaaa" + "'", str16.equals("aaaaaaaaa"));
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        int int3 = strBuilder0.lastIndexOf('4', (int) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.appendNewLine();
        char[] charArray16 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray16, strMatcher17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray16);
        org.apache.commons.lang.text.StrMatcher strMatcher20 = strTokenizer19.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder9.deleteFirst(strMatcher20);
        int int23 = strBuilder21.lastIndexOf(' ');
        java.util.Collection collection24 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder21.appendWithSeparators(collection24, "#  a a");
        char[] charArray27 = strBuilder21.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder0.insert((int) (short) 0, charArray27);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder0.appendNewLine();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strMatcher20);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder29);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder16.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder22.appendPadding(0, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder22.append((float) '#');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder27.deleteAll("#  a a");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder29);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder16.appendFixedWidthPadRight((java.lang.Object) strMatcher32, 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.appendPadding((int) (short) 100, 'a');
        char[] charArray45 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer(charArray45, strMatcher46);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray45);
        org.apache.commons.lang.text.StrMatcher strMatcher49 = strTokenizer48.getQuoteMatcher();
        int int51 = strBuilder38.indexOf(strMatcher49, (int) '#');
        java.lang.String str52 = strBuilder38.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder38.replaceAll('a', 'a');
        boolean boolean57 = strBuilder38.contains("aa4 #");
        org.apache.commons.lang.text.StrMatcher strMatcher58 = null;
        int int59 = strBuilder38.lastIndexOf(strMatcher58);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strMatcher49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "\naaaaaaaa10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str52.equals("\naaaaaaaa10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        int int18 = strBuilder16.lastIndexOf(' ');
        java.util.Collection collection19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder16.appendWithSeparators(collection19, "#  a a");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.setLength((int) ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder21.trim();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder24);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        char[] charArray0 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer(charArray0, "hi!");
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.ensureCapacity((int) ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.append(100.0f);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendPadding(0, '4');
        java.lang.String str10 = strBuilder1.getNewLineText();
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder1.replace((int) 'a', 10, "\naaaaaaaa101");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        boolean boolean16 = strBuilder4.contains('#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strBuilder4.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.deleteFirst("hi!");
        boolean boolean22 = strBuilder19.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder19.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder19.append((float) (byte) 1);
        char[] charArray27 = strBuilder19.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray27, ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer32.setQuoteChar('#');
        org.apache.commons.lang.text.StrMatcher strMatcher35 = strTokenizer32.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer17.setQuoteMatcher(strMatcher35);
        int int37 = strTokenizer17.size();
        java.util.List list38 = strTokenizer17.getTokenList();
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strMatcher35);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(list38);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        boolean boolean16 = strBuilder4.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder4.appendFixedWidthPadRight(0, (int) (byte) 0, 'a');
        int int22 = strBuilder20.indexOf('#');
        boolean boolean23 = strBuilder20.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder20.appendPadding((int) (short) 0, '0');
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(strBuilder26);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        boolean boolean18 = strBuilder4.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder4.replaceAll('a', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder4.appendFixedWidthPadLeft((int) (short) 1, (int) (byte) 100, 'a');
        int int26 = strBuilder25.size();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 101 + "'", int26 == 101);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(' ');
        int int19 = strBuilder4.indexOf('4', 0);
        char[] charArray26 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray26);
        boolean boolean30 = strTokenizer29.hasPrevious();
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer29, "");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder34.deleteFirst("hi!");
        boolean boolean37 = strBuilder34.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder34.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder34.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder43.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder43.appendNewLine();
        char[] charArray53 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher54 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer(charArray53, strMatcher54);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray53);
        org.apache.commons.lang.text.StrMatcher strMatcher57 = strTokenizer56.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder46.deleteFirst(strMatcher57);
        int int60 = strBuilder41.lastIndexOf(strMatcher57, 10);
        int int63 = strBuilder41.indexOf("hi!", 0);
        org.apache.commons.lang.text.StrBuilder strBuilder65 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder41.append(strBuilder65);
        java.lang.StringBuffer stringBuffer67 = strBuilder66.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder4.append(stringBuffer67);
        java.lang.String str69 = strBuilder68.toString();
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strMatcher57);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(stringBuffer67);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "hi!#  a a01.0hi!" + "'", str69.equals("hi!#  a a01.0hi!"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.append(100.0f);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.deleteFirst("hi!");
        boolean boolean11 = strBuilder8.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder8.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder8.appendPadding(0, '4');
        java.lang.String str17 = strBuilder8.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder8.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder4.append((java.lang.Object) strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder19);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder18.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder22.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder20.appendFixedWidthPadLeft((java.lang.Object) strBuilder25, (int) (byte) 10, 'a');
        java.io.Reader reader31 = strBuilder25.asReader();
        boolean boolean32 = strBuilder16.equalsIgnoreCase(strBuilder25);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder16.setLength(11);
        int int35 = strBuilder34.length();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(reader31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 11 + "'", int35 == 11);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((java.lang.Object) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.insert(0, "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder5.append("\n");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(' ');
        int int19 = strBuilder4.indexOf('4', 0);
        char[] charArray26 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray26);
        boolean boolean30 = strTokenizer29.hasPrevious();
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer29, "");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder32.append(0.0d);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder34);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.delete(0, 0);
        boolean boolean13 = strBuilder1.contains('a');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.setLength(5);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder();
        int int21 = strBuilder18.lastIndexOf('4', (int) (byte) -1);
        char[] charArray28 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer(charArray28, strMatcher29);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray28);
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder37.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder40.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder35.appendFixedWidthPadLeft((java.lang.Object) strBuilder40, (int) (byte) 10, 'a');
        char[] charArray47 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer(charArray47, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder40.append(charArray47);
        org.apache.commons.lang.text.StrBuilder strBuilder53 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder53.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder53.appendNewLine();
        char[] charArray63 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher64 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = new org.apache.commons.lang.text.StrTokenizer(charArray63, strMatcher64);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray63);
        org.apache.commons.lang.text.StrMatcher strMatcher67 = strTokenizer66.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder56.deleteFirst(strMatcher67);
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder40.replaceAll(strMatcher67, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer(charArray28, strMatcher67);
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder18.replaceAll(strMatcher67, "");
        int int75 = strBuilder17.indexOf(strMatcher67, (int) '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = new org.apache.commons.lang.text.StrTokenizer("0");
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder17.appendWithSeparators((java.util.Iterator) strTokenizer77, "\n");
        int int82 = strBuilder17.indexOf('0', 0);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(charArray47);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(charArray63);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(strMatcher67);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        int int9 = strTokenizer8.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer8.reset();
        int int11 = strTokenizer8.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer8.setQuoteChar('3');
        java.lang.String str14 = strTokenizer8.getContent();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#  a a" + "'", str14.equals("#  a a"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        java.io.Reader reader14 = strBuilder8.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder8.deleteFirst('4');
        char[] charArray17 = strBuilder8.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer(charArray17, "01.001.0hi!");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(reader14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(charArray17);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.appendNewLine();
        char[] charArray20 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray20, strMatcher21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray20);
        org.apache.commons.lang.text.StrMatcher strMatcher24 = strTokenizer23.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder13.deleteFirst(strMatcher24);
        int int27 = strBuilder8.lastIndexOf(strMatcher24, 10);
        int int30 = strBuilder8.indexOf("hi!", 0);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder8.append(strBuilder32);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder8.deleteFirst("a");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder37.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder37.appendNull();
        char[] charArray43 = strBuilder37.toCharArray(0, (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder37.deleteFirst("StrTokenizer[not tokenized yet]");
        char[] charArray52 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher53 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer(charArray52, strMatcher53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray52);
        boolean boolean56 = strTokenizer55.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher57 = strTokenizer55.getQuoteMatcher();
        int int59 = strBuilder45.lastIndexOf(strMatcher57, (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder61 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder61.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder64.setNewLineText("hi!");
        int int67 = strBuilder64.length();
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder64.setNullText("01.001.0hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder45.append((java.lang.Object) strBuilder69);
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder8.append(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strMatcher24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(charArray52);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(strMatcher57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNotNull(strBuilder71);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        java.lang.String str15 = strTokenizer10.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.appendNewLine();
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder20.deleteFirst(strMatcher31);
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder32.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder32.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder40 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder40.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder40.appendNewLine();
        char[] charArray50 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher51 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer(charArray50, strMatcher51);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray50);
        org.apache.commons.lang.text.StrMatcher strMatcher54 = strTokenizer53.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder43.deleteFirst(strMatcher54);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder55.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder55.ensureCapacity((-1));
        boolean boolean62 = strBuilder61.isEmpty();
        boolean boolean64 = strBuilder61.startsWith("");
        org.apache.commons.lang.text.StrBuilder strBuilder66 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder66.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder69.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strTokenizer75.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder69.appendWithSeparators((java.util.Iterator) strTokenizer75, "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer83 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = strTokenizer83.setIgnoreEmptyTokens(true);
        java.lang.String[] strArray86 = strTokenizer85.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher87 = strTokenizer85.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer88 = strTokenizer75.setIgnoredMatcher(strMatcher87);
        org.apache.commons.lang.text.StrMatcher strMatcher89 = strTokenizer75.getIgnoredMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder90 = strBuilder61.deleteFirst(strMatcher89);
        boolean boolean91 = strBuilder38.contains(strMatcher89);
        org.apache.commons.lang.text.StrTokenizer strTokenizer92 = strTokenizer10.setIgnoredMatcher(strMatcher89);
        int int93 = strTokenizer10.size();
        try {
            java.lang.Object obj94 = strTokenizer10.next();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "StrTokenizer[hi!]" + "'", str15.equals("StrTokenizer[hi!]"));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(charArray50);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strMatcher54);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertNotNull(strTokenizer85);
        org.junit.Assert.assertNotNull(strArray86);
        org.junit.Assert.assertNotNull(strMatcher87);
        org.junit.Assert.assertNotNull(strTokenizer88);
        org.junit.Assert.assertNotNull(strMatcher89);
        org.junit.Assert.assertNotNull(strBuilder90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strTokenizer92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        int int9 = strTokenizer8.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer8.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoredMatcher(strMatcher11);
        char[] charArray19 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer(charArray19, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray19);
        org.apache.commons.lang.text.StrMatcher strMatcher23 = strTokenizer22.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer10.setQuoteMatcher(strMatcher23);
        char[] charArray31 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher32 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer(charArray31, strMatcher32);
        int int34 = strTokenizer33.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer33.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher36 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer35.setIgnoredMatcher(strMatcher36);
        char[] charArray44 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher45 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = new org.apache.commons.lang.text.StrTokenizer(charArray44, strMatcher45);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray44);
        org.apache.commons.lang.text.StrMatcher strMatcher48 = strTokenizer47.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer35.setQuoteMatcher(strMatcher48);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer53.setIgnoreEmptyTokens(true);
        java.lang.String[] strArray56 = strTokenizer55.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher57 = strTokenizer55.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer49.setDelimiterMatcher(strMatcher57);
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = strTokenizer24.setTrimmerMatcher(strMatcher57);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer24.setEmptyTokenAsNull(true);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strMatcher23);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(charArray44);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strMatcher48);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertNotNull(strMatcher57);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertNotNull(strTokenizer61);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        char[] charArray15 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray15, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder8.append(charArray15);
        char[] charArray26 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher27);
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher29, strMatcher30);
        char[] charArray36 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer31.reset(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray36);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder8.appendWithSeparators((java.util.Iterator) strTokenizer39, "");
        java.lang.String str42 = strBuilder41.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder41.deleteAll("");
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder44.replaceFirst("hi!", "                                    ");
        int int50 = strBuilder47.lastIndexOf("#  a a", 99);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "aa4 #" + "'", str42.equals("aa4 #"));
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendPadding(0, '4');
        java.lang.String str10 = strBuilder1.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder12.appendNewLine();
        char[] charArray22 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray22, strMatcher23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray22);
        org.apache.commons.lang.text.StrMatcher strMatcher26 = strTokenizer25.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder15.deleteFirst(strMatcher26);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder27.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder27.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder35 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder35.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.appendNewLine();
        char[] charArray45 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer(charArray45, strMatcher46);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray45);
        org.apache.commons.lang.text.StrMatcher strMatcher49 = strTokenizer48.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder38.deleteFirst(strMatcher49);
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder50.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int55 = strBuilder54.capacity();
        boolean boolean56 = strBuilder33.equals(strBuilder54);
        boolean boolean57 = strBuilder1.equalsIgnoreCase(strBuilder54);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder54.append((float) '#');
        boolean boolean61 = strBuilder54.startsWith("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder63 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder63.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder63.appendFixedWidthPadRight((int) '#', 100, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder70.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder70.appendPadding(35, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder78 = strBuilder54.append(strBuilder75, 1, (int) (byte) 10);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strMatcher26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strMatcher49);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 35 + "'", int55 == 35);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNotNull(strBuilder72);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertNotNull(strBuilder78);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((java.lang.Object) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.insert(0, "");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder8.replaceFirst('a', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.deleteFirst("hi!");
        boolean boolean16 = strBuilder13.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder13.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder13.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder22.appendNewLine();
        char[] charArray32 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher33 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer(charArray32, strMatcher33);
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray32);
        org.apache.commons.lang.text.StrMatcher strMatcher36 = strTokenizer35.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder25.deleteFirst(strMatcher36);
        int int39 = strBuilder20.lastIndexOf(strMatcher36, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder20.appendPadding((int) (short) 0, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder8.append(strBuilder20);
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder8.setNullText("\n524");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(charArray32);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strMatcher36);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder45);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = new org.apache.commons.lang.text.StrTokenizer("0");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = strTokenizer1.reset("\naaaaaaaa10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder9.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder7.appendFixedWidthPadLeft((java.lang.Object) strBuilder12, (int) (byte) 10, 'a');
        char[] charArray19 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray19, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder12.append(charArray19);
        char[] charArray30 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher31 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray30, strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray30);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder35.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder39.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder42.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder37.appendFixedWidthPadLeft((java.lang.Object) strBuilder42, (int) (byte) 10, 'a');
        char[] charArray49 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer(charArray49, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder42.append(charArray49);
        org.apache.commons.lang.text.StrBuilder strBuilder55 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder55.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder55.appendNewLine();
        char[] charArray65 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher66 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = new org.apache.commons.lang.text.StrTokenizer(charArray65, strMatcher66);
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray65);
        org.apache.commons.lang.text.StrMatcher strMatcher69 = strTokenizer68.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder58.deleteFirst(strMatcher69);
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder42.replaceAll(strMatcher69, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = new org.apache.commons.lang.text.StrTokenizer(charArray30, strMatcher69);
        org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder12.append(charArray30);
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = new org.apache.commons.lang.text.StrTokenizer(charArray30);
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = new org.apache.commons.lang.text.StrTokenizer(charArray30);
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray30);
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = strTokenizer3.reset(charArray30);
        java.lang.String str79 = strTokenizer3.getContent();
        org.junit.Assert.assertNotNull(strTokenizer3);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(charArray49);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(charArray65);
        org.junit.Assert.assertNotNull(strTokenizer68);
        org.junit.Assert.assertNotNull(strMatcher69);
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNotNull(strBuilder72);
        org.junit.Assert.assertNotNull(strBuilder74);
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertNotNull(strTokenizer78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "#  a a" + "'", str79.equals("#  a a"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean5 = strBuilder3.contains('a');
        java.io.Reader reader6 = strBuilder3.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.deleteFirst("hi!");
        boolean boolean11 = strBuilder8.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder8.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder8.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.appendNewLine();
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder20.deleteFirst(strMatcher31);
        int int34 = strBuilder15.lastIndexOf(strMatcher31, 10);
        java.io.Reader reader35 = strBuilder15.asReader();
        java.lang.StringBuffer stringBuffer36 = strBuilder15.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder15.insert(4, "a");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder3.appendFixedWidthPadRight((java.lang.Object) "a", 0, 'i');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(reader6);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(reader35);
        org.junit.Assert.assertNotNull(stringBuffer36);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder42);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        int int9 = strBuilder1.indexOf('a', 3);
        java.lang.String str11 = strBuilder1.rightString((int) (short) 100);
        int int14 = strBuilder1.lastIndexOf("\naaaaaaaa10", (int) '3');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        java.lang.String[] strArray10 = strTokenizer9.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer9.setQuoteMatcher(strMatcher11);
        org.apache.commons.lang.text.StrMatcher strMatcher13 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer9.setQuoteMatcher(strMatcher13);
        java.lang.Object obj15 = strTokenizer14.next();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertTrue("'" + obj15 + "' != '" + "#  a a" + "'", obj15.equals("#  a a"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder16.appendFixedWidthPadRight((java.lang.Object) strMatcher32, 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder35.appendNull();
        char[] charArray43 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray43, strMatcher44);
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher47 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer(charArray43, strMatcher46, strMatcher47);
        char[] charArray53 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer48.reset(charArray53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strTokenizer48.reset("StrTokenizer[hi!]");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder36.appendWithSeparators((java.util.Iterator) strTokenizer57, "aaaaaaaaa");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertNotNull(strBuilder59);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendPadding(0, '4');
        java.lang.String str10 = strBuilder1.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder12.appendNewLine();
        char[] charArray22 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray22, strMatcher23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray22);
        org.apache.commons.lang.text.StrMatcher strMatcher26 = strTokenizer25.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder15.deleteFirst(strMatcher26);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder27.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder27.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder35 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder35.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.appendNewLine();
        char[] charArray45 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer(charArray45, strMatcher46);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray45);
        org.apache.commons.lang.text.StrMatcher strMatcher49 = strTokenizer48.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder38.deleteFirst(strMatcher49);
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder50.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int55 = strBuilder54.capacity();
        boolean boolean56 = strBuilder33.equals(strBuilder54);
        boolean boolean57 = strBuilder1.equalsIgnoreCase(strBuilder54);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder54.append((float) '#');
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder59.deleteCharAt((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder61.append("StrTokenizer[hi!]");
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder61.reverse();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strMatcher26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strMatcher49);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 35 + "'", int55 == 35);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertNotNull(strBuilder64);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder16.appendFixedWidthPadRight((java.lang.Object) strMatcher32, 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.appendPadding((int) (short) 100, 'a');
        char[] charArray45 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer(charArray45, strMatcher46);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray45);
        org.apache.commons.lang.text.StrMatcher strMatcher49 = strTokenizer48.getQuoteMatcher();
        int int51 = strBuilder38.indexOf(strMatcher49, (int) '#');
        java.lang.String str52 = strBuilder38.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder38.replaceAll('a', 'a');
        java.lang.StringBuffer stringBuffer56 = strBuilder55.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder55.deleteFirst("aaaaaaaaaa");
        org.apache.commons.lang.text.StrMatcher strMatcher59 = null;
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder58.replace(strMatcher59, "hi!", (int) ' ', 15, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strMatcher49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "\naaaaaaaa10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str52.equals("\naaaaaaaa10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(stringBuffer56);
        org.junit.Assert.assertNotNull(strBuilder58);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder8.appendNewLine();
        char[] charArray18 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray18, strMatcher19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray18);
        org.apache.commons.lang.text.StrMatcher strMatcher22 = strTokenizer21.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder11.deleteFirst(strMatcher22);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder23.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray34 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray34);
        boolean boolean38 = strTokenizer37.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer37.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder23.appendFixedWidthPadRight((java.lang.Object) strMatcher39, 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder42.appendPadding((int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder42.appendNull();
        char char48 = strBuilder42.charAt(4);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder42.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) strBuilder49, (int) '#', '#');
        int int55 = strBuilder49.indexOf("", 10);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strMatcher22);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(strMatcher39);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertTrue("'" + char48 + "' != '" + 'a' + "'", char48 == 'a');
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        java.io.Reader reader14 = strBuilder8.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder16.appendNewLine();
        char[] charArray26 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray26);
        org.apache.commons.lang.text.StrMatcher strMatcher30 = strTokenizer29.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder19.deleteFirst(strMatcher30);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder31.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int36 = strBuilder35.capacity();
        int int37 = strBuilder35.size();
        boolean boolean38 = strBuilder8.equals(strBuilder35);
        java.lang.String str40 = strBuilder35.leftString((int) (short) -1);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(reader14);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strMatcher30);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 35 + "'", int36 == 35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 11 + "'", int37 == 11);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray7 = strBuilder1.toCharArray(0, (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.insert(0, (float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.append((java.lang.Object) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.deleteFirst("01.001.0hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.deleteFirst("hi!");
        boolean boolean24 = strBuilder21.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder21.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder21.append((float) (byte) 1);
        char[] charArray29 = strBuilder21.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray29, '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer(charArray29, ' ');
        char[] charArray34 = strBuilder19.getChars(charArray29);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder10.insert((int) 'i', charArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 105");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(charArray34);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        boolean boolean18 = strBuilder4.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder4.replaceAll('a', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder23.deleteFirst("hi!");
        boolean boolean26 = strBuilder23.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder23.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder23.appendPadding(0, '4');
        java.lang.String str32 = strBuilder23.getNewLineText();
        int int35 = strBuilder23.indexOf(' ', 35);
        char[] charArray42 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher43 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray42, strMatcher43);
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray42);
        java.util.List list46 = strTokenizer45.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder23.appendWithSeparators((java.util.Collection) list46, "\naaaaaaaa101");
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder4.appendWithSeparators((java.util.Collection) list46, "aaaaaaaaa");
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder50.append((double) 100);
        char[] charArray59 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher60 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer(charArray59, strMatcher60);
        org.apache.commons.lang.text.StrMatcher strMatcher62 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher63 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = new org.apache.commons.lang.text.StrTokenizer(charArray59, strMatcher62, strMatcher63);
        char[] charArray69 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray69);
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = strTokenizer64.reset(charArray69);
        char[] charArray78 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher79 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = new org.apache.commons.lang.text.StrTokenizer(charArray78, strMatcher79);
        org.apache.commons.lang.text.StrTokenizer strTokenizer81 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray78);
        boolean boolean82 = strTokenizer81.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher83 = strTokenizer81.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = strTokenizer71.setTrimmerMatcher(strMatcher83);
        int int85 = strTokenizer71.nextIndex();
        java.lang.String[] strArray86 = strTokenizer71.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder88 = strBuilder50.appendWithSeparators((java.util.Iterator) strTokenizer71, "aa4 #");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(charArray42);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertNotNull(charArray69);
        org.junit.Assert.assertNotNull(strTokenizer70);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertNotNull(charArray78);
        org.junit.Assert.assertNotNull(strTokenizer81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(strMatcher83);
        org.junit.Assert.assertNotNull(strTokenizer84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertNotNull(strArray86);
        org.junit.Assert.assertNotNull(strBuilder88);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        int int9 = strTokenizer8.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer8.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoredMatcher(strMatcher11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer12.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer14.setIgnoreEmptyTokens(true);
        java.lang.String str17 = strTokenizer14.getContent();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder23.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder26.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder21.appendFixedWidthPadLeft((java.lang.Object) strBuilder26, (int) (byte) 10, 'a');
        char[] charArray33 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray33, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder26.append(charArray33);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder39.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder39.appendNewLine();
        char[] charArray49 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher50 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = new org.apache.commons.lang.text.StrTokenizer(charArray49, strMatcher50);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray49);
        org.apache.commons.lang.text.StrMatcher strMatcher53 = strTokenizer52.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder42.deleteFirst(strMatcher53);
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder26.replaceAll(strMatcher53, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strTokenizer14.setTrimmerMatcher(strMatcher53);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "#  a a" + "'", str17.equals("#  a a"));
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(charArray49);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strMatcher53);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strTokenizer57);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder2.deleteFirst("hi!");
        boolean boolean5 = strBuilder2.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder2.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder2.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder11.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder11.appendNewLine();
        char[] charArray21 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer(charArray21, strMatcher22);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray21);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer24.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder14.deleteFirst(strMatcher25);
        int int28 = strBuilder9.lastIndexOf(strMatcher25, 10);
        java.io.Reader reader29 = strBuilder9.asReader();
        java.lang.StringBuffer stringBuffer30 = strBuilder9.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder0.append(stringBuffer30);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder34.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder34.appendNewLine();
        char[] charArray44 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher45 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = new org.apache.commons.lang.text.StrTokenizer(charArray44, strMatcher45);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray44);
        org.apache.commons.lang.text.StrMatcher strMatcher48 = strTokenizer47.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder37.deleteFirst(strMatcher48);
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder49.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder49.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder55.appendPadding(0, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder55.append((float) '#');
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder55.deleteAll("");
        char[] charArray69 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher70 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer(charArray69, strMatcher70);
        char[] charArray72 = strBuilder55.getChars(charArray69);
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray69);
        org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder31.insert(0, charArray69);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(reader29);
        org.junit.Assert.assertNotNull(stringBuffer30);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(charArray44);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strMatcher48);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(charArray69);
        org.junit.Assert.assertNotNull(charArray72);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertNotNull(strBuilder74);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder16.ensureCapacity((-1));
        java.io.Writer writer23 = strBuilder16.asWriter();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder16.setNullText("eurt");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(writer23);
        org.junit.Assert.assertNotNull(strBuilder25);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean5 = strBuilder3.contains('a');
        int int6 = strBuilder3.capacity();
        int int7 = strBuilder3.size();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        java.io.Reader reader15 = strBuilder4.asReader();
        char[] charArray22 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray22, strMatcher23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray22);
        java.lang.String[] strArray26 = strTokenizer25.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder4.appendWithSeparators((java.lang.Object[]) strArray26, "0");
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder28.appendNewLine();
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(reader15);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder29);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray6, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer10.setIgnoredChar(' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer14.reset("StrTokenizer[hi!]");
        java.lang.Object obj17 = strTokenizer14.clone();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.delete(0, 0);
        boolean boolean13 = strBuilder1.contains('a');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.setLength(5);
        char[] charArray18 = strBuilder15.toCharArray();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(charArray18);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendPadding(0, '4');
        java.lang.String str10 = strBuilder1.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder20.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) strBuilder20, (int) (byte) 10, 'a');
        char[] charArray27 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer(charArray27, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder20.append(charArray27);
        org.apache.commons.lang.text.StrMatcher strMatcher32 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder31.replace(strMatcher32, "", 1, 100, (int) 'a');
        boolean boolean38 = strBuilder1.equals(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", '4', '#');
        char[] charArray10 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray10);
        org.apache.commons.lang.text.StrMatcher strMatcher14 = strTokenizer13.getQuoteMatcher();
        char[] charArray16 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer(charArray16, '#', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer13.reset(charArray16);
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer20.setQuoteMatcher(strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer3.setIgnoredMatcher(strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer33.setDelimiterChar('4');
        boolean boolean36 = strTokenizer35.isIgnoreEmptyTokens();
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strMatcher14);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        int int7 = strBuilder4.length();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("", 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder4.append((java.lang.Object) strTokenizer10);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendPadding(82, '0');
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("hi!", "01.001.0hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = strTokenizer2.setDelimiterChar(' ');
        org.junit.Assert.assertNotNull(strTokenizer4);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        java.io.Reader reader15 = strBuilder4.asReader();
        char[] charArray22 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray22, strMatcher23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray22);
        java.lang.String[] strArray26 = strTokenizer25.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder4.appendWithSeparators((java.lang.Object[]) strArray26, "0");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder30.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder34.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder37.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder32.appendFixedWidthPadLeft((java.lang.Object) strBuilder37, (int) (byte) 10, 'a');
        char[] charArray44 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer(charArray44, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder37.append(charArray44);
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder48.replace(strMatcher49, "", 1, 100, (int) 'a');
        java.io.Writer writer55 = strBuilder54.asWriter();
        boolean boolean56 = strBuilder4.equals((java.lang.Object) strBuilder54);
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder54.appendFixedWidthPadRight((int) '3', (int) (short) 1, '3');
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder54.deleteFirst(' ');
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(reader15);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(charArray44);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(writer55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder62);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.ensureCapacity((int) ' ');
        java.lang.String str19 = strBuilder16.midString((int) (byte) 1, 15);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "i!" + "'", str19.equals("i!"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        char[] charArray1 = new char[] { '4' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer(charArray1, ' ');
        char[] charArray10 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder19.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder17.appendFixedWidthPadLeft((java.lang.Object) strBuilder22, (int) (byte) 10, 'a');
        char[] charArray29 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray29, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder22.append(charArray29);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder35.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.appendNewLine();
        char[] charArray45 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer(charArray45, strMatcher46);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray45);
        org.apache.commons.lang.text.StrMatcher strMatcher49 = strTokenizer48.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder38.deleteFirst(strMatcher49);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder22.replaceAll(strMatcher49, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer3.setTrimmerMatcher(strMatcher49);
        int int55 = strTokenizer3.nextIndex();
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strMatcher49);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int21 = strBuilder20.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder20.setNullText("");
        java.lang.String str26 = strBuilder23.midString((int) (short) 100, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder28.deleteFirst("hi!");
        boolean boolean31 = strBuilder28.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder28.replaceAll('#', '4');
        boolean boolean35 = strBuilder23.equals((java.lang.Object) strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 35 + "'", int21 == 35);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance("a");
        org.junit.Assert.assertNotNull(strTokenizer1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", '4', '#');
        char[] charArray10 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray10);
        org.apache.commons.lang.text.StrMatcher strMatcher14 = strTokenizer13.getQuoteMatcher();
        char[] charArray16 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer(charArray16, '#', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer13.reset(charArray16);
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer20.setQuoteMatcher(strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer3.setIgnoredMatcher(strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer3.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder37 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder37.deleteFirst("hi!");
        boolean boolean40 = strBuilder37.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder37.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder37.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder46 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder46.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder46.appendNewLine();
        char[] charArray56 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher57 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer(charArray56, strMatcher57);
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray56);
        org.apache.commons.lang.text.StrMatcher strMatcher60 = strTokenizer59.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder49.deleteFirst(strMatcher60);
        int int63 = strBuilder44.lastIndexOf(strMatcher60, 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer3.setTrimmerMatcher(strMatcher60);
        int int65 = strTokenizer64.previousIndex();
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strMatcher14);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(charArray56);
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertNotNull(strMatcher60);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher9, strMatcher10);
        char[] charArray16 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray16);
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer11.reset(charArray16);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer11.reset("StrTokenizer[hi!]");
        int int21 = strTokenizer11.size();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder8.appendNewLine();
        char[] charArray18 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray18, strMatcher19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray18);
        org.apache.commons.lang.text.StrMatcher strMatcher22 = strTokenizer21.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder11.deleteFirst(strMatcher22);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder23.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray34 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray34);
        boolean boolean38 = strTokenizer37.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer37.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder23.appendFixedWidthPadRight((java.lang.Object) strMatcher39, 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder42.appendPadding((int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder42.appendNull();
        char char48 = strBuilder42.charAt(4);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder42.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder1.appendFixedWidthPadRight((java.lang.Object) strBuilder49, (int) '#', '#');
        int int55 = strBuilder49.lastIndexOf("\naaaaaaaa10", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strMatcher22);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(strMatcher39);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertTrue("'" + char48 + "' != '" + 'a' + "'", char48 == 'a');
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        int int18 = strBuilder4.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder4.appendFixedWidthPadRight(5, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder4.append((float) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder27.deleteFirst("hi!");
        boolean boolean30 = strBuilder27.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder27.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder27.appendPadding(0, '4');
        java.lang.String str36 = strBuilder27.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder38 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder38.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder38.appendNewLine();
        char[] charArray48 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer(charArray48, strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray48);
        org.apache.commons.lang.text.StrMatcher strMatcher52 = strTokenizer51.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder41.deleteFirst(strMatcher52);
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder53.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder53.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder61 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder61.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder61.appendNewLine();
        char[] charArray71 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher72 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = new org.apache.commons.lang.text.StrTokenizer(charArray71, strMatcher72);
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray71);
        org.apache.commons.lang.text.StrMatcher strMatcher75 = strTokenizer74.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder64.deleteFirst(strMatcher75);
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder76.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int81 = strBuilder80.capacity();
        boolean boolean82 = strBuilder59.equals(strBuilder80);
        boolean boolean83 = strBuilder27.equalsIgnoreCase(strBuilder80);
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder80.append((float) '#');
        boolean boolean87 = strBuilder80.startsWith("StrTokenizer[not tokenized yet]");
        char[] charArray90 = strBuilder80.toCharArray((int) (byte) 1, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder93 = strBuilder4.insert(0, charArray90, (int) (byte) 0, 0);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(charArray48);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strMatcher52);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(charArray71);
        org.junit.Assert.assertNotNull(strTokenizer74);
        org.junit.Assert.assertNotNull(strMatcher75);
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 35 + "'", int81 == 35);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(charArray90);
        org.junit.Assert.assertNotNull(strBuilder93);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        boolean boolean16 = strBuilder4.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder4.appendFixedWidthPadRight(0, (int) (byte) 0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.deleteFirst("hi!");
        boolean boolean25 = strBuilder22.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder22.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder22.appendPadding(0, '4');
        java.lang.String str31 = strBuilder22.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder33.appendNewLine();
        char[] charArray43 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray43, strMatcher44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray43);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer46.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder36.deleteFirst(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder48.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder48.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder56.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.appendNewLine();
        char[] charArray66 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher67 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer(charArray66, strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray66);
        org.apache.commons.lang.text.StrMatcher strMatcher70 = strTokenizer69.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder59.deleteFirst(strMatcher70);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder71.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int76 = strBuilder75.capacity();
        boolean boolean77 = strBuilder54.equals(strBuilder75);
        boolean boolean78 = strBuilder22.equalsIgnoreCase(strBuilder75);
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder22.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder80.deleteAll("");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder20.appendFixedWidthPadLeft((java.lang.Object) "", (-1), 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder87 = strBuilder85.append("01.001.0hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer90 = new org.apache.commons.lang.text.StrTokenizer("", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer92 = strTokenizer90.setQuoteChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder93 = strBuilder85.append((java.lang.Object) strTokenizer90);
        org.apache.commons.lang.text.StrBuilder strBuilder96 = strBuilder85.replaceAll('#', '0');
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strMatcher70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 35 + "'", int76 == 35);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(strBuilder87);
        org.junit.Assert.assertNotNull(strTokenizer92);
        org.junit.Assert.assertNotNull(strBuilder93);
        org.junit.Assert.assertNotNull(strBuilder96);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int21 = strBuilder20.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder20.setNullText("");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder25.appendNewLine();
        char[] charArray35 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher36 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray35, strMatcher36);
        int int38 = strTokenizer37.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer37.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher40 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer39.setIgnoredMatcher(strMatcher40);
        char[] charArray48 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer(charArray48, strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray48);
        org.apache.commons.lang.text.StrMatcher strMatcher52 = strTokenizer51.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer39.setQuoteMatcher(strMatcher52);
        int int54 = strBuilder25.indexOf(strMatcher52);
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder59.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strTokenizer65.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder59.appendWithSeparators((java.util.Iterator) strTokenizer65, "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = strTokenizer73.setIgnoreEmptyTokens(true);
        java.lang.String[] strArray76 = strTokenizer75.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher77 = strTokenizer75.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = strTokenizer65.setIgnoredMatcher(strMatcher77);
        org.apache.commons.lang.text.StrMatcher strMatcher79 = strTokenizer65.getIgnoredMatcher();
        boolean boolean80 = strBuilder25.contains(strMatcher79);
        boolean boolean81 = strBuilder20.contains(strMatcher79);
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder20.appendNull();
        char[] charArray83 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder84 = strBuilder20.append(charArray83);
        java.lang.Object obj85 = null;
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder88 = strBuilder20.appendFixedWidthPadRight(obj85, (int) '4', '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 35 + "'", int21 == 35);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(charArray48);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strMatcher52);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(strTokenizer67);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strTokenizer75);
        org.junit.Assert.assertNotNull(strArray76);
        org.junit.Assert.assertNotNull(strMatcher77);
        org.junit.Assert.assertNotNull(strTokenizer78);
        org.junit.Assert.assertNotNull(strMatcher79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder84);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder8.ensureCapacity((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder15.insert(0, (int) (short) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder15.setNewLineText("01.001.0hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder22.appendNewLine();
        char[] charArray32 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher33 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer(charArray32, strMatcher33);
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray32);
        org.apache.commons.lang.text.StrMatcher strMatcher36 = strTokenizer35.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder25.deleteFirst(strMatcher36);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder37.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray48 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer(charArray48, strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray48);
        boolean boolean52 = strTokenizer51.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher53 = strTokenizer51.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder37.appendFixedWidthPadRight((java.lang.Object) strMatcher53, 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.appendPadding((int) (short) 100, 'a');
        char[] charArray66 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher67 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer(charArray66, strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray66);
        org.apache.commons.lang.text.StrMatcher strMatcher70 = strTokenizer69.getQuoteMatcher();
        int int72 = strBuilder59.indexOf(strMatcher70, (int) '#');
        java.lang.String str73 = strBuilder59.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder59.insert((int) (short) 10, (double) 11);
        char[] charArray84 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher85 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = new org.apache.commons.lang.text.StrTokenizer(charArray84, strMatcher85);
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray84);
        org.apache.commons.lang.text.StrBuilder strBuilder88 = strBuilder59.insert(8, (java.lang.Object) charArray84);
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder20.append(charArray84);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(charArray32);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strMatcher36);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(charArray48);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(strMatcher53);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strMatcher70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "\naaaaaaaa10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str73.equals("\naaaaaaaa10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(charArray84);
        org.junit.Assert.assertNotNull(strTokenizer87);
        org.junit.Assert.assertNotNull(strBuilder88);
        org.junit.Assert.assertNotNull(strBuilder89);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        char[] charArray15 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray15, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder8.append(charArray15);
        boolean boolean21 = strBuilder19.contains(' ');
        int int24 = strBuilder19.lastIndexOf('#', 0);
        boolean boolean25 = strBuilder19.isEmpty();
        try {
            java.lang.String str27 = strBuilder19.substring((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("aaaaaaaaa", '3', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoreEmptyTokens(true);
        try {
            strTokenizer5.remove();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: remove() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(strTokenizer5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        char[] charArray15 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray15, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder8.append(charArray15);
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder19.replace(strMatcher20, "", 1, 100, (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder27.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder27.appendFixedWidthPadRight((int) '#', 100, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder27.append((float) (short) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder36.deleteFirst('a');
        org.apache.commons.lang.text.StrBuilder strBuilder40 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder40.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder44.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder47.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder42.appendFixedWidthPadLeft((java.lang.Object) strBuilder47, (int) (byte) 10, 'a');
        char[] charArray59 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher60 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer(charArray59, strMatcher60);
        org.apache.commons.lang.text.StrMatcher strMatcher62 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher63 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = new org.apache.commons.lang.text.StrTokenizer(charArray59, strMatcher62, strMatcher63);
        java.lang.String[] strArray65 = strTokenizer64.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder42.appendWithSeparators((java.lang.Object[]) strArray65, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder36.appendWithSeparators((java.lang.Object[]) strArray65, "hi!01.001.0hi! ");
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder25.appendWithSeparators((java.lang.Object[]) strArray65, "0");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertNotNull(strArray65);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder71);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder16.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder24.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder24.appendNewLine();
        char[] charArray34 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray34);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer37.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder27.deleteFirst(strMatcher38);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder39.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int44 = strBuilder43.capacity();
        boolean boolean45 = strBuilder22.equals(strBuilder43);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder22.appendPadding(100, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder48.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder49.appendPadding(0, '#');
        int int53 = strBuilder52.size();
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder52.replaceFirst("aaaaaaaaaa", "");
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder56.trim();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strMatcher38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 35 + "'", int44 == 35);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder57);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        boolean boolean16 = strBuilder4.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder4.appendFixedWidthPadRight(0, (int) (byte) 0, 'a');
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher31 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher30, strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray27, '4', '#');
        org.apache.commons.lang.text.StrMatcher strMatcher36 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder38 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder38.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder38.appendNewLine();
        char[] charArray48 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer(charArray48, strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray48);
        org.apache.commons.lang.text.StrMatcher strMatcher52 = strTokenizer51.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder41.deleteFirst(strMatcher52);
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder53.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder53.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder61 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder61.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder61.appendNewLine();
        char[] charArray71 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher72 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = new org.apache.commons.lang.text.StrTokenizer(charArray71, strMatcher72);
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray71);
        org.apache.commons.lang.text.StrMatcher strMatcher75 = strTokenizer74.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder64.deleteFirst(strMatcher75);
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder76.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int81 = strBuilder80.capacity();
        boolean boolean82 = strBuilder59.equals(strBuilder80);
        org.apache.commons.lang.text.StrBuilder strBuilder84 = strBuilder59.deleteFirst("StrTokenizer[not tokenized yet]");
        char[] charArray91 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher92 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer93 = new org.apache.commons.lang.text.StrTokenizer(charArray91, strMatcher92);
        org.apache.commons.lang.text.StrTokenizer strTokenizer94 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray91);
        boolean boolean95 = strTokenizer94.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher96 = strTokenizer94.getQuoteMatcher();
        int int97 = strBuilder84.lastIndexOf(strMatcher96);
        org.apache.commons.lang.text.StrTokenizer strTokenizer98 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher36, strMatcher96);
        boolean boolean99 = strBuilder20.contains(strMatcher96);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(charArray48);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strMatcher52);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(charArray71);
        org.junit.Assert.assertNotNull(strTokenizer74);
        org.junit.Assert.assertNotNull(strMatcher75);
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 35 + "'", int81 == 35);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(strBuilder84);
        org.junit.Assert.assertNotNull(charArray91);
        org.junit.Assert.assertNotNull(strTokenizer94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNotNull(strMatcher96);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + (-1) + "'", int97 == (-1));
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        java.lang.String[] strArray10 = strTokenizer9.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer9.setQuoteMatcher(strMatcher11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer12.reset("#  a a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer12.setIgnoreEmptyTokens(false);
        java.lang.Object obj17 = strTokenizer12.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer12.setQuoteChar('S');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertTrue("'" + obj17 + "' != '" + "#  a a" + "'", obj17.equals("#  a a"));
        org.junit.Assert.assertNotNull(strTokenizer19);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        int int9 = strBuilder1.indexOf('a', 3);
        char[] charArray16 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray16, strMatcher17);
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer(charArray16, strMatcher19, strMatcher20);
        char[] charArray28 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer(charArray28, strMatcher29);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray28);
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer31.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer21.setTrimmerMatcher(strMatcher32);
        int int35 = strBuilder1.lastIndexOf(strMatcher32, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder1.ensureCapacity(0);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder40 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder40.deleteFirst("hi!");
        boolean boolean43 = strBuilder40.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder40.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder40.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder49.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder49.appendNewLine();
        char[] charArray59 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher60 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer(charArray59, strMatcher60);
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray59);
        org.apache.commons.lang.text.StrMatcher strMatcher63 = strTokenizer62.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder52.deleteFirst(strMatcher63);
        int int66 = strBuilder47.lastIndexOf(strMatcher63, 10);
        java.io.Reader reader67 = strBuilder47.asReader();
        java.lang.StringBuffer stringBuffer68 = strBuilder47.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder38.append(stringBuffer68);
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder38.deleteFirst("0hi!0#################################################################################");
        boolean boolean73 = strBuilder38.contains('4');
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) strBuilder38, (int) (short) 100, 'a');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(strMatcher63);
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
        org.junit.Assert.assertNotNull(reader67);
        org.junit.Assert.assertNotNull(stringBuffer68);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(strBuilder76);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray6);
        org.junit.Assert.assertNotNull(charArray6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray6, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray6);
        java.lang.Class<?> wildcardClass12 = strTokenizer11.getClass();
        java.util.List list13 = strTokenizer11.getTokenList();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int21 = strBuilder20.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder20.setNullText("");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder25.appendNewLine();
        char[] charArray35 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher36 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray35, strMatcher36);
        int int38 = strTokenizer37.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer37.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher40 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer39.setIgnoredMatcher(strMatcher40);
        char[] charArray48 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer(charArray48, strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray48);
        org.apache.commons.lang.text.StrMatcher strMatcher52 = strTokenizer51.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer39.setQuoteMatcher(strMatcher52);
        int int54 = strBuilder25.indexOf(strMatcher52);
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder59.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strTokenizer65.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder59.appendWithSeparators((java.util.Iterator) strTokenizer65, "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = strTokenizer73.setIgnoreEmptyTokens(true);
        java.lang.String[] strArray76 = strTokenizer75.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher77 = strTokenizer75.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = strTokenizer65.setIgnoredMatcher(strMatcher77);
        org.apache.commons.lang.text.StrMatcher strMatcher79 = strTokenizer65.getIgnoredMatcher();
        boolean boolean80 = strBuilder25.contains(strMatcher79);
        boolean boolean81 = strBuilder20.contains(strMatcher79);
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder20.appendNull();
        char[] charArray83 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder84 = strBuilder20.append(charArray83);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder87 = strBuilder20.insert(15, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 15");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 35 + "'", int21 == 35);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(charArray48);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strMatcher52);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(strTokenizer67);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strTokenizer75);
        org.junit.Assert.assertNotNull(strArray76);
        org.junit.Assert.assertNotNull(strMatcher77);
        org.junit.Assert.assertNotNull(strTokenizer78);
        org.junit.Assert.assertNotNull(strMatcher79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder84);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        char[] charArray15 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray15, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder8.append(charArray15);
        char[] charArray26 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray26);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder31.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder38.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder33.appendFixedWidthPadLeft((java.lang.Object) strBuilder38, (int) (byte) 10, 'a');
        char[] charArray45 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer(charArray45, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder38.append(charArray45);
        org.apache.commons.lang.text.StrBuilder strBuilder51 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder51.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder51.appendNewLine();
        char[] charArray61 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher62 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer(charArray61, strMatcher62);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray61);
        org.apache.commons.lang.text.StrMatcher strMatcher65 = strTokenizer64.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder54.deleteFirst(strMatcher65);
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder38.replaceAll(strMatcher65, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher65);
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder8.append(charArray26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer(charArray26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = new org.apache.commons.lang.text.StrTokenizer(charArray26, "aa4 #");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(charArray61);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strMatcher65);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder70);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        char[] charArray0 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer(charArray0, '#', '0');
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((java.lang.Object) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder3.append((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder7.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.append((double) 1);
        char[] charArray11 = null;
        char[] charArray12 = strBuilder7.getChars(charArray11);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(charArray12);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int21 = strBuilder20.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder20.setNullText("");
        java.lang.StringBuffer stringBuffer24 = strBuilder23.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder23.appendFixedWidthPadLeft((int) (short) 10, 101, 'S');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 35 + "'", int21 == 35);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(stringBuffer24);
        org.junit.Assert.assertNotNull(strBuilder28);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder16.minimizeCapacity();
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.insert((int) ' ', '0');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 32");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder17);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = new org.apache.commons.lang.text.StrTokenizer("aaaaaaaaa");
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        boolean boolean16 = strBuilder4.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder4.appendFixedWidthPadRight(0, (int) (byte) 0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.deleteFirst("hi!");
        boolean boolean25 = strBuilder22.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder22.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder22.appendPadding(0, '4');
        java.lang.String str31 = strBuilder22.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder33.appendNewLine();
        char[] charArray43 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray43, strMatcher44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray43);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer46.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder36.deleteFirst(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder48.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder48.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder56.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.appendNewLine();
        char[] charArray66 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher67 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer(charArray66, strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray66);
        org.apache.commons.lang.text.StrMatcher strMatcher70 = strTokenizer69.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder59.deleteFirst(strMatcher70);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder71.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int76 = strBuilder75.capacity();
        boolean boolean77 = strBuilder54.equals(strBuilder75);
        boolean boolean78 = strBuilder22.equalsIgnoreCase(strBuilder75);
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder22.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder80.deleteAll("");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder20.appendFixedWidthPadLeft((java.lang.Object) "", (-1), 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder87 = strBuilder85.append("01.001.0hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder88 = strBuilder85.trim();
        java.lang.String str91 = strBuilder85.substring(8, 11);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strMatcher70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 35 + "'", int76 == 35);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(strBuilder87);
        org.junit.Assert.assertNotNull(strBuilder88);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "1.0" + "'", str91.equals("1.0"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("hi!", '#', ' ');
        int int4 = strTokenizer3.size();
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer("", '4', '#');
        char[] charArray15 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher16 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = new org.apache.commons.lang.text.StrTokenizer(charArray15, strMatcher16);
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray15);
        org.apache.commons.lang.text.StrMatcher strMatcher19 = strTokenizer18.getQuoteMatcher();
        char[] charArray21 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray21, '#', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer18.reset(charArray21);
        char[] charArray32 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher33 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer(charArray32, strMatcher33);
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray32);
        org.apache.commons.lang.text.StrMatcher strMatcher36 = strTokenizer35.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer25.setQuoteMatcher(strMatcher36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer8.setIgnoredMatcher(strMatcher36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer3.setIgnoredMatcher(strMatcher36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer39.reset();
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer40.setIgnoredChar('3');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strMatcher19);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(charArray32);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strMatcher36);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer42);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        java.io.Reader reader15 = strBuilder4.asReader();
        char[] charArray22 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray22, strMatcher23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray22);
        java.lang.String[] strArray26 = strTokenizer25.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder4.appendWithSeparators((java.lang.Object[]) strArray26, "0");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder28.append(true);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(reader15);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder30);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("", "hi!");
        java.lang.String str3 = strTokenizer2.previousToken();
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder0.appendFixedWidthPadRight(8, (int) (byte) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder4.replaceAll("", "hi!");
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher9, strMatcher10);
        java.lang.String[] strArray12 = strTokenizer11.getTokenArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.reset();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strTokenizer13);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        char[] charArray15 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray15, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder8.append(charArray15);
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder19.replace(strMatcher20, "", 1, 100, (int) 'a');
        char[] charArray27 = new char[] { '4' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, ' ');
        char[] charArray36 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher37 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray36, strMatcher37);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray36);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder41.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder45.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder48.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder43.appendFixedWidthPadLeft((java.lang.Object) strBuilder48, (int) (byte) 10, 'a');
        char[] charArray55 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer(charArray55, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder48.append(charArray55);
        org.apache.commons.lang.text.StrBuilder strBuilder61 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder61.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder61.appendNewLine();
        char[] charArray71 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher72 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = new org.apache.commons.lang.text.StrTokenizer(charArray71, strMatcher72);
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray71);
        org.apache.commons.lang.text.StrMatcher strMatcher75 = strTokenizer74.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder64.deleteFirst(strMatcher75);
        org.apache.commons.lang.text.StrBuilder strBuilder78 = strBuilder48.replaceAll(strMatcher75, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = new org.apache.commons.lang.text.StrTokenizer(charArray36, strMatcher75);
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = strTokenizer29.setTrimmerMatcher(strMatcher75);
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = strTokenizer29.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder84 = strBuilder25.appendWithSeparators((java.util.Iterator) strTokenizer82, "hi!");
        java.lang.Object obj85 = strTokenizer82.clone();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(charArray55);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(charArray71);
        org.junit.Assert.assertNotNull(strTokenizer74);
        org.junit.Assert.assertNotNull(strMatcher75);
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(strBuilder78);
        org.junit.Assert.assertNotNull(strTokenizer80);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertNotNull(strBuilder84);
        org.junit.Assert.assertNotNull(obj85);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = new org.apache.commons.lang.text.StrTokenizer(charArray1, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.appendNewLine();
        char[] charArray16 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray16, strMatcher17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray16);
        org.apache.commons.lang.text.StrMatcher strMatcher20 = strTokenizer19.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder9.deleteFirst(strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray1, strMatcher20);
        try {
            java.lang.Object obj23 = strTokenizer22.previous();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strMatcher20);
        org.junit.Assert.assertNotNull(strBuilder21);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendPadding(0, '4');
        boolean boolean10 = strBuilder9.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder9.setNewLineText("StrTokenizer[#   ]");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(strBuilder12);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = new org.apache.commons.lang.text.StrTokenizer("                                    ");
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        int int14 = strTokenizer13.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher16 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoredMatcher(strMatcher16);
        char[] charArray24 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher25 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer(charArray24, strMatcher25);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray24);
        org.apache.commons.lang.text.StrMatcher strMatcher28 = strTokenizer27.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer15.setQuoteMatcher(strMatcher28);
        int int30 = strBuilder1.indexOf(strMatcher28);
        int int31 = strBuilder1.capacity();
        char[] charArray32 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder1.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder1.appendNull();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strMatcher28);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 35 + "'", int31 == 35);
        org.junit.Assert.assertNotNull(charArray32);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder34);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray7 = strBuilder1.toCharArray(0, (int) '4');
        char[] charArray8 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray8, 'a');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray8);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder(0);
        java.lang.String str4 = strBuilder1.midString((int) (short) 100, 11);
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((long) 11);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(strBuilder6);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder0.appendFixedWidthPadRight(8, (int) (byte) 100, 'a');
        java.lang.String str5 = strBuilder4.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder4.insert((int) 'a', true);
        int int10 = strBuilder4.lastIndexOf(' ');
        char[] charArray12 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray12, '#', '4');
        char[] charArray16 = strBuilder4.getChars(charArray12);
        char[] charArray23 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher24 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray23, strMatcher24);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer(charArray23, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray23);
        char[] charArray35 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher36 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray35, strMatcher36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray35);
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer38.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer(charArray23, strMatcher39);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder4.append(charArray23, (int) 'S', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: Invalid startIndex: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strMatcher39);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 100);
        int int3 = strBuilder1.indexOf('0');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        boolean boolean16 = strBuilder4.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder4.appendFixedWidthPadRight(0, (int) (byte) 0, 'a');
        boolean boolean22 = strBuilder20.startsWith("hi!01.001.0hi! ");
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        char[] charArray8 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray8, strMatcher9);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray8);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder20.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) strBuilder20, (int) (byte) 10, 'a');
        char[] charArray27 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer(charArray27, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder20.append(charArray27);
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder33.appendNewLine();
        char[] charArray43 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray43, strMatcher44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray43);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer46.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder36.deleteFirst(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder20.replaceAll(strMatcher47, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = new org.apache.commons.lang.text.StrTokenizer(charArray8, strMatcher47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer("#   ", strMatcher1, strMatcher47);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder50);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray6, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer10.setIgnoredChar(' ');
        char[] charArray21 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer(charArray21, strMatcher22);
        int int24 = strTokenizer23.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer23.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher26 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer25.setIgnoredMatcher(strMatcher26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer25.reset("\naaaaaaaa10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str30 = strTokenizer25.nextToken();
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer25.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer14.setDelimiterMatcher(strMatcher31);
        boolean boolean33 = strTokenizer32.hasPrevious();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "\naaaaaaaa10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str30.equals("\naaaaaaaa10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.append(100.0f);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder6.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder6.replaceFirst("i!", "044");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder12.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.setNewLineText("hi!");
        java.lang.String str18 = strBuilder17.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.deleteAll("");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder17.append((int) '3');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder6.append(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder23);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray7 = strBuilder1.toCharArray(0, (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.deleteFirst("StrTokenizer[not tokenized yet]");
        java.lang.String str10 = strBuilder9.getNullText();
        int int11 = strBuilder9.capacity();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        int int14 = strTokenizer13.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher16 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoredMatcher(strMatcher16);
        char[] charArray24 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher25 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer(charArray24, strMatcher25);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray24);
        org.apache.commons.lang.text.StrMatcher strMatcher28 = strTokenizer27.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer15.setQuoteMatcher(strMatcher28);
        int int30 = strBuilder1.indexOf(strMatcher28);
        int int31 = strBuilder1.capacity();
        char[] charArray32 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder1.clear();
        java.lang.String str35 = strBuilder33.rightString((int) (short) 0);
        int int37 = strBuilder33.lastIndexOf(' ');
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder33.delete(35, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strMatcher28);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 35 + "'", int31 == 35);
        org.junit.Assert.assertNotNull(charArray32);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.appendNewLine();
        char[] charArray20 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray20, strMatcher21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray20);
        org.apache.commons.lang.text.StrMatcher strMatcher24 = strTokenizer23.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder13.deleteFirst(strMatcher24);
        int int27 = strBuilder8.lastIndexOf(strMatcher24, 10);
        int int30 = strBuilder8.indexOf("hi!", 0);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder8.append(strBuilder32);
        char[] charArray35 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray35, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder40 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder40.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder40.appendNewLine();
        char[] charArray50 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher51 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer(charArray50, strMatcher51);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray50);
        org.apache.commons.lang.text.StrMatcher strMatcher54 = strTokenizer53.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder43.deleteFirst(strMatcher54);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer(charArray35, strMatcher54);
        org.apache.commons.lang.text.StrBuilder strBuilder58 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder58.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder58.appendNewLine();
        char[] charArray68 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher69 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer(charArray68, strMatcher69);
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray68);
        org.apache.commons.lang.text.StrMatcher strMatcher72 = strTokenizer71.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder61.deleteFirst(strMatcher72);
        int int75 = strBuilder73.lastIndexOf(' ');
        java.util.Collection collection76 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder78 = strBuilder73.appendWithSeparators(collection76, "#  a a");
        char[] charArray79 = strBuilder73.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = strTokenizer56.reset(charArray79);
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder33.append(charArray79);
        org.apache.commons.lang.text.StrBuilder strBuilder83 = strBuilder33.deleteAll("StrTokenizer[not tokenized yet]");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strMatcher24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(charArray50);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strMatcher54);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(charArray68);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertNotNull(strMatcher72);
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(strBuilder78);
        org.junit.Assert.assertNotNull(charArray79);
        org.junit.Assert.assertNotNull(strTokenizer80);
        org.junit.Assert.assertNotNull(strBuilder81);
        org.junit.Assert.assertNotNull(strBuilder83);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder16.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = null;
        try {
            boolean boolean19 = strBuilder16.equals(strBuilder18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder17);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((java.lang.Object) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder3.append((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder7.reverse();
        java.util.Collection collection9 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder8.appendWithSeparators(collection9, "\n5aaaaaaaaa4444444100");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder11);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("eurta", "eurta");
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("", '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = strTokenizer2.setDelimiterString("StrTokenizer[hi!]");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder(0);
        java.lang.String str9 = strBuilder6.midString((int) (short) 100, 11);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder6.append((-1L));
        try {
            strTokenizer4.add((java.lang.Object) strBuilder6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: add() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(strTokenizer4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strBuilder11);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder4.insert(0, (long) 8);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder9.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder9.appendNewLine();
        char[] charArray19 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer(charArray19, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray19);
        org.apache.commons.lang.text.StrMatcher strMatcher23 = strTokenizer22.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder12.deleteFirst(strMatcher23);
        int int26 = strBuilder12.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder12.appendPadding((int) (byte) 100, ' ');
        char[] charArray36 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher37 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray36, strMatcher37);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray36);
        boolean boolean40 = strTokenizer39.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher41 = strTokenizer39.getQuoteMatcher();
        int int42 = strBuilder29.lastIndexOf(strMatcher41);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder44.deleteFirst("hi!");
        boolean boolean47 = strBuilder44.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder44.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder44.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder53 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder53.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder53.appendNewLine();
        char[] charArray63 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher64 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = new org.apache.commons.lang.text.StrTokenizer(charArray63, strMatcher64);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray63);
        org.apache.commons.lang.text.StrMatcher strMatcher67 = strTokenizer66.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder56.deleteFirst(strMatcher67);
        int int70 = strBuilder51.lastIndexOf(strMatcher67, 10);
        java.io.Reader reader71 = strBuilder51.asReader();
        java.lang.StringBuffer stringBuffer72 = strBuilder51.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder29.append(stringBuffer72);
        org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder7.append(stringBuffer72);
        boolean boolean76 = strBuilder74.endsWith("aaaaaaaaa");
        org.apache.commons.lang.text.StrBuilder strBuilder78 = strBuilder74.append((long) 0);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strMatcher23);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(strMatcher41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(charArray63);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(strMatcher67);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNotNull(reader71);
        org.junit.Assert.assertNotNull(stringBuffer72);
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertNotNull(strBuilder74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(strBuilder78);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder2.setNullText("StrTokenizer[hi!]");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder2.insert((int) (short) 1, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder9.deleteFirst("hi!");
        boolean boolean12 = strBuilder9.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder9.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder9.appendPadding(0, '4');
        java.lang.String str18 = strBuilder9.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder20.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder20.appendNewLine();
        char[] charArray30 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher31 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray30, strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray30);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer33.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder23.deleteFirst(strMatcher34);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder35.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder35.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder43 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder43.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder43.appendNewLine();
        char[] charArray53 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher54 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer(charArray53, strMatcher54);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray53);
        org.apache.commons.lang.text.StrMatcher strMatcher57 = strTokenizer56.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder46.deleteFirst(strMatcher57);
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder58.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int63 = strBuilder62.capacity();
        boolean boolean64 = strBuilder41.equals(strBuilder62);
        boolean boolean65 = strBuilder9.equalsIgnoreCase(strBuilder62);
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder62.append((float) '#');
        boolean boolean69 = strBuilder62.startsWith("StrTokenizer[not tokenized yet]");
        char[] charArray72 = strBuilder62.toCharArray((int) (byte) 1, (int) (short) 100);
        char[] charArray73 = strBuilder7.getChars(charArray72);
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = new org.apache.commons.lang.text.StrTokenizer(charArray73, "0hi!0#################################################################################");
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strMatcher57);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 35 + "'", int63 == 35);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(charArray72);
        org.junit.Assert.assertNotNull(charArray73);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int21 = strBuilder20.capacity();
        int int22 = strBuilder20.size();
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder20.deleteAll("StrTokenizer[not tokenized yet]");
        boolean boolean25 = strBuilder24.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder24.setNewLineText("");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 35 + "'", int21 == 35);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 11 + "'", int22 == 11);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(strBuilder27);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        java.lang.String[] strArray10 = strTokenizer9.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer9.setQuoteMatcher(strMatcher11);
        org.apache.commons.lang.text.StrMatcher strMatcher13 = strTokenizer9.getQuoteMatcher();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strMatcher13);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder9.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder7.appendFixedWidthPadLeft((java.lang.Object) strBuilder12, (int) (byte) 10, 'a');
        boolean boolean18 = strBuilder1.equals(strBuilder12);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder1.appendNewLine();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(strBuilder19);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        char[] charArray15 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray15, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder8.append(charArray15);
        char[] charArray26 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray26);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder31.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder38.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder33.appendFixedWidthPadLeft((java.lang.Object) strBuilder38, (int) (byte) 10, 'a');
        char[] charArray45 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer(charArray45, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder38.append(charArray45);
        org.apache.commons.lang.text.StrBuilder strBuilder51 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder51.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder51.appendNewLine();
        char[] charArray61 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher62 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer(charArray61, strMatcher62);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray61);
        org.apache.commons.lang.text.StrMatcher strMatcher65 = strTokenizer64.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder54.deleteFirst(strMatcher65);
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder38.replaceAll(strMatcher65, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher65);
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder8.append(charArray26);
        boolean boolean72 = strBuilder8.contains("a");
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder8.appendNewLine();
        org.apache.commons.lang.text.StrBuilder strBuilder77 = strBuilder8.appendFixedWidthPadLeft((int) (byte) -1, (int) '3', ' ');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(charArray61);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strMatcher65);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertNotNull(strBuilder77);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder15.appendNewLine();
        char[] charArray25 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher26 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer(charArray25, strMatcher26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray25);
        org.apache.commons.lang.text.StrMatcher strMatcher29 = strTokenizer28.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder18.deleteFirst(strMatcher29);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder32.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder36.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder39.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder34.appendFixedWidthPadLeft((java.lang.Object) strBuilder39, (int) (byte) 10, 'a');
        java.io.Reader reader45 = strBuilder39.asReader();
        boolean boolean46 = strBuilder30.equalsIgnoreCase(strBuilder39);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder13.appendFixedWidthPadLeft((java.lang.Object) strBuilder30, 35, 'a');
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder30.deleteCharAt(116);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 116");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strMatcher29);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(reader45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(strBuilder49);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder16.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder22.appendPadding(0, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder22.append((float) '#');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder22.deleteAll("");
        char[] charArray36 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher37 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray36, strMatcher37);
        char[] charArray39 = strBuilder22.getChars(charArray36);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder22.deleteCharAt((int) (short) 0);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(charArray39);
        org.junit.Assert.assertNotNull(strBuilder41);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        char[] charArray15 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray15, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder20.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder20.appendNewLine();
        char[] charArray30 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher31 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray30, strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray30);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer33.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder23.deleteFirst(strMatcher34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray15, strMatcher34);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder13.appendFixedWidthPadLeft((java.lang.Object) charArray15, (int) '#', '#');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder39);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        char[] charArray1 = new char[] { '4' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer(charArray1, ' ');
        char[] charArray10 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder19.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder17.appendFixedWidthPadLeft((java.lang.Object) strBuilder22, (int) (byte) 10, 'a');
        char[] charArray29 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray29, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder22.append(charArray29);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder35.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.appendNewLine();
        char[] charArray45 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer(charArray45, strMatcher46);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray45);
        org.apache.commons.lang.text.StrMatcher strMatcher49 = strTokenizer48.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder38.deleteFirst(strMatcher49);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder22.replaceAll(strMatcher49, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer3.setTrimmerMatcher(strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer3.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer3.setEmptyTokenAsNull(true);
        boolean boolean59 = strTokenizer58.hasNext();
        java.lang.String str60 = strTokenizer58.previousToken();
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strMatcher49);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNull(str60);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance("#  a a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = strTokenizer1.setEmptyTokenAsNull(false);
        java.lang.String str4 = strTokenizer1.previousToken();
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertNotNull(strTokenizer3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        char[] charArray0 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer(charArray0, "StrTokenizer[hi!]");
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("", 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = new org.apache.commons.lang.text.StrBuilder((int) (short) 100);
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher15 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher14, strMatcher15);
        char[] charArray21 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer16.reset(charArray21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray21, "");
        char[] charArray26 = strBuilder4.getChars(charArray21);
        char[] charArray33 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher34 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray33, strMatcher34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray33, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray33);
        char[] charArray45 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer(charArray45, strMatcher46);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray45);
        org.apache.commons.lang.text.StrMatcher strMatcher49 = strTokenizer48.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer(charArray33, strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = new org.apache.commons.lang.text.StrTokenizer(charArray21, strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer2.reset(charArray21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer2.setIgnoredChar('#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer54.setQuoteChar('S');
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strMatcher49);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strTokenizer56);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((java.lang.Object) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder3.append((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder7.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.append((double) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder12.appendNewLine();
        char[] charArray22 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray22, strMatcher23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray22);
        org.apache.commons.lang.text.StrMatcher strMatcher26 = strTokenizer25.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder15.deleteFirst(strMatcher26);
        int int29 = strBuilder15.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder15.appendPadding((int) (byte) 100, ' ');
        char[] charArray39 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher40 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer(charArray39, strMatcher40);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray39);
        boolean boolean43 = strTokenizer42.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher44 = strTokenizer42.getQuoteMatcher();
        int int45 = strBuilder32.lastIndexOf(strMatcher44);
        org.apache.commons.lang.text.StrBuilder strBuilder47 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder47.deleteFirst("hi!");
        boolean boolean50 = strBuilder47.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder47.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder47.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder56.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.appendNewLine();
        char[] charArray66 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher67 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer(charArray66, strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray66);
        org.apache.commons.lang.text.StrMatcher strMatcher70 = strTokenizer69.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder59.deleteFirst(strMatcher70);
        int int73 = strBuilder54.lastIndexOf(strMatcher70, 10);
        java.io.Reader reader74 = strBuilder54.asReader();
        java.lang.StringBuffer stringBuffer75 = strBuilder54.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder32.append(stringBuffer75);
        org.apache.commons.lang.text.StrBuilder strBuilder77 = strBuilder7.append((java.lang.Object) stringBuffer75);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strMatcher26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(charArray39);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(strMatcher44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strMatcher70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNotNull(reader74);
        org.junit.Assert.assertNotNull(stringBuffer75);
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(strBuilder77);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder4.appendPadding((int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder4.appendFixedWidthPadRight((int) 'a', (int) '3', '#');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder23);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.appendNewLine();
        char[] charArray20 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray20, strMatcher21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray20);
        org.apache.commons.lang.text.StrMatcher strMatcher24 = strTokenizer23.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder13.deleteFirst(strMatcher24);
        int int27 = strBuilder8.lastIndexOf(strMatcher24, 10);
        int int30 = strBuilder8.indexOf("hi!", 0);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder8.append(strBuilder32);
        char[] charArray41 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher42 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer(charArray41, strMatcher42);
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray41, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray41);
        char[] charArray53 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher54 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer(charArray53, strMatcher54);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray53);
        org.apache.commons.lang.text.StrMatcher strMatcher57 = strTokenizer56.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer(charArray41, strMatcher57);
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = new org.apache.commons.lang.text.StrTokenizer("#  a a", strMatcher57);
        int int61 = strBuilder32.indexOf(strMatcher57, (int) 'a');
        java.lang.String str63 = strBuilder32.leftString(82);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strMatcher24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strMatcher57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "hi!" + "'", str63.equals("hi!"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher9, strMatcher10);
        char[] charArray16 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray16);
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer11.reset(charArray16);
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer(charArray16, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer(charArray16, "\naaaaaaaa10");
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray16);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strTokenizer24);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        int int9 = strTokenizer8.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer8.reset();
        int int11 = strTokenizer8.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer8.setQuoteChar('3');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = new org.apache.commons.lang.text.StrBuilder();
        int int17 = strBuilder14.lastIndexOf('4', (int) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder20.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder20.appendNewLine();
        char[] charArray30 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher31 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray30, strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray30);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer33.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder23.deleteFirst(strMatcher34);
        int int37 = strBuilder35.lastIndexOf(' ');
        java.util.Collection collection38 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder35.appendWithSeparators(collection38, "#  a a");
        char[] charArray41 = strBuilder35.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder14.insert((int) (short) 0, charArray41);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer13.reset(charArray41);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strTokenizer43);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder(100);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.append((float) (byte) 1);
        char[] charArray9 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray9, '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray9, ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray9);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.deleteFirst("hi!");
        boolean boolean19 = strBuilder16.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder16.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder16.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder25.appendNewLine();
        char[] charArray35 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher36 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray35, strMatcher36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray35);
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer38.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder28.deleteFirst(strMatcher39);
        int int42 = strBuilder23.lastIndexOf(strMatcher39, 10);
        int int45 = strBuilder23.indexOf("hi!", 0);
        org.apache.commons.lang.text.StrBuilder strBuilder47 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder23.append(strBuilder47);
        char[] charArray56 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher57 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer(charArray56, strMatcher57);
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer(charArray56, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray56);
        char[] charArray68 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher69 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer(charArray68, strMatcher69);
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray68);
        org.apache.commons.lang.text.StrMatcher strMatcher72 = strTokenizer71.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = new org.apache.commons.lang.text.StrTokenizer(charArray56, strMatcher72);
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = new org.apache.commons.lang.text.StrTokenizer("#  a a", strMatcher72);
        int int76 = strBuilder47.indexOf(strMatcher72, (int) 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strTokenizer14.setIgnoredMatcher(strMatcher72);
        java.lang.String str78 = strTokenizer77.nextToken();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strMatcher39);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(charArray56);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(charArray68);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertNotNull(strMatcher72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "01.0" + "'", str78.equals("01.0"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.ensureCapacity((int) ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        char[] charArray25 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher26 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer(charArray25, strMatcher26);
        int int28 = strTokenizer27.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer27.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoredMatcher(strMatcher30);
        char[] charArray38 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher39 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer(charArray38, strMatcher39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray38);
        org.apache.commons.lang.text.StrMatcher strMatcher42 = strTokenizer41.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer29.setQuoteMatcher(strMatcher42);
        char[] charArray50 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher51 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer(charArray50, strMatcher51);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer(charArray50, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray50);
        char[] charArray62 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher63 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = new org.apache.commons.lang.text.StrTokenizer(charArray62, strMatcher63);
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray62);
        org.apache.commons.lang.text.StrMatcher strMatcher66 = strTokenizer65.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = new org.apache.commons.lang.text.StrTokenizer(charArray50, strMatcher66);
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = strTokenizer29.setQuoteMatcher(strMatcher66);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = strTokenizer18.setTrimmerMatcher(strMatcher66);
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance("StrTokenizer[not tokenized yet]");
        int int72 = strTokenizer71.size();
        char[] charArray79 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher80 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer81 = new org.apache.commons.lang.text.StrTokenizer(charArray79, strMatcher80);
        org.apache.commons.lang.text.StrMatcher strMatcher82 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher83 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = new org.apache.commons.lang.text.StrTokenizer(charArray79, strMatcher82, strMatcher83);
        char[] charArray89 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer90 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray89);
        org.apache.commons.lang.text.StrTokenizer strTokenizer91 = strTokenizer84.reset(charArray89);
        org.apache.commons.lang.text.StrTokenizer strTokenizer92 = strTokenizer71.reset(charArray89);
        org.apache.commons.lang.text.StrTokenizer strTokenizer94 = strTokenizer92.reset("StrTokenizer[hi!]");
        org.apache.commons.lang.text.StrMatcher strMatcher95 = strTokenizer94.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer96 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[not tokenized yet]", strMatcher66, strMatcher95);
        org.apache.commons.lang.text.StrBuilder strBuilder98 = strBuilder16.replaceFirst(strMatcher95, "i!");
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(charArray38);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(strMatcher42);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(charArray50);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(charArray62);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertNotNull(strMatcher66);
        org.junit.Assert.assertNotNull(strTokenizer68);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(charArray79);
        org.junit.Assert.assertNotNull(charArray89);
        org.junit.Assert.assertNotNull(strTokenizer90);
        org.junit.Assert.assertNotNull(strTokenizer91);
        org.junit.Assert.assertNotNull(strTokenizer92);
        org.junit.Assert.assertNotNull(strTokenizer94);
        org.junit.Assert.assertNotNull(strMatcher95);
        org.junit.Assert.assertNotNull(strBuilder98);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((java.lang.Object) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder3.append((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder7.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.append(5);
        java.lang.Object obj11 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder10.appendFixedWidthPadRight(obj11, (int) (byte) -1, '4');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder14);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        java.lang.String[] strArray10 = strTokenizer9.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer9.setQuoteMatcher(strMatcher11);
        java.lang.Class<?> wildcardClass13 = strTokenizer9.getClass();
        java.lang.String str14 = strTokenizer9.nextToken();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder16.appendNewLine();
        char[] charArray26 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray26);
        org.apache.commons.lang.text.StrMatcher strMatcher30 = strTokenizer29.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder19.deleteFirst(strMatcher30);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder31.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int36 = strBuilder35.capacity();
        int int37 = strBuilder35.size();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder35.deleteAll("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer43.setIgnoreEmptyTokens(true);
        java.lang.String[] strArray46 = strTokenizer45.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer45.getTrimmerMatcher();
        boolean boolean48 = strBuilder39.contains(strMatcher47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer9.setTrimmerMatcher(strMatcher47);
        java.util.List list50 = strTokenizer9.getTokenList();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#  a a" + "'", str14.equals("#  a a"));
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strMatcher30);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 35 + "'", int36 == 35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 11 + "'", int37 == 11);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertNotNull(list50);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = new org.apache.commons.lang.text.StrTokenizer("a");
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        org.apache.commons.lang.text.StrMatcher strMatcher10 = strTokenizer9.getQuoteMatcher();
        char[] charArray12 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray12, '#', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer9.reset(charArray12);
        boolean boolean17 = strTokenizer9.isEmptyTokenAsNull();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer9.reset();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strMatcher10);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(strTokenizer18);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((int) (short) -1, (int) (short) 0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder16.replaceFirst('4', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder16.append(false);
        try {
            char char27 = strBuilder25.charAt((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 97");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((java.lang.Object) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.deleteFirst("01.001.0hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer19.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder13.appendWithSeparators((java.util.Iterator) strTokenizer19, "");
        boolean boolean25 = strBuilder13.contains('#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strBuilder13.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder28.deleteFirst("hi!");
        boolean boolean31 = strBuilder28.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder28.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder28.append((float) (byte) 1);
        char[] charArray36 = strBuilder28.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray36, '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer(charArray36, ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer41.setQuoteChar('#');
        org.apache.commons.lang.text.StrMatcher strMatcher44 = strTokenizer41.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer26.setQuoteMatcher(strMatcher44);
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder5.insert(0, (java.lang.Object) strTokenizer26);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strMatcher44);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strBuilder46);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        int int18 = strBuilder4.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder4.appendFixedWidthPadRight(5, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder4.append((float) (short) 100);
        java.lang.String str27 = strBuilder4.midString(0, (int) (short) 1);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "\n" + "'", str27.equals("\n"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        int int9 = strBuilder1.indexOf('a', 3);
        java.lang.String str11 = strBuilder1.rightString((int) (short) 100);
        java.lang.String str12 = strBuilder1.getNewLineText();
        int int15 = strBuilder1.indexOf('4', 0);
        int int17 = strBuilder1.lastIndexOf("\naaaa");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder1.deleteFirst("");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder1.setNewLineText("StrTokenizer[#   ]");
        int int23 = strBuilder1.lastIndexOf("hi!");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("aaaaaaaaa", '3', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoreEmptyTokens(true);
        char[] charArray12 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher13 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = new org.apache.commons.lang.text.StrTokenizer(charArray12, strMatcher13);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray12);
        java.lang.String[] strArray16 = strTokenizer15.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer15.setQuoteMatcher(strMatcher17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer18.reset("#  a a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer18.setIgnoreEmptyTokens(false);
        int int23 = strTokenizer22.nextIndex();
        org.apache.commons.lang.text.StrMatcher strMatcher24 = strTokenizer22.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer3.setQuoteMatcher(strMatcher24);
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(strMatcher24);
        org.junit.Assert.assertNotNull(strTokenizer25);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        boolean boolean16 = strBuilder4.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder4.appendFixedWidthPadRight(0, (int) (byte) 0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.deleteFirst("hi!");
        boolean boolean25 = strBuilder22.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder22.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder22.appendPadding(0, '4');
        java.lang.String str31 = strBuilder22.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder33.appendNewLine();
        char[] charArray43 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray43, strMatcher44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray43);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer46.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder36.deleteFirst(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder48.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder48.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder56.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.appendNewLine();
        char[] charArray66 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher67 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer(charArray66, strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray66);
        org.apache.commons.lang.text.StrMatcher strMatcher70 = strTokenizer69.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder59.deleteFirst(strMatcher70);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder71.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int76 = strBuilder75.capacity();
        boolean boolean77 = strBuilder54.equals(strBuilder75);
        boolean boolean78 = strBuilder22.equalsIgnoreCase(strBuilder75);
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder22.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder80.deleteAll("");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder20.appendFixedWidthPadLeft((java.lang.Object) "", (-1), 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder87 = strBuilder85.append("01.001.0hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder87.deleteAll('3');
        org.apache.commons.lang.text.StrBuilder strBuilder91 = strBuilder87.append("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder94 = strBuilder87.replaceAll('3', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder96 = strBuilder94.append((long) 8);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strMatcher70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 35 + "'", int76 == 35);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(strBuilder87);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder91);
        org.junit.Assert.assertNotNull(strBuilder94);
        org.junit.Assert.assertNotNull(strBuilder96);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((java.lang.Object) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.insert(0, "");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder8.replaceFirst('a', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder8.replaceFirst('S', 'i');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = new org.apache.commons.lang.text.StrTokenizer(charArray1, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.appendNewLine();
        char[] charArray16 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray16, strMatcher17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray16);
        org.apache.commons.lang.text.StrMatcher strMatcher20 = strTokenizer19.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder9.deleteFirst(strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray1, strMatcher20);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder24.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder24.appendNewLine();
        char[] charArray34 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray34);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer37.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder27.deleteFirst(strMatcher38);
        int int41 = strBuilder39.lastIndexOf(' ');
        java.util.Collection collection42 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder39.appendWithSeparators(collection42, "#  a a");
        char[] charArray45 = strBuilder39.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer22.reset(charArray45);
        try {
            strTokenizer22.remove();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: remove() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strMatcher20);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strMatcher38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(strTokenizer46);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        java.lang.String[] strArray10 = strTokenizer9.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer9.setQuoteMatcher(strMatcher11);
        java.lang.Class<?> wildcardClass13 = strTokenizer9.getClass();
        java.lang.String str14 = strTokenizer9.nextToken();
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer9.setDelimiterChar('4');
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder18.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder18.appendNewLine();
        char[] charArray28 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer(charArray28, strMatcher29);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray28);
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer31.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder21.deleteFirst(strMatcher32);
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder33.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int38 = strBuilder37.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder37.setNullText("");
        char[] charArray41 = null;
        char[] charArray42 = strBuilder37.getChars(charArray41);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer16.reset(charArray42);
        org.apache.commons.lang.text.StrMatcher strMatcher44 = strTokenizer43.getIgnoredMatcher();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#  a a" + "'", str14.equals("#  a a"));
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 35 + "'", int38 == 35);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(charArray42);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strMatcher44);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int21 = strBuilder20.capacity();
        int int22 = strBuilder20.size();
        int int25 = strBuilder20.lastIndexOf('a', (int) '#');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder20.append(82);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder20.append("1.0", (int) (short) 1, 82);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: length must be valid");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 35 + "'", int21 == 35);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 11 + "'", int22 == 11);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 8 + "'", int25 == 8);
        org.junit.Assert.assertNotNull(strBuilder27);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder20.setNewLineText("0");
        int int23 = strBuilder22.size();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        boolean boolean18 = strBuilder4.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder4.replaceAll('a', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder23.deleteFirst("hi!");
        boolean boolean26 = strBuilder23.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder23.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder23.appendPadding(0, '4');
        java.lang.String str32 = strBuilder23.getNewLineText();
        int int35 = strBuilder23.indexOf(' ', 35);
        char[] charArray42 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher43 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray42, strMatcher43);
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray42);
        java.util.List list46 = strTokenizer45.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder23.appendWithSeparators((java.util.Collection) list46, "\naaaaaaaa101");
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder4.appendWithSeparators((java.util.Collection) list46, "aaaaaaaaa");
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder50.append((double) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder50.reverse();
        boolean boolean55 = strBuilder50.contains("");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(charArray42);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        org.apache.commons.lang.text.StrMatcher strMatcher15 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder14.replaceFirst(strMatcher15, "\naaaa");
        java.lang.StringBuffer stringBuffer18 = strBuilder14.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder14.ensureCapacity(15);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(stringBuffer18);
        org.junit.Assert.assertNotNull(strBuilder20);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder(8);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder5.appendFixedWidthPadLeft((java.lang.Object) strBuilder10, (int) (byte) 10, 'a');
        char[] charArray17 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray17, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder10.append(charArray17);
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder21.replace(strMatcher22, "", 1, 100, (int) 'a');
        char[] charArray34 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher35);
        int int37 = strTokenizer36.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer36.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher39 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.setIgnoredMatcher(strMatcher39);
        char[] charArray47 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher48 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = new org.apache.commons.lang.text.StrTokenizer(charArray47, strMatcher48);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray47);
        org.apache.commons.lang.text.StrMatcher strMatcher51 = strTokenizer50.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer38.setQuoteMatcher(strMatcher51);
        char[] charArray59 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher60 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer(charArray59, strMatcher60);
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer(charArray59, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray59);
        char[] charArray71 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher72 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = new org.apache.commons.lang.text.StrTokenizer(charArray71, strMatcher72);
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray71);
        org.apache.commons.lang.text.StrMatcher strMatcher75 = strTokenizer74.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = new org.apache.commons.lang.text.StrTokenizer(charArray59, strMatcher75);
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strTokenizer38.setQuoteMatcher(strMatcher75);
        boolean boolean78 = strBuilder27.contains(strMatcher75);
        int int79 = strBuilder1.indexOf(strMatcher75);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(charArray47);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strMatcher51);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(charArray71);
        org.junit.Assert.assertNotNull(strTokenizer74);
        org.junit.Assert.assertNotNull(strMatcher75);
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder2.setNullText("StrTokenizer[hi!]");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder2.insert((int) (short) 1, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder((int) (short) 100);
        char[] charArray16 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray16, strMatcher17);
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer(charArray16, strMatcher19, strMatcher20);
        char[] charArray26 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer21.reset(charArray26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer(charArray26, "");
        char[] charArray31 = strBuilder9.getChars(charArray26);
        char[] charArray38 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher39 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer(charArray38, strMatcher39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer(charArray38, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray38);
        char[] charArray50 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher51 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer(charArray50, strMatcher51);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray50);
        org.apache.commons.lang.text.StrMatcher strMatcher54 = strTokenizer53.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer(charArray38, strMatcher54);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer(charArray26, strMatcher54);
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder2.deleteFirst(strMatcher54);
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertNotNull(charArray38);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(charArray50);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strMatcher54);
        org.junit.Assert.assertNotNull(strBuilder57);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder15.appendNewLine();
        char[] charArray25 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher26 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer(charArray25, strMatcher26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray25);
        org.apache.commons.lang.text.StrMatcher strMatcher29 = strTokenizer28.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder18.deleteFirst(strMatcher29);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder32.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder36.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder39.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder34.appendFixedWidthPadLeft((java.lang.Object) strBuilder39, (int) (byte) 10, 'a');
        java.io.Reader reader45 = strBuilder39.asReader();
        boolean boolean46 = strBuilder30.equalsIgnoreCase(strBuilder39);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder13.appendFixedWidthPadLeft((java.lang.Object) strBuilder30, 35, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder51 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder51.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder54.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer60.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder54.appendWithSeparators((java.util.Iterator) strTokenizer60, "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = strTokenizer68.setIgnoreEmptyTokens(true);
        java.lang.String[] strArray71 = strTokenizer70.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher72 = strTokenizer70.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = strTokenizer60.setIgnoredMatcher(strMatcher72);
        org.apache.commons.lang.text.StrMatcher strMatcher74 = strTokenizer60.getIgnoredMatcher();
        boolean boolean75 = strBuilder30.contains(strMatcher74);
        org.apache.commons.lang.text.StrBuilder strBuilder77 = strBuilder30.deleteFirst("\naaaaaaaa101");
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder30.replaceAll("eurta", "\n");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strMatcher29);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(reader45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strTokenizer70);
        org.junit.Assert.assertNotNull(strArray71);
        org.junit.Assert.assertNotNull(strMatcher72);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertNotNull(strMatcher74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(strBuilder77);
        org.junit.Assert.assertNotNull(strBuilder80);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray7 = strBuilder1.toCharArray(0, (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.deleteFirst("StrTokenizer[not tokenized yet]");
        char[] charArray16 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray16, strMatcher17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray16);
        boolean boolean20 = strTokenizer19.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer19.getQuoteMatcher();
        int int23 = strBuilder9.lastIndexOf(strMatcher21, (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder9.append((long) 5);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder27.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder27.appendNewLine();
        char[] charArray37 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher38 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer(charArray37, strMatcher38);
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray37);
        org.apache.commons.lang.text.StrMatcher strMatcher41 = strTokenizer40.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder30.deleteFirst(strMatcher41);
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder42.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int47 = strBuilder46.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder46.setNullText("");
        java.lang.StringBuffer stringBuffer50 = strBuilder49.toStringBuffer();
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder9.append(stringBuffer50, (int) '#', (int) '3');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: startIndex must be valid");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strMatcher41);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 35 + "'", int47 == 35);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(stringBuffer50);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder3.appendNewLine();
        char[] charArray16 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder14.insert(5, charArray16);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder19.appendNewLine();
        char[] charArray29 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray29, strMatcher30);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray29);
        org.apache.commons.lang.text.StrMatcher strMatcher33 = strTokenizer32.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder22.deleteFirst(strMatcher33);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder34.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int39 = strBuilder38.capacity();
        int int40 = strBuilder38.size();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder38.deleteAll("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer46.setIgnoreEmptyTokens(true);
        java.lang.String[] strArray49 = strTokenizer48.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher50 = strTokenizer48.getTrimmerMatcher();
        boolean boolean51 = strBuilder42.contains(strMatcher50);
        char[] charArray54 = strBuilder42.toCharArray((int) (byte) 1, (int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder17.append(charArray54);
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder55.append("                                    ");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 35 + "'", int39 == 35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 11 + "'", int40 == 11);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNotNull(strMatcher50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strBuilder57);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder20.setNewLineText("0");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder20.append("");
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder20.insert((int) (byte) 100, (long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 100");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder16.appendFixedWidthPadRight((java.lang.Object) strMatcher32, 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.appendPadding((int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder("StrTokenizer[hi!]");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder41.append('3');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder38.insert((int) (short) 100, (java.lang.Object) strBuilder41);
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder41.ensureCapacity(4);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder46);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder16.appendFixedWidthPadRight((java.lang.Object) strMatcher32, 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.appendPadding((int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder35.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder35.replaceAll("\n", "StrTokenizer[#  a a]");
        char char44 = strBuilder35.charAt((int) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder35.replaceFirst('0', '#');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertTrue("'" + char44 + "' != '" + 'S' + "'", char44 == 'S');
        org.junit.Assert.assertNotNull(strBuilder47);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("01.001.0hi!");
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        char[] charArray27 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder16.appendFixedWidthPadRight((java.lang.Object) strMatcher32, 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.appendPadding((int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder("StrTokenizer[hi!]");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder41.append('3');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder38.insert((int) (short) 100, (java.lang.Object) strBuilder41);
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder38.insert(3, 100);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder47.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder48.deleteAll("aa4 #");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder50);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        boolean boolean4 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendPadding(0, '4');
        java.lang.String str10 = strBuilder1.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder1.deleteAll('#');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder18.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) strBuilder21, (int) (byte) 10, 'a');
        char[] charArray28 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray28, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder21.append(charArray28);
        char[] charArray39 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher40 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer(charArray39, strMatcher40);
        org.apache.commons.lang.text.StrMatcher strMatcher42 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher43 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray39, strMatcher42, strMatcher43);
        char[] charArray49 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = strTokenizer44.reset(charArray49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray49);
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder21.appendWithSeparators((java.util.Iterator) strTokenizer52, "");
        int int56 = strBuilder21.indexOf("#  a a");
        boolean boolean57 = strBuilder1.equalsIgnoreCase(strBuilder21);
        boolean boolean59 = strBuilder21.startsWith("\naaaaaaaa101");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(charArray39);
        org.junit.Assert.assertNotNull(charArray49);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        int int9 = strTokenizer8.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer8.reset();
        int int11 = strTokenizer8.previousIndex();
        boolean boolean12 = strTokenizer8.hasPrevious();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder4.appendWithSeparators((java.util.Iterator) strTokenizer10, "");
        boolean boolean16 = strBuilder4.contains('#');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder4.appendFixedWidthPadRight(0, (int) (byte) 0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.deleteFirst("hi!");
        boolean boolean25 = strBuilder22.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder22.append((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder22.appendPadding(0, '4');
        java.lang.String str31 = strBuilder22.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder33.appendNewLine();
        char[] charArray43 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray43, strMatcher44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray43);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer46.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder36.deleteFirst(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder48.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder48.ensureCapacity((-1));
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder56.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.appendNewLine();
        char[] charArray66 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher67 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer(charArray66, strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray66);
        org.apache.commons.lang.text.StrMatcher strMatcher70 = strTokenizer69.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder59.deleteFirst(strMatcher70);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder71.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int76 = strBuilder75.capacity();
        boolean boolean77 = strBuilder54.equals(strBuilder75);
        boolean boolean78 = strBuilder22.equalsIgnoreCase(strBuilder75);
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder22.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder80.deleteAll("");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder20.appendFixedWidthPadLeft((java.lang.Object) "", (-1), 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder86 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder20.append(strBuilder86, (int) (byte) 10, (int) (short) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder90 = strBuilder89.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder93 = strBuilder90.appendPadding(1, '#');
        int int95 = strBuilder90.indexOf('S');
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strMatcher70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 35 + "'", int76 == 35);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder90);
        org.junit.Assert.assertNotNull(strBuilder93);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + (-1) + "'", int95 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        int int14 = strTokenizer13.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher16 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoredMatcher(strMatcher16);
        char[] charArray24 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher25 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer(charArray24, strMatcher25);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray24);
        org.apache.commons.lang.text.StrMatcher strMatcher28 = strTokenizer27.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer15.setQuoteMatcher(strMatcher28);
        int int30 = strBuilder1.indexOf(strMatcher28);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder32.replaceAll("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder35.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer41.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder35.appendWithSeparators((java.util.Iterator) strTokenizer41, "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = new org.apache.commons.lang.text.StrTokenizer("hi!", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = strTokenizer49.setIgnoreEmptyTokens(true);
        java.lang.String[] strArray52 = strTokenizer51.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher53 = strTokenizer51.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer41.setIgnoredMatcher(strMatcher53);
        org.apache.commons.lang.text.StrMatcher strMatcher55 = strTokenizer41.getIgnoredMatcher();
        boolean boolean56 = strBuilder1.contains(strMatcher55);
        char[] charArray58 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder1.insert(0, charArray58, 1, 116);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strMatcher28);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strArray52);
        org.junit.Assert.assertNotNull(strMatcher53);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strMatcher55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(strBuilder61);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        java.lang.String[] strArray10 = strTokenizer9.getTokenArray();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer9.setQuoteMatcher(strMatcher11);
        java.lang.Class<?> wildcardClass13 = strTokenizer9.getClass();
        java.lang.String str14 = strTokenizer9.nextToken();
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer9.setDelimiterChar('4');
        try {
            java.lang.Object obj17 = strTokenizer9.next();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#  a a" + "'", str14.equals("#  a a"));
        org.junit.Assert.assertNotNull(strTokenizer16);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        char[] charArray7 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher8 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray7, strMatcher8);
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray7);
        org.apache.commons.lang.text.StrMatcher strMatcher11 = strTokenizer10.getQuoteMatcher();
        char[] charArray13 = new char[] { 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer(charArray13, '#', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer10.reset(charArray13);
        char[] charArray24 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher25 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer(charArray24, strMatcher25);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray24);
        org.apache.commons.lang.text.StrMatcher strMatcher28 = strTokenizer27.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer17.setQuoteMatcher(strMatcher28);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder31.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.appendNewLine();
        char[] charArray41 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher42 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer(charArray41, strMatcher42);
        int int44 = strTokenizer43.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer43.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer45.setIgnoredMatcher(strMatcher46);
        char[] charArray54 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher55 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer(charArray54, strMatcher55);
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray54);
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer57.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = strTokenizer45.setQuoteMatcher(strMatcher58);
        int int60 = strBuilder31.indexOf(strMatcher58);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[not tokenized yet]", strMatcher28, strMatcher58);
        org.apache.commons.lang.text.StrMatcher strMatcher62 = strTokenizer61.getDelimiterMatcher();
        org.apache.commons.lang.text.StrMatcher strMatcher63 = strTokenizer61.getIgnoredMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder65 = new org.apache.commons.lang.text.StrBuilder((int) (short) 100);
        char[] charArray66 = strBuilder65.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strTokenizer61.reset(charArray66);
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer(charArray66, '3', '4');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertNotNull(strMatcher11);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strMatcher28);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(strMatcher62);
        org.junit.Assert.assertNotNull(strMatcher63);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strTokenizer67);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNewLine();
        char[] charArray11 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder4.deleteFirst(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadLeft((java.lang.Object) 10, (int) (short) 10, 'a');
        int int21 = strBuilder20.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder20.setNullText("");
        java.lang.String str26 = strBuilder23.midString((int) (short) 100, 10);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder23.replace((int) '#', 100, "a");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 35 + "'", int21 == 35);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(true);
        java.lang.String str3 = strBuilder2.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder2.replaceAll("", "aaaaaaaaa");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder6.appendFixedWidthPadRight(82, (int) (short) -1, 'i');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.replaceFirst('i', 'S');
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        char[] charArray6 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher7);
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher9, strMatcher10);
        char[] charArray16 = new char[] { 'a', '4', ' ', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray16);
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer11.reset(charArray16);
        char[] charArray25 = new char[] { '#', ' ', ' ', 'a', ' ', 'a' };
        org.apache.commons.lang.text.StrMatcher strMatcher26 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer(charArray25, strMatcher26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray25);
        boolean boolean29 = strTokenizer28.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher30 = strTokenizer28.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer18.setTrimmerMatcher(strMatcher30);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer18.reset();
        java.util.List list33 = strTokenizer18.getTokenList();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(strMatcher30);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(list33);
    }
}

