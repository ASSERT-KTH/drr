import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test01");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test02");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("GawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa                                          /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOGawaaEapaaGawaaEapaaGawaaEapaaGawa", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "G w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w " + "'", str3.equals("G w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w "));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test03");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("CHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDALmAv...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test04");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ENENENENEOracle C", "SUN.LWAWT.MACOSX.LWCTOOLKITAAAAAAAAAAAAAAAAAAAAAAAAA", (int) (byte) 0);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test05");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "E                                             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test06");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "ersjava(TM...java(TM...javn", 1119, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test07");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "", 10);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   ###################################################################################################################", (java.lang.CharSequence[]) strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '4');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("/");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray10);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Java(TM)4SE4Runtime4Environment" + "'", str8.equals("Java(TM)4SE4Runtime4Environment"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test08");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_8sun.awt.CGraphicsEnvironment                                     ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test09");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 207, (long) 26, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test10");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", "1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7", (int) (byte) 100);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "en1#", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test11");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                                                                 ", "##############################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############################################" + "'", str2.equals("##############################################"));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test12");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("2.1", 104);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2.1" + "'", str2.equals("2.1"));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test13");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine SpecificationJava Virtual MaENJava Virtual Machine SpecificationJava Virtual Ma", '#');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("51.0");
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "TIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAjhTIONACHINE sPECIFICAL mA vIRTUAVAj", 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", strArray8, strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray8);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "sun.lwawt.macosx.LWCToolkitaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str13.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray17);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test14");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast(".", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test15");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                      class [ljava.lang.string...                       ", 216);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test16");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test17");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test18");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "eneneenene                                                                                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test19");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test20");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "E                                             aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test21");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("uSUSU                                                                                               ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test22");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 5, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test23");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java(TM) SE Runtime Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test24");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;", "1.7.0_8sun.awt.CGraphicsEnvironment                                     ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test25");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("J/BIL/RSU/:SNOISNETXE/AVAJ/YRARBIL/METSYS/:SNOISNETXE/AVAJ/YRARBIL/KROWTEN/:SNOISNETXE/AVAJ/YRARBIL/:TXE/BIL/ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test26");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("lLjava");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test27");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7H1sun.awt.CGraphicsEnvironment.sun.awt.CGraphicsEnvironment7", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test28");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("oneneneneneoracle corporationeneneneneoracle corporationenenenesun.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test29");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/vaENENENENEOr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test30");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "4.", 904);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test31");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("2 .80-b11");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("J/bil/r VirtuavaJs/sres");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("1.", strArray2, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 7 vs 12");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test32");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("h");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test33");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("444444444444444444444x86_644444444444444444444444", 61, "1.2");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444x86_6444444444444444444444441.21.21.21.2" + "'", str3.equals("444444444444444444444x86_6444444444444444444444441.21.21.21.2"));
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test34");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_1560210158", "####################################################################################################");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test35");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("...###############################################1.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...###############################################1.5" + "'", str1.equals("...###############################################1.5"));
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test36");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("J/bil/r VirtuavaJs/sres");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test37");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("G w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w ", "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "G w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w " + "'", str2.equals("G w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w                                           /USPS/SSE/UP/DSSMPE/S/DPPS/S4J//ME/E_REDSSE.E_95217_156eNENENENEOG w  E p  G w  E p  G w  E p  G w "));
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test38");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("5555", "srodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5555" + "'", str2.equals("5555"));
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test39");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java(TM)4SE4Runtime4Environment", (int) ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aJava(TM)4SE4Runtime4Environment" + "'", str3.equals("aJava(TM)4SE4Runtime4Environment"));
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test40");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("###################################################################################################################", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test41");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Chine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavaj");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test42");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "h", (java.lang.CharSequence) "class [ljava.lang.string;class [ljava.lang.string;######################################################################################################################################################", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test43");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Java Virtual Machine SpecificationJava Virtual MaENJava Virtual Machine SpecificationJava Virtual Ma", "####################1.7.0_80-b15####################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine SpecificationJava Virtual MaENJava Virtual Machine SpecificationJava Virtual Ma" + "'", str2.equals("Java Virtual Machine SpecificationJava Virtual MaENJava Virtual Machine SpecificationJava Virtual Ma"));
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test44");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("java(TM...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java(TM...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test45");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "aaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test46");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("corporationeneneneneoracle corporationeneneneneoracle corporationenenenesun.lwawt.macosx.cprinterjob", "", (int) (byte) 0, 22);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "acle corporationeneneneneoracle corporationenenenesun.lwawt.macosx.cprinterjob" + "'", str4.equals("acle corporationeneneneneoracle corporationenenenesun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test47");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("h", "tionachine Sp24.80-b11tionachine Sp", 0, (int) (byte) 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "tionachine Sp24.80-b11tionachine Sp" + "'", str4.equals("tionachine Sp24.80-b11tionachine Sp"));
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test48");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test49");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " VirtuavaJ", "tionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine specifical ma virtuavajhtionachine speci");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test50");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ENENEENENE", (int) '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaENENEENENEaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaENENEENENEaaaaaaaaaaaaa"));
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test51");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JV", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JV" + "'", str2.equals("LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JV"));
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test52");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "", (int) (short) 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test53");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 1, 100L, (long) 3);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test54");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test55");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 10, (short) 5);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test56");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "ENENEENENE");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LW...", strArray2, strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sun.lwawt.macosx.LW..." + "'", str6.equals("sun.lwawt.macosx.LW..."));
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test57");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "      Java HotSpot(TM) 64-Bit Server VM                                                                                  java(TM...", (java.lang.CharSequence) "eneneneneoracle corporationeneneneneoracle corporationeneneneneoracle corporationeneneneneoracle corporationenenenesun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test58");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", ".#1ne");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str2.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test59");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("MV revreS tiB-46 )MT(topStoH ava", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test60");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test61");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("j/BIL/R vIRTUAVAjS/SRES                         ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j/BIL/R vIRTUAVAjS/SRES                         " + "'", str2.equals("j/BIL/R vIRTUAVAjS/SRES                         "));
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test62");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("tionachine Specifica/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tionachine Specifica/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("tionachine Specifica/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test63");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("tionachine Specifical Ma VirtuavaJJava Virtual Machine SpecificationJava Virtual MaENJava Virtual Machine SpecificationJava Virtual Ma");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test64");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                   r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                   r/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/a/v" + "'", str2.equals("                                                   r/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/a/v"));
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test65");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                        aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0                                                        ", "SOPHIE/lIBRARY/jAVA/eX");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test66");
        short[] shortArray4 = new short[] { (byte) 0, (byte) 100, (byte) -1, (short) 0 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
    }
}

