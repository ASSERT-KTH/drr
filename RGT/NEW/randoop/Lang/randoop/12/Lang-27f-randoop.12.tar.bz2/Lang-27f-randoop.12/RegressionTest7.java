import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        int[] intArray0 = new int[] {};
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java HotSpot(TM) 64-Bit Server VM", "aaaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "avattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "eeAVA PLATFORM API SPECIFICATIONee");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaTTP://J.ORCE.COM/aaaaaa", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server V", "httpTac OSlIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/://TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/javaTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/.TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/oracleTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/.TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/comTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM//");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server V" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server V"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "Java Plhi!", (int) '4');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("jJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!aHJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!SJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!(TM)a64-BJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!taServeraVM", "jAVA pLHI!aaaaaaaa", 184);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TMjAVA pLHI!aaaaaaaaMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!taServeraVM" + "'", str3.equals("jJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TMjAVA pLHI!aaaaaaaaMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!taServeraVM"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "u", 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 5L, (float) 37L, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        float[] floatArray4 = new float[] { 'a', 35L, (byte) 100, 1.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("jAVA hOTsPOT(tm) 64-bIT sERVER vm", "Httpen://enjavaen.enoracleen.encomen/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("...FICATn.n lnwfarm .ecificnwian");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...FICATn.n lnwfarm .ecificnwian" + "'", str1.equals("...FICATn.n lnwfarm .ecificnwian"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sU...", "", 46);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU..." + "'", str3.equals("sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU..."));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION", "u");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION" + "'", str2.equals("JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(3L, (long) 32, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("avalatformpecification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"avalatformpecification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("ine specificationhie/documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", "1.7.0_80                                                                                         ", "", 24);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ine specificationhie/documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str4.equals("ine specificationhie/documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        int[] intArray2 = new int[] { 1, 10 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("jAVApLHI!", "avaava latform pecificationlatformava latform pecificationpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 10L, 133.0d, (double) 138L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 138.0d + "'", double3 == 138.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("jV pLTFORM api sPECIFICTION", 94);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTION" + "'", str2.equals("jV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTION"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("c OS XaM", "noitaroproC elcarO");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("          ", (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("http://java.oracle.com/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "httpTac OSlIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/://TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/javaTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/.TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/oracleTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/.TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/comTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM//", (java.lang.CharSequence) "racle Corporation                                                                                  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1812 + "'", int2 == 1812);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/users/sophie", "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("java virtual machine specificationhie/documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Mac OS XMac OS XMac 2.80-b11JMac OS XMac OS XMac O", 34);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("saalajforaaaiajecificajionibiasaalajforaaaiajecificajion/asaalajforaaaiajecificajionjaasaalajforaaaiajecificajionvasaalajforaaaiajecificajionaasaalajforaaaiajecificajionjeasaalajforaaaiajecificajionaasaalajforaaaiajecificajionrasaalajforaaaiajecificajionun/umaasaalajforaaaiajecificajionaasaalajforaaaiajecificajioneasaalajforaaaiajecificajionnbucynman");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SAALAJFORAAAIAJECIFICAJIONIBIASAALAJFORAAAIAJECIFICAJION/ASAALAJFORAAAIAJECIFICAJIONJAASAALAJFORAAAIAJECIFICAJIONVASAALAJFORAAAIAJECIFICAJIONAASAALAJFORAAAIAJECIFICAJIONJEASAALAJFORAAAIAJECIFICAJIONAASAALAJFORAAAIAJECIFICAJIONRASAALAJFORAAAIAJECIFICAJIONUN/UMAASAALAJFORAAAIAJECIFICAJIONAASAALAJFORAAAIAJECIFICAJIONEASAALAJFORAAAIAJECIFICAJIONNBUCYNMAN" + "'", str1.equals("SAALAJFORAAAIAJECIFICAJIONIBIASAALAJFORAAAIAJECIFICAJION/ASAALAJFORAAAIAJECIFICAJIONJAASAALAJFORAAAIAJECIFICAJIONVASAALAJFORAAAIAJECIFICAJIONAASAALAJFORAAAIAJECIFICAJIONJEASAALAJFORAAAIAJECIFICAJIONAASAALAJFORAAAIAJECIFICAJIONRASAALAJFORAAAIAJECIFICAJIONUN/UMAASAALAJFORAAAIAJECIFICAJIONAASAALAJFORAAAIAJECIFICAJIONEASAALAJFORAAAIAJECIFICAJIONNBUCYNMAN"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("vneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihl", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("SERSSOPHIEOCMENTSEFECTSJTMPRNRANOOPPL9912156022819TARGETCLASSESSERSSOPHIEOCMENTSEFECTSJFRAMEWORKLIBTESTGENERATIONGENERATIONRANOOPCRRENTJAR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SERSSOPHIEOCMENTSEFECTSJTMPRNRANOOPPL9912156022819TARGETCLASSESSERSSOPHIEOCMENTSEFECTSJFRAMEWORKLIBTESTGENERATIONGENERATIONRANOOPCRRENTJAR" + "'", str1.equals("SERSSOPHIEOCMENTSEFECTSJTMPRNRANOOPPL9912156022819TARGETCLASSESSERSSOPHIEOCMENTSEFECTSJFRAMEWORKLIBTESTGENERATIONGENERATIONRANOOPCRRENTJAR"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Virtual Machine Specificationhie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("JavajAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   PlatformjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   APIjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   Specification", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavajAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   PlatformjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   APIjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   Specification" + "'", str3.equals("JavajAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   PlatformjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   APIjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   Specification"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, " DEXIMn.n lnwfarm .ecificnwianO");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ttp:/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("JAVAJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   PLATFORMJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   APIJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVAJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   PLATFORMJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   APIJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   SPECIFICATION" + "'", str1.equals("JAVAJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   PLATFORMJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   APIJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   SPECIFICATION"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 1266, (double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("sun.lwa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwa" + "'", str1.equals("sun.lwa"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "sU...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SU..." + "'", str1.equals("SU..."));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("J### H##S###(TM) 64-B#t Server VM", "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/9418220651_2199_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("E", "JavaPlatformAPISpecification", "          ECIFICATIONSEAVA PLATFORM API SPE                    ECIFICATIONSEAVA PLATFORM API SPEC");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "E" + "'", str3.equals("E"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("UUSUUSUUSUUSUUSUUSUU1.7.0_80-b15", "4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UUSUUSUUSUUSUUSUUSUU1.7.0_80-b15" + "'", str2.equals("UUSUUSUUSUUSUUSUUSUU1.7.0_80-b15"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.7.0_80                                                                                         ", "JAVAJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   PLATFORMJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   APIJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/t/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav", "ication");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("V", "", "SERSSOPHIEOCMENTSEFECTSJTMPRNRANOOPPL9912156022819TARGETCLASSESSERSSOPHIEOCMENTSEFECTSJFRAMEWORKLIBTESTGENERATIONGENERATIONRANOOPCRRENTJAR");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "V" + "'", str3.equals("V"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("ac OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("vneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP", 12, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "vneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP" + "'", str3.equals("vneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ttp://j.orce.com/", 21, "MIXED");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MIXEttp://j.orce.com/" + "'", str3.equals("MIXEttp://j.orce.com/"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Plhi!aaaaaenJava Plhi!aaaaa", "jAVAOTsPOT(tm)64-bITsERVERvm", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/" + "'", str1.equals("HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "MACOSX.CPRINTERJO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_9912_1560228149/ta/Users/sophie/Documents/defects4j/tmp/run_r" + "'", str2.equals("randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_9912_1560228149/ta/Users/sophie/Documents/defects4j/tmp/run_r"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/", "jAVAApLATFORMAapiAsPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) " PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENV", (java.lang.CharSequence) "Java Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 993 + "'", int2 == 993);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!US");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("/usmrs/sophim/docummats/dmfmcts4j/tmp/rua_raadoop.pl_9912_1560228149/targmt/classms:/usmrs/sophim/docummats/dmfmcts4j/frammwork/lib/tmst_gmamratioa/gmamratioa/raadoop-currmat.jar", (java.lang.Object[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#', 3, 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(439.0f, (float) 993, (float) 5L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("J HS(TM) 64-Bt Server VM", "E");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("eeAVA PLATFORM API SPECIFICATIONeeeeAVAjAVA pLHI!aaaaaaaaeeAVA PLATFORM API SPECIFICATIONeeeeAVA ", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "eeAVA PLATFORM API SPECIFICATIONeeeeAVAjAVA pLHI!aaaaaaaaeeAVA PLATFORM API SPECIFICATIONeeeeAVA " + "'", str3.equals("eeAVA PLATFORM API SPECIFICATIONeeeeAVAjAVA pLHI!aaaaaaaaeeAVA PLATFORM API SPECIFICATIONeeeeAVA "));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("AVAAVA LATFORM PECIFICATIONLATFORMAVA LATFORM PECIFICATIONPECIFICATION", "jV pLTFORM api sPECIFICTION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AVAAVA LATFORM PECIFICATIONLATFORMAVA LATFORM PECIFICATIONPECIFICATION" + "'", str2.equals("AVAAVA LATFORM PECIFICATIONLATFORMAVA LATFORM PECIFICATIONPECIFICATION"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification", "jJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TMjAVA pLHI!aaaaaaaaMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!taServeraVM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sophisophisophisophisophisophisophisophisophisophi", "DEXIMn.n lnwfarm .ecificnwian", 99);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophisophisophisophisophisophisophisophisophisophi" + "'", str3.equals("sophisophisophisophisophisophisophisophisophisophi"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("saalajforaaaiajecificajionibiasaalajforaaaiajecificajion/asaalajforaaaiajecificajionjaasaaSUN.LWAWT.MACOSX.CPRINTERJOionaasaalajforaaaiajecificajionjeasaalajforaaaiajecificajionaasaalajforaaaiajecificajionrasaalajforaaaiajecificajionun/umaasaalajforaaaiajecificajionaasaalajforaaaiajecificajioneasaalajforaaaiajecificajionnbucynman", "TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        double[] doubleArray1 = new double[] { 4 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENV", "", "JJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VM PJava HotSpot(TM) 6 -Bit Server VMhi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENV" + "'", str3.equals("PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENV"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "jAVApLHI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!", '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "Java(TM) SE Runtime Environment");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "en", 0, 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', (int) (short) 100, 7);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!" + "'", str4.equals("JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Aaaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa", "JAVA pLHI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "jAVA pLHI!");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Mac OS XMac OS XMac 2.80-b11JMac OS XMac OS XMac O", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS XMac OS XMac 2.80-b11JMac OS XMac OS XMac O" + "'", str2.equals("Mac OS XMac OS XMac 2.80-b11JMac OS XMac OS XMac O"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("SERSSOPHIEOCMENTSEFECTSJTMPRNRANOOPPL9912156022819TARGETCLASSESSERSSOPHIEOCMENTSEFECTSJFRAMEWORKLIBTESTGENERATIONGENERATIONRANOOPCRRENTJAR", "us");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SERSSOPHIEOCMENTSEFECTSJTMPRNRANOOPPL9912156022819TARGETCLASSESSERSSOPHIEOCMENTSEFECTSJFRAMEWORKLIBTESTGENERATIONGENERATIONRANOOPCRRENTJAR" + "'", str2.equals("SERSSOPHIEOCMENTSEFECTSJTMPRNRANOOPPL9912156022819TARGETCLASSESSERSSOPHIEOCMENTSEFECTSJFRAMEWORKLIBTESTGENERATIONGENERATIONRANOOPCRRENTJAR"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("JJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VM PJAVA HOTSPOT(TM) 64-BIT SERVER VMHI!", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VM PJAVA HOTSPOT(TM) 64-BIT SERVER VMHI!" + "'", str2.equals("JJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VM PJAVA HOTSPOT(TM) 64-BIT SERVER VMHI!"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/uSER P...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("racle Corporation                                                                                  ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r" + "'", str2.equals("r"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", 184);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 184 + "'", int2 == 184);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java4Platform4API4S", 133, 17);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...Platform4API4S" + "'", str3.equals("...Platform4API4S"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', 257, 3);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "", (-1), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("J### H##S###(TM) 64-B#t Server VM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("OJRETNIRPC.XSOCAM.TWAWL.NUS", "jJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!aHJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!SJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!(TM)a64-BJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!taServeraVM", "", 153);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "OJRETNIRPC.XSOCAM.TWAWL.NUS" + "'", str4.equals("OJRETNIRPC.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("JAVA PLATFORM API SPECIFICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION)AVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONSEAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONRAVA PLATFORM API SPECIFICATIONuntimeAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONEAVA PLATFORM API SPECIFICATIONnvironment", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION)AVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONSEAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONRAVA PLATFORM API SPECIFICATIONuntimeAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONEAVA PLATFORM API SPECIFICATIONnvironment" + "'", str2.equals("ICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION)AVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONSEAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONRAVA PLATFORM API SPECIFICATIONuntimeAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONEAVA PLATFORM API SPECIFICATIONnvironment"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Java(TM) SE Runtime EnvironmentJavJ", "Jjava virtual machine specificationavajava virtual machine specification(java virtual machine specificationTMjava virtual machine specification)java virtual machine specification java virtual machine specificationSEjava virtual machine specification java virtual machine specificationRjava virtual machine specificationuntimejava virtual machine specification java virtual machine specificationEjava virtual machine specificationnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("jAVAOTsPOT(tm)64-bITsERVERvm", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVAOTsPOT(tm)64-bITsERVERvm" + "'", str2.equals("jAVAOTsPOT(tm)64-bITsERVERvm"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("JAVA VIRTUAL MACHINE SPECIFICATIONHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATIONHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.J" + "'", str1.equals("JAVA VIRTUAL MACHINE SPECIFICATIONHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.J"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                                                                                                    DEXIM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"         \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp(" PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLH...", "/usmrs/sophim/docummats/dmfmcts4j/tmp/rua_raadoop.pl_9912_1560228149/targmt/classms:/usmrs/sophim/docummats/dmfmcts4j/frammwork/lib/tmst_gmamratioa/gmamratioa/raadoop-currmat.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLH..." + "'", str2.equals(" PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLH..."));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("Jttp://j.orvttp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hien", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1266, (double) 99, (double) 4);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) " HOTSPOT(TM) 64-BIT SERVER V...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(" ", ":Java4Platform4API4Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("avaava latform pecificationlatformava latform pecificationpecification", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "avaava latform pecificationlatformava latform pecificationpecification" + "'", str2.equals("avaava latform pecificationlatformava latform pecificationpecification"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hien");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hien\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/9418220651_2199_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/9418220651_2199_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("Raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/9418220651_2199_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("jJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!aHJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!SJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!(TM)a64-BJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!taServeraVM", "", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(1266, (int) (byte) 1, 257);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1266 + "'", int3 == 1266);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        byte[] byteArray3 = new byte[] { (byte) 100, (byte) 10, (byte) 10 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 10 + "'", byte4 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "Java Plhi!aaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 100);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("\n", strArray3, strArray7);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("http://java.oracle.com/");
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hien", strArray3, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 8");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\n" + "'", str8.equals("\n"));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("24.80-b11Java Plhi!aaaaaaaaaaaaaaaaaaaaaaaaa", "MIXED ", (int) (byte) 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "MIXED aaaaaaaaaaaa" + "'", str4.equals("MIXED aaaaaaaaaaaa"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/AsAaLAJFORaaAIaJECIFICAJIONibiAsAaLAJFORaaAIaJECIFICAJION/AsAaLAJFORaaAIaJECIFICAJIONJaACGraphicsEn", 94, 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                          ", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                          " + "'", str2.equals("                                                                                          "));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "java virtual machine specifica");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(" PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENV");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 257, (long) 105, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 257L + "'", long3 == 257L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation", strArray3, strArray5);
        java.lang.Class<?> wildcardClass7 = strArray3.getClass();
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny("/nemocne.neelcarone.neavajne//:nepttH", strArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "C elcarO######################################");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Oracle Corporation" + "'", str6.equals("Oracle Corporation"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "JavaC elcarO######################################PlatformC elcarO######################################APIC elcarO######################################Specification" + "'", str10.equals("JavaC elcarO######################################PlatformC elcarO######################################APIC elcarO######################################Specification"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("###################################", (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaCGraphicsEnvaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Virtual Machine Specificatio", "Java Virtual Machine Specificationhie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 208);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("ttp://j.or", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("JavajAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   PlatformjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   APIjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   Specification", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", 18, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Se..." + "'", str3.equals("...VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Se..."));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Sun.awt.CGraphicsEnvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION", 170, "JJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VM PJAVA HOTSPOT(TM) 64-BIT SERVER VMHI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION" + "'", str3.equals("JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!US" + "'", str1.equals("USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!US"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("n.n lnwfarm .ecificnwian", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 10 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 10 + "'", byte11 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 10 + "'", byte12 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("V", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "dk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("dk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "SUN.AWT.CGRAPHICSENVIRONMENT", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("JAVAJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   PLATFORMJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   APIJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "", 17);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny("/Users/sophie", strArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str9.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ac OS ", "                                                                                                                                                    DEXIM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", "USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!US");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "          ECIFICATIONSEAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONRAVA PLATFORM API SPECIFICATIONuntimeAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONEAVA PLATFORM API SPECIFICATIONnvironment", 67, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "asses:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "Java Virtual Machine Specificationhie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", 35, 208);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Javaj:ecif");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Javaj:ecif\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("P", 52, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("jAVApLHI!", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCGraphicsEnvaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "OJRETNIRPC.XSOCAM.TWAWL.NUS");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("jV pLTFORM api sPECIFICTION", "...rs/_v/6v597zmn4_v31cq2n2x1n4...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jV pLTFORM api sPECIFICTION" + "'", str2.equals("jV pLTFORM api sPECIFICTION"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("terJob", "###################################", 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("          ", "JavaaPl...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("racle Corporation                                                                                  ", "/uSER P...", 1);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "Java Plhi!aaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 100);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("\n", strArray9, strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.concatWith("Oracle Corporation", (java.lang.Object[]) strArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray9);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("(/j.oruntimettp://j.or ttp://j.orEttp:", strArray5, strArray9);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny("ttp://j.or", strArray9);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "\n" + "'", str14.equals("\n"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "(/j.oruntimettp://j.or ttp://j.orEttp:" + "'", str17.equals("(/j.oruntimettp://j.or ttp://j.orEttp:"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("noitaroproC elcarOaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproC elcarOaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("noitaroproC elcarOaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("OJRETNIRPC.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OJRETNIRPC.XSOCAM.TWAWL.NUS" + "'", str1.equals("OJRETNIRPC.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("vneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP ", 993);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "evneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP " + "'", str2.equals("evneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP "));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("java virtual machine specificationhie/documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", "ac OS", 105);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("J/FRAMMWORK/LIB/TMST_GMAMRATIOA/GMAMRATIOA/RAADOOP-CURRMAT.JAR49/TARGMT/CLASSMS:/uSMRS/SOPHIM/dOCUMMATS/DMFMCTS4J/TMP/RUA_RAADOOP.PL_9912_156022814/uSMRS/SOPHIM/dOCUMMATS/DMFMCTS", "JavaaPlatformaAPIaSpecification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("JAVAJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   PLATFORMJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   APIJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   SPECIFICATION", "noitaroproC elcarO##################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("n.n lnwfarm .ecificnwian", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 18, 46);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "n.n lnwfarm .ecifi/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str4.equals("n.n lnwfarm .ecifi/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Aaaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa", 993, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("###################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"########\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("mixed mode", "ine specificationhie/documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sun.lwawt.macosx.CPrinterJo", (int) '#', 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("1.7.0_80-b15", 3, 184);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen", (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("JJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VM PJava HotSpot(TM) 6 -Bit Server VMhi!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "time Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(439.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("aaa/uSER P...aaaa", "ication                              ", "/users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaa/uSER P...aaaa" + "'", str3.equals("aaa/uSER P...aaaa"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("170_80                                                                                         ", 35, 34);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("httpen://enjavaen.enoracleen.encomen/", "JavaPlatformAPISpecification");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "h://j../" + "'", str3.equals("h://j../"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("c OS Xa", " DEXIMn.n lnwfarm .ecificnwian", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sophi", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("SUN.AWT.CGRAPHICSENVIRONMENT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp(" hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vm pjAVA hOTsPOT(tm) 64-bIT sERVER vmHI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vm pjAVA hOTsPOT(tm) 64-bIT sERVER vmHI!" + "'", str1.equals(" hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vm pjAVA hOTsPOT(tm) 64-bIT sERVER vmHI!"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                                                                  java virtual machine specification", "", 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("JavaPlatformAPISpecification");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', 138, 439);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 138");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/9418220651_2199_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(":24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80", "Java Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API Specification", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Java1.7.0_80                                                                                         Platform1.7.0_80                                                                                         API1.7.0_80                                                                                         Specification", (java.lang.CharSequence) "/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk.../Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk.../Libr4ry/J4v4/J4v4Virtu4lM4chines/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 'a', (double) 35, (double) 12.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.0d + "'", double3 == 12.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("x86_64", "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("javaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecifOJRETNIRPC.XSOCAM.TWAWL.NUS", "jAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   ", "...Platform4API4S", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "javaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecifOJRETNIRPC.XSOCAM.TWAWL.NUS" + "'", str4.equals("javaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecifOJRETNIRPC.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 1, (long) 18, (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 18L + "'", long3 == 18L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "Jttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(" Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenv", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "v" + "'", str2.equals("v"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jreJava(TM) SE Runtime EnvironmentJavJ/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jreJava(TM) SE Runtime EnvironmentJavJ/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre", ":Java4Platform4API4Specification", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(52);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        char[] charArray10 = new char[] { 'a', 'a', 'a', ' ', 'a', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJO", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJO", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ac os", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mettp://j.or ttp://j.orEttp:", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification", "JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("1", "4e44");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("aaaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa", "sun.lwawt.macosx.CPrinterJo");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("jAVA hOTsPOT(tm) 64-bIT sERVER vm", '#');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str3.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Javaj:ecif", "sun.awt.CGraphicsEnvi...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Javaj:ecif" + "'", str2.equals("Javaj:ecif"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "r", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.Object[] objArray1 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concatWith("Javaj:ecif", objArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java Virtual Machine Specification" + "'", str1.equals("java Virtual Machine Specification"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase(" ", "Folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API Specification", 0, " DEXIMn.n lnwfarm .ecificnwian");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API Specification" + "'", str3.equals("Java Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API Specification"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/uSER P...", (java.lang.CharSequence) "/AsAaLAJFORaaAIaJECIFICAJIONibiAsAaLAJFORaaAIaJECIFICAJION/AsAaLAJFORaaAIaJECIFICAJIONJaAsAaLAJFORaaAIaJECIFICAJIONvAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONJEAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONRAsAaLAJFORaaAIaJECIFICAJIONun/umaAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONEAsAaLAJFORaaAIaJECIFICAJIONnbucynman/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "j/frammwork/lib/tmst_gmamratioa/gmamratioa/raadoop-currmat.jar49/targmt/classms:/Usmrs/sophim/Docummats/dmfmcts4j/tmp/rua_raadoop.pl_9912_156022814/Usmrs/sophim/Docummats/dmfmcts", (java.lang.CharSequence) "NoitaroproC51.0elcarO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 165 + "'", int2 == 165);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "   UTF-   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", "                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                                                                                                                            Jmixed vmixed Pmixed hmixed !", " hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vm pjAVA hOTsPOT(tm) 64-bIT sERVER vmHI!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("jAVApLHI!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVApLHI!" + "'", str2.equals("jAVApLHI!"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("JAVA PLATFORM API SPECIFICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION)AVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONSEAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONRAVA PLATFORM API SPECIFICATIONuntimeAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONEAVA PLATFORM API SPECIFICATIONnvironment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("JAVAJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   PLATFORMJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   APIJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   SPECIFICATION", "mixed mode", "sUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVAJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   PLATFORMJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   APIJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   SPECIFICATION" + "'", str3.equals("JAVAJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   PLATFORMJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   APIJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   SPECIFICATION"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("ication                              ", 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.String[] strArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny("/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!US", 18, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!US" + "'", str3.equals("USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!US"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        double[] doubleArray4 = new double[] { 37L, 7, 1266.0f, 24 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 7.0d + "'", double5 == 7.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("(", 37, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444(" + "'", str3.equals("444444444444444444444444444444444444("));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("vneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP ", "jAVAOTsPOT(tm)64-bITsERVERvm", 12);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen", (java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "neJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nettp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmenneJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nettp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmenneJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nettp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmenneJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nettp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmenneJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nettp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmenneJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP " + "'", str5.equals("neJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nettp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmenneJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nettp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmenneJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nettp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmenneJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nettp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmenneJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nettp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmenneJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP "));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen", "/users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/" + "'", str2.equals("HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 24L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("n.n lnwfarm .ecifi/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"n.n lnwfarm .ecifi/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaa/uSER P...aaaa", 127, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444aaa/uSER P...aaaa4444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444aaa/uSER P...aaaa4444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("e");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!US", "170_80                                                                                         ", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("JAVAJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   PLATFORMJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   APIJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   SPECIFICATION");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        short[] shortArray1 = new short[] { (short) -1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.Class<?> wildcardClass7 = shortArray1.getClass();
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("tt      ://j/L      brary/Java/JavaV      rtualMac            n            /jdk1.7.0_80.jdk/C      nt      nt      /H      m      /jr      /l      b/      nd      r            d.      r/L      brary/Java/JavaV      rtualMac            n            /jdk1.7.0_80.jdk/C      nt      nt      /H      m      /jr      /l      b/      nd      r            dc/L      brary/Java/JavaV      rtualMac            n            /jdk1.7.0_80.jdk/C      nt      nt      /H      m      /jr      /l      b/      nd      r            d      .c      m/", "USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!US", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("j/frammwork/lib/tmst_gmamratioa/gmamratioa/raadoop-currmat.jar49/targmt/classms:/Usmrs/sophim/Docummats/dmfmcts4j/tmp/rua_raadoop.pl_9912_156022814/Usmrs/sophim/Docummats/dmfmcts", (int) (byte) 10, 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("j#v#(tm)seruntimeenvironmentj#vj", 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("java Virtual Machine Specification", "TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!", "MIXED aaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!" + "'", str2.equals("JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/nemocne.neelcarone.neavajne//:nepttH", "Mac OS X", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80", "         Sun.awt.CGraphicsEnvironment", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java Virtual Machine Specification", "mettp://j.orttp://j.orEttp:acOS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("VMhi! Server 64-Bit HotSpot(TM) PJava VM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM)", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VMhi! Server 64-Bit HotSpot(TM) PJava VM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM)" + "'", str3.equals("VMhi! Server 64-Bit HotSpot(TM) PJava VM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM)"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihc4Ml4utriV4v4J/4v4J/yr4rbiL/" + "'", str1.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihc4Ml4utriV4v4J/4v4J/yr4rbiL/"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Oracle Corporation", 0, "racle Corporation                                                                                  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("...Platform4API4S");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("x86_64", 1812);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 10, 3L, (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                             racle Corporation                                                                                  ", (float) 17);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 17.0f + "'", float2 == 17.0f);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/t/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("JAVA PLATFORM API SPECIFICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION)AVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONSEAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONRAVA PLATFORM API SPECIFICATIONuntimeAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONEAVA PLATFORM API SPECIFICATIONnvironment", 127);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA PLATFORM API SPECIFICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION" + "'", str2.equals("JAVA PLATFORM API SPECIFICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sun.awt.CGraphicsEnvi...", "/J.ORAVATTP://J.OR(TTP://J.ORtmTTP://J.OR)TTP://J.ORTTP://J.ORseTTP://J.ORTTP://J.ORrTTP://J.ORUNTIMETTP://J.ORTTP://J.OReTTP://J.ORNVIRONMEN");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvi..." + "'", str2.equals("sun.awt.CGraphicsEnvi..."));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("JavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification", 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Java Virtual Machine Specificationhie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 46);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73 + "'", int2 == 73);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("Mac OS XMac OS XMac OS XMac OJava4Platform4API4SpecificationMac OS XMac OS XMac OS XMac OS", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 17L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sophi", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATIONHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(" DEXIMn.n lnwfarm .ecificnwian");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DEXIMn.n lnwfarm .ecificnwian" + "'", str1.equals("DEXIMn.n lnwfarm .ecificnwian"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) 184);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 184L + "'", long2 == 184L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("macosx.cprinterjo", "                                   ttp://j.orce.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "macosx.cprinterjo" + "'", str2.equals("macosx.cprinterjo"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", 98, 1266);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".051.051.051.051.051.051.051.0" + "'", str3.equals(".051.051.051.051.051.051.051.0"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 22);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!" + "'", str2.equals("JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/9418220", "444444444444444444444444444444444\nAVA PLATFORM API SPECIF444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "24.80-b11J");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "Mac OS XMac OS XMac 2.80-b11JMac OS XMac OS XMac O");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("httpTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/://TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/javaTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/.TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/oracleTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/.TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/comTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM//", "sophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophi" + "'", str2.equals("sophi"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sUN.AWT.CGRAPHICSENVIRONMEN", "###################################################################Java Plhi!aaaaaenJava Plhi!aaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("JJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi! HJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!SJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!(TM) 64-BJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!t Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("jJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!aHJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!SJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!(TM)a64-BJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!taServeraVM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"jJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!aHJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!SJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!JJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!(TM)a64-BJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!taServeraVM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1L, 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                                                                                                                                    DEXIM", "                                                                                                             racle Corporation                                                                                  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("java(tm)seruntimeenvironmentjavj", 4.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("jV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTIONjV pLTFORM api sPECIFICTION");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("ttp://j.orSEttp://j.or");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ttp://j.orSEttp://j.or" + "'", str1.equals("ttp://j.orSEttp://j.or"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("v");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"v\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 184, "eeAVA PLATFORM API SPECIFICATIONeeeeAVAjAVA pLHI!aaaaaaaaeeAVA PLATFORM API SPECIFICATIONeeeeAVA ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "eeAVA PLATFORM API SPECIFICATIONeeeeAVAjAVA pLHI!aaaaaaaaeeAVA PLATFORM API SPECIFICATIONeeeeeAVA PLATFORM API SPECIFICATIONeeeeAVAjAVA pLHI!aaaaaaaaeeAVA PLATFORM API SPECIFICATIONeee" + "'", str3.equals("eeAVA PLATFORM API SPECIFICATIONeeeeAVAjAVA pLHI!aaaaaaaaeeAVA PLATFORM API SPECIFICATIONeeeeeAVA PLATFORM API SPECIFICATIONeeeeAVAjAVA pLHI!aaaaaaaaeeAVA PLATFORM API SPECIFICATIONeee"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("J### H##S###(TM) 64-B#t Server VM", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "JJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi! HJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!SJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!(TM) 64-BJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!t Server VM");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("          ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "PLHI!US...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 31, "CGraphicsEn");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CGraphicsEnCGraphicsEnCGraphics" + "'", str3.equals("CGraphicsEnCGraphicsEnCGraphics"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen", (int) (short) 100, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen" + "'", str3.equals("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("jJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!", "ttp://j.orce.com/", (int) (byte) 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny("Mac OS X", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "jJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!" + "'", str6.equals("jJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("ttp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/", 7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.lwawt.macosx.CPrinterJob", "", "ttp://j.orce.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("OOOOOOOOOO1.7OOOOOOOOOOO                                                                         ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: OOOOOOOOOO1.7OOOOOOOOOOO                                                                          is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("macosx.cprinterjo", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sAaLAJFORaaAIaJECIFICAJIONibiAsAaLAJFORaaAIaJECIFICAJION/AsAaLAJFORaaAIaJECIFICAJIONJaAsAaLAJFORaaAIaJECIFICAJIONvAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONJEAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONRAsAaLAJFORaaAIaJECIFICAJIONun/umaAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONEAsAaLAJFORaaAIaJECIFICAJIONnbucynman", (int) (short) 10, "r");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sAaLAJFORaaAIaJECIFICAJIONibiAsAaLAJFORaaAIaJECIFICAJION/AsAaLAJFORaaAIaJECIFICAJIONJaAsAaLAJFORaaAIaJECIFICAJIONvAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONJEAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONRAsAaLAJFORaaAIaJECIFICAJIONun/umaAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONEAsAaLAJFORaaAIaJECIFICAJIONnbucynman" + "'", str3.equals("sAaLAJFORaaAIaJECIFICAJIONibiAsAaLAJFORaaAIaJECIFICAJION/AsAaLAJFORaaAIaJECIFICAJIONJaAsAaLAJFORaaAIaJECIFICAJIONvAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONJEAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONRAsAaLAJFORaaAIaJECIFICAJIONun/umaAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONEAsAaLAJFORaaAIaJECIFICAJIONnbucynman"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("mettp://j.or ttp://j.orEttp:ac OS");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mettp:\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("avalatformpecification", 133);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 133 + "'", int2 == 133);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("ication", "                                 Java Virtual Machine Specification                                 ", 257, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                 Java Virtual Machine Specification                                 " + "'", str4.equals("                                 Java Virtual Machine Specification                                 "));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("ac OS", "                                                                                                    ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 0, "JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification" + "'", str3.equals("                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaa/uSER P...aaaa", 153, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                        aaa/uSER P...aaaa" + "'", str3.equals("                                                                                                                                        aaa/uSER P...aaaa"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("r", "eeAVA PLATFORM API SPECIFICATIONeeeeAVAjAVA pLHI!aaaaaaaaeeAVA PLATFORM API SPECIFICATIONeeeeAVA ", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 73);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("macosx.cprinterjo", "      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      " + "'", str2.equals("      "));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Jv(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Jv(TM) SE Runtime Environment" + "'", str1.equals("Jv(TM) SE Runtime Environment"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Platform API Specification", "/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk.../Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk.../Libr4ry/J4v4/J4v4Virtu4lM4chines/", "racle Corporation                                                                                  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "para P a foem API Sp  cfc a co " + "'", str3.equals("para P a foem API Sp  cfc a co "));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "Java Plhi!aaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 100);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("\n", strArray3, strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concatWith("Oracle Corporation", (java.lang.Object[]) strArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\n" + "'", str8.equals("\n"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("JavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification" + "'", str1.equals("JavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(31, 31, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ttp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmentavattp://j.or" + "'", str2.equals("ttp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmentavattp://j.or"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("us", "/NEMOCNE.NEELCARONE.NEAVAJNE//:N");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "us" + "'", str2.equals("us"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJo", "");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Sun.awt.CGraphicsEnvironment", 16, (int) (short) -1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concatWith("c OS XaM", (java.lang.Object[]) strArray3);
        java.lang.Class<?> wildcardClass9 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "sun.lwawt.macosx.CPrinterJo" + "'", str8.equals("sun.lwawt.macosx.CPrinterJo"));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "rs/sophie/Library/Java/Extension");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "Jjava virtual machine specificationavajava virtual machine specification(java virtual machine specificationTMjava virtual machine specification)java virtual machine specification java virtual machine specificationSEjava virtual machine specification java virtual machine specificationRjava virtual machine specificationuntimejava virtual machine specification java virtual machine specificationEjava virtual machine specificationnvironment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "                                       java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk.../Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk.../Libr4ry/J4v4/J4v4Virtu4lM4chines/", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        int[] intArray2 = new int[] { 1, 10 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification", "CGraphicsEn");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("...FICATn.n lnwfarm .ecificnwian", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Plhi!aaaaaenJava Plhi!aaaaa", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("vaAVA PLATFORM API SPECIFICATIONlatformAVA PLATFORM API SPECIFICATIONpecification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: vaAVA PLATFORM API SPECIFICATIONlatformAVA PLATFORM API SPECIFICATIONpecification is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("JAVA PLATFORM API SPECIFICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION", " Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA PLATFORM API SPECIFICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION" + "'", str2.equals("JAVA PLATFORM API SPECIFICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION", (java.lang.CharSequence) "ICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION)AVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONSEAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONRAVA PLATFORM API SPECIFICATIONuntimeAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONEAVA PLATFORM API SPECIFICATIONnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Jv Pltform API Specifiction");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Jv Pltform API Specifiction" + "'", str1.equals("Jv Pltform API Specifiction"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.Object[] objArray1 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concatWith("httpen://enjavaen.enoracleen.encomen/", objArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) " Vu Mh ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION", "", "051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Java Virtual Machine Specificationhie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "\n", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("", "4444444444444444444444444444444444444444444444444444444aaa/uSER P...aaaa4444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sU...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sU..." + "'", str2.equals("sU..."));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                               java virtual machine specification", "java virtual machine specification##################################################################", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "////////////////////////////////////////////////////////////////vav/aoldevs/_v/6o59/zm9/ovo/vdon5" + "'", str3.equals("////////////////////////////////////////////////////////////////vav/aoldevs/_v/6o59/zm9/ovo/vdon5"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        short[] shortArray1 = new short[] { (short) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "Java Plhi!aaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 100);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("\n", strArray3, strArray7);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("(", "java virtual machine specification");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                ", strArray7, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\n" + "'", str8.equals("\n"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "                                " + "'", str12.equals("                                "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str13.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("O", "4444444444444444444444444444444444444444444444444444444aaa/uSER P...aaaa4444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/httpen://enjavaen.enoracleen.encomen/", "/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("JavaaPl...", "OJRETNIRPC.XSOCAM.TWAWL.NUS", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase(" hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vm pjAVA hOTsPOT(tm) 64-bIT sERVER vmHI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!" + "'", str1.equals(" HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "      " + "'", str1.equals("      "));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        short[] shortArray1 = new short[] { (short) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 34, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("1.7.0_80                                                                                         ", "neJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nettp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmenneJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nettp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmenneJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nettp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmenneJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nettp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmenneJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nettp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmenneJSU!ihlttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sun.awt.CGraphicsEnvi...", "E", 1, 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sEraphicsEnvi..." + "'", str4.equals("sEraphicsEnvi..."));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "aaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa", 208, 4);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("JAVA PLATFORM API SPECIFICATION", (int) '#', "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.JAVA PLATFORM API SPECIFICATION" + "'", str3.equals("sun.JAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149", " Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("SU...", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SU..." + "'", str2.equals("SU..."));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("TTP://J.ORAVATTP://J.OR(TTP://J.ORtmTTP://J.OR)TTP://J.ORTTP://J.ORseTTP://J.ORTTP://J.ORrTTP://J.ORUNTIMETTP://J.ORTTP://J.OReTTP://J.ORNVIRONMEN", "Folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TTP://J.ORAVATTP://J.OR(TTP://J.ORtmTTP://J.OR)TTP://J.ORTTP://J.ORseTTP://J.ORTTP://J.ORrTTP://J.ORUNTIMETTP://J.ORTTP://J.OReTTP://J.ORNVIRONMEN" + "'", str2.equals("TTP://J.ORAVATTP://J.OR(TTP://J.ORtmTTP://J.OR)TTP://J.ORTTP://J.ORseTTP://J.ORTTP://J.ORrTTP://J.ORUNTIMETTP://J.ORTTP://J.OReTTP://J.ORNVIRONMEN"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("sophie", 34.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.0d + "'", double2 == 34.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 12, (double) 17.0f, (double) 10L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 17.0d + "'", double3 == 17.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                   TTP://J.ORCE.COM/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaattp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "24.80-b11J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("...FICATIONPECIFICATION", "", 94);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 23 + "'", int3 == 23);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        char[] charArray6 = new char[] { '4', ' ' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "macosx.CPrinterJo", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Jttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 58 + "'", int10 == 58);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("aaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAA24.80-B11jAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAA24.80-B11jAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification", "eeAVA PLATFORM API SPECIFICATIONeeeeAVAjAVA pLHI!aaaaaaaaeeAVA PLATFORM API SPECIFICATIONeeeeeAVA PLATFORM API SPECIFICATIONeeeeAVAjAVA pLHI!aaaaaaaaeeAVA PLATFORM API SPECIFICATIONeee");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification444444444444444444444444444444444444444444444444444444444444444java4virtual4machine4specification"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("JavaaPl...", "10.14.3", 153);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Jttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.orttp://j.orSEttp://j.orttp://j.orRttp://j.oruntimettp://j.orttp://j.orEttp://j.ornvironmen", 5, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Jttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.orttp://j.orSEttp://j.orttp://j.orRttp://j.oruntimettp://j.orttp://j.orEttp://j.ornvironmen" + "'", str3.equals("Jttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.orttp://j.orSEttp://j.orttp://j.orRttp://j.oruntimettp://j.orttp://j.orEttp://j.ornvironmen"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment", "svarsfolierssvsv7zmnv3cqnxnfcgnsrs");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("51.0", strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "avalatformpecification");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment" + "'", str6.equals("(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(16, (int) (short) 1, 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 67 + "'", int3 == 67);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("aaaaaTTP://J.ORCE.COM/aaaaaa", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaTTP://J.ORCE.COM/aaaaaa" + "'", str2.equals("aaaaaTTP://J.ORCE.COM/aaaaaa"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444aaa/uSER P...aaaa4444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1L, (double) 24L, (double) 3L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Mac OS XMac OS XMac 2.80-b11JMac OS XMac OS XMac O", "                                   ttp://j.orce.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS XMac OS XMac 2.80-b11JMac OS XMac OS XMac O" + "'", str2.equals("Mac OS XMac OS XMac 2.80-b11JMac OS XMac OS XMac O"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("asses:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/usmrs/sophim/docummats/dmfmcts4j/tmp/rua_raadoop.pl_9912_1560228149/targmt/classms:/usmrs/sophim/docummats/dmfmcts4j/frammwork/lib/tmst_gmamratioa/gmamratioa/raadoop-currmat.jar", "MIXED ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "Java Plhi!aaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 100);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "");
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray8);
        java.lang.Class<?> wildcardClass10 = strArray8.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.concatWith("USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!US", (java.lang.Object[]) strArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.concatWith("jJJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TMjAVA pLHI!aaaaaaaaMJavaaHotSpot(TM)a64-BitaServeraVMaPJavaaHotSpot(TM)a64-BitaServeraVMhi!taServeraVM", (java.lang.Object[]) strArray8);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str11.equals("Java HotSpot(TM) 64-Bit Server VM"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str12.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("          ECIFICATIONSEAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONRAVA PLATFORM API SPECIFICATIONuntimeAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONEAVA PLATFORM API SPECIFICATIONnvironmen", 46);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java(TM) SE Runtime EnvironmentJavJ", "##########################################################################################################################################################################", 208);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("java virtual machine specification##################################################################", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "j#v# virtu#l m#chine specific#tion##################################################################" + "'", str3.equals("j#v# virtu#l m#chine specific#tion##################################################################"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("ttp://j.or", "/httpen://enjavaen.enoracleen.encomen/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOP...", "...FICATn.n lnwfarm .ecificnwian", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/9418220651_2199_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "/Usmrs/sophim/Docummats/dmfmcts4j/tmp/rua_raadoop.pl_9912_1560228149/targmt/classms:/Usmrs/sophim/Docummats/dmfmcts4j/frammwork/lib/tmst_gmamratioa/gmamratioa/raadoop-currmat.jar", " HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/9418220651_2199_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str3.equals("Raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/9418220651_2199_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 133);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("...dk/Contents/Home/jre", 178);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION" + "'", str2.equals("JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("(/j.oruntimettp://j.or ttp://j.orEttp:");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("JAVA PLATFORM API SPECIFICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("", "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihc4Ml4utriV4v4J/4v4J/yr4rbiL/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/nemocne.neelcarone.neavajne//:n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/nemocne.neelcarone.neavajne//:n" + "'", str1.equals("/nemocne.neelcarone.neavajne//:n"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("JJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi! HJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!SJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!(TM) 64-BJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!t Server VM", "mixed mode");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        char[] charArray10 = new char[] { 'a', 'a', 'a', ' ', 'a', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJO", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJO", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ac os", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "terJob", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "P");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("JavaaPlatformaAPIaSpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVAAPLATFORMAAPIASPECIFICATION" + "'", str1.equals("JAVAAPLATFORMAAPIASPECIFICATION"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("4e44", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Jttp://j.orvttp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149", "/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace(":Java4Platform4API4Specification", "ac os", "", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":Java4Platform4API4Specification" + "'", str4.equals(":Java4Platform4API4Specification"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"     \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("httpen://enjavaen.enoracleen.encomen/", "mettp://j.or ttp://j.orEttp:ac OS", "Jv Pltform API Specifiction", 4);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "httpen://enjavaen.enoracleen.encomen/" + "'", str4.equals("httpen://enjavaen.enoracleen.encomen/"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Jttp://j.orvttp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Jttp://j.orvttp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment" + "'", str1.equals("Jttp://j.orvttp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("j#v#(tm)seruntimeenvironmentj#vj", "Jttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("J4v4 Plhi!44444enJ4v4 Plhi!44444", 16, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "nJ4v4 Plhi!4444" + "'", str3.equals("nJ4v4 Plhi!4444"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("PLHI!US...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("ICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION)AVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONSEAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONRAVA PLATFORM API SPECIFICATIONuntimeAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONEAVA PLATFORM API SPECIFICATIONnvironment", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("mettp://j.or ttp://j.orEttp:", (long) 34);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34L + "'", long2 == 34L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                 Java Virtual Machine Specification                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                 Java Virtual Machine Specification                                " + "'", str1.equals("                                 Java Virtual Machine Specification                                "));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("TTP://J.ORCE.COM/", (int) (byte) 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TTP://J.ORCE.COM/" + "'", str3.equals("TTP://J.ORCE.COM/"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/LIBR4RY/J4V4/J4V4VIRTU4LM4CHINES/JDK1.7.0_80.JDK.../LIBR4RY/J4V4/J4V4VIRTU4LM4CHINES/JDK1.7.0_80.JDK.../LIBR4RY/J4V4/J4V4VIRTU4LM4CHINES/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /LIBR4RY/J4V4/J4V4VIRTU4LM4CHINES/JDK1.7.0_80.JDK.../LIBR4RY/J4V4/J4V4VIRTU4LM4CHINES/JDK1.7.0_80.JDK.../LIBR4RY/J4V4/J4V4VIRTU4LM4CHINES/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("noitaroproC elcarO");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("Hi!", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44x86_644e44", "java(tm)seruntimeenvironmentjavj");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("n.n lnwfarm .ecificnwian", "CGraphicsEnv");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("JAVA VIRTUAL MACHINE SPECIFICATIONHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("          ", 138, 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!US", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Plhi!USavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaUSJ" + "'", str2.equals("Plhi!USavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaUSJ"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("java virtual machine specifica", "/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jreJava(TM) SE Runtime EnvironmentJavJ/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jreJava(TM) SE Runtime EnvironmentJavJ/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", " HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("mettp://j.or ttp://j.orEttp:ac OS ", "Java Virtual Machine Specificationhie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Java1.7.0_80                                                                                         Platform1.7.0_80                                                                                         API1.7.0_80                                                                                         Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java1.7.0_80                                                                                         Platform1.7.0_80                                                                                         API1.7.0_80                                                                                         Specificatio" + "'", str1.equals("Java1.7.0_80                                                                                         Platform1.7.0_80                                                                                         API1.7.0_80                                                                                         Specificatio"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                             racle Corporation                                                                                  ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU" + "'", str1.equals("SU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU!ihlP avaJSU"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/AsAaLAJFORaaAIaJECIFICAJIONibiAsAaLAJFORaaAIaJECIFICAJION/AsAaLAJFORaaAIaJECIFICAJIONJaACGraphicsEn", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("ttp://j.orce.com/", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ava latform pecification", "Java Plhi!aaaaaaaaaaaaaaaaaaaaaaaaa", "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihc4Ml4utriV4v4J/4v4J/yr4rbiL/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "rjreortformepec/f/crt/on" + "'", str3.equals("rjreortformepec/f/crt/on"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("##########################################################################################################################################################################", "sAaLAJFORaaAIaJECIFICAJIONibiAsAaLAJFORaaAIaJECIFICAJION/AsAaLAJFORaaAIaJECIFICAJIONJaAsAaLAJFORaaAIaJECIFICAJIONvAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONJEAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONRAsAaLAJFORaaAIaJECIFICAJIONun/umaAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONEAsAaLAJFORaaAIaJECIFICAJIONnbucynman");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("jJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("u", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "u" + "'", str3.equals("u"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("noitaroproC51.0elcarO");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("MIXED ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/nemocne.neelcarone.neavajne//:n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "/LIBR4RY/J4V4/J4V4VIRTU4LM4CHINES/JDK1.7.0_80.JDK.../LIBR4RY/J4V4/J4V4VIRTU4LM4CHINES/JDK1.7.0_80.JDK.../LIBR4RY/J4V4/J4V4VIRTU4LM4CHINES/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIBR4RY/J4V4/J4V4VIRTU4LM4CHINES/JDK1.7.0_80.JDK.../LIBR4RY/J4V4/J4V4VIRTU4LM4CHINES/JDK1.7.0_80.JDK.../LIBR4RY/J4V4/J4V4VIRTU4LM4CHINES/" + "'", str2.equals("/LIBR4RY/J4V4/J4V4VIRTU4LM4CHINES/JDK1.7.0_80.JDK.../LIBR4RY/J4V4/J4V4VIRTU4LM4CHINES/JDK1.7.0_80.JDK.../LIBR4RY/J4V4/J4V4VIRTU4LM4CHINES/"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!", "jAVA hOTsPOT(tm) 64-bIT sERVER vm", (int) (short) 0);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny("folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", strArray5);
        java.lang.Class<?> wildcardClass8 = strArray5.getClass();
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API Specification");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("MIXED ");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray2, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 154 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("1.7", "SERSSOPHIEOCMENTSEFECTSJTMPRNRANOOPPL9912156022819TARGETCLASSESSERSSOPHIEOCMENTSEFECTSJFRAMEWORKLIBTESTGENERATIONGENERATIONRANOOPCRRENTJAR", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sun.awt.CGraphicsEnvironment", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ment" + "'", str2.equals("ment"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIO", " PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLH...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "jV pLTFORM api sPECIFICTION", (java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26 + "'", int2 == 26);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 10 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 10 + "'", byte12 == (byte) 10);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "Java Plhi!aaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 100);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("\n", strArray5, strArray9);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java HotSpot(TM) 64-Bit Server VM", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10.14.3", strArray9, strArray14);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, ' ');
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("CGraphicsEnv", strArray14, strArray20);
        int int22 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("JAVA PLATFORM API SPECIFICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION", strArray20);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "\n" + "'", str10.equals("\n"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10.14.3" + "'", str15.equals("10.14.3"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str17.equals("Java HotSpot(TM) 64-Bit Server VM"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "CGraphicsEnv" + "'", str21.equals("CGraphicsEnv"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                 Java Virtual Machine Specification                                ", 178, "JAVAJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   PLATFORMJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   APIJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                   SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVAJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                           Java Virtual Machine Specification                                " + "'", str3.equals("JAVAJAVA HOTSPOT(TM) 64-BIT SERVER VM                                                                           Java Virtual Machine Specification                                "));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("macosx.cprinterjo");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("jAVA OTsPOT(tm) 64-bIT sERVER vm", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("SUN.LWAWT.MACOSX.CPRINTERJOe", "noit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("          ", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        char[] charArray5 = new char[] { '4', ' ' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Plhi!USavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaUSJ", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("MACOSX.CPRINTERJO");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("jJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("eeAVA PLATFORM API SPECIFICATIONeeeeAVAjAVA pLHI!aaaaaaaaeeAVA PLATFORM API SPECIFICATIONeeeeeAVA PLATFORM API SPECIFICATIONeeeeAVAjAVA pLHI!aaaaaaaaeeAVA PLATFORM API SPECIFICATIONeee", "AAAAAAAAAAAAAAAAAAAA24.80-B11jAAAAAAAAAAAAAAAAAAAAA", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("44444444444442.80-b11J4444444444444", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444..." + "'", str2.equals("444..."));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("evneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP ", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        long[] longArray5 = new long[] { 0L, (byte) 10, (short) 100, 100L, (short) -1 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Javaj:ecif");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Javaj:ecif" + "'", str1.equals("Javaj:ecif"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("UTF-", "noit                 ", 37);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("C elcarO######################################", ":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 98, (long) (byte) 100, 90L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 90L + "'", long3 == 90L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU..." + "'", str1.equals("sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU...sU..."));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment" + "'", str2.equals("(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "   UTF-   ", 32, 7);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                                                                                                                                    DEXIM", "ttp://j.orce.com/", "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                    DEXIM" + "'", str3.equals("                                                                                                                                                    DEXIM"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/NEMOCNE.NEELCARONE.NEAVAJNE//:N", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] { '4', ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11Java Plhi!aaaaaaaaaaaaaaaaaaaaaaaaa", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("sophi", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("24.80-b11J", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11J" + "'", str2.equals("24.80-b11J"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporation                                                                                  ", "                                ", 257);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("sAaLAJFORaaAIaJECIFICAJIONibiAsAaLAJFORaaAIaJECIFICAJION/AsAaLAJFORaaAIaJECIFICAJIONJaAsAaLAJFORaaAIaJECIFICAJIONvAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONJEAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONRAsAaLAJFORaaAIaJECIFICAJIONun/umaAsAaLAJFORaaAIaJECIFICAJIONaAsAaLAJFORaaAIaJECIFICAJIONEAsAaLAJFORaaAIaJECIFICAJIONnbucynman", "Plhi!USavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaUSJ", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "Java Plhi!", (int) '4');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("saalajforaaaiajecificajionibiasaalajforaaaiajecificajion/asaalajforaaaiajecificajionjaasaalajforaaaiajecificajionvasaalajforaaaiajecificajionaasaalajforaaaiajecificajionjeasaalajforaaaiajecificajionaasaalajforaaaiajecificajionrasaalajforaaaiajecificajionun/umaasaalajforaaaiajecificajionaasaalajforaaaiajecificajioneasaalajforaaaiajecificajionnbucynman", "J");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("          ECIFICATIONSEAVA PLATFORM API SPE                    ECIFICATIONSEAVA PLATFORM API SPEC", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "          ECIFICATIONSEAVA PLATFORM API SPE                    ECIFICATIONSEAVA PLATFORM API SPEC" + "'", str9.equals("          ECIFICATIONSEAVA PLATFORM API SPE                    ECIFICATIONSEAVA PLATFORM API SPEC"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", " Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ" + "'", str2.equals(" Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ#v# Plhi!USJ"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] { '4', ' ' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "en", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Jttp://j.orvttp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        char[] charArray7 = new char[] { '4', ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "(", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "V", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/users/sophie", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIO", "TTP://J.ORCE.COM/", 94);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFOTTP://J.ORCE.COM/AHOTSPOT(TM)64-BITSERVERVMSPECIFICATIO" + "'", str3.equals("JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFOTTP://J.ORCE.COM/AHOTSPOT(TM)64-BITSERVERVMSPECIFICATIO"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("vneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP nevneJSU!ihlP", "##########################################################################################################################################################################", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("7zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str1.equals("7zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Java Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API Specification", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API Specification" + "'", str2.equals("Java Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API Specification"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Jv(TM) SE Runtime Environment", "/users/sophie/documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/users/sop...", 184);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(97.0d, (double) 257, 12.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.0d + "'", double3 == 12.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 26, (double) (-1), (double) 24);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 26.0d + "'", double3 == 26.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("NoitaroproC51.0elcarO", "                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification", "                       Java Virtual Machine Specification                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "N      C51.0     O" + "'", str3.equals("N      C51.0     O"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("MIXED", "r");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Plhi!USavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaUSJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Plhi!USavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaUSJ" + "'", str1.equals("Plhi!USavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaPlhi!USJavaUSJ"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!", (int) (short) 1, 127);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Java(TM) SE Runtime EnvironmentJavJ", "aaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("MACOSX.CPRINTERJO", (long) 17);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 17L + "'", long2 == 17L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/NEMOCNE.NEELCARONE.NEAVAJNE//:N", "virtual ma", "Folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/NEMOCNE.NEELCARONE.NEAVAJNE//:N" + "'", str3.equals("/NEMOCNE.NEELCARONE.NEAVAJNE//:N"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/AsAaLAJFORaaAIaJECIFICAJIONibiAsAaLAJFORaaAIaJECIFICAJION/AsAaLAJFORaaAIaJE/AsAaLAJFORaaAIaJECIFICAJIONibiAsAaLAJFORaaAIaJECIFICAJION/AsAaLAJFORaaAIaJEC", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) '#', "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                   " + "'", str3.equals("                                   "));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("ojretnirpc.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Java(TM) SE Runtime EnvironmentJavJ", 3, 105);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a(TM) SE Runtime EnvironmentJavJ" + "'", str3.equals("a(TM) SE Runtime EnvironmentJavJ"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "j#v# virtu#l m#chine specific#tion##################################################################", "ac OS ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        char[] charArray6 = new char[] { '4', ' ' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "noitaroproC elcarO", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("terJob", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny(" HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!", charArray6);
        java.lang.Class<?> wildcardClass11 = charArray6.getClass();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("DEXIMn.n lnwfarm .ecificnwian", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DEXIMn.n lnwfarm .ecificnwian" + "'", str2.equals("DEXIMn.n lnwfarm .ecificnwian"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java HotSpot(TM) 64-Bit Server VM", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 10);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Hi!", strArray7, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.concatWith(" Vu Mh ", (java.lang.Object[]) strArray10);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Hi!" + "'", str11.equals("Hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION", (java.lang.CharSequence) "JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("avaAVA PLATFORM API SPECIFICATIONlatformAVA PLATFORM API SPECIFICATIONpecification", "Folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "httpen://enjavaen.enoracleen.encomen/", (java.lang.CharSequence) "...VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Se...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "E");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/9418220");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("h://j../", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification", "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server V", 94);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Java(TM) SE Runtime EnvironmentJavJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}

